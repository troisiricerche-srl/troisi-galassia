<?php
/*
Template Name: Sondaggio AI nella PA — III Forum 2026
*/
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sondaggio AI nella PA — III Forum dei Pubblici Ufficiali</title>
<meta name="description" content="Mini-sondaggio sull'utilizzo dell'Intelligenza Artificiale nella Pubblica Amministrazione — III Forum dei Pubblici Ufficiali, Bari 17 aprile 2026">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700&family=Lora:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
<style>
  :root {
    --blu-italia: #0066CC;
    --blu-scuro: #004080;
    --blu-chiaro: #EBF5FF;
    --grigio-100: #F7F9FC;
    --grigio-200: #E6E9F2;
    --grigio-300: #CCD4E0;
    --grigio-500: #6B7B8D;
    --grigio-700: #3A4A5C;
    --grigio-900: #1A2332;
    --verde-ok: #008055;
    --rosso-err: #CC334D;
    --arancio: #E07020;
    --ombra-1: 0 2px 8px rgba(0,40,80,.08);
    --ombra-2: 0 4px 20px rgba(0,40,80,.12);
    --raggio: 8px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  html { font-size: 16px; scroll-behavior: smooth; }

  body {
    font-family: 'Titillium Web', -apple-system, sans-serif;
    background: var(--grigio-100);
    color: var(--grigio-900);
    line-height: 1.6;
    min-height: 100vh;
  }

  /* HEADER */
  .header {
    background: linear-gradient(135deg, var(--blu-italia) 0%, var(--blu-scuro) 100%);
    color: #fff;
    padding: 2rem 1.5rem 1.8rem;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .header::after {
    content: '';
    position: absolute; bottom: 0; left: 0; right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--arancio), #F5A623, var(--arancio));
  }
  .header-badge {
    display: inline-block;
    background: rgba(255,255,255,.15);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 20px;
    padding: .3rem 1rem;
    font-size: .78rem;
    font-weight: 600;
    letter-spacing: .04em;
    text-transform: uppercase;
    margin-bottom: .8rem;
  }
  .header h1 {
    font-family: 'Lora', Georgia, serif;
    font-size: clamp(1.4rem, 4vw, 1.9rem);
    font-weight: 600;
    line-height: 1.3;
    margin-bottom: .5rem;
  }
  .header p {
    font-size: .92rem;
    opacity: .88;
    max-width: 520px;
    margin: 0 auto;
    font-weight: 300;
  }

  /* MAIN */
  .main {
    max-width: 640px;
    margin: 0 auto;
    padding: 1.5rem 1rem 3rem;
  }

  /* INFO BAR */
  .info-bar {
    display: flex;
    align-items: center;
    gap: .6rem;
    background: var(--blu-chiaro);
    border-left: 3px solid var(--blu-italia);
    border-radius: 0 var(--raggio) var(--raggio) 0;
    padding: .8rem 1rem;
    margin-bottom: 1.8rem;
    font-size: .85rem;
    color: var(--blu-scuro);
  }
  .info-bar svg { flex-shrink: 0; }

  /* PROGRESS */
  .progress-wrap {
    margin-bottom: 1.5rem;
  }
  .progress-label {
    display: flex;
    justify-content: space-between;
    font-size: .8rem;
    font-weight: 600;
    color: var(--grigio-500);
    margin-bottom: .4rem;
  }
  .progress-track {
    height: 6px;
    background: var(--grigio-200);
    border-radius: 3px;
    overflow: hidden;
  }
  .progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--blu-italia), #3399FF);
    border-radius: 3px;
    transition: width .4s ease;
    width: 0%;
  }

  /* SECTIONS */
  .section {
    background: #fff;
    border-radius: var(--raggio);
    box-shadow: var(--ombra-1);
    padding: 1.5rem;
    margin-bottom: 1.2rem;
    border: 1px solid var(--grigio-200);
    display: none;
    animation: fadeUp .35s ease;
  }
  .section.active { display: block; }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(12px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .section-tag {
    display: inline-block;
    font-size: .68rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .06em;
    padding: .2rem .6rem;
    border-radius: 4px;
    margin-bottom: .8rem;
  }
  .section-tag.profilo { background: #EDE7F6; color: #5E35B1; }
  .section-tag.ai { background: #E0F2F1; color: #00796B; }

  .question-text {
    font-size: 1.02rem;
    font-weight: 600;
    color: var(--grigio-900);
    margin-bottom: 1rem;
    line-height: 1.45;
  }
  .question-text .q-num {
    color: var(--blu-italia);
    font-weight: 700;
    margin-right: .25rem;
  }

  /* RADIO / CHECKBOX OPTIONS */
  .options-list {
    display: flex;
    flex-direction: column;
    gap: .5rem;
  }
  .option-item {
    position: relative;
  }
  .option-item input {
    position: absolute;
    opacity: 0;
    width: 0; height: 0;
  }
  .option-item label {
    display: flex;
    align-items: flex-start;
    gap: .7rem;
    padding: .7rem .9rem;
    border: 1.5px solid var(--grigio-200);
    border-radius: 6px;
    cursor: pointer;
    transition: all .2s;
    font-size: .92rem;
    line-height: 1.4;
  }
  .option-item label:hover {
    border-color: var(--blu-italia);
    background: var(--blu-chiaro);
  }
  .option-item input:checked + label {
    border-color: var(--blu-italia);
    background: var(--blu-chiaro);
    font-weight: 600;
  }
  .option-dot {
    flex-shrink: 0;
    width: 20px; height: 20px;
    border: 2px solid var(--grigio-300);
    border-radius: 50%;
    margin-top: 1px;
    position: relative;
    transition: all .2s;
  }
  input:checked + label .option-dot {
    border-color: var(--blu-italia);
    background: var(--blu-italia);
  }
  input:checked + label .option-dot::after {
    content: '';
    position: absolute;
    top: 4px; left: 4px;
    width: 8px; height: 8px;
    background: #fff;
    border-radius: 50%;
  }

  /* TEXT INPUT */
  .text-input {
    width: 100%;
    padding: .65rem .9rem;
    border: 1.5px solid var(--grigio-200);
    border-radius: 6px;
    font-family: inherit;
    font-size: .92rem;
    color: var(--grigio-900);
    transition: border-color .2s;
    background: #fff;
  }
  .text-input:focus {
    outline: none;
    border-color: var(--blu-italia);
    box-shadow: 0 0 0 3px rgba(0,102,204,.12);
  }
  .text-input::placeholder { color: var(--grigio-300); }

  /* SELECT */
  .select-wrap {
    position: relative;
  }
  .select-wrap select {
    width: 100%;
    padding: .65rem .9rem;
    border: 1.5px solid var(--grigio-200);
    border-radius: 6px;
    font-family: inherit;
    font-size: .92rem;
    color: var(--grigio-900);
    background: #fff;
    appearance: none;
    cursor: pointer;
  }
  .select-wrap select:focus {
    outline: none;
    border-color: var(--blu-italia);
    box-shadow: 0 0 0 3px rgba(0,102,204,.12);
  }
  .select-wrap::after {
    content: '▾';
    position: absolute;
    right: .9rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--grigio-500);
    pointer-events: none;
  }

  /* SCALA LIKERT */
  .likert-scale {
    display: flex;
    gap: .4rem;
    flex-wrap: wrap;
    margin-top: .3rem;
  }
  .likert-scale .option-item { flex: 1; min-width: 52px; }
  .likert-scale label {
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: .6rem .3rem;
    font-size: .82rem;
  }
  .likert-scale .option-dot { margin: 0 0 .3rem 0; }
  .likert-labels {
    display: flex;
    justify-content: space-between;
    font-size: .72rem;
    color: var(--grigio-500);
    margin-top: .3rem;
    padding: 0 .2rem;
  }

  /* TEXTAREA */
  .text-area {
    width: 100%;
    min-height: 80px;
    padding: .65rem .9rem;
    border: 1.5px solid var(--grigio-200);
    border-radius: 6px;
    font-family: inherit;
    font-size: .92rem;
    color: var(--grigio-900);
    resize: vertical;
    transition: border-color .2s;
  }
  .text-area:focus {
    outline: none;
    border-color: var(--blu-italia);
    box-shadow: 0 0 0 3px rgba(0,102,204,.12);
  }

  /* BUTTONS */
  .nav-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 1.5rem;
    gap: .8rem;
  }
  .btn {
    font-family: inherit;
    font-size: .9rem;
    font-weight: 600;
    padding: .7rem 1.5rem;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    transition: all .2s;
    display: inline-flex;
    align-items: center;
    gap: .4rem;
  }
  .btn-primary {
    background: var(--blu-italia);
    color: #fff;
  }
  .btn-primary:hover { background: var(--blu-scuro); }
  .btn-secondary {
    background: transparent;
    color: var(--grigio-500);
    border: 1.5px solid var(--grigio-200);
  }
  .btn-secondary:hover { border-color: var(--grigio-500); color: var(--grigio-700); }
  .btn-submit {
    background: var(--verde-ok);
    color: #fff;
    width: 100%;
    justify-content: center;
    padding: .85rem;
    font-size: 1rem;
  }
  .btn-submit:hover { background: #006644; }
  .btn:disabled { opacity: .45; cursor: not-allowed; }

  /* VALIDATION */
  .error-msg {
    color: var(--rosso-err);
    font-size: .8rem;
    margin-top: .4rem;
    display: none;
  }
  .has-error .error-msg { display: block; }
  .has-error .text-input,
  .has-error select,
  .has-error .text-area { border-color: var(--rosso-err); }

  /* THANK YOU */
  .thank-you {
    display: none;
    text-align: center;
    padding: 3rem 1.5rem;
    background: #fff;
    border-radius: var(--raggio);
    box-shadow: var(--ombra-2);
    animation: fadeUp .5s ease;
  }
  .thank-you.active { display: block; }
  .thank-you .check-icon {
    width: 64px; height: 64px;
    background: #E8F5E9;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.2rem;
  }
  .thank-you h2 {
    font-family: 'Lora', Georgia, serif;
    font-size: 1.5rem;
    color: var(--verde-ok);
    margin-bottom: .6rem;
  }
  .thank-you p {
    color: var(--grigio-500);
    font-size: .92rem;
    max-width: 380px;
    margin: 0 auto;
  }

  /* LEAD CAPTURE CARD */
  .lead-card {
    text-align: left;
    background: var(--grigio-100);
    border: 1.5px solid var(--grigio-200);
    border-radius: var(--raggio);
    padding: 1.5rem;
    margin-top: 1.5rem;
    position: relative;
  }
  .lead-card::before {
    content: '';
    position: absolute;
    top: 0; left: 1.5rem; right: 1.5rem;
    height: 3px;
    background: linear-gradient(90deg, var(--blu-italia), #3399FF);
    border-radius: 0 0 3px 3px;
  }
  .lead-card-icon {
    width: 40px; height: 40px;
    background: var(--blu-chiaro);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: .8rem;
  }
  .lead-card-title {
    font-family: 'Lora', Georgia, serif;
    font-size: 1.15rem;
    color: var(--grigio-900);
    margin-bottom: .4rem;
  }
  .lead-card-desc {
    font-size: .85rem;
    color: var(--grigio-500);
    line-height: 1.5;
    margin-bottom: 1.2rem;
    text-align: left;
    max-width: 100%;
  }
  .lead-fields {
    display: flex;
    flex-direction: column;
    gap: .8rem;
  }
  .lead-row { display: flex; gap: .8rem; }
  .lead-row-2col > .lead-field { flex: 1; }
  .lead-field { flex: 1; }
  .lead-field label {
    display: block;
    font-size: .8rem;
    font-weight: 600;
    color: var(--grigio-700);
    margin-bottom: .3rem;
  }
  .optional-tag {
    font-weight: 400;
    color: var(--grigio-300);
    font-style: italic;
  }
  .lead-consent {
    margin-top: .4rem;
  }
  .consent-label {
    display: flex;
    align-items: flex-start;
    gap: .6rem;
    font-size: .78rem;
    color: var(--grigio-500);
    line-height: 1.5;
    cursor: pointer;
  }
  .consent-label input {
    position: absolute;
    opacity: 0;
    width: 0; height: 0;
  }
  .consent-box {
    flex-shrink: 0;
    width: 20px; height: 20px;
    border: 2px solid var(--grigio-300);
    border-radius: 4px;
    margin-top: 1px;
    position: relative;
    transition: all .2s;
  }
  .consent-label input:checked + .consent-box {
    background: var(--blu-italia);
    border-color: var(--blu-italia);
  }
  .consent-label input:checked + .consent-box::after {
    content: '✓';
    position: absolute;
    top: -1px; left: 2px;
    color: #fff;
    font-size: .75rem;
    font-weight: 700;
  }
  .consent-label a { color: var(--blu-italia); }
  .lead-buttons {
    margin-top: 1.2rem;
    display: flex;
    flex-direction: column;
    gap: .5rem;
  }
  .lead-btn-send {
    width: 100%;
    justify-content: center;
  }
  .btn-ghost {
    font-family: inherit;
    font-size: .82rem;
    font-weight: 400;
    color: var(--grigio-500);
    background: transparent;
    border: none;
    cursor: pointer;
    padding: .5rem;
    text-decoration: underline;
    text-underline-offset: 2px;
    transition: color .2s;
  }
  .btn-ghost:hover { color: var(--grigio-700); }

  @media (max-width: 480px) {
    .lead-row-2col { flex-direction: column; }
    .lead-card { padding: 1.2rem 1rem; }
  }

  /* FOOTER */
  .footer {
    text-align: center;
    padding: 1.5rem 1rem;
    font-size: .75rem;
    color: var(--grigio-500);
  }
  .footer a { color: var(--blu-italia); text-decoration: none; }
  .footer a:hover { text-decoration: underline; }

  /* PRIVACY TOGGLE */
  .privacy-note {
    font-size: .78rem;
    color: var(--grigio-500);
    line-height: 1.5;
    margin-top: 1rem;
    padding: .8rem;
    background: var(--grigio-100);
    border-radius: 6px;
  }
  .privacy-note a { color: var(--blu-italia); }

  /* RESPONSIVE */
  @media (max-width: 480px) {
    .header { padding: 1.5rem 1rem 1.3rem; }
    .section { padding: 1.2rem 1rem; }
    .likert-scale { gap: .25rem; }
    .likert-scale label { padding: .5rem .2rem; font-size: .75rem; }
    .nav-buttons { flex-direction: column; }
    .btn { width: 100%; justify-content: center; }
  }
</style>
</head>
<body>

<div class="header">
  <div class="header-badge">III Forum dei Pubblici Ufficiali — Bari, 17 aprile 2026</div>
  <h1>L'Intelligenza Artificiale nella PA</h1>
  <p>Un mini-sondaggio per capire a che punto siamo. Tempo stimato: 3 minuti.</p>
</div>

<div class="main">

  <div class="info-bar">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
    <span>Le risposte sono anonime e aggregate. I dati saranno utilizzati esclusivamente per finalità di ricerca.</span>
  </div>

  <div class="progress-wrap">
    <div class="progress-label">
      <span id="progressSection">Profilazione</span>
      <span id="progressCount">0 / 11</span>
    </div>
    <div class="progress-track">
      <div class="progress-fill" id="progressFill"></div>
    </div>
  </div>

  <!-- ===================== SEZIONE 1: PROFILAZIONE ===================== -->
  <div class="section active" id="s1">
    <span class="section-tag profilo">Profilazione</span>

    <div class="question-text"><span class="q-num">P1.</span> Qual è il tuo ruolo nella Pubblica Amministrazione?</div>
    <div class="select-wrap">
      <select id="p1" required>
        <option value="">— Seleziona —</option>
        <option value="dirigente">Dirigente</option>
        <option value="funzionario">Funzionario / Posizione Organizzativa</option>
        <option value="impiegato">Impiegato / Istruttore</option>
        <option value="segretario">Segretario Comunale / Direttore Generale</option>
        <option value="amministratore">Amministratore / Assessore / Sindaco</option>
        <option value="consulente">Consulente / Collaboratore esterno</option>
        <option value="altro_ruolo">Altro</option>
      </select>
    </div>
    <div class="error-msg">Seleziona un'opzione per proseguire.</div>

    <div style="margin-top:1.2rem">
      <div class="question-text"><span class="q-num">P2.</span> In quale tipologia di ente lavori?</div>
      <div class="select-wrap">
        <select id="p2" required>
          <option value="">— Seleziona —</option>
          <option value="comune_piccolo">Comune (fino a 15.000 abitanti)</option>
          <option value="comune_medio">Comune (15.001 – 100.000 abitanti)</option>
          <option value="comune_grande">Comune (oltre 100.000 abitanti)</option>
          <option value="provincia_cm">Provincia / Città Metropolitana</option>
          <option value="regione">Regione</option>
          <option value="ministero">Ministero / Agenzia centrale</option>
          <option value="azienda_sanitaria">Azienda Sanitaria / Ospedaliera</option>
          <option value="universita">Università / Ente di ricerca</option>
          <option value="societa_partecipata">Società partecipata / in house</option>
          <option value="altro_ente">Altro ente pubblico</option>
        </select>
      </div>
      <div class="error-msg">Seleziona un'opzione per proseguire.</div>
    </div>

    <div style="margin-top:1.2rem">
      <div class="question-text"><span class="q-num">P3.</span> In quale area geografica si trova il tuo ente?</div>
      <div class="select-wrap">
        <select id="p3" required>
          <option value="">— Seleziona —</option>
          <option value="nord_ovest">Nord-Ovest</option>
          <option value="nord_est">Nord-Est</option>
          <option value="centro">Centro</option>
          <option value="sud">Sud</option>
          <option value="isole">Isole</option>
        </select>
      </div>
      <div class="error-msg">Seleziona un'opzione per proseguire.</div>
    </div>

    <div class="nav-buttons">
      <span></span>
      <button class="btn btn-primary" onclick="goTo(2)">Avanti →</button>
    </div>
  </div>

  <!-- ===================== SEZIONE 2: DOMANDE AI 1-4 ===================== -->
  <div class="section" id="s2">
    <span class="section-tag ai">Intelligenza Artificiale</span>

    <div class="question-text"><span class="q-num">1.</span> Hai mai utilizzato strumenti di Intelligenza Artificiale (es. ChatGPT, Copilot, Claude, Gemini) nel tuo lavoro in PA?</div>
    <div class="options-list" data-name="q1">
      <div class="option-item">
        <input type="radio" name="q1" id="q1a" value="si_regolarmente">
        <label for="q1a"><span class="option-dot"></span>Sì, li uso regolarmente</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q1" id="q1b" value="si_ogni_tanto">
        <label for="q1b"><span class="option-dot"></span>Sì, li ho provati qualche volta</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q1" id="q1c" value="no_conosco">
        <label for="q1c"><span class="option-dot"></span>No, ma so cosa sono</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q1" id="q1d" value="no_non_conosco">
        <label for="q1d"><span class="option-dot"></span>No, e non li conosco bene</label>
      </div>
    </div>
    <div class="error-msg">Seleziona una risposta.</div>

    <div style="margin-top:1.5rem">
      <div class="question-text"><span class="q-num">2.</span> Per quale attività l'AI potrebbe esserti più utile nel lavoro quotidiano?</div>
      <div class="options-list" data-name="q2">
        <div class="option-item">
          <input type="radio" name="q2" id="q2a" value="redazione_atti">
          <label for="q2a"><span class="option-dot"></span>Redazione di atti, determine, delibere</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q2" id="q2b" value="analisi_dati">
          <label for="q2b"><span class="option-dot"></span>Analisi dati e reportistica</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q2" id="q2c" value="comunicazione">
          <label for="q2c"><span class="option-dot"></span>Comunicazione con i cittadini (chatbot, FAQ, risposte)</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q2" id="q2d" value="semplificazione">
          <label for="q2d"><span class="option-dot"></span>Semplificazione di procedure interne</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q2" id="q2e" value="formazione">
          <label for="q2e"><span class="option-dot"></span>Formazione e aggiornamento normativo</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q2" id="q2f" value="altro_uso">
          <label for="q2f"><span class="option-dot"></span>Altro</label>
        </div>
      </div>
      <div class="error-msg">Seleziona una risposta.</div>
    </div>

    <div style="margin-top:1.5rem">
      <div class="question-text"><span class="q-num">3.</span> Il tuo ente ha già adottato linee guida o policy sull'uso dell'AI?</div>
      <div class="options-list" data-name="q3">
        <div class="option-item">
          <input type="radio" name="q3" id="q3a" value="si_policy">
          <label for="q3a"><span class="option-dot"></span>Sì, abbiamo una policy ufficiale</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q3" id="q3b" value="in_corso">
          <label for="q3b"><span class="option-dot"></span>È in fase di definizione</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q3" id="q3c" value="no_policy">
          <label for="q3c"><span class="option-dot"></span>No, non ancora</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q3" id="q3d" value="non_so_policy">
          <label for="q3d"><span class="option-dot"></span>Non lo so</label>
        </div>
      </div>
      <div class="error-msg">Seleziona una risposta.</div>
    </div>

    <div style="margin-top:1.5rem">
      <div class="question-text"><span class="q-num">4.</span> Quanto ti senti preparato/a ad utilizzare strumenti di AI nel tuo lavoro?</div>
      <div class="likert-scale" data-name="q4">
        <div class="option-item">
          <input type="radio" name="q4" id="q4_1" value="1">
          <label for="q4_1"><span class="option-dot"></span>1</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q4" id="q4_2" value="2">
          <label for="q4_2"><span class="option-dot"></span>2</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q4" id="q4_3" value="3">
          <label for="q4_3"><span class="option-dot"></span>3</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q4" id="q4_4" value="4">
          <label for="q4_4"><span class="option-dot"></span>4</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q4" id="q4_5" value="5">
          <label for="q4_5"><span class="option-dot"></span>5</label>
        </div>
      </div>
      <div class="likert-labels"><span>Per niente</span><span>Molto preparato</span></div>
      <div class="error-msg">Indica il tuo livello di preparazione.</div>
    </div>

    <div class="nav-buttons">
      <button class="btn btn-secondary" onclick="goTo(1)">← Indietro</button>
      <button class="btn btn-primary" onclick="goTo(3)">Avanti →</button>
    </div>
  </div>

  <!-- ===================== SEZIONE 3: DOMANDE AI 5-8 ===================== -->
  <div class="section" id="s3">
    <span class="section-tag ai">Intelligenza Artificiale</span>

    <div class="question-text"><span class="q-num">5.</span> Qual è la principale barriera all'adozione dell'AI nel tuo ente?</div>
    <div class="options-list" data-name="q5">
      <div class="option-item">
        <input type="radio" name="q5" id="q5a" value="competenze">
        <label for="q5a"><span class="option-dot"></span>Mancanza di competenze digitali</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q5" id="q5b" value="budget">
        <label for="q5b"><span class="option-dot"></span>Risorse economiche insufficienti</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q5" id="q5c" value="normativa">
        <label for="q5c"><span class="option-dot"></span>Incertezza normativa (AI Act, privacy)</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q5" id="q5d" value="resistenza">
        <label for="q5d"><span class="option-dot"></span>Resistenza culturale al cambiamento</label>
      </div>
      <div class="option-item">
        <input type="radio" name="q5" id="q5e" value="leadership">
        <label for="q5e"><span class="option-dot"></span>Mancanza di volontà politica / dirigenziale</label>
      </div>
    </div>
    <div class="error-msg">Seleziona una risposta.</div>

    <div style="margin-top:1.5rem">
      <div class="question-text"><span class="q-num">6.</span> Pensi che l'AI possa migliorare la qualità dei servizi al cittadino?</div>
      <div class="likert-scale" data-name="q6">
        <div class="option-item">
          <input type="radio" name="q6" id="q6_1" value="1">
          <label for="q6_1"><span class="option-dot"></span>1</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q6" id="q6_2" value="2">
          <label for="q6_2"><span class="option-dot"></span>2</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q6" id="q6_3" value="3">
          <label for="q6_3"><span class="option-dot"></span>3</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q6" id="q6_4" value="4">
          <label for="q6_4"><span class="option-dot"></span>4</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q6" id="q6_5" value="5">
          <label for="q6_5"><span class="option-dot"></span>5</label>
        </div>
      </div>
      <div class="likert-labels"><span>Per niente</span><span>Moltissimo</span></div>
      <div class="error-msg">Indica la tua valutazione.</div>
    </div>

    <div style="margin-top:1.5rem">
      <div class="question-text"><span class="q-num">7.</span> Quale aspetto dell'AI ti preoccupa di più?</div>
      <div class="options-list" data-name="q7">
        <div class="option-item">
          <input type="radio" name="q7" id="q7a" value="privacy_dati">
          <label for="q7a"><span class="option-dot"></span>Protezione dei dati e privacy</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q7" id="q7b" value="errori_bias">
          <label for="q7b"><span class="option-dot"></span>Errori e bias nelle risposte dell'AI</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q7" id="q7c" value="posti_lavoro">
          <label for="q7c"><span class="option-dot"></span>Impatto sui posti di lavoro</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q7" id="q7d" value="dipendenza">
          <label for="q7d"><span class="option-dot"></span>Dipendenza dalla tecnologia</label>
        </div>
        <div class="option-item">
          <input type="radio" name="q7" id="q7e" value="nessuna_preoccupazione">
          <label for="q7e"><span class="option-dot"></span>Nessuna preoccupazione particolare</label>
        </div>
      </div>
      <div class="error-msg">Seleziona una risposta.</div>
    </div>

    <div style="margin-top:1.5rem">
      <div class="question-text"><span class="q-num">8.</span> Se potessi chiedere una cosa sola all'AI per il tuo lavoro, quale sarebbe?</div>
      <textarea class="text-area" id="q8" placeholder="Scrivi liberamente la tua risposta (facoltativa)..." maxlength="500"></textarea>
    </div>

    <div class="privacy-note">
      🔒 Le risposte al sondaggio sono aggregate e anonime. Al termine, potrai <em>facoltativamente</em> lasciare i tuoi dati di contatto per ricevere i risultati.
      Trattamento ai sensi del GDPR (Reg. UE 2016/679). Titolare: <strong>Troisi Ricerche S.r.l.</strong> — 
      <a href="mailto:info@troisiricerche.net">info@troisiricerche.net</a>
    </div>

    <div class="nav-buttons">
      <button class="btn btn-secondary" onclick="goTo(2)">← Indietro</button>
      <button class="btn btn-submit" onclick="submitSurvey()">✓ Invia le risposte</button>
    </div>
  </div>

  <!-- ===================== THANK YOU + LEAD CAPTURE ===================== -->
  <div class="thank-you" id="thankYou">
    <div class="check-icon">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#008055" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
    </div>
    <h2>Grazie!</h2>
    <p>Le tue risposte sono state registrate.</p>

    <!-- LEAD CAPTURE CARD -->
    <div class="lead-card" id="leadCard">
      <div class="lead-card-icon">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0066CC" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
      </div>
      <h3 class="lead-card-title">Vuoi ricevere i risultati?</h3>
      <p class="lead-card-desc">Lascia i tuoi dati per ricevere il report con i risultati aggregati e restare aggiornato sulle nostre iniziative dedicate alla PA.</p>

      <div class="lead-fields">
        <div class="lead-row">
          <div class="lead-field">
            <label for="lead_nome">Nome e Cognome</label>
            <input type="text" class="text-input" id="lead_nome" placeholder="es. Mario Rossi">
          </div>
        </div>
        <div class="lead-row">
          <div class="lead-field">
            <label for="lead_ente">Ente di appartenenza</label>
            <input type="text" class="text-input" id="lead_ente" placeholder="es. Comune di Bari">
          </div>
        </div>
        <div class="lead-row lead-row-2col">
          <div class="lead-field">
            <label for="lead_email">Email</label>
            <input type="email" class="text-input" id="lead_email" placeholder="nome@ente.it">
          </div>
          <div class="lead-field">
            <label for="lead_tel">Telefono <span class="optional-tag">facoltativo</span></label>
            <input type="tel" class="text-input" id="lead_tel" placeholder="+39 ...">
          </div>
        </div>
        <div class="lead-row">
          <div class="lead-field">
            <label for="lead_ruolo_ext">Ruolo / Funzione</label>
            <input type="text" class="text-input" id="lead_ruolo_ext" placeholder="es. Responsabile Transizione Digitale">
          </div>
        </div>

        <div class="lead-consent">
          <label class="consent-label">
            <input type="checkbox" id="lead_consenso">
            <span class="consent-box"></span>
            <span>Acconsento al trattamento dei dati personali ai sensi del GDPR (Reg. UE 2016/679) per ricevere i risultati del sondaggio e comunicazioni informative da Troisi Ricerche S.r.l. Potrò revocare il consenso in qualsiasi momento scrivendo a <a href="mailto:info@troisiricerche.net">info@troisiricerche.net</a>.</span>
          </label>
        </div>
      </div>

      <div class="lead-buttons">
        <button class="btn btn-primary lead-btn-send" id="btnSendLead" onclick="submitLead()" disabled>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          Invia i miei dati
        </button>
        <button class="btn btn-ghost" onclick="skipLead()">No grazie, preferisco restare anonimo/a</button>
      </div>
    </div>
  </div>

  <!-- ===================== FINAL CONFIRMATION ===================== -->
  <div class="thank-you" id="finalConfirm">
    <div class="check-icon">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#008055" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
    </div>
    <h2 id="finalTitle">Tutto registrato!</h2>
    <p id="finalMsg">Ti invieremo i risultati del sondaggio al termine del Forum.</p>
    <p style="margin-top:1rem; font-size:.82rem; color:#6B7B8D;">
      A cura di <strong><a href="https://troisiricerche.net" target="_blank" style="color:var(--blu-italia);">Troisi Ricerche</a></strong> per il III Forum dei Pubblici Ufficiali.
    </p>
  </div>

</div>

<div class="footer">
  © 2026 <a href="https://troisiricerche.net" target="_blank">Troisi Ricerche S.r.l.</a> — P.IVA 07216100722<br>
  <a href="https://customerpa.it" target="_blank">customerpa.it</a>
</div>

<script>
  const TOTAL_QUESTIONS = 11; // 3 profiling + 8 AI
  let currentSection = 1;

  function updateProgress() {
    let answered = 0;

    // Profiling
    if (document.getElementById('p1').value) answered++;
    if (document.getElementById('p2').value) answered++;
    if (document.getElementById('p3').value) answered++;

    // Radio questions
    ['q1','q2','q3','q4','q5','q6','q7'].forEach(name => {
      if (document.querySelector(`input[name="${name}"]:checked`)) answered++;
    });

    // Q8 is optional, count if filled
    if (document.getElementById('q8').value.trim()) answered++;

    const pct = Math.round((answered / TOTAL_QUESTIONS) * 100);
    document.getElementById('progressFill').style.width = pct + '%';
    document.getElementById('progressCount').textContent = answered + ' / ' + TOTAL_QUESTIONS;

    const labels = { 1: 'Profilazione', 2: 'Domande AI (1–4)', 3: 'Domande AI (5–8)' };
    document.getElementById('progressSection').textContent = labels[currentSection] || '';
  }

  function validateSection(num) {
    let valid = true;

    if (num === 1) {
      ['p1','p2','p3'].forEach(id => {
        const el = document.getElementById(id);
        const wrap = el.closest('.select-wrap') ? el.closest('div[style]') || el.parentElement.parentElement : el.parentElement;
        // Find the error-msg sibling
        const errEl = el.closest('.select-wrap').nextElementSibling;
        if (!el.value) {
          if (errEl && errEl.classList.contains('error-msg')) errEl.style.display = 'block';
          el.style.borderColor = 'var(--rosso-err)';
          valid = false;
        } else {
          if (errEl && errEl.classList.contains('error-msg')) errEl.style.display = 'none';
          el.style.borderColor = '';
        }
      });
    }

    if (num === 2) {
      ['q1','q2','q3','q4'].forEach(name => {
        const container = document.querySelector(`[data-name="${name}"]`) || document.querySelector(`.likert-scale[data-name="${name}"]`);
        const errEl = container.nextElementSibling?.classList.contains('likert-labels')
          ? container.nextElementSibling.nextElementSibling
          : container.nextElementSibling;
        if (!document.querySelector(`input[name="${name}"]:checked`)) {
          if (errEl && errEl.classList.contains('error-msg')) errEl.style.display = 'block';
          valid = false;
        } else {
          if (errEl && errEl.classList.contains('error-msg')) errEl.style.display = 'none';
        }
      });
    }

    if (num === 3) {
      ['q5','q6','q7'].forEach(name => {
        const container = document.querySelector(`[data-name="${name}"]`) || document.querySelector(`.likert-scale[data-name="${name}"]`);
        const errEl = container.nextElementSibling?.classList.contains('likert-labels')
          ? container.nextElementSibling.nextElementSibling
          : container.nextElementSibling;
        if (!document.querySelector(`input[name="${name}"]:checked`)) {
          if (errEl && errEl.classList.contains('error-msg')) errEl.style.display = 'block';
          valid = false;
        } else {
          if (errEl && errEl.classList.contains('error-msg')) errEl.style.display = 'none';
        }
      });
      // q8 is optional
    }

    return valid;
  }

  function goTo(target) {
    // Validate current section before moving forward
    if (target > currentSection) {
      if (!validateSection(currentSection)) {
        // Scroll to first error
        const firstErr = document.querySelector(`#s${currentSection} .error-msg[style*="block"]`);
        if (firstErr) firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
    }

    document.getElementById('s' + currentSection).classList.remove('active');
    currentSection = target;
    document.getElementById('s' + currentSection).classList.add('active');
    updateProgress();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function collectData() {
    const data = {
      timestamp: new Date().toISOString(),
      profilo: {
        ruolo: document.getElementById('p1').value,
        tipo_ente: document.getElementById('p2').value,
        area_geografica: document.getElementById('p3').value
      },
      risposte: {}
    };

    ['q1','q2','q3','q4','q5','q6','q7'].forEach(name => {
      const checked = document.querySelector(`input[name="${name}"]:checked`);
      data.risposte[name] = checked ? checked.value : null;
    });

    data.risposte.q8 = document.getElementById('q8').value.trim() || null;

    return data;
  }

  function submitSurvey() {
    if (!validateSection(3)) {
      const firstErr = document.querySelector('#s3 .error-msg[style*="block"]');
      if (firstErr) firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    const data = collectData();
    console.log('📊 Dati sondaggio:', JSON.stringify(data, null, 2));

    // ============================================================
    // ENDPOINT: sostituire con l'URL del tuo backend o Google Form
    // Esempio con Google Apps Script:
    //
    // fetch('https://script.google.com/macros/s/XXXXXXX/exec', {
    //   method: 'POST',
    //   body: JSON.stringify(data),
    //   headers: { 'Content-Type': 'text/plain' }
    // });
    //
    // Esempio con Formspree:
    // fetch('https://formspree.io/f/XXXXXXX', {
    //   method: 'POST',
    //   body: JSON.stringify(data),
    //   headers: { 'Content-Type': 'application/json' }
    // });
    // ============================================================

    // Mostra il grazie
    document.getElementById('s3').classList.remove('active');
    document.getElementById('thankYou').classList.add('active');
    document.querySelector('.progress-wrap').style.display = 'none';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Live progress updates
  document.querySelectorAll('select, input[type="radio"]').forEach(el => {
    el.addEventListener('change', updateProgress);
  });
  document.getElementById('q8').addEventListener('input', updateProgress);

  // Lead capture: enable send button only when consent is checked + required fields filled
  function checkLeadReady() {
    const nome = document.getElementById('lead_nome').value.trim();
    const ente = document.getElementById('lead_ente').value.trim();
    const email = document.getElementById('lead_email').value.trim();
    const consenso = document.getElementById('lead_consenso').checked;
    const btn = document.getElementById('btnSendLead');
    btn.disabled = !(nome && ente && email && consenso);
  }

  document.getElementById('lead_consenso').addEventListener('change', checkLeadReady);
  ['lead_nome','lead_ente','lead_email','lead_tel','lead_ruolo_ext'].forEach(id => {
    document.getElementById(id).addEventListener('input', checkLeadReady);
  });

  function submitLead() {
    const leadData = {
      nome: document.getElementById('lead_nome').value.trim(),
      ente: document.getElementById('lead_ente').value.trim(),
      email: document.getElementById('lead_email').value.trim(),
      telefono: document.getElementById('lead_tel').value.trim() || null,
      ruolo: document.getElementById('lead_ruolo_ext').value.trim() || null,
      consenso_marketing: true,
      timestamp_consenso: new Date().toISOString()
    };

    // Merge with survey data
    const fullData = { ...collectData(), contatto: leadData };
    console.log('📊 Dati completi (sondaggio + contatto):', JSON.stringify(fullData, null, 2));

    // ============================================================
    // ENDPOINT: sostituire con l'URL del tuo backend
    // fetch('https://script.google.com/macros/s/XXXXXXX/exec', {
    //   method: 'POST',
    //   body: JSON.stringify(fullData),
    //   headers: { 'Content-Type': 'text/plain' }
    // });
    // ============================================================

    // Show final confirmation
    document.getElementById('thankYou').classList.remove('active');
    document.getElementById('finalConfirm').classList.add('active');
    document.getElementById('finalTitle').textContent = 'Tutto registrato!';
    document.getElementById('finalMsg').textContent = 'Ti invieremo i risultati del sondaggio a ' + leadData.email;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function skipLead() {
    document.getElementById('thankYou').classList.remove('active');
    document.getElementById('finalConfirm').classList.add('active');
    document.getElementById('finalTitle').textContent = 'Grazie per aver partecipato!';
    document.getElementById('finalMsg').textContent = 'I risultati aggregati saranno presentati durante il Forum.';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  updateProgress();
</script>

</body>
</html>
