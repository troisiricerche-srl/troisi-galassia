<?php
// Registra template pagina Sei in regola
add_filter('theme_page_templates', function($templates) {
    $templates['page-sei-in-regola.php'] = 'Sei in regola — Checker Compliance CustomerPA';
    $templates['page-sondaggio-ai.php'] = 'Sondaggio AI nella PA — III Forum 2026';
    return $templates;
});

// Crea automaticamente la pagina sei-in-regola se non esiste
add_action('after_switch_theme', function() {
    $page = get_page_by_path('sei-in-regola');
    if (!$page) {
        wp_insert_post([
            'post_title'    => 'Sei in regola',
            'post_name'     => 'sei-in-regola',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'page_template' => 'page-sei-in-regola.php',
        ]);
    }
    // Crea automaticamente la pagina sondaggio-ai se non esiste
    $page2 = get_page_by_path('sondaggio-ai');
    if (!$page2) {
        wp_insert_post([
            'post_title'    => 'Sondaggio AI nella PA',
            'post_name'     => 'sondaggio-ai',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'page_template' => 'page-sondaggio-ai.php',
        ]);
    }
});

// Intercetta /sei-in-regola e serve la pagina checker direttamente
add_action('template_redirect', function() {
    $path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    if ($path === 'sei-in-regola' || $path === 'sei-in-regola/') {
        global $wp_query; if ($wp_query) { $wp_query->is_404 = false; }
        status_header(200); // v2.2.1: prima la pagina usciva con stato 404
        include(get_template_directory() . '/page-sei-in-regola.php');
        exit;
    }
    if ($path === 'sondaggio-ai' || $path === 'sondaggio-ai/') {
        global $wp_query; if ($wp_query) { $wp_query->is_404 = false; }
        status_header(200); // v2.2.1: prima la pagina usciva con stato 404
        include(get_template_directory() . '/page-sondaggio-ai.php');
        exit;
    }
});

// Aggiunge la regola rewrite per /sei-in-regola
add_action('init', function() {
    add_rewrite_rule('^sei-in-regola/?$', 'index.php?sei_in_regola=1', 'top');
    add_rewrite_tag('%sei_in_regola%', '([0-9]+)');
});


// ============================================================
// ARTICOLI SETTIMANALI — Troisi Ricerche (v2.2)
// ============================================================
add_action('after_setup_theme', function () {
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
});

function cpa_articoli($n = 3, $offset = 0) {
    return new WP_Query(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => $n, 'offset' => $offset,
                         'post_name__not_in' => ['ciao-mondo', 'hello-world'], 'ignore_sticky_posts' => true]);
}

function cpa_minuti_lettura($post = null) {
    $parole = str_word_count(wp_strip_all_tags(preg_replace('#<(style|svg)\b.*?</\1>#s', ' ', get_post_field('post_content', $post))));
    return max(2, (int) round($parole / 200));
}

// Tema dell'articolo = prima categoria diversa da "Analisi"
function cpa_tema($post = null) {
    foreach ((array) get_the_category($post ? get_post($post)->ID : 0) as $c) {
        if (!in_array($c->slug, ['analisi', 'senza-categoria', 'uncategorized'], true)) return $c->name;
    }
    return 'Analisi';
}

function cpa_url_archivio() {
    $c = get_category_by_slug('analisi');
    return $c ? get_category_link($c) : home_url('/');
}

// Titolo delle pagine interne (la homepage mantiene il proprio <title>)
add_filter('pre_get_document_title', function ($t) {
    if (is_singular()) return wp_strip_all_tags(get_the_title()) . ' — CustomerPA';
    if (is_category() || is_tag()) return single_term_title('', false) . ' — Analisi — CustomerPA';
    if (is_404()) return 'Pagina non trovata — CustomerPA';
    if (is_home() || is_archive() || is_search()) return 'Analisi — CustomerPA';
    return $t;
});
add_action('wp_head', function () {
    if (!is_front_page()) echo '<title>' . esc_html(wp_get_document_title()) . "</title>\n";
}, 1);

// SEO articoli: description, Open Graph, JSON-LD NewsArticle
add_action('wp_head', function () {
    if (!is_singular('post')) return;
    $p = get_queried_object();
    $desc = wp_strip_all_tags(has_excerpt($p) ? get_the_excerpt($p) : wp_trim_words($p->post_content, 32, '…'));
    $url = get_permalink($p);
    echo '<meta name="description" content="' . esc_attr($desc) . "\">\n";
    echo '<meta property="og:type" content="article">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr(get_the_title($p)) . "\">\n";
    echo '<meta property="og:description" content="' . esc_attr($desc) . "\">\n";
    echo '<meta property="og:url" content="' . esc_url($url) . "\">\n";
    echo '<meta property="og:site_name" content="CustomerPA">' . "\n";
    $ld = [
        '@context' => 'https://schema.org', '@type' => 'NewsArticle',
        'headline' => get_the_title($p), 'description' => $desc,
        'datePublished' => get_the_date('c', $p), 'dateModified' => get_the_modified_date('c', $p),
        'mainEntityOfPage' => $url, 'inLanguage' => 'it-IT', 'articleSection' => cpa_tema($p),
        'keywords' => implode(', ', wp_list_pluck((array) get_the_tags($p->ID), 'name')),
        'author' => ['@type' => 'Person', 'name' => 'Andrea Troisi', 'url' => 'https://andreatroisi.it'],
        'publisher' => ['@type' => 'Organization', 'name' => 'Troisi Ricerche S.r.l. Unipersonale', 'url' => 'https://www.troisiricerche.net'],
    ];
    echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
}, 5);

// Il "Ciao mondo" di WordPress non compare in archivi e feed
add_action('pre_get_posts', function ($q) {
    if (!is_admin() && $q->is_main_query() && ($q->is_home() || $q->is_archive() || $q->is_feed())) {
        $q->set('post_name__not_in', ['ciao-mondo', 'hello-world']);
    }
});

