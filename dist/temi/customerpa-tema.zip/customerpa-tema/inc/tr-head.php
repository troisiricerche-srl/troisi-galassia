<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/favicon-32.png">
<link rel="icon" type="image/png" sizes="192x192" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/apple-touch-icon.png">
<!-- Flourish embed script — caricato una sola volta -->
<script src="https://public.flourish.studio/resources/embed.js"></script>

<!-- Schema.org -->
<style>
/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --blu:        #1a3a5c;
  --blu-pa:     #1d4ed8;
  --blu-dark:   #1e3a8a;
  --accento:    #e8a020;
  --testo:      #1a1a2e;
  --grigio:     #6b7280;
  --grigio-bg:  #f8f9fa;
  --bordo:      #e5e7eb;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --verde-bg:   #f0fdf4;
  --celeste-bg: #eff6ff;
}
body { font-family: 'Segoe UI', system-ui, sans-serif; color: var(--testo); background: var(--bianco); line-height: 1.6; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; height: auto; }

/* =============================================
   TOPBAR
   ============================================= */
.topbar { background: var(--blu-dark); padding: 6px 0; font-size: 0.72rem; }
.topbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; gap: 16px; flex-wrap: wrap; align-items: center; }
.topbar a { color: rgba(255,255,255,.7); transition: color .2s; }
.topbar a:hover { color: var(--accento); }
.topbar a.topbar-personal { color: var(--accento); font-weight: 700; }
.topbar a.topbar-active { color: var(--bianco); font-weight: 700; }

/* =============================================
   NAVBAR
   ============================================= */
.navbar { background: var(--bianco); border-bottom: 3px solid var(--blu-pa); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.08); }
.navbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.navbar-brand { display: flex; align-items: center; gap: 10px; font-weight: 800; font-size: 1.05rem; color: var(--blu-dark); }
.navbar-brand .logo-text { font-size: 1.1rem; font-weight: 900; }
.navbar-brand .logo-text span { color: var(--blu-pa); }
.navbar-brand .subtitle { font-size: 0.68rem; color: var(--grigio); font-weight: 400; display: block; line-height: 1.2; }
.navbar-links { display: flex; gap: 4px; align-items: center; }
.navbar-links a { padding: 6px 11px; border-radius: 6px; font-size: 0.83rem; color: var(--testo); font-weight: 500; transition: all .2s; }
.navbar-links a:hover { background: var(--celeste-bg); color: var(--blu-pa); }
.navbar-links .btn-accedi { border: 1.5px solid var(--bordo); color: var(--blu); font-weight: 600; }
.navbar-links .btn-demo { background: var(--blu-pa); color: var(--bianco) !important; font-weight: 700; padding: 7px 16px; }
.navbar-links .btn-demo:hover { background: var(--blu-dark); }

/* HAMBURGER */
.hamburger { display: none; flex-direction: column; justify-content: center; gap: 5px; cursor: pointer; padding: 8px; border: none; background: none; }
.hamburger span { display: block; width: 24px; height: 2px; background: var(--blu-pa); border-radius: 2px; transition: all .3s; }
.hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.mobile-menu { display: none; position: fixed; top: 64px; left: 0; right: 0; bottom: 0; background: var(--bianco); z-index: 99; padding: 20px; flex-direction: column; gap: 4px; overflow-y: auto; box-shadow: 0 4px 20px rgba(0,0,0,.15); }
.mobile-menu.open { display: flex; }
.mobile-menu a { padding: 14px 16px; border-radius: 8px; font-size: 1rem; color: var(--testo); font-weight: 500; border-bottom: 1px solid var(--bordo); transition: background .2s; }
.mobile-menu a:hover { background: var(--celeste-bg); }
.mobile-menu .btn-demo { background: var(--blu-pa); color: var(--bianco) !important; font-weight: 700; margin-top: 8px; text-align: center; border-bottom: none; }
.mobile-menu-social { display: flex; gap: 12px; padding: 16px 0 0; }
.mobile-menu-social a { font-size: 0.8rem; color: var(--blu-pa) !important; font-weight: 700; border: 1px solid var(--bordo) !important; padding: 8px 14px !important; border-radius: 6px !important; text-align: center; flex: 1; border-bottom: 1px solid var(--bordo) !important; }

/* =============================================
   HERO
   ============================================= */
.hero { background: linear-gradient(135deg, var(--blu-dark) 0%, #1e40af 50%, var(--blu-pa) 100%); color: var(--bianco); padding: 72px 20px 56px; position: relative; overflow: hidden; }
.hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 75% 30%, rgba(99,102,241,.15) 0%, transparent 60%); }
.hero .inner { max-width: 1100px; margin: 0 auto; position: relative; display: grid; grid-template-columns: 1fr 360px; gap: 48px; align-items: center; }
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.9); font-size: 0.7rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; padding: 5px 14px; border-radius: 20px; margin-bottom: 18px; }
.hero h1 { font-size: clamp(1.9rem, 4vw, 2.9rem); font-weight: 900; line-height: 1.15; margin-bottom: 10px; }
.hero h1 em { color: #93c5fd; font-style: normal; }
.hero-sub { font-size: 0.88rem; color: rgba(255,255,255,.6); margin-bottom: 16px; }
.hero-desc { font-size: 0.95rem; color: rgba(255,255,255,.82); margin-bottom: 32px; line-height: 1.7; max-width: 520px; }
.hero-cta { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 28px; }
.btn-primary-hero { background: var(--bianco); color: var(--blu-dark); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-primary-hero:hover { background: #dbeafe; transform: translateY(-1px); }
.btn-outline-hero { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.35); transition: all .2s; display: inline-block; }
.btn-outline-hero:hover { border-color: rgba(255,255,255,.7); }
.hero-badges { display: flex; gap: 8px; flex-wrap: wrap; }
.hb { font-size: 0.68rem; font-weight: 700; padding: 5px 12px; border-radius: 6px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.85); }

/* Hero dashboard card */
.hero-card { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); border-radius: 16px; padding: 22px; backdrop-filter: blur(8px); }
.hc-title { font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,.6); margin-bottom: 4px; text-transform: uppercase; letter-spacing: .06em; }
.hc-year { font-size: 0.65rem; color: rgba(255,255,255,.35); margin-bottom: 16px; }
.hc-score { font-size: 4rem; font-weight: 900; color: var(--bianco); line-height: 1; margin-bottom: 4px; }
.hc-index { font-size: 0.78rem; color: rgba(255,255,255,.6); margin-bottom: 6px; }
.hc-rank { font-size: 0.78rem; color: var(--accento); font-weight: 700; margin-bottom: 20px; }
.hc-dims { display: flex; flex-direction: column; gap: 8px; }
.hc-dim { display: flex; align-items: center; gap: 8px; }
.hc-dim .hd-icon { font-size: 0.9rem; width: 20px; flex-shrink: 0; }
.hc-dim .hd-label { font-size: 0.65rem; color: rgba(255,255,255,.6); flex: 1; }
.hc-dim .hd-bar { width: 80px; height: 4px; background: rgba(255,255,255,.12); border-radius: 2px; }
.hc-dim .hd-fill { height: 100%; border-radius: 2px; background: var(--accento); }
.hc-dim .hd-val { font-size: 0.7rem; color: rgba(255,255,255,.8); font-weight: 700; width: 24px; text-align: right; }
.hc-footer { margin-top: 14px; font-size: 0.6rem; color: rgba(255,255,255,.3); border-top: 1px solid rgba(255,255,255,.08); padding-top: 10px; }
.hc-camera { font-size: 0.68rem; color: #93c5fd; font-weight: 600; margin-top: 8px; }

/* =============================================
   SEZIONI GENERALI
   ============================================= */
section { padding: 64px 20px; }
.section-inner { max-width: 1100px; margin: 0 auto; }
.section-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .1em; color: var(--blu-pa); font-weight: 700; margin-bottom: 8px; }
.section-title { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; color: var(--blu); margin-bottom: 12px; line-height: 1.2; }
.section-title em { color: var(--blu-pa); font-style: normal; }
.section-desc { color: var(--grigio); max-width: 640px; margin-bottom: 36px; line-height: 1.7; }

/* =============================================
   STRUMENTI
   ============================================= */
#strumenti { background: var(--grigio-bg); }
.strumenti-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.strumento-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; text-align: center; transition: all .2s; cursor: pointer; }
.strumento-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); border-color: var(--blu-pa); transform: translateY(-2px); }
.sc-icon { font-size: 1.8rem; margin-bottom: 10px; }
.sc-title { font-size: 0.9rem; font-weight: 700; color: var(--blu); margin-bottom: 6px; }
.sc-desc { font-size: 0.75rem; color: var(--grigio); margin-bottom: 10px; }
.sc-badge { font-size: 0.65rem; background: var(--celeste-bg); color: var(--blu-pa); border: 1px solid #bae6fd; padding: 3px 9px; border-radius: 4px; font-weight: 600; display: inline-block; }

/* =============================================
   CPA INDEX
   ============================================= */
#cpi { background: var(--bianco); }
.cpi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.formula-box { background: var(--blu-dark); color: var(--bianco); border-radius: 12px; padding: 28px; font-family: 'Courier New', monospace; }
.fb-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: .1em; color: var(--accento); font-family: 'Segoe UI', sans-serif; font-weight: 700; margin-bottom: 16px; }
.fb-formula { font-size: 1rem; font-weight: 700; color: var(--bianco); margin-bottom: 14px; line-height: 1.6; }
.fb-vars { font-size: 0.75rem; color: rgba(255,255,255,.6); line-height: 1.8; font-family: 'Segoe UI', sans-serif; }
.dim-list { display: flex; flex-direction: column; gap: 10px; }
.dim-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: var(--grigio-bg); border-radius: 8px; border: 1px solid var(--bordo); }
.di-letter { width: 32px; height: 32px; background: var(--blu-pa); color: var(--bianco); border-radius: 8px; display: grid; place-items: center; font-weight: 900; font-size: 0.9rem; flex-shrink: 0; }
.di-info { flex: 1; }
.di-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); }
.di-sub { font-size: 0.7rem; color: var(--grigio); }
.di-pct { font-size: 1rem; font-weight: 900; color: var(--blu-pa); flex-shrink: 0; }
.di-bar { width: 50px; height: 5px; background: var(--bordo); border-radius: 3px; }
.di-fill { height: 100%; border-radius: 3px; background: var(--blu-pa); }

/* =============================================
   CALCOLATORI
   ============================================= */
.calcolatori-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.calc-box { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 28px; box-shadow: 0 2px 12px rgba(0,0,0,.04); }
.calc-box h3 { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
.calc-box .cb-sub { font-size: 0.8rem; color: var(--grigio); margin-bottom: 20px; line-height: 1.5; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 0.78rem; font-weight: 600; color: var(--testo); margin-bottom: 5px; }
.form-group input, .form-group select { width: 100%; padding: 9px 12px; border: 1.5px solid var(--bordo); border-radius: 7px; font-size: 0.85rem; outline: none; transition: border-color .2s; background: var(--bianco); }
.form-group input:focus, .form-group select:focus { border-color: var(--blu-pa); }
.btn-calc { width: 100%; background: var(--blu-pa); color: var(--bianco); border: none; padding: 11px; border-radius: 8px; font-size: 0.9rem; font-weight: 700; cursor: pointer; transition: background .2s; margin-top: 4px; }
.btn-calc:hover { background: var(--blu-dark); }
.result-box { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 10px; padding: 18px; margin-top: 16px; display: none; }
.result-box.visible { display: block; }
.rb-main { font-size: 2rem; font-weight: 900; color: var(--blu-pa); line-height: 1; margin-bottom: 6px; }
.rb-label { font-size: 0.78rem; color: var(--grigio); margin-bottom: 12px; }
.rb-details { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.rb-detail { font-size: 0.72rem; color: var(--grigio); }
.rb-detail strong { color: var(--blu); }
.rb-formula { font-size: 0.68rem; color: var(--grigio); margin-top: 10px; font-family: 'Courier New', monospace; border-top: 1px solid var(--bordo); padding-top: 8px; }
.cpa-result-box { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 10px; padding: 18px; margin-top: 16px; display: none; }
.cpa-result-box.visible { display: block; }
.cpa-score { font-size: 2.5rem; font-weight: 900; color: var(--blu-pa); line-height: 1; margin-bottom: 4px; }
.cpa-judgment { font-size: 0.85rem; font-weight: 700; margin-bottom: 12px; }
.cpa-breakdown { display: flex; flex-direction: column; gap: 4px; font-size: 0.72rem; color: var(--grigio); }
.cpa-breakdown span strong { color: var(--blu); }

/* =============================================
   GRAFICI FLOURISH
   ============================================= */
#grafici { background: var(--grigio-bg); }
.grafici-intro { margin-bottom: 32px; }
.flourish-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; margin-bottom: 28px; }
.flourish-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; overflow: hidden; transition: box-shadow .2s; }
.flourish-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.flourish-card.full-width { grid-column: 1 / -1; }
.fc-header { padding: 16px 20px 12px; border-bottom: 1px solid var(--bordo); }
.fc-report { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--blu-pa); margin-bottom: 4px; }
.fc-title { font-size: 0.92rem; font-weight: 700; color: var(--blu); }
.fc-body { padding: 0; }
.fc-body .flourish-embed { margin: 0; }
.fc-footer { padding: 10px 20px; border-top: 1px solid var(--bordo); display: flex; justify-content: space-between; align-items: center; background: var(--grigio-bg); }
.fc-source { font-size: 0.68rem; color: var(--grigio); }
.fc-link { font-size: 0.72rem; color: var(--blu-pa); font-weight: 600; border: 1px solid var(--bordo); padding: 4px 10px; border-radius: 5px; transition: all .2s; }
.fc-link:hover { background: var(--blu-pa); color: var(--bianco); }
.flourish-cta { text-align: center; }
.flourish-cta a { font-size: 0.85rem; color: var(--blu-pa); font-weight: 700; border: 1.5px solid var(--blu-pa); padding: 10px 24px; border-radius: 8px; display: inline-block; transition: all .2s; }
.flourish-cta a:hover { background: var(--blu-pa); color: var(--bianco); }

/* =============================================
   BENCHMARK
   ============================================= */
#benchmark { background: var(--bianco); }
.benchmark-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
.benchmark-table th { text-align: left; padding: 10px 14px; background: var(--blu-dark); color: var(--bianco); font-size: 0.72rem; text-transform: uppercase; letter-spacing: .06em; }
.benchmark-table th:first-child { border-radius: 8px 0 0 0; }
.benchmark-table th:last-child { border-radius: 0 8px 0 0; }
.benchmark-table td { padding: 12px 14px; border-bottom: 1px solid var(--bordo); }
.benchmark-table tr:hover td { background: var(--celeste-bg); }
.rank-pos { font-weight: 900; color: var(--grigio); font-size: 0.8rem; }
.rank-pos.top3 { color: var(--accento); }
.rank-nome { font-weight: 700; color: var(--blu); }
.rank-regione { font-size: 0.72rem; color: var(--grigio); display: block; }
.rank-score { font-size: 1rem; font-weight: 900; color: var(--blu-pa); }
.rank-bar-cell { width: 100px; }
.rank-bar { height: 5px; background: var(--bordo); border-radius: 3px; }
.rank-bar-fill { height: 100%; border-radius: 3px; background: linear-gradient(90deg, var(--blu-pa), var(--accento)); }
.rank-trend { font-size: 0.78rem; font-weight: 700; }
.rank-trend.up { color: var(--verde); }
.rank-nota { font-size: 0.72rem; color: var(--grigio); font-style: italic; margin-top: 12px; padding: 10px 14px; background: var(--grigio-bg); border-radius: 6px; border-left: 3px solid var(--bordo); }

/* =============================================
   GENERATORE QUESTIONARI
   ============================================= */
#questionario { background: var(--grigio-bg); }
.questionario-box { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 28px; max-width: 700px; }
.servizi-list { display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px; }
.servizio-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border: 1.5px solid var(--bordo); border-radius: 8px; cursor: pointer; transition: all .2s; }
.servizio-item:hover { border-color: var(--blu-pa); background: var(--celeste-bg); }
.servizio-item.selected { border-color: var(--blu-pa); background: var(--celeste-bg); }
.si-left { display: flex; align-items: center; gap: 10px; }
.si-icon { font-size: 1.1rem; }
.si-name { font-size: 0.88rem; font-weight: 600; color: var(--blu); }
.si-domande { font-size: 0.68rem; color: var(--grigio); background: var(--grigio-bg); padding: 3px 8px; border-radius: 4px; }
.si-check { width: 20px; height: 20px; border: 2px solid var(--bordo); border-radius: 4px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: all .2s; }
.servizio-item.selected .si-check { background: var(--blu-pa); border-color: var(--blu-pa); color: var(--bianco); font-size: 0.7rem; }
.questionario-output { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 8px; padding: 16px; margin-top: 16px; max-height: 360px; overflow-y: auto; display: none; font-size: 0.8rem; }
.questionario-output.visible { display: block; }
.qo-sezione { margin-bottom: 14px; }
.qo-titolo { font-size: 0.82rem; font-weight: 800; color: var(--blu); margin-bottom: 8px; border-bottom: 1px solid var(--bordo); padding-bottom: 4px; }
.qo-domanda { padding: 5px 0; color: var(--testo); border-bottom: 1px solid var(--bordo); }
.qo-domanda:last-child { border-bottom: none; }
.qo-num { color: var(--blu-pa); font-weight: 700; margin-right: 6px; }

/* =============================================
   METODOLOGIA
   ============================================= */
#metodo { background: var(--bianco); }
.fasi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
.fase-card { border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; position: relative; transition: box-shadow .2s; }
.fase-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.fase-num { font-size: 2rem; font-weight: 900; color: var(--bordo); line-height: 1; margin-bottom: 10px; }
.fase-icon { font-size: 1.3rem; margin-bottom: 8px; }
.fase-title { font-size: 0.9rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.fase-desc { font-size: 0.78rem; color: var(--grigio); line-height: 1.6; }
.fase-arrow { position: absolute; top: 50%; right: -14px; transform: translateY(-50%); font-size: 1.2rem; color: var(--bordo); z-index: 1; }
.fase-card:last-child .fase-arrow { display: none; }
.libro-section { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 14px; padding: 28px; display: grid; grid-template-columns: auto 1fr; gap: 24px; align-items: center; margin-top: 28px; }
.libro-cover { width: 120px; background: var(--blu-dark); border-radius: 8px; padding: 16px; text-align: center; color: var(--bianco); flex-shrink: 0; }
.libro-cover .lc-icon { font-size: 2rem; margin-bottom: 8px; }
.libro-cover .lc-editore { font-size: 0.65rem; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .08em; }
.libro-cover .lc-titolo { font-size: 0.72rem; font-weight: 700; line-height: 1.3; margin-top: 6px; }
.libro-info h4 { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.libro-info .li-autore { font-size: 0.82rem; color: var(--grigio); margin-bottom: 10px; }
.libro-info p { font-size: 0.85rem; color: var(--testo); line-height: 1.7; margin-bottom: 14px; }
.libro-info .camera-badge { display: inline-flex; align-items: center; gap: 6px; background: #dbeafe; border: 1px solid #93c5fd; color: var(--blu-dark); font-size: 0.75rem; font-weight: 700; padding: 6px 14px; border-radius: 6px; margin-bottom: 14px; }
.btn-libro { display: inline-block; background: var(--blu-pa); color: var(--bianco); padding: 10px 22px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; transition: background .2s; }
.btn-libro:hover { background: var(--blu-dark); }

/* =============================================
   ECOSISTEMA
   ============================================= */
#ecosistema { background: var(--grigio-bg); }
.eco-intro { font-size: 0.9rem; color: var(--testo); line-height: 1.7; margin-bottom: 28px; max-width: 780px; background: var(--bianco); border: 1px solid var(--bordo); border-left: 4px solid var(--blu-pa); border-radius: 8px; padding: 16px 20px; }
.eco-intro strong { color: var(--blu); }
.eco-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; margin-bottom: 20px; }
.eco-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px; text-align: center; transition: all .2s; }
.eco-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.08); border-color: var(--blu-pa); }
.eco-card.active { border-color: var(--accento); background: #fffbeb; }
.ec-step { font-size: 0.6rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--grigio); margin-bottom: 6px; }
.ec-icon { font-size: 1.4rem; margin-bottom: 6px; }
.ec-name { font-size: 0.82rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.ec-desc { font-size: 0.68rem; color: var(--grigio); margin-bottom: 8px; }
.ec-link { font-size: 0.68rem; color: var(--blu-pa); font-weight: 600; }
.eco-card.active .ec-link { color: var(--accento); }
.eco-grid-2 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }

/* =============================================
   CHI SIAMO
   ============================================= */
#chi-siamo { background: var(--bianco); }
.chi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.at-card { background: var(--grigio-bg); border-radius: 12px; padding: 24px; border: 1px solid var(--bordo); }
.at-avatar { width: 48px; height: 48px; background: var(--blu-pa); border-radius: 10px; display: grid; place-items: center; font-size: 1rem; font-weight: 900; color: var(--bianco); margin-bottom: 14px; }
.at-name { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.at-ruolo { font-size: 0.72rem; color: var(--grigio); margin-bottom: 12px; }
.at-desc { font-size: 0.82rem; color: var(--testo); line-height: 1.7; margin-bottom: 14px; }
.at-links { display: flex; gap: 8px; flex-wrap: wrap; }
.at-links a { font-size: 0.75rem; color: var(--blu-pa); font-weight: 600; border: 1px solid var(--bordo); padding: 5px 12px; border-radius: 6px; transition: all .2s; }
.at-links a:hover { background: var(--blu-pa); color: var(--bianco); border-color: var(--blu-pa); }
.troisi-box { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; }
.troisi-box h4 { font-size: 0.8rem; font-weight: 800; color: var(--blu); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 12px; }
.troisi-box p { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; margin-bottom: 14px; }
.tb-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px; }
.tb-stat { text-align: center; background: var(--bianco); border-radius: 8px; padding: 10px 6px; border: 1px solid var(--bordo); }
.tb-stat .ts-val { font-size: 1.2rem; font-weight: 900; color: var(--blu-pa); }
.tb-stat .ts-lbl { font-size: 0.6rem; color: var(--grigio); text-transform: uppercase; letter-spacing: .04em; }

/* =============================================
   FAQ
   ============================================= */
#faq { background: var(--grigio-bg); }
.faq-list { max-width: 780px; }
.faq-item { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; margin-bottom: 10px; overflow: hidden; }
.faq-question { padding: 18px 20px; font-size: 0.9rem; font-weight: 700; color: var(--blu); cursor: pointer; display: flex; justify-content: space-between; align-items: center; transition: background .2s; }
.faq-question:hover { background: var(--celeste-bg); }
.faq-question .fq-icon { font-size: 1rem; color: var(--blu-pa); transition: transform .3s; flex-shrink: 0; }
.faq-item.open .fq-icon { transform: rotate(45deg); }
.faq-answer { display: none; padding: 14px 20px 18px; font-size: 0.83rem; color: var(--grigio); line-height: 1.7; border-top: 1px solid var(--bordo); }
.faq-item.open .faq-answer { display: block; }

/* =============================================
   CTA FINALE
   ============================================= */
.cta-finale { background: linear-gradient(135deg, var(--blu-dark) 0%, #1e40af 100%); color: var(--bianco); padding: 64px 20px; text-align: center; }
.cta-finale h2 { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; margin-bottom: 10px; }
.cta-finale p { color: rgba(255,255,255,.7); margin-bottom: 28px; max-width: 500px; margin-left: auto; margin-right: auto; }
.cta-btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.btn-cta-white { background: var(--bianco); color: var(--blu-dark); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-cta-white:hover { background: #dbeafe; }
.btn-cta-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.3); transition: all .2s; display: inline-block; }
.btn-cta-outline:hover { border-color: rgba(255,255,255,.7); }

/* =============================================
   FOOTER
   ============================================= */
.site-footer { background: #0d1f35; color: rgba(255,255,255,.7); padding: 48px 20px 24px; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 36px; }
.footer-brand .brand-name { font-size: 1rem; font-weight: 800; color: var(--bianco); margin-bottom: 8px; }
.footer-brand p { font-size: 0.78rem; line-height: 1.6; margin-bottom: 10px; }
.footer-brand .brand-legal { font-size: 0.68rem; color: rgba(255,255,255,.3); line-height: 1.6; }
.footer-col h4 { font-size: 0.72rem; font-weight: 700; color: var(--bianco); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 7px; }
.footer-col ul li a { font-size: 0.8rem; color: rgba(255,255,255,.55); transition: color .2s; }
.footer-col ul li a:hover { color: var(--accento); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,.1); padding-top: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
.footer-bottom .copy { font-size: 0.7rem; color: rgba(255,255,255,.35); }
.footer-legal { display: flex; gap: 16px; }
.footer-legal a { font-size: 0.7rem; color: rgba(255,255,255,.35); transition: color .2s; }
.footer-legal a:hover { color: rgba(255,255,255,.7); }
.seo-hidden { position: absolute; left: -9999px; width: 1px; height: 1px; overflow: hidden; }

/* =============================================
   RESPONSIVE
   ============================================= */
@media (max-width: 960px) {
  .hero .inner { grid-template-columns: 1fr; }
  .hero-card { display: none; }
  .cpi-grid { grid-template-columns: 1fr; }
  .calcolatori-grid { grid-template-columns: 1fr; }
  .fasi-grid { grid-template-columns: 1fr 1fr; }
  .fase-arrow { display: none; }
  .eco-grid { grid-template-columns: repeat(3, 1fr); }
  .eco-grid-2 { grid-template-columns: repeat(2, 1fr); }
  .chi-grid { grid-template-columns: 1fr; }
  .flourish-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .navbar-links { display: none !important; }
  .hamburger { display: flex; }
  .topbar .inner { gap: 8px; font-size: 0.65rem; }
  .strumenti-grid { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr 1fr; gap: 24px; }
  section { padding: 44px 16px; }
  .libro-section { grid-template-columns: 1fr; text-align: center; }
  .benchmark-table th:nth-child(6),
  .benchmark-table td:nth-child(6),
  .benchmark-table th:nth-child(7),
  .benchmark-table td:nth-child(7) { display: none; }
}
@media (max-width: 480px) {
  .strumenti-grid { grid-template-columns: 1fr; }
  .eco-grid { grid-template-columns: 1fr 1fr; }
  .eco-grid-2 { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr; }
  .topbar { display: none; }
  .cta-btns { flex-direction: column; align-items: center; }
  .fasi-grid { grid-template-columns: 1fr; }
}

/* ===== RESPONSIVE NUOVE SEZIONI HOMEPAGE ===== */
@media (max-width: 768px) {
  /* Hero nuova */
  .hero .inner { grid-template-columns: 1fr !important; }
  .hero-card { display: none; }
  /* Riquadro checker */
  #checker-riquadro-grid { grid-template-columns: 1fr !important; gap: 24px !important; }
  /* Sezione perché obbligatorio */
  #perche-obbligatorio .section-inner > div { grid-template-columns: 1fr !important; }
  /* Sezione cosa ottieni */
  #cosa-ottieni .section-inner > div { grid-template-columns: 1fr 1fr !important; }
  /* Sezione certificazione */
  #cert-section .section-inner > div { grid-template-columns: 1fr !important; }
  /* Hero bullet */
  .hero-desc { max-width: 100% !important; }
}
@media (max-width: 480px) {
  /* Cosa ottieni — 1 colonna su mobile stretto */
  #cosa-ottieni .section-inner > div { grid-template-columns: 1fr !important; }
  /* Hero h1 */
  .hero h1 { font-size: 1.5rem !important; }
  /* Riquadro checker score */
  #checker-riquadro-grid [style*="font-size:2.8rem"] { font-size: 2rem !important; }
}
</style>

<!-- Structured Data per AI e SEO -->
<link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/tr-articoli.css?ver=2.2">
<?php wp_head(); ?>
</head>
<body <?php body_class('tr-pagina'); ?>>
<?php get_template_part('inc/tr-nav'); ?>
