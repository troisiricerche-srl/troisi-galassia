<!-- TOPBAR -->
<div class="topbar">
  <div class="inner">
    <a href="https://andreatroisi.it" class="topbar-personal">andreatroisi.it</a>
    <a href="https://www.troisiricerche.net">troisiricerche.net</a>
    <a href="https://www.t-index.it">TR-Index</a>
    <a href="https://www.mappaturadellecompetenze.it">Mappatura Competenze</a>
    <a href="https://www.registrodellecompetenze.it">Registro Competenze</a>
    <a href="https://www.customerpa.it" class="topbar-active">CustomerPA</a>
    <a href="https://www.benessereorganizzativo.it">BenessereOrg.</a>
    <a href="https://www.troisiformazione.it">Formazione</a>
    <a href="https://www.tiplive.it">TIP</a>
    <a href="https://www.troisiinsight.it">TroisiInsight</a>
    <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
    <a href="https://www.dibattito-pubblico.it">Dibattito Pubblico</a>
    <a href="https://www.voiceinhub.it">VoiceInHub</a>
    <a href="https://www.governancefinanziaria.it">Governance Fin.</a>
    <a href="https://www.consulenzainternazionalizzazione.it">Internazionalizzazione</a>
    <a href="https://www.benesseredigitalegiovani.it">BDG</a>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="navbar-brand">
      <div>
        <div class="logo-text">Customer<span>PA</span></div>
        <span class="subtitle">Piattaforma nazionale · Customer Satisfaction PA · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="<?php echo esc_url(home_url('/')); ?>#cpi">CPA Index</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#strumenti">Strumenti</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#grafici">Grafici</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#metodo">Metodologia</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#benchmark">Benchmark</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#ecosistema">Ecosistema</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#chi-siamo">Chi siamo</a>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="btn-accedi">Accedi</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi demo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" aria-label="Menu" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile menu -->
<div class="mobile-menu" id="mobile-menu">
  <a href="<?php echo esc_url(home_url('/')); ?>#cpi" onclick="closeMobileMenu()">CPA Index</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#strumenti" onclick="closeMobileMenu()">Strumenti</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#grafici" onclick="closeMobileMenu()">Grafici</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#metodo" onclick="closeMobileMenu()">Metodologia</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#benchmark" onclick="closeMobileMenu()">Benchmark</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#ecosistema" onclick="closeMobileMenu()">Ecosistema</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#chi-siamo" onclick="closeMobileMenu()">Chi siamo</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#faq" onclick="closeMobileMenu()">FAQ</a>
  <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo" onclick="closeMobileMenu()">Richiedi demo ↗</a>
  <div class="mobile-menu-social">
    <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a>
    <a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a>
  </div>
</div>

<!-- HERO -->
