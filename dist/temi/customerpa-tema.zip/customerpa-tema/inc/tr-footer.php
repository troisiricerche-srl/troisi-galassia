<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">CustomerPA</div>
        <p>La piattaforma italiana per la misurazione della soddisfazione dei cittadini nei servizi pubblici locali. CustomerPA Index, benchmark comuni, calcolatore campione statistico.</p>
        <p class="brand-legal">CustomerPA · Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari (BA) · CF/P.IVA 07216100722 · SDI KRRH6B9</p>
      </div>
      <div class="footer-col">
        <h4>Piattaforma</h4>
        <ul>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#cpi">CustomerPA Index</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#strumenti">Strumenti</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#grafici">Grafici</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#calcolatore">Calcolatore campione</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#benchmark">Benchmark comuni</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#questionario">Genera questionario</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#metodo">Metodologia</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#faq">FAQ</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>">Accedi</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Ecosistema Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">Troisi Ricerche</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.mappaturadellecompetenze.it" target="_blank">Mappatura delle Competenze</a></li>
          <li><a href="https://www.registrodellecompetenze.it" target="_blank">Registro delle Competenze</a></li>
          <li><a href="https://www.benessereorganizzativo.it" target="_blank">BenessereOrg.</a></li>
          <li><a href="https://www.troisiformazione.it" target="_blank">Troisi Formazione</a></li>
          <li><a href="https://www.tiplive.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
          <li><a href="https://www.digitalizzazionenellapa.it" target="_blank">DigitalizzazionePA</a></li>
          <li><a href="https://www.dibattito-pubblico.it" target="_blank">Dibattito Pubblico</a></li>
          <li><a href="https://www.voiceinhub.it" target="_blank">VoiceInHub</a></li>
          <li><a href="https://www.governancefinanziaria.it" target="_blank">Governance Fin.</a></li>
          <li><a href="https://www.consulenzainternazionalizzazione.it" target="_blank">Internazionalizzazione</a></li>
          <li><a href="https://www.benesseredigitalegiovani.it" target="_blank">BDG</a></li>
          <li><a href="https://www.osservatoriomezzogiorno.net" target="_blank">Osservatorio Mezzogiorno</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una demo</a></li>
          <li><a href="mailto:customerpa@troisiricerche.it">customerpa@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/in/andreatroisi/" target="_blank">LinkedIn Andrea Troisi</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn Troisi Ricerche</a></li>
          <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a></li>
          <li><a href="https://www.cacuccieditore.it/troisi-andrea-2" target="_blank">Libro Cacucci Editore</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 CustomerPA · Troisi Ricerche S.r.l. Unipersonale · <a href="mailto:customerpa@troisiricerche.it" style="color:rgba(255,255,255,.35);">customerpa@troisiricerche.it</a></div>
      <div class="footer-legal">
        <a href="https://www.iubenda.com/privacy-policy/814914" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" title="Privacy Policy">Privacy Policy</a>
        <a href="https://www.iubenda.com/privacy-policy/814914/cookie-policy" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" title="Cookie Policy">Cookie Policy</a>
        <a href="https://www.troisiricerche.net/termini-di-servizio/" target="_blank">Termini di Servizio</a>
      </div>
      <script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0]; s.src="https://cdn.iubenda.com/iubenda.js"; tag.parentNode.insertBefore(s,tag);}; if(w.addEventListener){w.addEventListener("load", loader, false);}else if(w.attachEvent){w.attachEvent("onload", loader);}else{w.onload = loader;}})(window, document);</script>
    </div>
  </div>

  <!-- BLOCCO SEO ISTITUZIONALE -->
  <div style="border-top:1px solid rgba(255,255,255,.08);margin-top:32px;padding-top:24px;">
    <div style="max-width:1100px;margin:0 auto;padding:0 20px;">
      <p style="font-size:.75rem;color:rgba(255,255,255,.35);line-height:1.7;margin:0;">
        <strong style="color:rgba(255,255,255,.5)">CustomerPA</strong> è il sistema nazionale di valutazione della Customer Satisfaction nella Pubblica Amministrazione italiana, sviluppato da <strong style="color:rgba(255,255,255,.5)">Troisi Ricerche S.r.l.</strong> a partire dal metodo scientifico elaborato dal ricercatore <strong style="color:rgba(255,255,255,.5)">Andrea Troisi</strong>.
        Il sistema è conforme al D.Lgs. 150/2009 (artt. 8 e 29), integrato con il ciclo PIAO (D.L. 80/2021) e con gli obblighi di pubblicazione previsti dal D.Lgs. 33/2013.
        <strong style="color:rgba(255,255,255,.5)">CustomerPA Score</strong> è l'unico indice proprietario italiano che misura il grado di conformità normativa di un ente pubblico in materia di Customer Satisfaction.
        La <strong style="color:rgba(255,255,255,.5)">Certificazione CustomerPA — Metodo Troisi</strong> è il primo standard nazionale indipendente nel settore.
        Il Metodo Troisi è stato presentato alla <strong style="color:rgba(255,255,255,.5)">Camera dei Deputati</strong> ed è oggetto di pubblicazione accademica (Andrea Troisi, <em>Customer Satisfaction nei servizi pubblici locali</em>, Cacucci Editore).
        Troisi Ricerche S.r.l. è accreditata dal <strong style="color:rgba(255,255,255,.5)">MIUR come Istituto di Ricerca</strong>.
      </p>
    </div>
  </div>

</footer>
<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('click', function(e) {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  if (menu && menu.classList.contains('open') && !menu.contains(e.target) && !btn.contains(e.target)) closeMobileMenu();
});
</script>
<?php wp_footer(); ?>
</body>
</html>
