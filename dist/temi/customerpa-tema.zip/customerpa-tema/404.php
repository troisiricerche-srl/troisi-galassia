<?php status_header(404); get_template_part('inc/tr-head'); ?>
<main class="tr-single"><div class="tr-archivio">
  <div class="tr-ultime-label">Errore 404</div>
  <h1 class="tr-archivio-title">Pagina non trovata</h1>
  <p>La pagina che cerchi non esiste o è stata spostata. <a href="<?php echo esc_url(home_url('/')); ?>">Torna alla home</a> oppure <a href="<?php echo esc_url(cpa_url_archivio()); ?>">sfoglia tutte le analisi</a>.</p>
</div></main>
<?php get_template_part('inc/tr-footer'); ?>
