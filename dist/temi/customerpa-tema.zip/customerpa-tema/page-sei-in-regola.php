<?php
/*
Template Name: Sei in regola — Checker Compliance CustomerPA v4
*/
?><!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "CustomerPA Audit — Verifica conformità Customer Satisfaction PA",
  "url": "https://www.customerpa.it/sei-in-regola",
  "description": "Audit gratuito di conformità normativa sulla Customer Satisfaction nella PA. Genera il CustomerPA Score — D.Lgs. 150/2009, PIAO, OIV. Metodo Troisi — Troisi Ricerche.",
  "applicationCategory": "GovernmentApplication",
  "operatingSystem": "Web",
  "offers": {"@type": "Offer", "price": "0", "priceCurrency": "EUR"},
  "provider": {
    "@type": "Organization",
    "name": "Troisi Ricerche S.r.l.",
    "url": "https://www.customerpa.it"
  },
  "about": {
    "@type": "Thing",
    "name": "Customer Satisfaction Pubblica Amministrazione",
    "description": "Verifica della conformità normativa sulla Customer Satisfaction nella Pubblica Amministrazione italiana secondo il D.Lgs. 150/2009"
  },
  "potentialAction": {
    "@type": "UseAction",
    "target": "https://www.customerpa.it/sei-in-regola",
    "object": "Audit conformità Customer Satisfaction PA"
  }
}
</script>
<title>Sei in regola? — Audit CustomerPA · Verifica conformità CS · Troisi Ricerche</title>
<meta name="description" content="Verifica in 8 punti il livello di conformità del tuo ente sulla Customer Satisfaction. CustomerPA Score, benchmark nazionale, scenario di rischio OIV. Gratuito.">
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
<style>


/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --blu:        #1a3a5c;
  --blu-pa:     #1d4ed8;
  --blu-dark:   #1e3a8a;
  --accento:    #e8a020;
  --testo:      #1a1a2e;
  --grigio:     #6b7280;
  --grigio-bg:  #f8f9fa;
  --bordo:      #e5e7eb;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --verde-bg:   #f0fdf4;
  --celeste-bg: #eff6ff;
}
body { font-family: 'Segoe UI', system-ui, sans-serif; color: var(--testo); background: var(--bianco); line-height: 1.6; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; height: auto; }

/* =============================================
   TOPBAR
   ============================================= */
.topbar { background: var(--blu-dark); padding: 6px 0; font-size: 0.72rem; }
.topbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; gap: 16px; flex-wrap: wrap; align-items: center; }
.topbar a { color: rgba(255,255,255,.7); transition: color .2s; }
.topbar a:hover { color: var(--accento); }
.topbar a.topbar-personal { color: var(--accento); font-weight: 700; }
.topbar a.topbar-active { color: var(--bianco); font-weight: 700; }

/* =============================================
   NAVBAR
   ============================================= */
.navbar { background: var(--bianco); border-bottom: 3px solid var(--blu-pa); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.08); }
.navbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.navbar-brand { display: flex; align-items: center; gap: 10px; font-weight: 800; font-size: 1.05rem; color: var(--blu-dark); }
.navbar-brand .logo-text { font-size: 1.1rem; font-weight: 900; }
.navbar-brand .logo-text span { color: var(--blu-pa); }
.navbar-brand .subtitle { font-size: 0.68rem; color: var(--grigio); font-weight: 400; display: block; line-height: 1.2; }
.navbar-links { display: flex; gap: 4px; align-items: center; }
.navbar-links a { padding: 6px 11px; border-radius: 6px; font-size: 0.83rem; color: var(--testo); font-weight: 500; transition: all .2s; }
.navbar-links a:hover { background: var(--celeste-bg); color: var(--blu-pa); }
.navbar-links .btn-accedi { border: 1.5px solid var(--bordo); color: var(--blu); font-weight: 600; }
.navbar-links .btn-demo { background: var(--blu-pa); color: var(--bianco) !important; font-weight: 700; padding: 7px 16px; }
.navbar-links .btn-demo:hover { background: var(--blu-dark); }

/* HAMBURGER */
.hamburger { display: none; flex-direction: column; justify-content: center; gap: 5px; cursor: pointer; padding: 8px; border: none; background: none; }
.hamburger span { display: block; width: 24px; height: 2px; background: var(--blu-pa); border-radius: 2px; transition: all .3s; }
.hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.mobile-menu { display: none; position: fixed; top: 64px; left: 0; right: 0; bottom: 0; background: var(--bianco); z-index: 99; padding: 20px; flex-direction: column; gap: 4px; overflow-y: auto; box-shadow: 0 4px 20px rgba(0,0,0,.15); }
.mobile-menu.open { display: flex; }
.mobile-menu a { padding: 14px 16px; border-radius: 8px; font-size: 1rem; color: var(--testo); font-weight: 500; border-bottom: 1px solid var(--bordo); transition: background .2s; }
.mobile-menu a:hover { background: var(--celeste-bg); }
.mobile-menu .btn-demo { background: var(--blu-pa); color: var(--bianco) !important; font-weight: 700; margin-top: 8px; text-align: center; border-bottom: none; }
.mobile-menu-social { display: flex; gap: 12px; padding: 16px 0 0; }
.mobile-menu-social a { font-size: 0.8rem; color: var(--blu-pa) !important; font-weight: 700; border: 1px solid var(--bordo) !important; padding: 8px 14px !important; border-radius: 6px !important; text-align: center; flex: 1; border-bottom: 1px solid var(--bordo) !important; }

/* =============================================
   HERO
   ============================================= */
.hero { background: linear-gradient(135deg, var(--blu-dark) 0%, #1e40af 50%, var(--blu-pa) 100%); color: var(--bianco); padding: 72px 20px 56px; position: relative; overflow: hidden; }
.hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 75% 30%, rgba(99,102,241,.15) 0%, transparent 60%); }
.hero .inner { max-width: 1100px; margin: 0 auto; position: relative; display: grid; grid-template-columns: 1fr 360px; gap: 48px; align-items: center; }
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.9); font-size: 0.7rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; padding: 5px 14px; border-radius: 20px; margin-bottom: 18px; }
.hero h1 { font-size: clamp(1.9rem, 4vw, 2.9rem); font-weight: 900; line-height: 1.15; margin-bottom: 10px; }
.hero h1 em { color: #93c5fd; font-style: normal; }
.hero-sub { font-size: 0.88rem; color: rgba(255,255,255,.6); margin-bottom: 16px; }
.hero-desc { font-size: 0.95rem; color: rgba(255,255,255,.82); margin-bottom: 32px; line-height: 1.7; max-width: 520px; }
.hero-cta { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 28px; }
.btn-primary-hero { background: var(--bianco); color: var(--blu-dark); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-primary-hero:hover { background: #dbeafe; transform: translateY(-1px); }
.btn-outline-hero { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.35); transition: all .2s; display: inline-block; }
.btn-outline-hero:hover { border-color: rgba(255,255,255,.7); }
.hero-badges { display: flex; gap: 8px; flex-wrap: wrap; }
.hb { font-size: 0.68rem; font-weight: 700; padding: 5px 12px; border-radius: 6px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.85); }

/* Hero dashboard card */
.hero-card { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); border-radius: 16px; padding: 22px; backdrop-filter: blur(8px); }
.hc-title { font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,.6); margin-bottom: 4px; text-transform: uppercase; letter-spacing: .06em; }
.hc-year { font-size: 0.65rem; color: rgba(255,255,255,.35); margin-bottom: 16px; }
.hc-score { font-size: 4rem; font-weight: 900; color: var(--bianco); line-height: 1; margin-bottom: 4px; }
.hc-index { font-size: 0.78rem; color: rgba(255,255,255,.6); margin-bottom: 6px; }
.hc-rank { font-size: 0.78rem; color: var(--accento); font-weight: 700; margin-bottom: 20px; }
.hc-dims { display: flex; flex-direction: column; gap: 8px; }
.hc-dim { display: flex; align-items: center; gap: 8px; }
.hc-dim .hd-icon { font-size: 0.9rem; width: 20px; flex-shrink: 0; }
.hc-dim .hd-label { font-size: 0.65rem; color: rgba(255,255,255,.6); flex: 1; }
.hc-dim .hd-bar { width: 80px; height: 4px; background: rgba(255,255,255,.12); border-radius: 2px; }
.hc-dim .hd-fill { height: 100%; border-radius: 2px; background: var(--accento); }
.hc-dim .hd-val { font-size: 0.7rem; color: rgba(255,255,255,.8); font-weight: 700; width: 24px; text-align: right; }
.hc-footer { margin-top: 14px; font-size: 0.6rem; color: rgba(255,255,255,.3); border-top: 1px solid rgba(255,255,255,.08); padding-top: 10px; }
.hc-camera { font-size: 0.68rem; color: #93c5fd; font-weight: 600; margin-top: 8px; }

/* =============================================
   SEZIONI GENERALI
   ============================================= */
section { padding: 64px 20px; }
.section-inner { max-width: 1100px; margin: 0 auto; }
.section-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .1em; color: var(--blu-pa); font-weight: 700; margin-bottom: 8px; }
.section-title { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; color: var(--blu); margin-bottom: 12px; line-height: 1.2; }
.section-title em { color: var(--blu-pa); font-style: normal; }
.section-desc { color: var(--grigio); max-width: 640px; margin-bottom: 36px; line-height: 1.7; }

/* =============================================
   STRUMENTI
   ============================================= */
#strumenti { background: var(--grigio-bg); }
.strumenti-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.strumento-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; text-align: center; transition: all .2s; cursor: pointer; }
.strumento-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); border-color: var(--blu-pa); transform: translateY(-2px); }
.sc-icon { font-size: 1.8rem; margin-bottom: 10px; }
.sc-title { font-size: 0.9rem; font-weight: 700; color: var(--blu); margin-bottom: 6px; }
.sc-desc { font-size: 0.75rem; color: var(--grigio); margin-bottom: 10px; }
.sc-badge { font-size: 0.65rem; background: var(--celeste-bg); color: var(--blu-pa); border: 1px solid #bae6fd; padding: 3px 9px; border-radius: 4px; font-weight: 600; display: inline-block; }

/* =============================================
   CPA INDEX
   ============================================= */
#cpi { background: var(--bianco); }
.cpi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.formula-box { background: var(--blu-dark); color: var(--bianco); border-radius: 12px; padding: 28px; font-family: 'Courier New', monospace; }
.fb-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: .1em; color: var(--accento); font-family: 'Segoe UI', sans-serif; font-weight: 700; margin-bottom: 16px; }
.fb-formula { font-size: 1rem; font-weight: 700; color: var(--bianco); margin-bottom: 14px; line-height: 1.6; }
.fb-vars { font-size: 0.75rem; color: rgba(255,255,255,.6); line-height: 1.8; font-family: 'Segoe UI', sans-serif; }
.dim-list { display: flex; flex-direction: column; gap: 10px; }
.dim-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: var(--grigio-bg); border-radius: 8px; border: 1px solid var(--bordo); }
.di-letter { width: 32px; height: 32px; background: var(--blu-pa); color: var(--bianco); border-radius: 8px; display: grid; place-items: center; font-weight: 900; font-size: 0.9rem; flex-shrink: 0; }
.di-info { flex: 1; }
.di-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); }
.di-sub { font-size: 0.7rem; color: var(--grigio); }
.di-pct { font-size: 1rem; font-weight: 900; color: var(--blu-pa); flex-shrink: 0; }
.di-bar { width: 50px; height: 5px; background: var(--bordo); border-radius: 3px; }
.di-fill { height: 100%; border-radius: 3px; background: var(--blu-pa); }

/* =============================================
   CALCOLATORI
   ============================================= */
.calcolatori-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.calc-box { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 28px; box-shadow: 0 2px 12px rgba(0,0,0,.04); }
.calc-box h3 { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
.calc-box .cb-sub { font-size: 0.8rem; color: var(--grigio); margin-bottom: 20px; line-height: 1.5; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 0.78rem; font-weight: 600; color: var(--testo); margin-bottom: 5px; }
.form-group input, .form-group select { width: 100%; padding: 9px 12px; border: 1.5px solid var(--bordo); border-radius: 7px; font-size: 0.85rem; outline: none; transition: border-color .2s; background: var(--bianco); }
.form-group input:focus, .form-group select:focus { border-color: var(--blu-pa); }
.btn-calc { width: 100%; background: var(--blu-pa); color: var(--bianco); border: none; padding: 11px; border-radius: 8px; font-size: 0.9rem; font-weight: 700; cursor: pointer; transition: background .2s; margin-top: 4px; }
.btn-calc:hover { background: var(--blu-dark); }
.result-box { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 10px; padding: 18px; margin-top: 16px; display: none; }
.result-box.visible { display: block; }
.rb-main { font-size: 2rem; font-weight: 900; color: var(--blu-pa); line-height: 1; margin-bottom: 6px; }
.rb-label { font-size: 0.78rem; color: var(--grigio); margin-bottom: 12px; }
.rb-details { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.rb-detail { font-size: 0.72rem; color: var(--grigio); }
.rb-detail strong { color: var(--blu); }
.rb-formula { font-size: 0.68rem; color: var(--grigio); margin-top: 10px; font-family: 'Courier New', monospace; border-top: 1px solid var(--bordo); padding-top: 8px; }
.cpa-result-box { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 10px; padding: 18px; margin-top: 16px; display: none; }
.cpa-result-box.visible { display: block; }
.cpa-score { font-size: 2.5rem; font-weight: 900; color: var(--blu-pa); line-height: 1; margin-bottom: 4px; }
.cpa-judgment { font-size: 0.85rem; font-weight: 700; margin-bottom: 12px; }
.cpa-breakdown { display: flex; flex-direction: column; gap: 4px; font-size: 0.72rem; color: var(--grigio); }
.cpa-breakdown span strong { color: var(--blu); }

/* =============================================
   GRAFICI FLOURISH
   ============================================= */
#grafici { background: var(--grigio-bg); }
.grafici-intro { margin-bottom: 32px; }
.flourish-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; margin-bottom: 28px; }
.flourish-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; overflow: hidden; transition: box-shadow .2s; }
.flourish-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.flourish-card.full-width { grid-column: 1 / -1; }
.fc-header { padding: 16px 20px 12px; border-bottom: 1px solid var(--bordo); }
.fc-report { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--blu-pa); margin-bottom: 4px; }
.fc-title { font-size: 0.92rem; font-weight: 700; color: var(--blu); }
.fc-body { padding: 0; }
.fc-body .flourish-embed { margin: 0; }
.fc-footer { padding: 10px 20px; border-top: 1px solid var(--bordo); display: flex; justify-content: space-between; align-items: center; background: var(--grigio-bg); }
.fc-source { font-size: 0.68rem; color: var(--grigio); }
.fc-link { font-size: 0.72rem; color: var(--blu-pa); font-weight: 600; border: 1px solid var(--bordo); padding: 4px 10px; border-radius: 5px; transition: all .2s; }
.fc-link:hover { background: var(--blu-pa); color: var(--bianco); }
.flourish-cta { text-align: center; }
.flourish-cta a { font-size: 0.85rem; color: var(--blu-pa); font-weight: 700; border: 1.5px solid var(--blu-pa); padding: 10px 24px; border-radius: 8px; display: inline-block; transition: all .2s; }
.flourish-cta a:hover { background: var(--blu-pa); color: var(--bianco); }

/* =============================================
   BENCHMARK
   ============================================= */
#benchmark { background: var(--bianco); }
.benchmark-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
.benchmark-table th { text-align: left; padding: 10px 14px; background: var(--blu-dark); color: var(--bianco); font-size: 0.72rem; text-transform: uppercase; letter-spacing: .06em; }
.benchmark-table th:first-child { border-radius: 8px 0 0 0; }
.benchmark-table th:last-child { border-radius: 0 8px 0 0; }
.benchmark-table td { padding: 12px 14px; border-bottom: 1px solid var(--bordo); }
.benchmark-table tr:hover td { background: var(--celeste-bg); }
.rank-pos { font-weight: 900; color: var(--grigio); font-size: 0.8rem; }
.rank-pos.top3 { color: var(--accento); }
.rank-nome { font-weight: 700; color: var(--blu); }
.rank-regione { font-size: 0.72rem; color: var(--grigio); display: block; }
.rank-score { font-size: 1rem; font-weight: 900; color: var(--blu-pa); }
.rank-bar-cell { width: 100px; }
.rank-bar { height: 5px; background: var(--bordo); border-radius: 3px; }
.rank-bar-fill { height: 100%; border-radius: 3px; background: linear-gradient(90deg, var(--blu-pa), var(--accento)); }
.rank-trend { font-size: 0.78rem; font-weight: 700; }
.rank-trend.up { color: var(--verde); }
.rank-nota { font-size: 0.72rem; color: var(--grigio); font-style: italic; margin-top: 12px; padding: 10px 14px; background: var(--grigio-bg); border-radius: 6px; border-left: 3px solid var(--bordo); }

/* =============================================
   GENERATORE QUESTIONARI
   ============================================= */
#questionario { background: var(--grigio-bg); }
.questionario-box { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 28px; max-width: 700px; }
.servizi-list { display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px; }
.servizio-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border: 1.5px solid var(--bordo); border-radius: 8px; cursor: pointer; transition: all .2s; }
.servizio-item:hover { border-color: var(--blu-pa); background: var(--celeste-bg); }
.servizio-item.selected { border-color: var(--blu-pa); background: var(--celeste-bg); }
.si-left { display: flex; align-items: center; gap: 10px; }
.si-icon { font-size: 1.1rem; }
.si-name { font-size: 0.88rem; font-weight: 600; color: var(--blu); }
.si-domande { font-size: 0.68rem; color: var(--grigio); background: var(--grigio-bg); padding: 3px 8px; border-radius: 4px; }
.si-check { width: 20px; height: 20px; border: 2px solid var(--bordo); border-radius: 4px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: all .2s; }
.servizio-item.selected .si-check { background: var(--blu-pa); border-color: var(--blu-pa); color: var(--bianco); font-size: 0.7rem; }
.questionario-output { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 8px; padding: 16px; margin-top: 16px; max-height: 360px; overflow-y: auto; display: none; font-size: 0.8rem; }
.questionario-output.visible { display: block; }
.qo-sezione { margin-bottom: 14px; }
.qo-titolo { font-size: 0.82rem; font-weight: 800; color: var(--blu); margin-bottom: 8px; border-bottom: 1px solid var(--bordo); padding-bottom: 4px; }
.qo-domanda { padding: 5px 0; color: var(--testo); border-bottom: 1px solid var(--bordo); }
.qo-domanda:last-child { border-bottom: none; }
.qo-num { color: var(--blu-pa); font-weight: 700; margin-right: 6px; }

/* =============================================
   METODOLOGIA
   ============================================= */
#metodo { background: var(--bianco); }
.fasi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
.fase-card { border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; position: relative; transition: box-shadow .2s; }
.fase-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.fase-num { font-size: 2rem; font-weight: 900; color: var(--bordo); line-height: 1; margin-bottom: 10px; }
.fase-icon { font-size: 1.3rem; margin-bottom: 8px; }
.fase-title { font-size: 0.9rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.fase-desc { font-size: 0.78rem; color: var(--grigio); line-height: 1.6; }
.fase-arrow { position: absolute; top: 50%; right: -14px; transform: translateY(-50%); font-size: 1.2rem; color: var(--bordo); z-index: 1; }
.fase-card:last-child .fase-arrow { display: none; }
.libro-section { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 14px; padding: 28px; display: grid; grid-template-columns: auto 1fr; gap: 24px; align-items: center; margin-top: 28px; }
.libro-cover { width: 120px; background: var(--blu-dark); border-radius: 8px; padding: 16px; text-align: center; color: var(--bianco); flex-shrink: 0; }
.libro-cover .lc-icon { font-size: 2rem; margin-bottom: 8px; }
.libro-cover .lc-editore { font-size: 0.65rem; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .08em; }
.libro-cover .lc-titolo { font-size: 0.72rem; font-weight: 700; line-height: 1.3; margin-top: 6px; }
.libro-info h4 { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.libro-info .li-autore { font-size: 0.82rem; color: var(--grigio); margin-bottom: 10px; }
.libro-info p { font-size: 0.85rem; color: var(--testo); line-height: 1.7; margin-bottom: 14px; }
.libro-info .camera-badge { display: inline-flex; align-items: center; gap: 6px; background: #dbeafe; border: 1px solid #93c5fd; color: var(--blu-dark); font-size: 0.75rem; font-weight: 700; padding: 6px 14px; border-radius: 6px; margin-bottom: 14px; }
.btn-libro { display: inline-block; background: var(--blu-pa); color: var(--bianco); padding: 10px 22px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; transition: background .2s; }
.btn-libro:hover { background: var(--blu-dark); }

/* =============================================
   ECOSISTEMA
   ============================================= */
#ecosistema { background: var(--grigio-bg); }
.eco-intro { font-size: 0.9rem; color: var(--testo); line-height: 1.7; margin-bottom: 28px; max-width: 780px; background: var(--bianco); border: 1px solid var(--bordo); border-left: 4px solid var(--blu-pa); border-radius: 8px; padding: 16px 20px; }
.eco-intro strong { color: var(--blu); }
.eco-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; margin-bottom: 20px; }
.eco-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px; text-align: center; transition: all .2s; }
.eco-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.08); border-color: var(--blu-pa); }
.eco-card.active { border-color: var(--accento); background: #fffbeb; }
.ec-step { font-size: 0.6rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--grigio); margin-bottom: 6px; }
.ec-icon { font-size: 1.4rem; margin-bottom: 6px; }
.ec-name { font-size: 0.82rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.ec-desc { font-size: 0.68rem; color: var(--grigio); margin-bottom: 8px; }
.ec-link { font-size: 0.68rem; color: var(--blu-pa); font-weight: 600; }
.eco-card.active .ec-link { color: var(--accento); }
.eco-grid-2 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }

/* =============================================
   CHI SIAMO
   ============================================= */
#chi-siamo { background: var(--bianco); }
.chi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.at-card { background: var(--grigio-bg); border-radius: 12px; padding: 24px; border: 1px solid var(--bordo); }
.at-avatar { width: 48px; height: 48px; background: var(--blu-pa); border-radius: 10px; display: grid; place-items: center; font-size: 1rem; font-weight: 900; color: var(--bianco); margin-bottom: 14px; }
.at-name { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.at-ruolo { font-size: 0.72rem; color: var(--grigio); margin-bottom: 12px; }
.at-desc { font-size: 0.82rem; color: var(--testo); line-height: 1.7; margin-bottom: 14px; }
.at-links { display: flex; gap: 8px; flex-wrap: wrap; }
.at-links a { font-size: 0.75rem; color: var(--blu-pa); font-weight: 600; border: 1px solid var(--bordo); padding: 5px 12px; border-radius: 6px; transition: all .2s; }
.at-links a:hover { background: var(--blu-pa); color: var(--bianco); border-color: var(--blu-pa); }
.troisi-box { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; }
.troisi-box h4 { font-size: 0.8rem; font-weight: 800; color: var(--blu); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 12px; }
.troisi-box p { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; margin-bottom: 14px; }
.tb-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px; }
.tb-stat { text-align: center; background: var(--bianco); border-radius: 8px; padding: 10px 6px; border: 1px solid var(--bordo); }
.tb-stat .ts-val { font-size: 1.2rem; font-weight: 900; color: var(--blu-pa); }
.tb-stat .ts-lbl { font-size: 0.6rem; color: var(--grigio); text-transform: uppercase; letter-spacing: .04em; }

/* =============================================
   FAQ
   ============================================= */
#faq { background: var(--grigio-bg); }
.faq-list { max-width: 780px; }
.faq-item { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; margin-bottom: 10px; overflow: hidden; }
.faq-question { padding: 18px 20px; font-size: 0.9rem; font-weight: 700; color: var(--blu); cursor: pointer; display: flex; justify-content: space-between; align-items: center; transition: background .2s; }
.faq-question:hover { background: var(--celeste-bg); }
.faq-question .fq-icon { font-size: 1rem; color: var(--blu-pa); transition: transform .3s; flex-shrink: 0; }
.faq-item.open .fq-icon { transform: rotate(45deg); }
.faq-answer { display: none; padding: 14px 20px 18px; font-size: 0.83rem; color: var(--grigio); line-height: 1.7; border-top: 1px solid var(--bordo); }
.faq-item.open .faq-answer { display: block; }

/* =============================================
   CTA FINALE
   ============================================= */
.cta-finale { background: linear-gradient(135deg, var(--blu-dark) 0%, #1e40af 100%); color: var(--bianco); padding: 64px 20px; text-align: center; }
.cta-finale h2 { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; margin-bottom: 10px; }
.cta-finale p { color: rgba(255,255,255,.7); margin-bottom: 28px; max-width: 500px; margin-left: auto; margin-right: auto; }
.cta-btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.btn-cta-white { background: var(--bianco); color: var(--blu-dark); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-cta-white:hover { background: #dbeafe; }
.btn-cta-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.3); transition: all .2s; display: inline-block; }
.btn-cta-outline:hover { border-color: rgba(255,255,255,.7); }

/* =============================================
   FOOTER
   ============================================= */
.site-footer { background: #0d1f35; color: rgba(255,255,255,.7); padding: 48px 20px 24px; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 36px; }
.footer-brand .brand-name { font-size: 1rem; font-weight: 800; color: var(--bianco); margin-bottom: 8px; }
.footer-brand p { font-size: 0.78rem; line-height: 1.6; margin-bottom: 10px; }
.footer-brand .brand-legal { font-size: 0.68rem; color: rgba(255,255,255,.3); line-height: 1.6; }
.footer-col h4 { font-size: 0.72rem; font-weight: 700; color: var(--bianco); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 7px; }
.footer-col ul li a { font-size: 0.8rem; color: rgba(255,255,255,.55); transition: color .2s; }
.footer-col ul li a:hover { color: var(--accento); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,.1); padding-top: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
.footer-bottom .copy { font-size: 0.7rem; color: rgba(255,255,255,.35); }
.footer-legal { display: flex; gap: 16px; }
.footer-legal a { font-size: 0.7rem; color: rgba(255,255,255,.35); transition: color .2s; }
.footer-legal a:hover { color: rgba(255,255,255,.7); }
.seo-hidden { position: absolute; left: -9999px; width: 1px; height: 1px; overflow: hidden; }

/* =============================================
   RESPONSIVE
   ============================================= */
@media (max-width: 960px) {
  .hero .inner { grid-template-columns: 1fr; }
  .hero-card { display: none; }
  .cpi-grid { grid-template-columns: 1fr; }
  .calcolatori-grid { grid-template-columns: 1fr; }
  .fasi-grid { grid-template-columns: 1fr 1fr; }
  .fase-arrow { display: none; }
  .eco-grid { grid-template-columns: repeat(3, 1fr); }
  .eco-grid-2 { grid-template-columns: repeat(2, 1fr); }
  .chi-grid { grid-template-columns: 1fr; }
  .flourish-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .navbar-links { display: none !important; }
  .hamburger { display: flex; }
  .topbar .inner { gap: 8px; font-size: 0.65rem; }
  .strumenti-grid { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr 1fr; gap: 24px; }
  section { padding: 44px 16px; }
  .libro-section { grid-template-columns: 1fr; text-align: center; }
  .benchmark-table th:nth-child(6),
  .benchmark-table td:nth-child(6),
  .benchmark-table th:nth-child(7),
  .benchmark-table td:nth-child(7) { display: none; }
}
@media (max-width: 480px) {
  .strumenti-grid { grid-template-columns: 1fr; }
  .eco-grid { grid-template-columns: 1fr 1fr; }
  .eco-grid-2 { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr; }
  .topbar { display: none; }
  .cta-btns { flex-direction: column; align-items: center; }
  .fasi-grid { grid-template-columns: 1fr; }
}

/* === CHECKER STYLES === */
/* OVERRIDE LARGHEZZA CHECKER */
.chk-main, .chk-hero, .progress-bar-wrap, .step, .step-card, .options, .btn-row,
.reg-intro, .form-grid, .result-header, .result-items, .cta-box, .cta-commercial {
  max-width: 100% !important;
  width: 100% !important;
  box-sizing: border-box !important;
}


:root {
  --blu: #1a3a5c;
  --blu-pa: #1d4ed8;
  --blu-dark: #1e3a8a;
  --verde: #16a34a;
  --verde-dark: #064e3b;
  --accento: #e8a020;
  --viola: #7c3aed;
  --testo: #1a1a2e;
  --grigio: #6b7280;
  --bordo: #e5e7eb;
  --bg: #f8f9ff;
  --bianco: #ffffff;
  --rosso: #dc2626;
  --giallo: #d97706;

  /* Pesi scoring */
  --peso-critico: 3;
  --peso-alto: 2;
  --peso-medio: 1;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body { width: 100%; overflow-x: hidden; }
body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--testo); line-height: 1.6; }

/* ==============================
   HERO — AUDIT ISTITUZIONALE
   ============================== */
.cpa-hero {
  background: linear-gradient(135deg, #0f2027 0%, #1e3a8a 50%, #1a3a5c 100%);
  color: #fff; padding: 48px 20px 36px; text-align: center; position: relative; overflow: hidden;
}
.cpa-hero::before {
  content: ''; position: absolute; inset: 0;
  background: repeating-linear-gradient(0deg, transparent, transparent 40px, rgba(255,255,255,.015) 40px, rgba(255,255,255,.015) 41px),
              repeating-linear-gradient(90deg, transparent, transparent 40px, rgba(255,255,255,.015) 40px, rgba(255,255,255,.015) 41px);
}
.hero-badge-istituz {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(232,160,32,.15); border: 1px solid rgba(232,160,32,.4);
  color: var(--accento); font-size: .68rem; font-weight: 700;
  letter-spacing: .12em; text-transform: uppercase;
  padding: 5px 16px; border-radius: 4px; margin-bottom: 16px;
}
.hero-badge-istituz::before { content: '🏛'; font-size: .9rem; }
.cpa-hero h1 {
  font-size: clamp(1.4rem, 3.5vw, 2.1rem); font-weight: 900;
  line-height: 1.2; margin-bottom: 8px;
}
.cpa-hero h1 em { color: var(--accento); font-style: normal; }
.hero-sub {
  font-size: .88rem; color: rgba(255,255,255,.75);
  max-width: 560px; margin: 0 auto 16px; line-height: 1.6;
}
.hero-norm-row { display: flex; gap: 6px; justify-content: center; flex-wrap: wrap; margin-bottom: 12px; }
.hero-norm {
  font-size: .65rem; font-weight: 700; letter-spacing: .06em;
  border: 1px solid rgba(255,255,255,.25); color: rgba(255,255,255,.8);
  padding: 3px 10px; border-radius: 3px; background: rgba(255,255,255,.06);
}
.hero-disclaimer {
  font-size: .7rem; color: rgba(255,255,255,.4);
  border-top: 1px solid rgba(255,255,255,.1); padding-top: 12px; margin-top: 4px;
}

/* ==============================
   SEZIONE FASE (livelli audit)
   ============================== */
.fase-banner {
  display: flex; align-items: center; gap: 10px;
  padding: 8px 16px; border-radius: 6px; margin-bottom: 14px;
  font-size: .72rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
}
.fase-1 { background: #eff6ff; color: var(--blu-pa); border-left: 3px solid var(--blu-pa); }
.fase-2 { background: #fff7ed; color: #c2410c; border-left: 3px solid #c2410c; }
.fase-3 { background: #fdf4ff; color: #7e22ce; border-left: 3px solid #7e22ce; }
.fase-dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; flex-shrink: 0; }

/* ==============================
   PROGRESS BAR AVANZATA
   ============================== */
.audit-progress-wrap { padding: 20px 20px 0; max-width: 860px; margin: 0 auto; }
.progress-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.progress-label-main { font-size: .72rem; font-weight: 700; color: var(--blu); letter-spacing: .04em; text-transform: uppercase; }
.progress-pct-badge {
  font-size: .7rem; font-weight: 700; background: var(--blu-dark); color: #fff;
  padding: 2px 10px; border-radius: 20px;
}
.progress-track { background: var(--bordo); border-radius: 99px; height: 8px; overflow: hidden; position: relative; }
.progress-fill {
  height: 100%; border-radius: 99px;
  background: linear-gradient(90deg, var(--blu-pa), var(--accento));
  transition: width .5s cubic-bezier(.4,0,.2,1);
  width: 0%;
}
.progress-steps-row { display: flex; justify-content: space-between; margin-top: 6px; }
.progress-step-dot {
  width: 6px; height: 6px; border-radius: 50%; background: var(--bordo);
  transition: background .3s; position: relative;
}
.progress-step-dot.done { background: var(--blu-pa); }
.progress-step-dot.current { background: var(--accento); box-shadow: 0 0 0 3px rgba(232,160,32,.3); }

/* ==============================
   MICRO-COPY CONTESTUALE
   ============================== */
.micro-copy {
  text-align: center; font-size: .72rem; color: var(--grigio);
  padding: 6px 0 14px; font-style: italic; letter-spacing: .01em;
}
.micro-copy strong { color: var(--blu); font-style: normal; }

/* ==============================
   STEP / AUDIT CARD
   ============================== */
.audit-wrap { max-width: 860px; margin: 0 auto; padding: 16px 20px 60px; }
.step { display: none; }
.step.active { display: block; animation: auditIn .3s ease; }
@keyframes auditIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }

.audit-card {
  background: var(--bianco); border: 1.5px solid var(--bordo);
  border-radius: 12px; padding: 22px; margin-bottom: 12px;
  box-shadow: 0 2px 16px rgba(30,58,138,.06);
}

/* Header domanda */
.q-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 14px; }
.q-step-info {
  display: flex; align-items: center; gap: 8px;
  font-size: .67rem; font-weight: 700; color: var(--blu-pa);
  letter-spacing: .08em; text-transform: uppercase;
}
.q-step-num {
  background: var(--blu-dark); color: #fff;
  width: 22px; height: 22px; border-radius: 50%;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: .68rem; font-weight: 700; flex-shrink: 0;
}
.q-peso {
  font-size: .63rem; font-weight: 700; padding: 2px 8px; border-radius: 20px;
  letter-spacing: .04em; text-transform: uppercase; white-space: nowrap;
}
.peso-critico { background: #fee2e2; color: var(--rosso); }
.peso-alto { background: #fef9c3; color: #854d0e; }
.peso-medio { background: #dbeafe; color: var(--blu-pa); }

/* Titolo audit */
.q-titolo-audit {
  font-size: .65rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
  color: var(--grigio); margin-bottom: 6px;
}
.q-titolo-audit span { color: var(--blu); }
.q-text {
  font-size: 1rem; font-weight: 700; color: var(--testo); line-height: 1.4; margin-bottom: 8px;
}
.q-norm-box {
  display: flex; gap: 8px; align-items: flex-start;
  background: #f0f5ff; border: 1px solid #c7d7fe; border-radius: 8px;
  padding: 9px 12px; margin-bottom: 14px; font-size: .78rem; line-height: 1.5;
}
.q-norm-icon { font-size: .95rem; flex-shrink: 0; margin-top: 1px; }
.q-norm-text { color: var(--blu); }
.q-norm-text strong { display: block; font-size: .8rem; color: var(--blu-dark); margin-bottom: 1px; }
.q-impact {
  display: inline-flex; align-items: center; gap: 5px;
  font-size: .67rem; font-weight: 600; color: var(--rosso);
  background: #fef2f2; padding: 2px 8px; border-radius: 20px; margin-top: 5px;
}

/* Opzioni */
.options { display: flex; flex-direction: column; gap: 8px; }
.opt {
  display: flex; align-items: flex-start; gap: 12px;
  padding: 12px 14px; border: 1.5px solid var(--bordo);
  border-radius: 10px; cursor: pointer; background: var(--bianco);
  transition: all .15s; position: relative; overflow: hidden;
}
.opt::before {
  content: ''; position: absolute; left: 0; top: 0; bottom: 0;
  width: 3px; background: transparent; transition: background .15s;
}
.opt:hover { border-color: var(--blu-pa); background: #f0f5ff; }
.opt:hover::before { background: var(--blu-pa); }
.opt.selected { border-color: var(--blu-pa); background: #eff6ff; }
.opt.selected::before { background: var(--blu-pa); }
.opt.selected-ok { border-color: var(--verde); background: #f0fdf4; }
.opt.selected-ok::before { background: var(--verde); }
.opt.selected-warn { border-color: var(--giallo); background: #fffbeb; }
.opt.selected-warn::before { background: var(--giallo); }
.opt.selected-ko { border-color: var(--rosso); background: #fef2f2; }
.opt.selected-ko::before { background: var(--rosso); }

.opt input[type=radio] { width: 17px; height: 17px; min-width: 17px; margin-top: 2px; accent-color: var(--blu-pa); cursor: pointer; }
.opt-icon { font-size: .95rem; flex-shrink: 0; margin-top: 1px; }
.opt-text { font-size: .87rem; font-weight: 600; line-height: 1.4; color: var(--testo); }
.opt-desc { font-size: .73rem; color: var(--grigio); margin-top: 3px; font-weight: 400; }

/* Micro-feedback inline dopo selezione */
.opt-feedback {
  display: none; margin-top: 6px; font-size: .72rem; padding: 5px 8px;
  border-radius: 6px; font-weight: 500; line-height: 1.4;
}
.opt.selected-ok .opt-feedback-ok { display: block; background: #f0fdf4; color: #15803d; }
.opt.selected-warn .opt-feedback-warn { display: block; background: #fffbeb; color: #92400e; }
.opt.selected-ko .opt-feedback-ko { display: block; background: #fef2f2; color: #b91c1c; }

/* ==============================
   BOTTONI
   ============================== */
.btn-row { display: flex; gap: 10px; justify-content: flex-end; margin-top: 14px; }
.btn-back {
  padding: 10px 18px; border: 1.5px solid var(--bordo); border-radius: 8px;
  background: var(--bianco); color: var(--grigio); font-size: .86rem;
  font-weight: 500; font-family: inherit; cursor: pointer;
}
.btn-next {
  padding: 11px 24px; border: none; border-radius: 8px;
  background: var(--blu-dark); color: #fff; font-size: .87rem;
  font-weight: 700; font-family: inherit; cursor: pointer;
  display: inline-flex; align-items: center; gap: 6px;
  transition: background .2s, transform .1s;
}
.btn-next:not(:disabled):hover { background: var(--blu-pa); transform: translateY(-1px); }
.btn-next:disabled { opacity: .35; cursor: not-allowed; }

/* ==============================
   FORM REGISTRAZIONE
   ============================== */
.reg-box {
  background: linear-gradient(135deg, #f0f5ff, #eff6ff);
  border: 1.5px solid #c7d7fe; border-radius: 10px;
  padding: 14px 16px; margin-bottom: 16px;
  display: flex; gap: 12px; align-items: flex-start;
}
.reg-box-icon { font-size: 1.5rem; flex-shrink: 0; }
.reg-box-text { font-size: .82rem; color: var(--blu-dark); line-height: 1.5; }
.reg-box-text strong { display: block; font-size: .9rem; margin-bottom: 2px; }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px; }
.field { display: flex; flex-direction: column; gap: 4px; }
.field label { font-size: .72rem; font-weight: 700; color: var(--testo); letter-spacing: .03em; text-transform: uppercase; }
.field input, .field select {
  padding: 9px 12px; border: 1.5px solid var(--bordo); border-radius: 8px;
  font-size: .87rem; font-family: inherit; color: var(--testo); background: var(--bianco);
  width: 100%; -webkit-appearance: none;
}
.field input:focus, .field select:focus { border-color: var(--blu-pa); outline: none; }
.privacy-row { display: flex; gap: 8px; align-items: flex-start; font-size: .74rem; color: var(--grigio); margin-top: 10px; line-height: 1.5; }
.privacy-row input { margin-top: 3px; flex-shrink: 0; min-width: 16px; accent-color: var(--blu-pa); }

/* ==============================
   PRE-OUTPUT SCREEN (AI analysis)
   ============================== */
.preoutput-screen {
  display: none; text-align: center; padding: 48px 20px;
}
.preoutput-screen.active { display: block; }
.ai-spinner-wrap { margin-bottom: 24px; }
.ai-spinner {
  width: 72px; height: 72px; border-radius: 50%;
  border: 3px solid var(--bordo);
  border-top-color: var(--blu-pa);
  animation: spin 1.2s linear infinite;
  margin: 0 auto 12px;
}
@keyframes spin { to { transform: rotate(360deg); } }
.ai-pulse {
  display: flex; justify-content: center; gap: 6px; margin-bottom: 20px;
}
.ai-pulse span {
  width: 8px; height: 8px; border-radius: 50%; background: var(--blu-pa);
  animation: pulse 1.4s ease-in-out infinite;
}
.ai-pulse span:nth-child(2) { animation-delay: .2s; }
.ai-pulse span:nth-child(3) { animation-delay: .4s; }
@keyframes pulse { 0%,80%,100% { opacity:.2; transform:scale(.8); } 40% { opacity:1; transform:scale(1); } }
.ai-label {
  font-size: .7rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
  color: var(--blu-pa); margin-bottom: 8px;
}
.ai-step-text { font-size: .85rem; color: var(--grigio); margin-bottom: 6px; min-height: 20px; }
.ai-norm-scanning {
  display: inline-block; font-size: .72rem; color: var(--grigio);
  background: #f0f5ff; border: 1px solid #c7d7fe;
  padding: 4px 12px; border-radius: 20px; margin-top: 8px;
}

/* ==============================
   RISULTATO
   ============================== */
.result-top { text-align: center; padding: 20px 0 16px; }
.cpa-score-wrap {
  display: inline-flex; flex-direction: column; align-items: center; margin-bottom: 16px;
}
.cpa-gauge-outer {
  position: relative; width: 130px; height: 130px;
  border-radius: 50%; display: flex; align-items: center; justify-content: center;
  margin-bottom: 10px;
}
.cpa-gauge {
  width: 130px; height: 130px; border-radius: 50%;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  border: 6px solid; box-shadow: 0 6px 24px rgba(0,0,0,.1);
}
.gauge-verde { border-color: var(--verde); color: var(--verde); background: #f0fdf4; }
.gauge-giallo { border-color: var(--giallo); color: var(--giallo); background: #fffbeb; }
.gauge-rosso { border-color: var(--rosso); color: var(--rosso); background: #fef2f2; }
.gauge-score { font-size: 2.2rem; font-weight: 900; line-height: 1; }
.gauge-label { font-size: .65rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; margin-top: 2px; }

.cpa-index-badge {
  font-size: .68rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
  padding: 4px 16px; border-radius: 20px; margin-bottom: 8px;
}
.badge-verde { background: #dcfce7; color: var(--verde); }
.badge-giallo { background: #fef9c3; color: var(--giallo); }
.badge-rosso { background: #fee2e2; color: var(--rosso); }

.result-ente-title { font-size: 1.3rem; font-weight: 900; color: var(--blu); margin-bottom: 4px; }
.result-sub { font-size: .87rem; color: var(--grigio); max-width: 500px; margin: 0 auto; line-height: 1.6; }

/* Score bar per item */
.result-items { display: flex; flex-direction: column; gap: 8px; margin: 16px 0; }
.result-item {
  display: flex; gap: 10px; align-items: flex-start;
  padding: 10px 14px; border-radius: 10px; border: 1.5px solid;
}
.item-ok { background: #f0fdf4; border-color: #bbf7d0; }
.item-warn { background: #fffbeb; border-color: #fde68a; }
.item-ko { background: #fef2f2; border-color: #fecaca; }
.item-icon { font-size: 1rem; flex-shrink: 0; margin-top: 1px; }
.item-text { font-size: .82rem; line-height: 1.5; flex: 1; }
.item-text strong { display: block; font-size: .86rem; margin-bottom: 2px; }
.item-peso-bar { width: 40px; flex-shrink: 0; display: flex; flex-direction: column; align-items: flex-end; gap: 2px; }
.peso-dots { display: flex; gap: 2px; }
.peso-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--bordo); }
.peso-dot.filled { background: var(--blu-pa); }

/* Benchmark box */
.benchmark-box {
  background: linear-gradient(135deg, #1e3a8a, #1a3a5c);
  border-radius: 12px; padding: 16px 18px; margin: 16px 0;
  display: flex; gap: 16px; align-items: center; flex-wrap: wrap;
}
.bench-stat { text-align: center; }
.bench-num { font-size: 1.4rem; font-weight: 900; color: var(--accento); display: block; }
.bench-lbl { font-size: .65rem; color: rgba(255,255,255,.65); line-height: 1.3; }
.bench-divider { width: 1px; background: rgba(255,255,255,.15); align-self: stretch; }

/* CustomerPA Score badge */
.cpa-score-finale {
  background: linear-gradient(135deg, var(--blu-dark), var(--blu-pa));
  border-radius: 12px; padding: 14px 18px; margin: 12px 0;
  display: flex; align-items: center; gap: 14px;
}
.cpa-score-icon { font-size: 2rem; flex-shrink: 0; }
.cpa-score-text h4 { color: #fff; font-size: .95rem; font-weight: 800; margin-bottom: 2px; }
.cpa-score-text p { color: rgba(255,255,255,.75); font-size: .78rem; line-height: 1.5; }
.cpa-score-val {
  margin-left: auto; font-size: 2rem; font-weight: 900; color: var(--accento);
  flex-shrink: 0; text-align: right;
}
.cpa-score-val small { display: block; font-size: .65rem; font-weight: 600; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .06em; }

/* Integration badge */
.integration-strip {
  display: flex; gap: 8px; flex-wrap: wrap; margin: 10px 0;
}
.int-badge {
  display: flex; align-items: center; gap: 6px; padding: 6px 12px;
  border: 1.5px solid var(--bordo); border-radius: 8px; font-size: .73rem;
  color: var(--grigio); background: var(--bianco); cursor: default;
}
.int-badge .int-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.int-active .int-dot { background: var(--verde); }
.int-soon .int-dot { background: var(--grigio); }
.int-badge strong { color: var(--testo); }

/* CTA COMMERCIALE */
.cta-section {
  margin-top: 16px; background: var(--bianco); border: 1.5px solid var(--bordo);
  border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,.06);
}
.cta-head {
  background: linear-gradient(135deg, #064e3b, #16a34a);
  padding: 22px; text-align: center;
}
.cta-head-eyebrow { font-size: .67rem; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: rgba(255,255,255,.6); margin-bottom: 7px; }
.cta-head h3 { font-size: 1.1rem; color: #fff; font-weight: 800; margin-bottom: 7px; line-height: 1.3; }
.cta-head h3 em { color: #6ee7b7; font-style: normal; }
.cta-head p { font-size: .83rem; color: rgba(255,255,255,.8); line-height: 1.6; margin: 0; }
.cta-body { padding: 18px 20px; }
.servizi-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 14px;
}
.serv-card {
  display: flex; gap: 8px; align-items: flex-start; padding: 10px;
  background: #f0fdf4; border-radius: 8px; border: 1px solid #bbf7d0;
}
.serv-card h4 { font-size: .79rem; font-weight: 700; color: #064e3b; margin-bottom: 2px; }
.serv-card p { font-size: .72rem; color: var(--grigio); line-height: 1.4; margin: 0; }
.output-box {
  background: linear-gradient(135deg, #eff6ff, #f0fdf4);
  border: 1.5px solid #bfdbfe; border-radius: 10px;
  padding: 14px 16px; margin-bottom: 14px; display: flex; gap: 12px;
}
.output-box h4 { font-size: .88rem; font-weight: 700; color: var(--blu-dark); margin-bottom: 5px; }
.output-box p { font-size: .8rem; color: var(--grigio); line-height: 1.6; margin-bottom: 8px; }
.pills { display: flex; gap: 5px; flex-wrap: wrap; }
.pill { font-size: .69rem; font-weight: 600; background: #dbeafe; color: var(--blu-pa); padding: 3px 8px; border-radius: 20px; }
.proof-bar {
  background: var(--blu-dark); border-radius: 10px;
  padding: 12px 14px; display: flex; gap: 12px; align-items: center;
  margin-bottom: 14px; flex-wrap: wrap;
}
.proof-stats { display: flex; gap: 14px; flex: 1; flex-wrap: wrap; }
.proof-stat { text-align: center; }
.proof-stat b { display: block; font-size: 1.15rem; font-weight: 700; color: var(--accento); }
.proof-stat small { font-size: .66rem; color: rgba(255,255,255,.65); line-height: 1.3; }
.cta-btns { display: flex; flex-direction: column; gap: 8px; }
.btn-cta-primary {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  background: linear-gradient(135deg, #064e3b, #16a34a); color: #fff;
  font-weight: 700; font-size: .9rem; padding: 13px; border-radius: 10px;
  text-decoration: none; border: none; cursor: pointer; font-family: inherit;
  box-shadow: 0 4px 14px rgba(22,163,74,.3);
}
.btn-cta-secondary {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  background: var(--bianco); color: var(--blu-pa); font-weight: 600;
  font-size: .87rem; padding: 11px; border-radius: 10px;
  text-decoration: none; border: 1.5px solid var(--blu-pa);
}
.btn-pdf {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  background: var(--bianco); color: var(--grigio); font-size: .82rem; padding: 9px;
  border-radius: 10px; border: 1px solid var(--bordo); cursor: pointer; font-family: inherit;
}
.cta-footer-note {
  background: #f8faff; border-top: 1px solid var(--bordo);
  padding: 11px 20px; display: flex; gap: 9px; font-size: .73rem; color: var(--grigio); line-height: 1.4;
}

@media (max-width: 580px) {
  .form-grid { grid-template-columns: 1fr; }
  .servizi-grid { grid-template-columns: 1fr; }
  .btn-row { flex-direction: column-reverse; }
  .btn-back, .btn-next { width: 100%; justify-content: center; }
  .proof-bar { flex-direction: column; }
  .cpa-score-finale { flex-wrap: wrap; }
  .percorso-steps { flex-direction: column; }
  .percorso-step::after { display: none; }
  .urgenza-strip { flex-wrap: wrap; }
  .urgenza-deadline { margin-left: 0; width: 100%; }
}

/* Pre-output items */
.preout-item {
  display: flex; gap: 10px; align-items: flex-start;
  font-size: .8rem; color: var(--testo); padding: 6px 0;
  border-bottom: 1px solid var(--bordo); line-height: 1.5;
  opacity: .3; transition: opacity .5s ease;
}
.preout-item:last-child { border-bottom: none; }
.preout-item.done { opacity: 1; }
.poi-dot {
  width: 8px; height: 8px; border-radius: 50%; background: var(--bordo);
  flex-shrink: 0; margin-top: 5px; transition: background .4s;
}
.preout-item.done .poi-dot { background: var(--verde); }

/* Scenario rischio */
.rischio-box {
  background: linear-gradient(135deg, #fff1f2, #fef2f2);
  border: 1.5px solid #fecaca; border-radius: 12px;
  padding: 16px 18px; margin: 16px 0;
}
.rischio-box-header {
  display: flex; align-items: center; gap: 10px;
  font-size: .72rem; font-weight: 700; letter-spacing: .08em;
  text-transform: uppercase; color: var(--rosso); margin-bottom: 10px;
}
.rischio-items { display: flex; flex-direction: column; gap: 7px; }
.rischio-item {
  display: flex; gap: 10px; align-items: flex-start;
  font-size: .82rem; color: var(--testo); line-height: 1.5;
}
.rischio-item-icon { font-size: .9rem; flex-shrink: 0; margin-top: 2px; }

/* Percorso operativo */
.percorso-box {
  background: linear-gradient(135deg, #f0f5ff, #eff6ff);
  border: 1.5px solid #bfdbfe; border-radius: 12px;
  padding: 16px 18px; margin: 16px 0;
}
.percorso-header {
  display: flex; align-items: center; gap: 10px;
  font-size: .72rem; font-weight: 700; letter-spacing: .08em;
  text-transform: uppercase; color: var(--blu-pa); margin-bottom: 14px;
}
.percorso-steps { display: flex; gap: 0; }
.percorso-step {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; text-align: center; position: relative;
  padding: 0 6px;
}
.percorso-step:not(:last-child)::after {
  content: '→'; position: absolute; right: -8px; top: 8px;
  font-size: 1rem; color: var(--blu-pa); font-weight: 700;
}
.ps-num {
  width: 28px; height: 28px; border-radius: 50%;
  background: var(--blu-dark); color: #fff;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem; font-weight: 800; margin-bottom: 6px;
}
.ps-label { font-size: .75rem; font-weight: 700; color: var(--blu-dark); margin-bottom: 3px; }
.ps-desc { font-size: .67rem; color: var(--grigio); line-height: 1.4; }

/* Cross-system BO */
.cross-box {
  background: linear-gradient(135deg, #fdf4ff, #ede9fe);
  border: 1.5px solid #c4b5fd; border-radius: 12px;
  padding: 16px 18px; margin: 16px 0;
  display: flex; gap: 14px; align-items: flex-start;
}
.cross-icon { font-size: 1.8rem; flex-shrink: 0; }
.cross-text h4 { font-size: .92rem; font-weight: 800; color: #4c1d95; margin-bottom: 5px; }
.cross-text p { font-size: .8rem; color: var(--grigio); line-height: 1.6; margin-bottom: 8px; }
.cross-link {
  display: inline-flex; align-items: center; gap: 6px;
  font-size: .78rem; font-weight: 700; color: #7c3aed;
  background: #ede9fe; padding: 5px 12px; border-radius: 20px;
  text-decoration: none; border: 1px solid #c4b5fd;
}

/* CTA urgenza istituzionale */
.urgenza-strip {
  background: linear-gradient(135deg, #1e3a8a, #0f2027);
  border-radius: 10px; padding: 14px 18px; margin-bottom: 14px;
  display: flex; gap: 12px; align-items: center;
}
.urgenza-icon { font-size: 1.3rem; flex-shrink: 0; }
.urgenza-text h4 { color: var(--accento); font-size: .88rem; font-weight: 800; margin-bottom: 3px; }
.urgenza-text p { color: rgba(255,255,255,.8); font-size: .78rem; line-height: 1.5; margin: 0; }
.urgenza-deadline {
  margin-left: auto; text-align: center; flex-shrink: 0;
  background: rgba(232,160,32,.15); border: 1px solid rgba(232,160,32,.4);
  border-radius: 8px; padding: 8px 14px;
}
.urgenza-deadline b { display: block; color: var(--accento); font-size: .85rem; font-weight: 800; }
.urgenza-deadline small { color: rgba(255,255,255,.6); font-size: .65rem; line-height: 1.3; }


/* ===== RESPONSIVE HOMEPAGE SEZIONI ===== */
@media (max-width: 768px) {
  .audit-wrap { padding: 12px 14px 40px; }
  .audit-card { padding: 16px; }
  .q-header { flex-direction: column; gap: 6px; }
  .q-peso { align-self: flex-start; }
  .percorso-steps { flex-direction: column; gap: 8px; }
  .percorso-step::after { display: none; }
  .benchmark-box { flex-direction: column; gap: 10px; }
  .bench-divider { display: none; }
  .cpa-score-finale { flex-wrap: wrap; }
  .urgenza-strip { flex-wrap: wrap; }
  .urgenza-deadline { margin-left: 0; width: 100%; text-align: left; }
  .integration-strip { flex-direction: column; }
  .servizi-grid { grid-template-columns: 1fr; }
  .proof-bar { flex-direction: column; }
  .preout-item { font-size: .75rem; }
}
@media (max-width: 480px) {
  .cpa-hero h1 { font-size: 1.3rem; }
  .btn-row { flex-direction: column-reverse; }
  .btn-back, .btn-next { width: 100%; justify-content: center; }
  .form-grid { grid-template-columns: 1fr; }
  .cpa-gauge { width: 100px; height: 100px; font-size: 1.6rem; }
  .cross-box { flex-direction: column; }
}
</style>
</head>
<body>

<div class="topbar">
  <div class="inner">
    <a href="https://andreatroisi.it" class="topbar-personal">andreatroisi.it</a>
    <a href="https://www.troisiricerche.net">troisiricerche.net</a>
    <a href="https://www.t-index.it">TR-Index</a>
    <a href="https://www.mappaturadellecompetenze.it">Mappatura Competenze</a>
    <a href="https://www.registrodellecompetenze.it">Registro Competenze</a>
    <a href="https://www.customerpa.it" class="topbar-active">CustomerPA</a>
    <a href="https://www.benessereorganizzativo.it">BenessereOrg.</a>
    <a href="https://www.troisiformazione.it">Formazione</a>
    <a href="https://www.tiplive.it">TIP</a>
    <a href="https://www.troisiinsight.it">TroisiInsight</a>
    <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
    <a href="https://www.dibattito-pubblico.it">Dibattito Pubblico</a>
    <a href="https://www.voiceinhub.it">VoiceInHub</a>
    <a href="https://www.governancefinanziaria.it">Governance Fin.</a>
    <a href="https://www.consulenzainternazionalizzazione.it">Internazionalizzazione</a>
    <a href="https://www.benesseredigitalegiovani.it">BDG</a>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="https://www.customerpa.it" class="navbar-brand">
      <div>
        <div class="logo-text">Customer<span>PA</span></div>
        <span class="subtitle">Piattaforma nazionale · Customer Satisfaction PA · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="https://www.customerpa.it#cpi">CPA Index</a>
      <a href="https://www.customerpa.it#strumenti">Strumenti</a>
      <a href="https://www.customerpa.it#grafici">Grafici</a>
      <a href="https://www.customerpa.it#metodo">Metodologia</a>
      <a href="https://www.customerpa.it#benchmark">Benchmark</a>
      <a href="https://www.customerpa.it#ecosistema">Ecosistema</a>
      <a href="https://www.customerpa.it#chi-siamo">Chi siamo</a>
      <a href="https://www.customerpa.it" class="btn-accedi">Accedi</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi demo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" aria-label="Menu" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- HERO -->
<div class="cpa-hero">
  <div class="hero-badge-istituz">Strumento di verifica istituzionale · Troisi Ricerche S.r.l.</div>
  <h1>Audit di Conformità<br><em>Customer Satisfaction PA</em></h1>
  <p class="hero-sub">Verifica in 8 punti il livello di adempimento normativo del tuo ente sulla rilevazione della soddisfazione degli utenti. Strumento riservato a dirigenti pubblici.</p>
  <div class="hero-norm-row">
    <span class="hero-norm">D.Lgs. 150/2009</span>
    <span class="hero-norm">D.L. 80/2021 · PIAO</span>
    <span class="hero-norm">D.Lgs. 33/2013</span>
    <span class="hero-norm">D.Lgs. 74/2017</span>
    <span class="hero-norm">Linee guida DFP</span>
  </div>
  <div class="hero-disclaimer">CustomerPA — Metodo Troisi · Il primo standard nazionale indipendente per la valutazione della conformità CS nella PA italiana · Accreditato MIUR come Ente di Ricerca</div>
</div>

<!-- PROGRESS -->
<div class="audit-progress-wrap">
  <div class="progress-header">
    <div class="progress-label-main" id="progress-label">Verifica base — Punto 1 di 8</div>
    <div class="progress-pct-badge" id="progress-pct">0%</div>
  </div>
  <div class="progress-track">
    <div class="progress-fill" id="progress-fill"></div>
  </div>
  <div class="progress-steps-row" id="progress-dots"></div>
</div>
<div class="micro-copy" id="micro-copy">Stai avviando una <strong>verifica ufficiale di conformità</strong> — i dati sono trattati con riservatezza</div>

<!-- CHECKER -->
<div class="audit-wrap">

  <!-- ========================
       FASE 1 — VERIFICA BASE
       ======================== -->

  <!-- STEP 1 — peso critico 3 -->
  <div class="step active" id="step-1">
    <div class="fase-banner fase-1"><span class="fase-dot"></span>Fase 1 — Verifica base · Adempimenti fondamentali</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">1</span>Piano della Performance / PIAO</div>
        <span class="q-peso peso-critico">⬆ Peso critico</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Pianificazione della performance</span></div>
      <div class="q-text">Il tuo ente ha formalmente approvato e pubblicato il Piano Integrato di Attività e Organizzazione (PIAO) per l'anno in corso, con sezione CS identificabile e misurabile?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.Lgs. 150/2009 art. 10 · D.L. 80/2021 (PIAO)</strong>
          Il PIAO sostituisce Piano Performance, Piano anticorruzione e altri strumenti. La sezione performance deve contenere obiettivi, indicatori e target di CS espliciti. La mancata adozione è segnalata dalla Corte dei Conti nelle verifiche sui controlli interni e può bloccare l'erogazione di premi al personale.
          <div class="q-impact">⚠️ Impatto: blocco premi personale · rilievo Corte dei Conti</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-1-2">
          <input type="radio" name="q1" value="2" onchange="sel(1,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — PIAO approvato, pubblicato e con sezione CS con indicatori e target</span>
            <span class="opt-desc">Disponibile su Amministrazione Trasparente, aggiornato all'anno in corso</span>
            <span class="opt-feedback opt-feedback-ok">✓ Adempimento verificato. Il tuo ente soddisfa il requisito base di pianificazione.</span>
          </span>
        </label>
        <label class="opt" id="opt-1-1">
          <input type="radio" name="q1" value="1" onchange="sel(1,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Parzialmente — PIAO approvato ma CS citata senza target misurabili</span>
            <span class="opt-desc">La CS è presente come enunciazione di principio ma senza KPI</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Gap rilevato. La CS senza target non soddisfa il requisito del DFP. Intervento necessario.</span>
          </span>
        </label>
        <label class="opt" id="opt-1-0">
          <input type="radio" name="q1" value="0" onchange="sel(1,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — PIAO non approvato, non pubblicato o privo di qualsiasi riferimento CS</span>
            <span class="opt-feedback opt-feedback-ko">✗ Non conformità critica. Questo gap è rilevabile nelle verifiche di controllo interno.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row"><button class="btn-next" id="btn-1" disabled onclick="goNext(1)">Punto successivo →</button></div>
  </div>

  <!-- STEP 2 — peso critico 3 -->
  <div class="step" id="step-2">
    <div class="fase-banner fase-1"><span class="fase-dot"></span>Fase 1 — Verifica base · Adempimenti fondamentali</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">2</span>Rilevazione Customer Satisfaction</div>
        <span class="q-peso peso-critico">⬆ Peso critico</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Obbligo di rilevazione annuale</span></div>
      <div class="q-text">Il tuo ente ha formalmente condotto, nell'ultimo anno solare, almeno un'indagine di customer satisfaction sui servizi erogati ai cittadini?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.Lgs. 150/2009 artt. 8 e 29 · Linee guida DFP 2017</strong>
          L'obbligo è annuale e riguarda i servizi principali erogati al pubblico. Una rilevazione informale (box suggerimenti, modulo web non strutturato) non soddisfa l'obbligo. Il campione deve essere statisticamente rappresentativo.
          <div class="q-impact">⚠️ Impatto: invalidazione ciclo performance · rilievo OIV · esposizione Corte dei Conti</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-2-2">
          <input type="radio" name="q2" value="2" onchange="sel(2,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — indagine condotta con metodo statistico validato e campione adeguato</span>
            <span class="opt-desc">Formula di Cochran o equivalente, questionario strutturato</span>
            <span class="opt-feedback opt-feedback-ok">✓ Adempimento verificato. Rilevazione conforme agli standard DFP.</span>
          </span>
        </label>
        <label class="opt" id="opt-2-1">
          <input type="radio" name="q2" value="1" onchange="sel(2,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Sì — ma con modalità informali non strutturate</span>
            <span class="opt-desc">Box suggerimenti, modulo online generico, raccolta non campionata</span>
            <span class="opt-feedback opt-feedback-warn">⚠ La raccolta informale non soddisfa l'obbligo normativo. Rilevante in sede di verifica OIV.</span>
          </span>
        </label>
        <label class="opt" id="opt-2-0">
          <input type="radio" name="q2" value="0" onchange="sel(2,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — nessuna indagine nell'ultimo anno solare</span>
            <span class="opt-feedback opt-feedback-ko">✗ Non conformità critica. L'inadempimento è documentabile e sanzionabile.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(2)">← Indietro</button>
      <button class="btn-next" id="btn-2" disabled onclick="goNext(2)">Punto successivo →</button>
    </div>
  </div>

  <!-- STEP 3 — peso alto 2 -->
  <div class="step" id="step-3">
    <div class="fase-banner fase-1"><span class="fase-dot"></span>Fase 1 — Verifica base · Adempimenti fondamentali</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">3</span>Pubblicazione su Amministrazione Trasparente</div>
        <span class="q-peso peso-alto">↑ Peso alto</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Obblighi di trasparenza</span></div>
      <div class="q-text">I risultati delle rilevazioni CS sono stati pubblicati nella sezione "Performance" di Amministrazione Trasparente, con data di aggiornamento verificabile?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.Lgs. 33/2013 art. 20 · D.Lgs. 97/2016</strong>
          L'obbligo di pubblicazione riguarda i risultati aggregati, non i dati individuali. L'omissione configura inadempimento sanzionabile da ANAC con misure interdittive e pubblicazione dell'inadempimento sul sito ANAC.
          <div class="q-impact">⚠️ Impatto: sanzione ANAC · riduzione punteggio trasparenza · rilievo Corte dei Conti</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-3-2">
          <input type="radio" name="q3" value="2" onchange="sel(3,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — pubblicati, aggiornati e con riferimento all'anno corrente</span>
            <span class="opt-feedback opt-feedback-ok">✓ Trasparenza verificata. L'obbligo di pubblicazione risulta assolto.</span>
          </span>
        </label>
        <label class="opt" id="opt-3-1">
          <input type="radio" name="q3" value="1" onchange="sel(3,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Parzialmente — pubblicati ma non aggiornati o incompleti</span>
            <span class="opt-desc">Mancano alcune annualità o la sezione non è facilmente accessibile</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Pubblicazione incompleta. Rischio di rilievo in caso di accesso civico o ispezione ANAC.</span>
          </span>
        </label>
        <label class="opt" id="opt-3-0">
          <input type="radio" name="q3" value="0" onchange="sel(3,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — non pubblicati su Amministrazione Trasparente</span>
            <span class="opt-feedback opt-feedback-ko">✗ Inadempimento sanzionabile da ANAC. Intervenire immediatamente.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(3)">← Indietro</button>
      <button class="btn-next" id="btn-3" disabled onclick="goNext(3)">Punto successivo →</button>
    </div>
  </div>

  <!-- ============================
       FASE 2 — VERIFICA OPERATIVA
       ============================ -->

  <!-- STEP 4 — peso critico 3 -->
  <div class="step" id="step-4">
    <div class="fase-banner fase-2"><span class="fase-dot"></span>Fase 2 — Verifica operativa · Integrazione nel sistema di valutazione</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">4</span>Collegamento alla Performance Dirigenziale</div>
        <span class="q-peso peso-critico">⬆ Peso critico</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Performance individuale e CS</span></div>
      <div class="q-text">I risultati della CS sono esplicitamente collegati al sistema di valutazione della performance individuale dei dirigenti e dei responsabili di servizio?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.Lgs. 150/2009 art. 8 c.1 lett. c) · D.Lgs. 74/2017</strong>
          La CS è una delle dimensioni obbligatorie della performance organizzativa da cui dipende la valutazione individuale. La mancata connessione rende il sistema di valutazione non conforme e può essere contestata dall'OIV nella validazione della Relazione sulla Performance.
          <div class="q-impact">⚠️ Impatto: invalidazione valutazione individuale · contestazione OIV · rilievo DFP</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-4-2">
          <input type="radio" name="q4" value="2" onchange="sel(4,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — il collegamento è esplicito nel sistema di valutazione e nei contratti dirigenziali</span>
            <span class="opt-feedback opt-feedback-ok">✓ Integrazione verificata. Il sistema di valutazione soddisfa il requisito normativo.</span>
          </span>
        </label>
        <label class="opt" id="opt-4-1">
          <input type="radio" name="q4" value="1" onchange="sel(4,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Solo in parte — la CS incide indirettamente sulla valutazione ma non è esplicita</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Integrazione parziale. Il collegamento implicito non soddisfa il requisito art. 8.</span>
          </span>
        </label>
        <label class="opt" id="opt-4-0">
          <input type="radio" name="q4" value="0" onchange="sel(4,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — la CS non è collegata alla valutazione della performance individuale</span>
            <span class="opt-feedback opt-feedback-ko">✗ Non conformità critica. Il sistema di valutazione è strutturalmente inadeguato.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(4)">← Indietro</button>
      <button class="btn-next" id="btn-4" disabled onclick="goNext(4)">Punto successivo →</button>
    </div>
  </div>

  <!-- STEP 5 — peso alto 2 -->
  <div class="step" id="step-5">
    <div class="fase-banner fase-2"><span class="fase-dot"></span>Fase 2 — Verifica operativa · Integrazione nel sistema di valutazione</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">5</span>Validazione OIV / Nucleo di Valutazione</div>
        <span class="q-peso peso-alto">↑ Peso alto</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Controllo indipendente OIV</span></div>
      <div class="q-text">L'OIV (o Nucleo di Valutazione) ha esplicitamente validato il processo di rilevazione CS nell'ultima Relazione sulla Performance approvata?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.Lgs. 150/2009 art. 14 · D.P.R. 105/2016</strong>
          L'OIV ha l'obbligo di verificare la correttezza metodologica delle rilevazioni e di attestarne l'adeguatezza nella Relazione sulla Performance. La mancata validazione indebolisce l'intero sistema di controllo interno e può bloccare l'erogazione dei premi di produttività.
          <div class="q-impact">⚠️ Impatto: blocco premi · invalidazione relazione performance · rilievo DFP</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-5-2">
          <input type="radio" name="q5" value="2" onchange="sel(5,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — l'OIV ha validato esplicitamente il processo CS nella Relazione sulla Performance</span>
            <span class="opt-feedback opt-feedback-ok">✓ Validazione verificata. Il controllo indipendente è correttamente esercitato.</span>
          </span>
        </label>
        <label class="opt" id="opt-5-1">
          <input type="radio" name="q5" value="1" onchange="sel(5,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Parzialmente — la CS è menzionata nella Relazione ma non validata nel merito</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Validazione formale ma non sostanziale. Gap rilevante in sede di audit DFP.</span>
          </span>
        </label>
        <label class="opt" id="opt-5-0">
          <input type="radio" name="q5" value="0" onchange="sel(5,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — l'OIV non ha validato o l'ente non ha OIV attivo</span>
            <span class="opt-feedback opt-feedback-ko">✗ Assenza di controllo indipendente. Situazione critica per il ciclo della performance.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(5)">← Indietro</button>
      <button class="btn-next" id="btn-5" disabled onclick="goNext(5)">Punto successivo →</button>
    </div>
  </div>

  <!-- ============================
       FASE 3 — VERIFICA AVANZATA
       ============================ -->

  <!-- STEP 6 — peso alto 2 -->
  <div class="step" id="step-6">
    <div class="fase-banner fase-3"><span class="fase-dot"></span>Fase 3 — Verifica avanzata · Qualità e continuità del sistema</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">6</span>Metodo statistico e campionamento</div>
        <span class="q-peso peso-alto">↑ Peso alto</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Adeguatezza metodologica</span></div>
      <div class="q-text">Le rilevazioni adottano un campione statisticamente significativo, un questionario con scale validate e una procedura di raccolta dati documentata?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>Linee guida DFP 2017 · Metodologia Troisi Ricerche</strong>
          La Corte dei Conti e il DFP hanno più volte segnalato che rilevazioni metodologicamente inadeguate non soddisfano l'obbligo normativo, anche se formalmente condotte. Il campionamento deve seguire la formula di Cochran o equivalente. Le scale devono essere validate (SERVQUAL, Likert 5 o 7 punti).
          <div class="q-impact">⚠️ Impatto: invalidazione formale della rilevazione · rilievo OIV · non utilizzabilità per benchmark</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-6-2">
          <input type="radio" name="q6" value="2" onchange="sel(6,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — campionamento statistico documentato e questionario con scale validate</span>
            <span class="opt-desc">Formula di Cochran o equivalente · Scale SERVQUAL o Likert validate</span>
            <span class="opt-feedback opt-feedback-ok">✓ Metodo conforme. La rilevazione è difendibile in sede di audit.</span>
          </span>
        </label>
        <label class="opt" id="opt-6-1">
          <input type="radio" name="q6" value="1" onchange="sel(6,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Parzialmente — questionario strutturato ma campionamento non documentato</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Il metodo è parziale. Senza campionamento documentato la rilevazione è contestabile.</span>
          </span>
        </label>
        <label class="opt" id="opt-6-0">
          <input type="radio" name="q6" value="0" onchange="sel(6,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — raccolta informale senza campionamento né scale validate</span>
            <span class="opt-feedback opt-feedback-ko">✗ La rilevazione non è metodologicamente difendibile. Non soddisfa l'obbligo normativo.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(6)">← Indietro</button>
      <button class="btn-next" id="btn-6" disabled onclick="goNext(6)">Punto successivo →</button>
    </div>
  </div>

  <!-- STEP 7 — peso medio 1 -->
  <div class="step" id="step-7">
    <div class="fase-banner fase-3"><span class="fase-dot"></span>Fase 3 — Verifica avanzata · Qualità e continuità del sistema</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">7</span>CS nel PIAO con indicatori misurabili</div>
        <span class="q-peso peso-medio">= Peso standard</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Integrazione nel PIAO</span></div>
      <div class="q-text">Nel PIAO vigente la Customer Satisfaction è presente come obiettivo misurabile con indicatori quantitativi e target espliciti — non come semplice enunciazione di principio?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.L. 80/2021 · Linee guida PIAO Ministero PA</strong>
          La presenza della CS nel PIAO come enunciazione generica ("si prevede di rilevare la soddisfazione") non costituisce obiettivo misurabile. Servono: indicatore (es. CustomerPA Index), target numerico (es. ≥7/10), modalità di rilevazione e responsabile.
          <div class="q-impact">⚠️ Impatto: obiettivo non rendicontabile · Relazione Performance non validabile dall'OIV</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-7-2">
          <input type="radio" name="q7" value="2" onchange="sel(7,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — CS presente con indicatore, target numerico e responsabile identificato</span>
            <span class="opt-feedback opt-feedback-ok">✓ Integrazione completa. La CS è rendicontabile e validabile dall'OIV.</span>
          </span>
        </label>
        <label class="opt" id="opt-7-1">
          <input type="radio" name="q7" value="1" onchange="sel(7,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Parzialmente — CS citata ma senza target o senza indicatore misurabile</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Enunciazione di principio. Non rendicontabile. Da integrare entro il prossimo PIAO.</span>
          </span>
        </label>
        <label class="opt" id="opt-7-0">
          <input type="radio" name="q7" value="0" onchange="sel(7,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — la CS non è presente come obiettivo nel PIAO</span>
            <span class="opt-feedback opt-feedback-ko">✗ Assenza totale. Il PIAO non è conforme alle linee guida ministeriali sulla CS.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(7)">← Indietro</button>
      <button class="btn-next" id="btn-7" disabled onclick="goNext(7)">Punto successivo →</button>
    </div>
  </div>

  <!-- STEP 8 — peso medio 1 -->
  <div class="step" id="step-8">
    <div class="fase-banner fase-3"><span class="fase-dot"></span>Fase 3 — Verifica avanzata · Qualità e continuità del sistema</div>
    <div class="audit-card">
      <div class="q-header">
        <div class="q-step-info"><span class="q-step-num">8</span>Piani di miglioramento formali</div>
        <span class="q-peso peso-medio">= Peso standard</span>
      </div>
      <div class="q-titolo-audit">Verifica di conformità: <span>Chiusura del ciclo della performance</span></div>
      <div class="q-text">A seguito delle rilevazioni CS il tuo ente ha adottato formalmente piani di miglioramento dei servizi, con azioni tracciabili, responsabili e scadenze documentate?</div>
      <div class="q-norm-box">
        <div class="q-norm-icon">⚖️</div>
        <div class="q-norm-text">
          <strong>D.Lgs. 150/2009 · Ciclo della performance · Linee guida DFP</strong>
          Il ciclo della performance non si chiude con la rilevazione: i dati CS devono alimentare azioni correttive documentate. Senza piani formali la rilevazione è priva di valore ai fini del ciclo e non può essere utilizzata come base per la Relazione sulla Performance.
          <div class="q-impact">⚠️ Impatto: ciclo performance incompleto · CS non rendicontabile · rilievo OIV</div>
        </div>
      </div>
      <div class="options">
        <label class="opt" id="opt-8-2">
          <input type="radio" name="q8" value="2" onchange="sel(8,2,'ok')">
          <span class="opt-icon">✅</span>
          <span>
            <span class="opt-text">Sì — piani formali approvati, con responsabili e scadenze, monitorati</span>
            <span class="opt-feedback opt-feedback-ok">✓ Ciclo chiuso correttamente. Il tuo ente ha un sistema CS completo e rendicontabile.</span>
          </span>
        </label>
        <label class="opt" id="opt-8-1">
          <input type="radio" name="q8" value="1" onchange="sel(8,1,'warn')">
          <span class="opt-icon">⚠️</span>
          <span>
            <span class="opt-text">Parzialmente — alcune azioni sono state intraprese ma non documentate formalmente</span>
            <span class="opt-feedback opt-feedback-warn">⚠ Azioni informali. Il ciclo è incompiuto. Da formalizzare per il prossimo ciclo.</span>
          </span>
        </label>
        <label class="opt" id="opt-8-0">
          <input type="radio" name="q8" value="0" onchange="sel(8,0,'ko')">
          <span class="opt-icon">❌</span>
          <span>
            <span class="opt-text">No — i dati CS non hanno generato alcun piano di miglioramento</span>
            <span class="opt-feedback opt-feedback-ko">✗ Ciclo della performance aperto. La rilevazione è fine a sé stessa e non rendicontabile.</span>
          </span>
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack(8)">← Indietro</button>
      <button class="btn-next" id="btn-8" disabled onclick="goNext(8)">Completa l'audit →</button>
    </div>
  </div>

  <!-- REGISTRAZIONE -->
  <div class="step" id="step-reg">
    <div class="audit-card">
      <div class="q-step-info" style="margin-bottom:14px"><span class="q-step-num">✓</span>Audit completato — Generazione report</div>
      <div class="reg-box">
        <div class="reg-box-icon">🏛</div>
        <div class="reg-box-text">
          <strong>Il tuo CustomerPA Score è pronto</strong>
          Inserisci i dati istituzionali per ricevere il report completo con CustomerPA Score, gap normativi, benchmark nazionale e raccomandazioni operative. Il report è riservato e conforme al GDPR.
        </div>
      </div>
      <div class="form-grid">
        <div class="field"><label>Nome *</label><input type="text" id="f-nome" oninput="ckReg()"></div>
        <div class="field"><label>Cognome *</label><input type="text" id="f-cognome" oninput="ckReg()"></div>
      </div>
      <div class="form-grid">
        <div class="field"><label>Email istituzionale *</label><input type="email" id="f-email" placeholder="nome@comune.it" oninput="ckReg()"></div>
        <div class="field">
          <label>Ruolo</label>
          <select id="f-ruolo">
            <option value="">Seleziona...</option>
            <option>Sindaco / Presidente</option>
            <option>Segretario Generale</option>
            <option>Direttore Generale</option>
            <option>Dirigente / Responsabile Servizio</option>
            <option>Responsabile Performance / OIV</option>
            <option>Responsabile Trasparenza</option>
            <option>Funzionario amministrativo</option>
            <option>Consulente / Mandatario esterno</option>
          </select>
        </div>
      </div>
      <div class="form-grid">
        <div class="field"><label>Ente *</label><input type="text" id="f-comune" placeholder="es. Comune di Bari" oninput="ckReg()"></div>
        <div class="field">
          <label>Tipologia ente</label>
          <select id="f-tipo">
            <option value="">Seleziona...</option>
            <optgroup label="Enti locali">
              <option>Comune fino a 5.000 ab.</option>
              <option>Comune 5.001–15.000 ab.</option>
              <option>Comune 15.001–50.000 ab.</option>
              <option>Comune oltre 50.000 ab.</option>
              <option>Provincia</option>
              <option>Regione</option>
              <option>Unione di Comuni</option>
            </optgroup>
            <optgroup label="Sanità e partecipate">
              <option>ASL / AO / IRCCS</option>
              <option>Società in-house (D.Lgs. 175/2016)</option>
              <option>CCIAA</option>
            </optgroup>
            <optgroup label="Altre PA">
              <option>Ministero / Ente centrale</option>
              <option>Istituzione scolastica</option>
              <option>Altro ente pubblico</option>
            </optgroup>
          </select>
        </div>
      </div>
      <div class="privacy-row">
        <input type="checkbox" id="f-privacy" onchange="ckReg()">
        <label for="f-privacy">Acconsento al trattamento dei dati personali da parte di <strong>Troisi Ricerche S.r.l.</strong> ai sensi del Reg. UE 2016/679 (GDPR) per ricevere il CustomerPA Report e comunicazioni pertinenti. <a href="https://www.iubenda.com/privacy-policy/814914" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" target="_blank" style="color:var(--blu-pa)">Privacy Policy</a> *</label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-back" onclick="goBack('reg')">← Rivedi le risposte</button>
      <button class="btn-next" id="btn-reg" disabled onclick="showPreOutput()">🔍 Genera il CustomerPA Report →</button>
    </div>
  </div>

  <!-- PRE-OUTPUT SCREEN -->
  <div class="preoutput-screen" id="preoutput">
    <div class="ai-spinner-wrap">
      <div class="ai-spinner"></div>
    </div>
    <div class="ai-label">Sistema CustomerPA — Analisi in corso</div>
    <div class="ai-pulse"><span></span><span></span><span></span></div>
    <div class="ai-step-text" id="ai-step-text">Acquisizione dati istituzionali...</div>
    <div class="ai-norm-scanning" id="ai-norm-text">Verifica D.Lgs. 150/2009 art. 10...</div>

    <div style="max-width:440px;margin:20px auto 0;background:#fff;border:1.5px solid var(--bordo);border-radius:12px;padding:16px 18px;text-align:left;">
      <div style="font-size:.68rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--blu-pa);margin-bottom:10px">Dimensioni di analisi in elaborazione</div>
      <div class="preout-item" id="poi-1">
        <span class="poi-dot"></span>
        <span><strong>Conformità normativa</strong> — D.Lgs. 150/2009, D.L. 80/2021, D.Lgs. 33/2013</span>
      </div>
      <div class="preout-item" id="poi-2">
        <span class="poi-dot"></span>
        <span><strong>Qualità metodologica</strong> — campionamento, scale, struttura rilevazione</span>
      </div>
      <div class="preout-item" id="poi-3">
        <span class="poi-dot"></span>
        <span><strong>Integrazione performance</strong> — PIAO, OIV, valutazione individuale</span>
      </div>
      <div class="preout-item" id="poi-4">
        <span class="poi-dot"></span>
        <span><strong>Scoring pesato a 3 livelli</strong> — ponderazione criteri critici/alti/standard</span>
      </div>
      <div class="preout-item" id="poi-5">
        <span class="poi-dot"></span>
        <span><strong>Benchmark nazionale</strong> — confronto con 200+ PA italiane monitorate</span>
      </div>
    </div>
    <p style="font-size:.73rem;color:var(--grigio);margin-top:14px;max-width:400px;margin-left:auto;margin-right:auto;line-height:1.6;">Il CustomerPA Score viene calcolato su un modello a pesi differenziati. I criteri critici (peso 3) incidono 3 volte di più dei criteri standard (peso 1) sul punteggio finale.</p>
  </div>

  <!-- RISULTATO -->
  <div class="step" id="step-result">

    <!-- Score -->
    <div class="result-top">
      <div class="cpa-score-wrap">
        <div class="cpa-gauge" id="result-gauge"></div>
        <div class="cpa-index-badge" id="result-badge" style="margin-top:8px"></div>
      </div>
      <div class="result-ente-title" id="result-title"></div>
      <div class="result-sub" id="result-sub"></div>
    </div>

    <!-- CustomerPA Score -->
    <div class="cpa-score-finale" id="cpa-score-box"></div>

    <!-- Integrazione futura -->
    <div style="margin:10px 0 4px;font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--grigio)">Ecosistema Troisi Ricerche — integrazione attiva</div>
    <div class="integration-strip">
      <div class="int-badge int-active">
        <span class="int-dot"></span>
        <span><strong>CustomerPA</strong> — questo strumento</span>
      </div>
      <div class="int-badge int-soon">
        <span class="int-dot"></span>
        <span><strong>Benessere Organizzativo</strong> — disponibile</span>
      </div>
      <div class="int-badge int-soon">
        <span class="int-dot"></span>
        <span><strong>TR-Index PA</strong> — in arrivo</span>
      </div>
      <div class="int-badge int-soon">
        <span class="int-dot"></span>
        <span><strong>Certificazione CustomerPA</strong> — in arrivo</span>
      </div>
    </div>

    <!-- Dettaglio punti -->
    <div style="margin:16px 0 8px;font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--grigio)">Dettaglio verifica per punto</div>
    <div class="result-items" id="result-items"></div>

    <!-- Benchmark -->
    <div class="benchmark-box" id="benchmark-box"></div>

    <!-- BLOCCO CERTIFICAZIONE -->
    <div id="cert-block" style="margin:16px 0;background:linear-gradient(135deg,#1e3a8a,#1a3a5c);border-radius:12px;padding:18px 20px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-20px;right:-20px;width:100px;height:100px;background:radial-gradient(circle,rgba(232,160,32,.15),transparent 70%);pointer-events:none"></div>
      <div style="font-size:.67rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.5);margin-bottom:8px">🏅 Standard nazionale — Certificazione CustomerPA</div>
      <div style="display:flex;gap:14px;align-items:flex-start">
        <div style="font-size:2rem;flex-shrink:0">🏅</div>
        <div>
          <div style="font-size:.95rem;font-weight:800;color:#fff;margin-bottom:5px">Certificazione CustomerPA — Metodo Troisi</div>
          <p style="font-size:.8rem;color:rgba(255,255,255,.8);line-height:1.6;margin-bottom:10px">Questo audit costituisce la base documentale per accedere alla <strong style="color:var(--accento)">Certificazione CustomerPA</strong>, il primo standard nazionale indipendente per la valutazione della qualità del sistema CS nella Pubblica Amministrazione italiana. La certificazione è rilasciata da Troisi Ricerche S.r.l. — Istituto accreditato MIUR come Ente di Ricerca — e attesta che il sistema CS dell'ente è conforme al D.Lgs. 150/2009 e alle Linee guida DFP.</p>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <span style="font-size:.7rem;font-weight:600;background:rgba(232,160,32,.2);border:1px solid rgba(232,160,32,.4);color:var(--accento);padding:3px 10px;border-radius:20px">✅ Allegabile al PIAO</span>
            <span style="font-size:.7rem;font-weight:600;background:rgba(232,160,32,.2);border:1px solid rgba(232,160,32,.4);color:var(--accento);padding:3px 10px;border-radius:20px">✅ Validabile dall'OIV</span>
            <span style="font-size:.7rem;font-weight:600;background:rgba(232,160,32,.2);border:1px solid rgba(232,160,32,.4);color:var(--accento);padding:3px 10px;border-radius:20px">✅ Standard nazionale indipendente</span>
            <span style="font-size:.7rem;font-weight:600;background:rgba(232,160,32,.2);border:1px solid rgba(232,160,32,.4);color:var(--accento);padding:3px 10px;border-radius:20px">✅ Accreditato MIUR</span>
          </div>
        </div>
      </div>
    </div>

    <!-- CTA COMMERCIALE -->
    <div class="cta-section">
      <div class="cta-head">
        <div class="cta-head-eyebrow">⚖️ Non una consulenza — un adempimento necessario</div>
        <h3>Questo report è la diagnosi.<br>La <em>conformità reale</em> richiede un piano operativo.</h3>
        <p>La prossima Relazione sulla Performance sarà valutata dall'OIV. Il prossimo ciclo del PIAO dovrà documentare obiettivi CS misurabili. Troisi Ricerche trasforma questo audit in un'indagine ufficiale, difendibile in ogni sede istituzionale — Giunta, OIV, Corte dei Conti.</p>
      </div>
      <div class="cta-body">
        <div style="font-size:.67rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#16a34a;margin-bottom:11px">🔧 Il nostro metodo operativo</div>
        <div class="servizi-grid">
          <div class="serv-card"><span style="font-size:1.1rem;flex-shrink:0">📱</span><div><h4>Rilevazione sul campo</h4><p>Tablet, roll-up agli sportelli, QR code — il cittadino risponde in 2 minuti senza frizioni</p></div></div>
          <div class="serv-card"><span style="font-size:1.1rem;flex-shrink:0">🔗</span><div><h4>Survey digitale GDPR</h4><p>Link e form online conformi GDPR, con consenso informato, anonimizzazione e dati certificati</p></div></div>
          <div class="serv-card"><span style="font-size:1.1rem;flex-shrink:0">🎓</span><div><h4>Formazione personale</h4><p>Formiamo i dipendenti dalla gestione dello sportello alla lettura dei dati di soddisfazione</p></div></div>
          <div class="serv-card"><span style="font-size:1.1rem;flex-shrink:0">📊</span><div><h4>Metodo Cochran · SERVQUAL</h4><p>Campionamento scientifico, scale validate, piena difendibilità in sede di audit OIV e DFP</p></div></div>
          <div class="serv-card"><span style="font-size:1.1rem;flex-shrink:0">🗺️</span><div><h4>Multicanale CAWI/CATI/PAPI</h4><p>Raggiungiamo tutti i segmenti di utenza, inclusi i non digitali e i fragili</p></div></div>
          <div class="serv-card"><span style="font-size:1.1rem;flex-shrink:0">🤖</span><div><h4>Dashboard AI + CustomerPA Index</h4><p>Elaborazione automatica, benchmark con gli altri enti, alert sui gap critici in tempo reale</p></div></div>
        </div>
        <div class="output-box">
          <span style="font-size:1.6rem;flex-shrink:0">📋</span>
          <div>
            <h4>Il risultato: un report che vale in Giunta</h4>
            <p>Consegniamo il <strong>Report ufficiale CustomerPA</strong> con CustomerPA Score, benchmark nazionale, analisi per servizio e piano di miglioramento. Conforme al D.Lgs. 150/2009 — allegabile alla Relazione della Performance e approvabile dalla Giunta Comunale o dal Consiglio di Amministrazione.</p>
            <div class="pills">
              <span class="pill">✅ Conforme D.Lgs. 150/2009</span>
              <span class="pill">✅ Allegabile Relazione Performance</span>
              <span class="pill">✅ Benchmark nazionale</span>
              <span class="pill">✅ Approvabile in Giunta/CdA</span>
              <span class="pill">✅ Accreditato MIUR — Ente di Ricerca</span>
            </div>
          </div>
        </div>
        <div class="proof-bar">
          <div class="proof-stats">
            <div class="proof-stat"><b>20+</b><small>anni sul<br>mercato</small></div>
            <div class="proof-stat"><b>500+</b><small>ricerche<br>realizzate</small></div>
            <div class="proof-stat"><b>200+</b><small>enti<br>serviti</small></div>
            <div class="proof-stat"><b>ISO</b><small>9001:2015<br>TÜV</small></div>
          </div>
          <div style="border-left:1px solid rgba(255,255,255,.15);padding-left:14px;text-align:center;min-width:80px">
            <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAJABAADASIAAhEBAxEB/8QAHQABAAICAwEBAAAAAAAAAAAAAAcIBQYCAwQBCf/EAE4QAAEDBAAEBAMDCAYGCQMFAAABAgMEBQYRBxIhMRNBUWEiMnEIFIEVI0JSkaGxwRYzNnJz0SQ0YpKy4RclNTdDU1VjdFRkkyYngoOi/8QAHAEBAAEFAQEAAAAAAAAAAAAAAAYCAwQFBwEI/8QAPREBAAEDAgQDBAgEBgIDAQAAAAECAwQFEQYSITFBUXETMmGxIjM0gZGhwdEHFHLhFSM1QqLwQ4IWUvFE/9oADAMBAAIRAxEAPwC5YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGt5tmthxKjdPdKyNr9bbEi7e78BM7K7duu7VFNEbzLZDwXC82q3tVa24U0Gk3p8qIpWPOuPF/uz309jjbb6ZenMvV6+6L5EU3S6XK6TLLca6epevnI9VLU3Y8ElxeGL1yN71XL8O8rjXLi1g1C5WS3drnJ+o1XfwMYvHTh+juX8oy/8A4Xf5FP0anofdIUe1ltaeF8SI61TP4fsudQcX8FrHI2O7I1V/WYqG2W2/2W5Na6iudLNvsjZUVf2FBFai+R6bfXVtvmSahq5qZ6LvcblQ9i7PitXeFbMx/l1zHr1foKnUFSMI44ZPY3sguapcqRF683z/ALSw+AcQ8ezCma6hqmR1P6UD105F9k8y5TXFSOZ2j5OH9KqN6fOG4AAraoAAAAAAAAAAAAAAAAB47nc6S3QrJUStavk3fVTSbxmNVOro6JqRM7bXupodX4kwNKja9VvV5R1n+zOxNPv5XuR082+zVNPCm5Zo2fV2jG1GR2mFVR9SiqnomyMamqqKl3NPM+RfdTp0QDL/AIkX5nbHsxEfGd/ls3lrh6iI/wAyvf0SYuXWbevHd/uqd0OT2eVdNqdfVCLRowaf4i6lE/Sopn7p/dfnQMbwmUx09dSToixVEbt+SOTZ6CF4pZIXc0UjmO9UUztpyu4Uao2Z3jx+aL3/AGki07+IuPdqinLt8nxjrH7sDI4frpje1VuksGKst9ormxPDejJPNjl6mVOg4uXZy7cXbNUVUz4w0N21Xaq5a42kABkLYAAAAAAAAAAAAAAHGWRkUaySPaxqd1VdIgmdhyOMj2Rt5nva1PVV0aJlfEWioHPpra1KmZOnMi/Cn+ZG94yi93V6rUVj2NX9Bi6QjefxPiYszRR9Or4dvxYtzLoo6R1TfX5HZqJPz1fD/wDxcimKm4g41Gulq3L9GKQY74l25VVV81PmkI7d4xyqp+hREfjP7Mac2vwhOcXELGnrpKtyfVimUoMmslaqJDXxbX9Z2v4leNIEREXadFPLfGOXE/Toifxj9yM2vxhZyKWOVvNFI16erV2cyu1pyK8Wt7XUtZJyp+g5VVP2EiYtxJp6l7Ka7RpDIvTxE7L/AJEhwOKcTJmKbn0J+Pb8WTby6Kuk9Eig66aeGohbLBI2RjuzmrtDsJLExMbwygAHoAAAAAAAAAAAAAAOMsjIo3SSORjGptVVdIhGWd8XLVZnPpLW1K6pTormr8LV+vmX7GPcv1ctuN2HmZ+PhUc9+raEmySMjarpHtY1PNy6MLdMtx62pupulOns16OX9xWbJM+yW+yOWor3xRr+hEqtQ1d7nPcrnuVzl7qqm9s6BMxvdq/BC8vjimJ2x7e/xn9loqjizhkLuVbg5V9o1OEXFzC5Ha+/vT6xqVe0fTL/AMBx/OWr/wDm2fv7tP4T+63drzjGLk5Ep7pCir+u7l/iZ+nqIKhvNBNHK31Y5FQpL27GcsOWX+yytfQ3GZGt7Mc5Vb+wxr2gRtvbq/FscXjmd9si3084/ZcIENYPxngqXspMghSF66Tx29lX6eRL1DWU1dTtqKSdk0Tk2jmLtDRZOJdxp2uQmeBqmNn0c1irf4eLvABjNgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARfxu4oUuHW91vt72TXedqoxqL/AFX+0p5MxEbyv42NcybkW7cbzLjxo4q0WH0y263uZU3WVq6ai7SL3Uqnfrxcb7cH190qX1EzlVduXonsh0XCsqrhWy1tbM6aeVyue5y7XZ5zGqrmp0jTdLtYNG0davGQAFDZgAAAAAem2V1ZbK2OsoKh9PPGu2uYujzAPJiJjaVpeCXGCC/tZZsgkjguCIiRyKukl/5k0H56wySQzMmhe6ORio5rmrpUUsvwI4vR3RkWPZHM2OsaiNgncukl9EX3L9FzfpKFa1oXs97+PHTxjy9E5gIqKm06gvImAAAAAAAAAAAYLJ8ghtUSxsVH1Dk6N329z7lN9itVOrGKj6h6fC3fb3I0qZ5amd00z1e9y7VVIDxdxbGnxOLizvdnvP8A9f7/ACb3StK9vPtbvu/N2V9ZUV06zVEivcv7jzgHF7t2u7XNdc7zPil1NMUxtHYABbVAAAAADnDJJDIkkT1Y9F2iopveKZOlTy0lc5Gy9mvXzNBPrVVrkc1VRU7Khu9E13J0i9Fy1P0fGPCWHmYVvKo5a+/hKak6g03D8lSRG0Ne7TuzHqvc3JOp3vSdXx9Vx4v2J9Y8YnylB8rFuY1zkrgABtGMAAAAAAAAAHTXVUFFSvqaiRscbE2qqp5VVFMbz2Ozjca2noKR9VVSNjjYm1VVIXzfNau9TOpqVzoKNq6TS9XnVnuWT3+sdDCqx0Ua6aiL83upqxzfXuIasmqbGPO1HjPn/Zq8jJmr6NPZ8RNH0AibDAAAAAAKmwANlw3L66wVDWOc6akVfijVe30Jsst0pLtQsq6OVr2OTrpey+hW4zmIZJWY9XJLEqvp3L+ciVeioSfQ+IK8KqLV6d7fy/sy8fJmjpV2WCB4LFdqO8UDKukkRzXJ1TfVF9D3nS7dym5TFdE7xLaRMTG8AAK3oAAAAAAAAee5V1LbqOSrrJmxQsTbnOXSH2uq6ehpZKqqlbFFGm3OcukQrXxb4g1GTVrqChesduicqJpf6xfX6Gdg4NeXXtHbxlptZ1m1plnmq61T2j/vg7+KHE6uv88lvtb3U1A1VRVaulk/5Ear1Xa9VUAmtjHt2KOSiNocfzc6/m3Zu3qt5AAX2GAAAAABt/D7PbrilY1GPdPROVEkhcvTXt6GoAt3bVF2maa43hkY2VdxbkXLVW0wuRi2QW7IrXHXUEzXtc1Fc1F6tX0UyxUTA8uuOJ3RtTSvV8DlTxYlXo5C0OIZJbsltcdbQytcqonOzfVi+ikM1HTqsWreOtMutaDr9vUrfLV0uR3jz+MM0ADWJGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHfGTiRRYXanRQvbLcpmqkUaL8vup5M7dZXsfHuZFyLduN5l08aeJlHhtsdS0j2zXSZqpGxF+T3UqNdrhWXW4S19fM6aolcrnOcuzne7pXXq5S3G4zOmqJXbcqr29kPEY1dfNLpGl6Zbwbe0dap7yAAobQAAAAAAAAAAA5RvfHI2WJ7mSMXbXIulRTiA8WT4D8Xm1rYccySZrKlNMp6hy/1noi+5PLVRyI5qoqL2VD89Gucx6PY5Wvau0ci9UUsTwH4vrL4OOZLMiSdGU9Q5fm9lL9u54Shut6Htvfx49Y/WFgwfGOa9iPY5HNVNoqL3PpeRAAAAAADDZNfIbVTKjVR1Q5Phb6e5yyS9Q2qlVdo6ZyfC0jKuqpq2pdUTuVz3L+wgvFvFdOm0TjY873Z/4/3bvStLnIn2lz3fm41lTNV1Dp53q57l2qqdQBxKuuq5VNdU7zKYxEUxtAACh6AAAAAAAAAAAiqioqLpU7Kbth+Tb5KGvf7MkX+CmkhOi7ToqG30fWcjSciL1mfWPCYYuXiW8q3yV/8A4mtFRU2i7QGjYfkysVtDXO+Hsx6/wN4a5HNRzVRUXzQ75o2s4+rY8XrM+seMSg2Xh3MW5yVvoANuxQAAADrqZ4qeB00z0YxibVVU8mYiN5HyqqIaWnfPPI1kbE25yr2IU4g5dNfap1LSuVlFGuk0vz+6nZxDzCa9VDqKjcrKKNdbRfnU0051xDr85Mzj48/Q8Z8/7NZk5PN9GnsAAiDCAAAAAAAAAAAAAGZxPIazH69JoHK6FV/ORqvRUJ0x+8Ud6oGVVJIioqfE3fVqlcjL4vf62wV7aimcqxqvxxqvRUJHoWu14FXs7nW3P5ejKx8ibc7T2WHBi8bvdHfLeyqpZEVVT42b6tX0ModOtXaLtEV0TvEtrExMbwAAuPQAADqq6iGlp31FRI2ONibc5y6REOU8scEL5pntZGxNucq6REK68YuI8t8qH2e0yKygjcqPe1esq/5GZhYVeXc5ae3jLU6vq9nTLPPX1me0ebz8X+Ik2RVb7ZbnrHb4nKiuRf633+hGwBN7FiixRFFEdHHM7NvZt6b12d5kABfYYAAAAAAAAAABn8Iyq44tdG1dG9VjVfzkSr0chgAUV26blM01RvErti/csXIuW52mFwcLye3ZPamVlFK1X6TxI99WqZ0p5h2T3LF7o2toJF1v441Xo5C0eD5XbsqtTKujkakqIiSxKvVqkN1LTasWrmp60/J1vQOILepUezudLkfn8YbAADVJKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGlcVs+t2E2V00r2yVkjVSGFF6qvr9DyZ2XbNmu9XFuiN5l0cXuIlvwizOXmbNcJkVIIUXrv1X2KfZBeLhfrrNc7nOs1RKu1VV6J7J7HPJ77ccjvEt1ukyyzyL069Gp6IYwxq6+aXR9K0ujBt+dU95/SAAFDbAAAAAAAAAAAAAAAAB9RVa5HNVUci7RU8j4ALA8B+L7o3Q45ks20XTaeocv7lLFRvZIxr43I5rk2iou0U/PTzRU6Ki7RSeeA/F59E+LHclmV0Kqjaeocvy+yl6i54SiGt6Hvvfx49Y/WFlAcYpGSxtkie17HJtrkXaKhyL6GBi8ivEFqpFe5UWVU+Bvqpyv93gtVI6SRUWRU+BvmqkYXOunuFW6oqHKqr2TyRCFcWcVUaXbmxYne7P/AB+M/HybjS9MnJq56/dj83G41k9dVOqJ3K5zl/YecA4ddu13a5rrneZ7ymdNMUxtHYABbVAAAAAAAAAAAAAAAABt+H5KsLmUNc7bF6Mevl7KagDaaTq2RpeRF+xPrHhMeUsbKxbeTb5K4TUxzXtRzVRUXsqH00DEMldTObRVrtxL0Y9fI36N7ZGI9jkc1eqKh3zRNcx9Xx4u2p6+MeMSg+ZhXMSvlq7eEvoBxlkZFG6SRyNa1Nqqr2N1M7MN8nljgidLK9GMam1VVIa4i5jJdp32+herKRi6c5P01O7iRmT7lM+2W96tpmLp70/SU0M55xFr/tpnGx5+j4z5/D0a3Jyeb6NPYABDWCAAAAAAAAAAAAAAAAAADJ41fK2w17aqkf8AD+mxezkJ0xe/0V+t7KmmeiP18bFXq1SvBkcevNZY69tXSPVOvxs8nISDRNcr0+vkr6258PL4wycfIm3O09ljQYXFMho79QNmgeiSonxs31RTNHULN6i/RFy3O8S21NUVRvAcJpY4YnSyvaxjU2rlXSIfZZGRRukkcjWtTaqq9EIB4zcSH3CSSx2aVW07VVJpWr8/sbDDw68q5y0/fLW6rqtnTbM3LnfwjzdPGXiRJdppLJZ5FZRsVUlkav8AWL/kROATfGxqMe3FFEON6hqF7PvTeuz1+QADIYIAAAAAAAAAAAAAAAAZjEcjuOM3Vlfb5FRUX42L8rk9FMOCmuimumaao3iVy1drs1xXRO0wt1geX27K7W2ppXoydqIksSr1apshTbFr/cMcujK+3Sqx7V+Jvk5PRS0HD3M7fllsbLC9rKlqJ4sSr1RSHalplWNPPR1p+TrHD/EVGoUxau9Lkfn6NpABqEpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANZ4i5hbsNx+W5Vr2rJpUhi31e7yQTOyu1bqu1xRRG8y83E/OrZhNkfVVT2vqntXwIOb4nL/kU5y/I7llN6lulzmWSR6ryt30YnohzzXJ7nll7kulzmV7nKvhs30Y30Qwhi118zo2kaTRg0b1da57z+kAAKG5AAAO+hpKuvqW01FTy1Ez10jI27U6F7Ftvs74Xb7Rh9NdZadj66rTnV727VvshVRTzS12p6hTgWfaTG8z0iEOWrgVmVdbkq3pDTucm2xud1NFyjF77jVU6C72+aFEXSScq8i/RS+hismsFtyG1y2+5UzJY5Gqm1b1b7oXptR4Ivj8UXouf5tMTT8PBQcG9cW+HVfg11XSPntsqr4U2vl9lNFLExt0lNLF+i/bi5bneJDM4vjF8yWrbT2mgmmRV0snKvI36qbJwh4c3DOLqjntfBa4nIssyp0d7IW8xqwWzHrZFQWyljhjjaibROrvdVK6LfN1aXVdcowp9nRG9fyVfr+AmY01CtTG+CZ6N2saO6kY3a219prX0dypZaadq/LI1U37ofoER7xswe15Pi1VUvhYytpo3SRzIml6JtUX1K6rUbdGqwOJbk3IoyI6T4x4KaA+NVVb17n0sJoAAAPRfTqgAE5cB+Lklslix7IplfSuVGwTuXqz2X2LE3a80lDb0q/Fa9Ht3HpfmKCe6dFTsS5wszSoro2WK61KvdEn+juevl6Gr13UMnC0+5dx6eaqPy+Px2RvUNBtXr0XqekeMJRu1wnuVW6ondvfyp5Ih5AD57vXrl+5Ny5O9U95ZtFFNFMU0xtEAALSoAAAAADnFFJM9GRRue5fJqbU4tRXORqd1XRJ2LWSnt9IyVWI6d7ducpIuHeH7utX5opnamnvLAz86nDo5pjeZ7NCWxXVIvF+6Sa1vWupj5I3xPVkjHMcndFTSk0mt5rZ4qq3vqYokSePrtE7oS7WP4f04+NVexbkzNMb7T4+jVYmuzcuRRdp2iUcAA5ekgAAAAAAAAbTiORvpHto6t3NCvRrl/RNWBsdL1TI0zIi/YnaY/OPKWPk41vIomiuE0eNF4Pjc7fD1vm300RLxJzR1bI+1WyTUDV1JI1fm9kPJfL7dW2BaCGVUi38Tk769DSUOmZ/Fv+I41NGP9HePpevk5rq9u5iXZsT+PnAACLtIAAAAAB7rTZ7jdXKlDTPlRO7kTon4nCy0Trjdqeibv849EX6eZYWx2uktNCylpIkY1E6qidVUkGh6JOpVTVVO1MMnHx/a9Z7IMuOI36hp/HmonOYnfk6qhgvNUXoqdyzrmtc1WuRFRe6KQ1xZx6G1V8dfStRkNQvxNTycZut8NxhWfb2apmI7xPzV38X2dPNS0dqK5yNaiucvRETzM9RYfkFXAkzKJzGr5P6KZ7hHj7LhXPuVVHzRQrpiKnRVJiRERNJ0RCrReGqc2z7e9VMRPaI+b2xixXTzVK43myXO0Kn36mfG1ez9dP2mPLJ3W30tzo30tXE2Rjk807Ff8qta2e+1FFvbEdtn93yMLXNCnTtrlE70T+MLeRj+y6x2YwAEdYwAAAAA99hu1ZZq9tXRvVFRfib5OQnHE8lor5bUqGSNZIxPzjFX5Sv5zZUVcMM0dLUPgWZiscrV8lJBoWtVYF2KK5/y5nr8PjC9byK7MTtG/wAGx8aOJK1D5LFZJfzaLqaZq9/ZCGVVVVVXqqnbWQyQVL45d8yL1VfM6j6TwLVm3YpmzO9Mxvv5/FybVc/Izciqu/3jw8vgAAzGtAAAAAAA76SirKvf3Wlln135G7PJmI7qqaZqnaI3dAMl/R++/wDpFZ/+NTh+RbxtU/JlVtP/AG1KfaUecLs416P9s/g8AMgljvS9rVV//jU7G45kDkRUs1aqL/7SnntaPOCMa9PaifwliwdtVTVFJMsNVA+GRO7XppUOorid+yzMTTO0gAPXgAABksbvdfYLnHX2+Z0cjVTmRF6OT0UxoKaqYqjaeyu3cqt1RXRO0wtjw3zWhy21o+NyR1caJ4sSr1RfX6G2lNsUvtbjt5huNFIrVa5OdqL0c30UtliN9pciskFypXNVJGpztRd8rvNCG6pp/wDK1c1Huz+TrfDeuxqNv2d36yn8482XABqUnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdNbUw0dJLVVD0ZFE1XPcvZEQphxlzWpzPKpJedUoaVyx07EXprfVf3E7faeyt9kxRlppn8tRcNtXS9eTspVFE0hYu1eCa8M4EU0Tk1R1npH6gALKWgAAAAD47y+qfxL28OGo3CrWidvAb/Aok7sn1T+Je7hz1wu2f4Df4F6z3lFOKvqbfrLYAAX0IY3JLJQX+0zW24wMlhlareqbVPdCAmfZ0qf6Q/FdG/krxObX6fLvsWPBTNMT3Z+JqWRiRNNqraJY/H7PQWK1w263wMihiajURE1v3UyABUwaqpqnee4YvLl5cXua/8A2sn/AAqZQxOY/wBlbp/8WT/hUSrte/T6qEJ5/UHxvY+mE68AAAAAB20dRLSVcVVC5WyRORzdex1A8qpiqJie0ixuK3aO9WOnrmKiq5un+zk7mVIq4H3RUmqrVI7oqc8aemu5Kp8+8Qad/h2oXLEe73j0nt+zW3KeWqYAAaVQAAAAAOUTuSVrvRUUmC11EdVQQzRqitVqEOmaxzIKi0KrFb4kLu7VXt9CZ8G8QWtJyKqb/uV7dfKYajV8GrKtxNHeEomMyasZRWeeR2lVzVaifUw39N6Lw9+BJza7Gp3+8VF2qed/wRp8rEXoTzXeNMC1iVRi189dUbRt4b+MtJhaPfquxN2NohjN76gA4imQADwAAAAAAAAcZGo9itd2U1WvgWnqnR+Xdv0NsMPkcO42zonVq9TZaZemi7yeEo3xNhRfxPaxHWjr93iwgAJG5sAAAAAM9w+XWY0P1X+BYBCvuA/2vof7ylgkOi8G/Za/6v0hs8H3JCOuOSf9T0nT/wAVP5kikd8cf+xKX/GT+Zt+If8ATrvovZP1UspwjRExGFUREVV6+5uBqfCj+xtL9F/ibYZGkRtg2v6Y+Sqz9XAQfxb1/S9+v/LaTgQhxdT/APVzv8Jpp+LvsMf1R+qzm/VtQABzNqgAAAAAAAGEyejSSFKlifE35voa0b7PG2WF8bk2jk0aNUxrFO+Ne6Kdy/hpq9WTh14Vyetvt/TP7SgfFGHFu9F+ntV39YdYAOmosAAAAANk4b2FuRZZS2+Xfgq7cn0LU2qx2q2UrKajoYI2MTSfAir+0rpwBdy55Enq3RZwieu3a/bRRv02dQ4LxrX8pVd2+lM93X4EH/kx/wC6hx+603/00P8AuIdwNFvKacseTq+7U/8A9PF/uIckhhTtFH/uocwN5OWPJquf4da8js08clPHHUNaro5WtRFRUQqhWU8lLVy00qKj43K1ULqVcjIaWWWRURjWKqqv0KeZjVRVuU3GqgVFikncrdehJdAu11c1E9oc843xrNHs7tMbVTvE/FiQASRz4AAAAACUfs/5StqvrrRUyapqv5dr0a7/AJkXHdQVMlFWw1cS6fE9Hp+CmPk2Iv2ptz4s7Tc2vCyaL1PhP5LsAxWJXFt1x2irWuRyyQtV2vXXUypz+qmaappnwd0t1xcoiuntIAClWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAddTJ4VPJJ+q1VBHVUP7SV7W7cQ5adr+aGkajG9ey+ZGRms5qHVWY3Wdy73Uv/iphTDqneXWMO1FnHoojwiAAHjKAAAAAHx3l9UL28N/7EWv/AaUSd5fVC9nDb+xFr/wGl6z3lFOKvqbfrLYgAX0IAAAAAAxWXpvFron/wBrJ/wqZUxmWf2Zuf8A8WT/AIVErlr349VBG9j6E8/qDCdeAAAAAAAAbDw5q1o8wolRdJK9I1/FSwK91K2Y69Y8itr07pUs/iWSau2tX1RDkv8AES1FOVauR40z+UsLJj6US+gA54xwAAAAANkxrF5LlH94qXOihXtrupr1O1HTxtXsrkJjo2NjpY2MRERGp0JzwToGPql6u5kdaaNunnM+bS6xnXMaiKbfefFri4TbNaSWbf1Q1rJscktKNlic6WBe6+aEmnhv8LZrTUMcm05FX9xPtY4P027iV+xtxRVEbxMfBpMTVsim7HPVvCIgOwOEpqAA8AAAAAAAAA8t0jSSikb7bPUddQm4Hp/sqXLdXLXEwsZNuLlmqifGJaenY+he6/UExcZ22AAAAAGcwH+11D/eUsEhXzAv7XUP95SwaHReDfs1z+r9IbPB9yQjnjlv8kUn+Kn8yRiO+OKf9S0q/wDvJ/M2/EP+nXfReyfqpZfhMu8Opvx/ibaafwjXeIQeyqbgZGkTvg2v6YVWfq4CEeL39rXf4Tf5k3EJcX/7Wr/hN/maji77BH9ULOZ9W04AHMmqAAAAAAAADUcjj8O5PVP0uptxrOVt1Vxr/sk//hvfm3rPJHaqmY/X9Ef4moirC38phhQAfQDnQAAAAAkDgJr+nsG/1SzxWDgL/b6D+6pZ8h+u/aI9HVuC/sE/1T+geC93i3WWkWquVSyCL1d5nvIO+09USpJaqdF1GqPVU9exgYWPGTei3M7bt5q+fOBiV34jeYbg/i9h7Xq3745dLrfKp1zcYcRYzbKh719ERSsuj6SX/Asbzlz2eNc/yp/BKvEjizPfKV1us8b6Wnd0e9V+JyEVAGyx8a3j08tuNoR3P1C/n3PaX6t5AAZDBAAAAAAKABZT7PVwWrwtKdy7dA9UJKIY+zBKrrfdY17NezX7yZyCanRFGVXEebtfD12bum2qp8tvw6AAMBugAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADzXXf5Mqdf+U7+B6ThUM8SCSP9ZqoHtM7TCgmRb/pDcd9/vL/+JTwGbzumdSZldYHJrVS9f3qYQw5ddtTvRTMeUAAPFwAAAAAfHeX1QvXw0XeD2v8AwGlFHdk+qF6uGO/6C2rf/kIXrPdFOKvqbfrLZAApfQhX7iNxvu+PZrU2qjoI5KanVEdterl8zzO+0g77pptgd4/r4vT+BGXHKNI+J10RPN2/3qaSY011RLomNo2FdsUVVUddo81ieG/HC737NaS03GiiZT1b/DZy92qq9CwhSLgu1ruKFk5k7VDVT67Lul23MzHVG+IcSzjX6abVO0TAYzK/7M3P/wCLJ/wqZMxuU/2auf8A8WX/AIVLktFa9+PVQTzX6gL8y/UGE6+AAAAAAAAyOMRrLktsjRN7qWfxLIomkRPRNEDcLaJazMKddbSD84v4KTyvc5H/ABCvxVmWrcf7afnLCyZ+lEAAOfMcAAAAAdlL/rMf95CZKf8A1eP+6hDdN/rEf95CY6b/AFeP+6h1b+GnbI/9f1RjiL/x/f8Ao7DzXT/s6o/w3fwPSee5/wDZ1R/hu/gdNyfqa/Sfkjlv349UOu+ZfqfD675l+p8Pl6ru6TAACl6AAAAAAAAHXUry071/2VOw8d4k8Kgevn2LlqnnuRT5yx8u7FqxXXPhEtYXqqqAgJi40AAAAAM3gn9rKH+8pYNOxXzBP7WUP95SwadjonBv2a56/o2eD7shHvHBP+oaZf8A30/gpIRHvHBHfkKmVPlSdN/vNzxB/p130Xsn6qWT4SNRMPp1Tuu9m3mpcJuX+h1NpevXf7TbS/pH2G1/TCqz9XAQlxf/ALWr/hN/mTaQnxg/tav+E3+ZqOLvsH/tCzmfVtNABzJqgAAAAAAAA1jK3brGN9GmzmnX6XxblIqL0RdIdC/hrjzc1ebnhTTP59Ed4nuRTh8vnMPAADvrngAAAAA33gOus/pk9UUtCVe4D/2/pvopaEh+u/aI9HVuC/sE/wBU/oEFfagT/SrR/df/ACJ1IL+1B/rFo+j/AORY0f7XT9/yZvFX+l3Pu+cIVABN3HAAAAAAAAAAAAD4vYCfPsxwKy03KZU6SPbr8NkxmgcCLatBg0D3tVr5nK5dp5eRv5AtRr58muY83bdAszZ061TPlv8Aj1AAYTcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACoX2lbItq4hSVTGK2GsYjm9Oiqnci8tl9pnE3X3EUulNGrqm37f0T9DupU1Oxi3I2qdK0PKjIw6fOnpIAChuAAAAAB8d2T6oXq4Y/wBhbV/gIUVd2T6oXp4XrvBLUv8A7CF6z3RXir6m36y2UKApfQdSnjn/AN59z16p/FTSDd+Oia4n3NF9UX96mkGJV3dYwfs1v0ht/BhdcULH/wDJb/Eu8Ui4Lt5uKFj661UNX95d0vWeyH8VfaKPT9Qx2Tf2cuX/AMSX/hUyJj8l647ck/8AtZf+FS7KNW/fj1UDX5nfVT4fXpqR6ejlPhhOvgAAAAAAe6w2ye73WChgaqrI5OZU8m+alF25RaomuudojrLyZ2SZwStKw0NRdZWqizLyxqqeXmSQeW00MVtt0NFCiIyJqJ9V81PUfPWtajOo5tzIntM9PSOzW11c1UyAA1SkAAAAAdlP/rEf95CY6b/V4/7qEN0/+sR/3kJkpf8AVo/7qHVv4af/ANH/AK/qjPEX/j+/9HYee59LdUf4bv4HoPPc/wDs6o/w3fwOm5P1NfpPyRu378eqHXfMv1Ph9d87vqfD5eq7y6TAACl6AAAAAAAAGDyOfbmQIvbqpmKmVsMLpHLpEQ1OoldNO6V36Sm10uxNVz2k9oRXinPi1j/y9M9avk4AAkDngAAAAAzWC/2sof7ylhE7FesIXWV0P94sKnY6Jwb9muev6Nng+7IYTM8fiyO1JRSSuiVr0c1yJvSmbBLL9mi/bm3cjeJ7syqmKo2ljMYs8NjtEVvhesiMTq5U7qZMA9tWqbVEUURtEdIIiIjaAhTjD/a3/wDqaTWQrxi/tYn+EhHOLfsH3wxcz6tpYAOYtUAAAAAAAA6a2ZsFNJK5flQ0eR6vkc9V7rszmUVqOVKSNeidXKnqYE75/DrRasHAnJuRtVd6/wDrHb8e7n3EudF/Ii1TPSn5gAOho2AAAAAN94Ef94FN9FLQlXeBK/8A7gUn4/wLREQ137RHo6twV9gn+qflAQZ9qH+vtHTyf/InMg37UH9baPo/+Rj6P9rp+/5M3ir/AEu593zhCYAJu44AAAAAAAAAAAe7H7dJdbzS0ETVcs0iNXXkm+qnhJr+ztiblmkyKtiVGonLT7Tv6qYmbkxj2Zrn7mz0jT6s/Losx28fRM9lo22+00tEzWoYms6eyHsAIDMzM7y7hTTFNMUx2gAB4qAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHXVQRVNPJTzsR8cjVa5q9lRSmfGzCKjDcqkRjHLQVblkgfronXqhdA17P8Tt2YWCa117E+JF8OTXVjvJUKK6eaG20fUpwb28+7Pf91EwbBneJ3TD73JbrjE5G7VYpdfC9v1NfMaY2dJt3KblMV0TvEgAPFYAAPju34l3eDNwp7jw8tcsEjXcsSNciL2UpGbvwx4k3vBZ3MpdVFDI7csD/AOKeildurllptb0+vNsRTb96J3XWOM0jIonSSORrGoqqq+SET2jj3hdVR+LVyy0kyJ1jc1V6/VEI24n8dK69RS2zHIfutHI1Wvmd87k9vQvzcpiENx9DzLtzkmjb4y0Hi7dIbxxDudZTuR0SSLGip2XSr1NTHuqqqr3VQY0zu6Patxat00R4RszmAXZlizS13WX+qgqGrJ/d2Xqt9XDXUUNXA9r45WI5qou06ofnypKnCjjHdMRhZbLjGtdbUX4evxxp7L6Fy3Xy9JaHXtKrzKYuWvejw84W5MFnt0pLTiVyqquVsbPu72ptdbVWqiEfVv2gMNioFmp1mmnVOkKNVF39dEC8TeJF8ziq1VO+70LF/N07F0n1X1UuVXIiOiPafoWTeuxNynlpjvv+jS1dzvc/tzKqnwAxnQwAAADnFHJNKyKJjpJHqjWtam1VVDx8ijfLK2KJqve9dNRE7qTdw0xRtioPvdU3dbOm12nyJ6G08E+D8NBbPyxkEXNXzt3FGqdIk8vxMzfLXUWurdFK1VYq/C7XRUIFx9dzreLTRbj/ACp96flE/Bpv8VsZF2qzbnt+fox4AOProAAAAAAADlG7lka70VFJftVQypt8M0aoqK1CHjMWLIKy1LyNXxIfNi/yJlwdxDa0i/XF+PoV7dY8JhqdWwKsuiOTvCUzw36ojprTUSSLpFYqftMAub0fgK5KeTxP1dmr32/1t2+CVUZEi9GN/mdA1njXTrONVGPXz11R02/VosTR8iq5E3I2iGJVdqq+oAOHSmYADwAAAAAAIiqukRVX0QIiqqIiKqr2RDe8NxtIWtrq1u5F6sYvkbnRNEyNXyIs2o6eM+EQxMzMoxbfPV90IivVY6aZYW7RrV6781McSbxNwxyOfeLZHvfWWNE/ehGXVF0qKip3RSTZelV6XX7CqOkdp8/i5VqF69fv1XLveQAGKwgAAAABk8VqWUmRUc8nypIiL+JYmNzXxte1doqbRSsfZUVF0qdjb7HxBvVtgbTvSOoiamk5k+JEJVw5rVnAiq3e7T13ZeLfpt7xUm8EaQ8VafkTxLbLza66chz/AOlWk/8ATZv99CYRxFps/wDk/Kf2Z38za80kAjb/AKVaX/02b/eQ6qniqzwl+7216P8ALmcmjyeI9NiN/aflP7PP5q15pNe5rGq5yoiIm1VSBOItziumUTyw9WR/m9+uj133P73dKZ1Mnh08bu6sTTlQ1L3VdqRLiHXredRFmx7veZlh5ORFyOWkABE2GAAAAABj7zcGUUCo1UWV3RqenubbhuN1WQ3BI2o5lMxdySa/chleLvC9EoUu1hjc6SFmpoU/SRE7oTThDh+3qGVTdy+lqP8AlPl6ebE1KnKpw67mPG8/p4zCDpHue9XuXaqu1Ph9e1zHqx7Va5F0qKnVD4fRNMRTERHZyaqZmd5AAVPAAAAABvfAn/vApPx/gWjKt8DZ4oc/pPFejebaIq+paQiGvfaI9HVeCpj+Qq/qn5QEH/agT4rQvs/+ROBAv2mrjTzXC3UDF3LC1yv0vbfYx9HiZy6dvj8mdxVVTGmXN577fOENgAm7jgAAAAAAAAAbLw/xCvy27pTU7HMp2KizSqnRqf5lu5cpt0zVVO0QvY+PcyLkWrcbzL0cMsNq8svTY0Y5lHEqOmk1016FqLVQ09tt8NFSsRkULUa1ETyQ8mMWG349aorfb4kZGxOrtdXL6qZQhWo59WXX092OzsOg6JRplnr1rnvP6AANc3wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANa4g4basxs0lBcIk59L4cqJ8TF9lKd8QMNumG3l9DXxuWJVVYpkT4XJ/mXpNfzrE7Vl1mkt9yhR20Xkfr4mL6opbro5m70jWK8Krkr60T+XookDaeI+EXTCby6jrY3PpnLuGdG/C5P8zVjHmNnQ7V2i7RFdE7xIADxcAAA0gAAAAAAAAAAAAAAfWtc97WMarnOXSIidVUD7Gx8kjY42K97l01qJtVUstwC4TNtsUWR5BCjqxyc0ELk6MT1X3PPwC4SJSMiyTIoNzrp1PA9PlT1VCfURERERNIhft2/GUL1zW+bfHsT08Z/SA8d2t1PcqV0E7UXfZfND2A9vWbd+3Nu5G9M94ROiuqiqKqZ2mES3201FqqljkRVjX5X66KY4mC6UFPcaV0E7UVFTovmhGV/s9RaalWPRXRKvwv0cQ4q4UuaXXN+xG9qf+Pwn4fFM9M1SnJjkr6VfNjAAQluAAAAAAAAAAAAAAAAAAAAiKqoiJtV7IO66RNqbrhmOb5a+tZ7sYqfvNto2j5GrZEWbMes+EQxcvLt4tvnrc8NxvkRtfWt+Luxi+XubmnRNIERETSdEB9AaRpOPpWPFizHrPjM+coLl5VzKuTXWORHIqKm0XuhF3EfB9eJdbSz3liRP3oSiFRFRUVNovcu6jp1nPtTbux6T5MK7apuRtKsKoqKqORUVOiovkCUuI+EJIj7pamaf3kiRO/0IucjmuVrmq1yLpUXuhynUdOvYF32dyPSfNp7tqq3O0vgANetgAAAAAAAAAAAAAAAAAAGaxLHqrILg2GJqtgav5yTXREOGK2Crv9xbTwNVIkX85JroiE7Y9Z6Sy29lJSsRERPid5uX1JHoOhVZ9ftLnS3H5/BlY+PNyd57OVitVLZ6BlJSMRrWp1XzVfU969QDp9u3TbpimiNohtYiIjaENcY+GTapsl8sUSNmT4poGp0d7oQRIx8cjo5Gq17V0qKmlQu4qIqaXqhD/GHhnHXskvVkiRtSnxSxNTo76Em0vVeXa1enp4SgfEnDPtN8nFjr4x+sIBBymikhldFKxzJGLpzXJpUU4kmc4mJidpAAevAAAd1DVTUVZFV07uWWJyOavuTlhvGqlkpkhyKLwpm9PEjTov4EDgxMrCtZUbXIbTTdXytOqmbM9J7x4LA5ZxptlPSuZYo3VE6/K56aan4EG3+7Vt7uktxr5OeaRdr6J7IeAHmLg2cX3I6+arU9ay9RmPbVdI8I7AAMxqQAAAAAAM5hmM3DKLsyio415N/nJNdGoUV1026ZqqnaIXbNmu/XFu3G8y7MGxSvyq7NpKVitiRUWWVU6NQtNiOO2/G7THQUEaNRqfE7zcvqp1YXjNvxi0soqKNEdpPEfrq5TOkM1LUasqrlp92HXOH9Bo023z19bk958vhAADVpIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwmZ4xa8qs0ttukDZGOavI7XVi+qFO+JuCXTB7w6mqmPlo3r+YqOX4XJ6fUu+YfLsctmT2eW2XOBskb2qjXKnVi+qFFdHM3Ok6vXg18s9aJ7x+sKFA3Pilw/ueD3d0MrXzUD1XwZ9dFT0X3NMMaY2dEs3qL1EV253iQAHi6AAAAAAAAAAAAPPSJtV7IA6qqIiKqr0RE8yxH2f+EvIkWTZJTqj9o6mp3t7f7SoeXgBwlWofDk2R06o1qo+mp3p39HKWOY1rGo1qIjUTSInkXrdvxlD9d1vbfHsT6z+kPrURqIiJpE6IgAL6GgAAHmuVFBX0roJ2I5rk/YekFu7aou0TRXG8T3hVTVNMxVT3RTkVlntNSqKiuhcvwv0YomSvpIK2mdBOxHMcn7CM8ksc9pqFVEV8Dl+F+v3HFOK+Ea9NqnIxo3tT/x/t8Ux0vVYyI9nc6VfNhwAQRugAAAAAAAAAAAAAANuw3HFnc2urmKkadWMVPm9zZ6TpWRqmRFixHXxnwiPOWNlZVvGtzXXLnhuNrIra+uYqNTqxip39zekRERERNIh8aiNajWoiInZEPp9AaLo2PpOPFmzHXxnxmUGzMy5lXOev7o8gAG3YgAACoippU2hHHEbCEqWvulqj1MnWSJE+b6Ejhevcws/As51qbV2P7Ldy3TcjaVYntcx6se1WuaulRe6KfCXOI2ENrmvudrYjalE2+NE6P/AOZEkjHxyOjkarHtXSovkcp1PTL2n3eS528J82ou2qrc7S+AA1q0AAAAAAAAAAAAABlMZslXfri2lpmLy7/OP10ahwx6zVl8uLKSkYq7X4366NT1J3xew0dhtzKamaiv18b1Tq5SQ6HoleoV89fS3Hf4/CGTj483J3ns5Y3ZKSx25lJTMTaJ8T9dXKZQA6hatUWqIoojaIbaIiI2gABcegVNppQAIl4wcM47rFJeLNGjKxu3SRtTpIV+nhlp53wTxujlYvK5rk0qKXbIs4vcNYb3C+7WiNI69iKr2NTpL/zJBpeq8m1q9PTwlBeJOGYvROTix9Lxjz+MfFXQHZVQTUtQ+nqI3Ryxryua5NKinWSmJ3c1mJidpAAevAAAAAAAAAAAADK4tYa/IrrHb6CJznOX4na6NT1UpqqiiJqqnouWrVd2uKKI3mXPEcduGS3aOgoInLtfjfroxPVS0uDYrb8WtLKSkYiyKiLJJrq5TrwDEaDFLS2mp2NdO5EWWXXVymykN1PUpyauSj3Y/N1rh7h+jTqPaXOtyfy+EAANSk4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxWU2C3ZHaJrbcoGyRSNVEVU6tX1Qp/xY4eXLCLq5Fa+a3SKqxTInRE9FLqmNySyW+/2qa23KBssMrVRdp1T3Qoro5m30rVrmDXt3onvCggJA4ucNbjhNydLEx9RbJVVY5UTfJ7KR+Y0xMdJdFsX7eRbi5bneJAAeLwAAAAAADqqoiIqqvZE8wH06qTpwD4TvuMsWR5BC5lOxUdTwOT5vdTp4E8JJrtPFf8hhdFSMVHQwuTq9fVSzkEUcELYomIxjU01qJ0RC9bt+Molrmt8kTj2J6+M/pD7FGyKNscbUaxqaRETohyAL6FAAAAAAAAB01tLDV07oJ2I5jk11O4FNdFNymaao3iXtNU0zvCLsmsM1pqFcxFfTuX4Xa7exhSZquniqoHQzMRzHJpUUjbJ8fmtcyyRIr6d3Zddji/FnCFWBVOViRvbnvH/1/smGl6rF+It3fe+bBAA5+3gAAAAAAAAAbRiOOSVkjausYrYU6tav6RsdM0zI1LIixYjeZ/CPjKxkZNvHomuuXPDsddVPbW1jVSJvVrVT5jf2NaxqNaiIidERD5GxsbEYxERqJpEQ5Hf9D0Oxo+PFq31me8+Mygubm15dzmq7eEAAN0wwAAAAAAAA0LiLhMdzjfcbcxGVbU25iJ8//M30GJm4VnNtTauxvHyUXLcVxtKsc0ckMropmKyRq6VFQ4ky8Q8Liu0Tq+gajKxqbVETo8h2ohmpp3QTxujkYulaqHKdV0q9p13lr60z2nzai9ZqtTtLgADVrIAAAAAAAAe+w2mrvNwZR0kauVV+J2ujU9T5Y7TWXmubSUcSuVV+J2ujUJzw/HKTH7e2KJqOmcm5JFTqqm+0TRbmoXOarpRHefP4QyLFibk9ezniePUlgt7YIGosip+ckVOrlM0AdSs2aLFEW7cbRDb00xTG0AALr0AAAAAAABGXFzhvBkFO+52tiRXBibVqJ0k/5lc6ymno6mSmqYnRyxuVrmuTWlLskccWeHNNktM6vt7Ww3GNN9E6Sey+5vtL1WbW1q7P0fCfJCeI+GoyYnIxo+n4x5/3+atAPRcaKqt9ZJSVkL4pY1VFRyaPOSuJiY3hzKqmaZ2qjqAA9UgAAAAAAZHHrLcL7cY6G3QOlkeulVE6NT1UpqqimN57K7duq5VFFEbzJjllrr9dIrfQQukkevVUTo1PVS0nDvDqHE7S2GJqPqnoizSqnVV9E9jp4a4RQ4ja0a1EkrZGos0qp5+iext5D9T1KcieSj3Y/N1fhzh6nAoi9eje5P5f3AAadKwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeW6W+judFJR11OyeCRNOY9NoqFc+KHAeqo3yXHE3OnhXbnUz16p9F9CywKaqYq7s/B1G/hVb256eXhL8+q+irLfO6CupZqeRq6VJGKn8Tzl78nw/H8jhcy626GZyprxOVOZPopFWQfZ2ss71fZ7lNSb/Rk+MszamOyXYvE2Ncja7E0z+MKygmWv+z3k8LlSlroKhPJVTlPC3gLm6v0rKdE9edCjkq8m0p1fCmN4uQigbQm61fZ2vsz0WuusNO3zRGb/AJm+Y1wAxe3vbLcppq6Vq776av4FUW6pY17X8G1HSrf0Vpx7Hrzf6xtLaqCad7l1zI1eVPx7FiuFHA2itEkV1yZzausbpzINfAxfdPNSX7LZbXZqZKe2UUNNGnlG1E2ZAu024jujOocRXsiJotRy0/m4xsZGxGMajWomkRE7HIAuI6AAAAAAAAAAAAABwmijmjdHK1HNcmlRTmDyqmKo2ns9iZid4aPkOHua51RbV2ndY1/kahUQTU71ZNE5jk9UJnPJX26jrWK2ogY/311Q57rXAONlVTdw55Kp8PD+ze4euXLUct2OaPPxQ+Dfq7CaSRVWmmdF7L1MVPhVcxV8KZj0/YQLK4M1fHn6rmj4Tv8A3by3q+Jc/wB23q1YGxf0Ou2+zNfU9NPhNY9U8adrE9k2YtvhbV7k7RYq+/p812rUsWmN5rhqh30dHU1ciR08LnqvonQ3uhwughVHVEj5XJ+CGxUdHTUjOSnhZGnshJtN/h5l3aoqy6oojyjrP7Ndka/apja1G8/k1fHcRZArai4Kj3p1SPyT6m3Ma1jUa1ERE7Ih9B1HS9IxdLteyxqdvOfGfWUaycu7k1c1yQAGzYwAAAAAAAAAAAAAGs5hh1vv8SyKng1SfLI3z+pswLGRjWsm3Nu7TvEqaqYqjaVe8hxi7WSZW1FO6SLfwyMTaKhhN+RZyaKOaNY5WNexe6Km0U1a9YDYri50jYlp5F84+ifsIRncIVxM1YtW8eU/uwLmFPeiUGgkiv4WVDVVaS4Ncno5pi5OG1/aumeE5Proj9zQdQtztNqfu6sace5Hg0sG7wcNL49dSPijT13szNu4Vt2jq2vVyebWt0VWuH9QuztFuY9ej2Ma5Pgi9qOc5GsarnL5Im1NsxXBbneHtkqGrS0q93OTqpKVjxCyWnSwUqSPT9KTqpsCIiJpE0hJNP4QimYryqt/hH7sq3hbda5YvHbFQWOjSno4kT9Z693fUygBNLVqi1RFFEbRDOiIiNoAAXHoAAAAAAAAAAAAA1DP8Bs+WU6rMzwKtqfBOxNLv39UK95lgN/xqd3j0z56ffwyxt2ip9PItmcJoo5o3Rysa9jk0rXJtFNnh6pexvo96fJHtW4bxdR+n7tfnH6qSLtF0qaX0UFpMl4W4veXOl+7LSyr2WH4U39DQ7rwLqGqrrfdWuTya5n8yQWdaxrkfSnafigmVwhqFmfoRFUfBC4JLn4MZSx2o/BkT15kQ5U3BfJ3u1M+GJPXezK/xHF2354a7/ANR329jP4IyPrGue5GsarnL2RE2pN1o4Foio643XmTzYxmv3kgY1w5xixKj4KJJpE/Sm05UX2MS9rePRH0estpicH596f8zaiPj/ZBWDcMr5kcrJZ43UVH5ySN0q/RCwuGYlacWoUp7fCnOqfHK75nfiZ5rWtajWoiInZEPpHczUruV0npHknmk8P4umxzUxvX5z+nkAA17egAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGIyS/0VjgY6pdzSSORscafM5V9imqqKY3l7EbsueS53KgtkCz3Cshpo0/SkejUNO4o8R7fhePsqpEbLcJ2/mKXfxKq+xWq9V+U5tXurr/WywxyL+bpmr5eScv8yxfyqLUdVG8zO0R1WtxLNLJlFZV09nmfP91dyySI34d+y+ZsiqiIqqvYifgNjt2s1tajoUo6HW+RzNPlXyVVJVVWPRWKqdU0qbK7FyblHNMKtpju12rznGaW6tt09zhZMvmrk5U+qmco6+irOtJVQz/DzfA9F6epAHFrhZc23GtvVsYxaNV51bzqr9+yEeYvk99w68xXSNamWKBVbNC9VRFb6aNfOfctXOS7TtCia+XuuWCEMN+0Tjl4rXUtyo57dp39a9PgRPLaqSzjWQ2jI6J1ZZ66Krha5Wq6NyL1Q2VF2iv3ZKblNfaWWABcVgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhszvtPjmPVV0qHIiRMVWpvup5MxEbyMjX1kFHSTVM0jUbE1XLtSuma5usVxlyStgkqmxOVKSnb5r+iYvFssu2QJevHnke6tnX4d9GMRd9DTM6vTrveKPHbVFz+C/lXl83r0Xfsaq/d9tXFMdo6y9priLU3PwZjBbdfOI+WVV4vNVElQuteIvwQNXs1qdiboMLtmJU0VTHy1la7vLIm+X6J2NcwrF24vZ4oXyc1XM1HzerF9PwNiV1RVPRFc+RydE2ZFvHpmeeuN6ldmiYpjdsNrylYaJ0VW10knZqtTRhaWvmhuLKp0kitR/MrebyPktvmigWaRUTXkYaG4wy3aW3IipJG3mVV7KZMyv0Wpq3mmO3duN5yZ9THG2jRY0T50e1F2eDI8Vt+a4VUQVEFPBVac5kjERvxa7ro8622dYWyM05FTekOhJKiDmY172b6KmzyqmKo2qjdbqtxMbK1X3HlxuvdY7pUUsk0jdt8J3Nsy3CnN7rhV8gs9O7VLV1caSr58u/JDfs44dtuiy3qxx0zbk3b5kncvxN7roiWua2a3uukU8bJaKZUdruxzVNLcouY9/mpjpLXXLfJ0jvHZeukqI6mBksbkVHNR3fts7SlvBvi/f7Nf5XV0v36mqJGtfzu6I3ttvuXMoqhlVRw1MaorZWI9NL6ps3dq7FxetXIuRvDuABdXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK+faqyKRstLY4ZNMaxZX6XuvbRYMqP8AaHe6fic6lcrnJ4jeiem0LGRO1CzfmYo6ONhZDj3C2vubnKlXOzfTo6NruiKn4mtcHLa6pyCjgciukT87PIvVdp1T95tHFS40EWO01upI2rJM5EVNdUjREVPx2bHwhxz8kWT8o1TNVdYiO6p1azyT6mNRbjeI+97NM1Xabcdqe/qkGkp5KuflRV/2lUz9NTx07EaxqIvr6mv0F5p6VHR+JA7S/Fp6bT6mShv9tfpHVEbF/voZcTDY8lXk7b7IkVskkeukTqpr1RanU2K0N8fGrZ3z89Q7/Y6on8jJ5DUQXGkp7dSTsldVztidyORVai+Zut4tcdTjMtsVE5fB5e3on/I825mRbr9jTHN/un8v+/JgLeu6KFfVuz5WUkVSzTk07ychjbFcqWOzQNqqmKOVicr2uciKip7HZNkFub8k8b1/voh7vGyxVarpqmnbs1rMWVdLYbk2BWtn+7vRquXSL0UqliVXJL98sdZWR0kNS93ivXq1XJ9C3N9qaG+UslBUugcyZisVqPTmVFK+8QODclko5rnj88tTAjuZ0Lur2J67Me9TM7TDVahZuzNNdMdkTfc6mzV7qKmqlcr+dWPb0ROvTuXh+zDeK6u4cUdNdJkfURIvIqu+J7d9yo+S2WoqrLTT8rYlmiWZmumvD+FfxVSaPse3FK7IZfvdc9Z4KRY4KdEVUazabXfbuW7NUxcj4rFiJor9VpwAbFngAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVq4h2harjfU1c7F8Gkp/HXad03oshVyLFTSyp1VrVVCEZ7nT5zaK+8U7m0t1oUWnqYk6rLGjize6xs85YqrpifNrdrx6jvnEGS4XKDlt1tj8ONvL0lf5fxQ36JiySpGxETfZPQzlkx6GpxOgqIJOTlgRXdN8y+qkF3fNLtQcQ3pQyNWJk7KdzXfKjUd1X9ilG8W4jfxVxNNreZ7zKS57CluuD7hT26nkkcu5Y5GczZE/kpuGMLiF6Z4f5Hoqeqb88L40Rd+3qdkE0NTCksMjJo3J8zV2imOvFroZI3ViudTTQpztmjXSpr19UK+XbrDZRk1XIiiuqfhMf8AercaSw2ajmSeltlLDKnZzI0RUMiv7jCYNV1tbjdPUXBUWdVcm9a2iL0X9hnC7Ttt0YF/niuaa53mOjFT45YZpnTTWmkfI9duc6NNqpquUVGKW160VFZKKsrndEjZGmmr/tL5GY4iVldSWyFaWb7vDJJyTzIm1Y1TE2y00NCzcLOd7urpHrzOd7qpRV1naGZarqooi5XVM+Ubz4ef7NYt2O+LWrcpqOBtVrSKxnK1ieiIe2NGNmRs7OaPenovmnmbBdqp1Da6qsZCsywxOekbe7tJvRWrDeIeT3HirFbq2kfHR3CXlbTuT4o9r3/AtzVTRMR5sbKzJmqJuzM79PR6c4tFox7J2MnbVTQPrmPouZqrCjHbV7XeXfyJe+zPidDZrXcL5D4D/wAoTKsMjG8vw+bU/E7eL9gtsOGSU89VFJVxytnjaqJzfCi/u6leeGvEnJ5M4x2z/fFitdNW8jYYW65kVy73ruWJqi1d6/8Ad2LcpptURV4b7R968wOMTuaNrvVEU5GeqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHVWM8SlljT9Jip+4qHa7hVYvntdA9ysZJK6Odi+aKvQuCVs+0lic1uvrMkpY1WnqF/PKidnFi/TO3NHgt17xtMeDP3HOHWLhHX1CTI2otyrEkaL8T0Xoip+0rhNW1VTbnVsr1dVVDUe53mrnGx5jKy5W60Q+PI2KZUZVtRf/8ASnPDsdp7tmDrRA9XUVM9FR6p1VrV2hiXKprmIMiZuVRNPafmsZwyhWDA7RE9VWT7sxX77711OeV1Dp2w2qBetVK2F6p5I46qCpdRNVkSfm+XlRvoYaavrYsmifBSrK6ONyo93yNcvZV+hl1TtGza4lve5Hw6/gk+53e3YzaYIqh6LI2NGxQs+eRUTXRDXW5JkdOqXWpo2vo3/NSs6yRt9fdfYx9ktkk9UtzuUrqqpcu+d/8AJPI2FeqaXqi+RV1l5zW7fSI5t+8z+nl693qrqi3ZXitS2kmbI1zNq1F6tcnXS+5rmJ17qq2xxTLqeNvK5F7ovoeO40FTa6/8o2iZaeR3zNT5Hp6Khh7HXVK3eudLSvppFlWbr8q7X9H2PJq69V32dE2auSekTvt4x4T6ttv9dBQWyWeokbHGjVVznL0RvmpUK651RWrjJJklvRKyjp2K1nL2VV80LQXtG3eCemqk/NTRrG5qeipoqtlfDltuzh1lttWyeCRFc79aJF9Sxf6bVT4NNm+22pi1HikXiDk7cjS05VTSTq2ro5IVikXSs6oirr8DG8Esf/KfFO0voXtp4qJfGkTw0dz9eqde3fua5LR1Nhp5KGtc2SOBiq17XbTX8lJ7+yPj0H9G5MtkkZJNWOVkbUT+rai61+4xLMVXciZnwU18/PFuZ7J5RNJoAG4XgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMZk9lo7/ZKm1VzEfDOxWr07e5kzXM5zXH8Mooqy/1v3aKV/IxeVXKq/RCmqqKY3q7LlqzXeqii3G8z4Qr1Dgc+PZXUWG7q5YJk/wBDnVPhkai7VFXyVEPfwwt1Di/FevtszUqqeqiZLSSO8mq5dIvubVeeLeH5dkNnx6y8t0Sslc2b82rXxJy90VTG55jlwxq4Ur6WFXxxzrLFVK1VcqL+g5fb+ZiTyz9KjwZc4F3Hmmi/HLv1iJ/BvWUQU9PdXR0yK1NbVPIxiba5FVv4Knc2XGbrZMroY553Rsq4ETxUVyJ28/odmSsoq+ma+0rT1DmLp6xPRypr6GRExVG8LO1UdJjsxsF2jRiMfFy6T9E7fyrTa7OOFtx6qraN1QrvC0vRrm9VMXT0z5q1lK3o5zuXej3qbw91ZdGSxOiZFtF83GL0q9dKvvoy93sNVQNjVPz3P0+FOxmbOlrt9p5bvJS00si61JI1HKi9u6j1Inf3erA2haeKlrauSHxpIIXPYxey6Qi67unvUyZBHQwU8jpo4mxN7u3/AJEj8T7tbbLYX2y1TRrUVCbc9rkX4fqnqY/gvhU09m/KmRRJI1z3Opqd3ZrfJymHd3u3PZ09o7r1O1Fua57+CFqTDYcp4jsxqjir/wAlOkSSrna3su/ibtemuqlusZsdux2y09otVO2Clp2crGtT95CFn45WTHb3d7VkNFDSvp6jkp208fdqb79yWuHebWrN7S+5WrnSJj+VyO7opXi1Wqfo0z1kyNHy8Wmbtyj6PTr4dezZwAZrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABexX7ipWW2/ZPcPy1KxlLbmeFBC9vNzP78/L+4sCRtxM4YU+SXBt7ts6UlzY3S7btkqd9OQxMy3Xco2p6/Bu9AyrGNk816eXeOk+X/AO9lcrBY1xHL7Vl1Mm42SeMyl5fznhO6b15r36FurLeLJlln8SmkjqIZG6kienxN9lTuhWjKVr8Qvs12yS11MlVG3lpkaqrC1eyqjuydPI7pbskNFa8ho6uS1trZPDdBDLp0qrrSrrvrfc1eLkfy+9Efh/35Jlq+mRqtNF3fr2iqOsT47f3b3xosVqwixS5BQVj6Rj18KSBHfOjunwkP2y5PfRuuOMX5bTNGnMjY3cqSeqOTzN2vuOMv1ZBBfblU19Jp2mLUKqRqnmq/yNYnx23Wu92l0Vv3QVfiQTOVNo1u0RHKvl0Pci7VXO8U7LOm6ZbtURE3ZmrvPTpMeW0+kpL4QcaX1Nqnp82YsE1Oi8lUyNeSVqfzPRLx3wmG/R08dskRqyadUKzlVqfraVNkUZ3SUdbeGPt15pKexNRGNp0lRFarei7b7qiqa1nlzsl8Snlt0DobjTuSF8TU34zET5i3Vn5FFM0xMTMfmzKeHNNv3IuVUzEVd4iduX1/7tCcuL/G6KntcNJhEzKqsn+eRzVVIm+pC+U5DTvio3ZRUVdyrX/nXyeLtGL3RE9Opi8Clp6e2X+skdA2dsDW08cmlVXc3Xp9DabpR0d2qrPbpoqOCkbRRSV1QjERWvVVTuWasqu/PNX+C9GhY+NRFqxVNO09avGem/67RslLgjiltzC0w5HcatZ4Wryx0qO+XXk/1JayvJbJiNn8Wsljia1OSGBnzOXyREKqo2vxC0XlLPcKumYypatJ4Uqo1zFd30nfoe6+0tFX1ckl+utwWWGlgmhqHSK/w3ObtV5TMt53JRy0U7T/AN/ZpauF6K7/AD13Zm3v2iOvh+7WLtYn3bL23yvoqmGkuFdyStc1WuY1VXXVfYlbgZI/FsyktlrrvylaK5/KrET44X+SqnprzPDY6HMcxey3W+ZktG9iNqKyaHbdImmuYvromnhxw8s2GRPlpWrNWzInjTv6qq+3ohRiY1VV2LlP4yzdb1azaxJxrm28xtFMdfSZ8pjw8W5gA37mYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwXyzW290L6K50sdRC9NKj2719CFMm+z5HU3SGost7mpaeFyOihenOkaovTWyegY97FtX/fhs9P1fM0+Z/l69onw7x+EoTfwou8KpV3TM0iijRebVM1revffU0W+0eO2urkpIqqe5o3/AMdZ1a3fs1OiloaqnhqoHQzsR8bk0qL5mnO4ZY1JdG1s9P4iMdzNi7IimNdwomY5IZtPEGVVE89e3pER8oRjwu4M22urvy7eaBWUqrzwQvcqq9e+3Iv8CXosDxOK5tuMdko2ztbyoqRJrX0NkijZFE2ONqNY1NIieSHIzLdmiinaIam7m37lU1TXPX4oO4t8DrTclnvlgZ90q0RXyQsT4ZPp6Gi4nj2E3O3utt5WrpatumPnSRdLryc3ei1SpvovZTWavBcdqbutyfRMSR3VzW9EcvqY+RiU1zzU0xuzcTWcqxTyxcqiI7bSjuh4OUdZbv8Aq7KHy0sjUb8USPTX4qZCz8ErbFd2194us1ya2NsaRK3kRUb23pepK9PBFTwpFBG2NjezWppDsPacGzG29PzV1cQ6hVEx7Tv8I3/HZ5rdQ0lupGUtFTxwQsTTWMbpEPSAZcRt2aaqqap3nuAA9eAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGuZ7ltBilpfVVLkfO5F8GFF6uVE/cgDPMys2HWv75dKhrZJF5YIUX45X+TUT6nfbb+3+ijL9eoVtbPB8aVk66WNNbVF9yB+E9qquJGcVfEvLp1fareqtt8LukXMndyIvlpen0PJxBvt24x8S6LBbBI+HHaN6S3GRi9JWovRF9l12Annh9lsOYW6W50dLLFReIrIJHprxUT9JPZTZjwWijt9lt9LaaNIoIoY0ZFEionRE10Q94AA4ySRxMV8r2xtTu5y6RAOQPjXNc1HNVFReyop9AA4RTQyq5IpY3q35ka5F19TmAAAAAAADwZDdaOx2Sru9fIkdNSROlkcq9kRNge/ab1vqCEvs73XKs3vN4zu7V1RHZqiRYbXRdo+RF0r9evT95NoAER/aDz2vscFDiuLudJkd3kSOFI1+KJvm/+J1cSswruGHC6hopLg+55NWtbTUyydXySu0iu0npvf4ATDsGgcDZqpMRSku1+dd7xE9fvznO2sUnTbPoim/gADF5ZfKLG8drb5cZEZTUkSyPX2QD1XO40VspX1VdUxwRMTaue7RoeQcWbRQUMldQ0NXcaVnRZ4m6bzeTevVVNSxulmyy3z8RuIFQ6C0xIstDb1dqNkadnOT9Zf5nzhTS1HEzIZczudMlLYKKRYrRQo3TXon/iuTzVewEm8PMhumSWhbjcbLPaUev5qKf51b6qbOcURrE8mtRPwQ+QzQzIroZWSIi6VWORdL+AHMAAAAAAODZonSuibKxZGptWo5Np+AHMAAAAAAAAAABtN62a9xEyiiw/EK+/Vz0aymiVzWqulc7XRE9zRvs3/wBLLrj9TlWVXGeV9zlWSlpX9oY99EAloAhLjpm96qcttHDTCKtYbxXPSSsqI+q08KLve/JV0qdQJtH0IV445pcsXslpwrHq18+R16NiSdzvijYnzSO/DqbLa8jZaeGtNLT3Zb3XuclI2dV34lR2X8NgZrLczp7TUpbLfTvuN1enMlPF+g39Zy+SIR7eeKWa0EsktLZLddqan61SUjnq6FPffTZ6rVYqq4XOWwUtQ9JnKkt7r9/G5XdUiRfTSqn4GT4zVdswjhVVUNthjinqWpT0kbU+KSRf3r5gd+NcR6youVrpr1bEpoLv8NFPGvwufrfKu/PRJJWt1e6u4lYBgtAqTrZNV1e9v/hq5qpyr+0lTjxxBpOHWA1d2kcj6x7VipIUX4nvXomvpvYGPvvGK10vFGl4f2ugqLlcpU3K6HSsiTz5vTWiUE7EBfZL4f1dvtdVxAyZqy3+/O+8K56dWMd1Tv1Reqk+gAfHuaxqve5GtTqqqukQ+RSMlYj43te1eytXaKByAAAAAAAABwZNE97mMlY5zOjmo5FVPqHTQtlSJ0sbZHdmq5Nr+AHMHxHNVVbzJzIm9b6n1AAAAAAANpvWzw3+6Ulls9VdK6RsdPTRuke5y67JsiH7PV0yvNr1es3utdUx2OomWO1UTvl8NF2j/wAUX9wE2AERfaHzy5WOlocUxSRFyW8yJFBy9ViYvRX9O2toBLo2hD3ErLbjw04V0ND98lueT1rWwU/iLt75nJ30nkim58JrZfbbhlI3JLlLcLnM3xZnvX5VXryp9NgbcAdFwqW0dDPVOarkijV/KnddJvQGDzTK6bHoooWQyVlxqVVKeli6vevr9ENGyW8ZbS07Ku6XujtVRKm6eip9uc9fJrtp0U7Kesno2Jf5IfveQXl2rfA9P6mLy36a31NtxPEYLa51zuci191mTmmml68q/qt9ETyA0HBeI+fZDPXWd2N01JdLc5rZvvDlRr2uTbXJr1Q9uV8UL9g0DKrLrCx9PI7la6hVXKi+6L5GDxPLLVRZ/wARM0q6psVpoFiiR69EcrY+qJ6rtDp4aR12bMu3FHMVVlCsMkdrpJP6uOLr8aovmqp+8CX8ByKPKsXpL5CjEiqW8zUReye/uZ8r59iCrrqrCL394V60rLpIlNzdkZ7exYB00TZWxOlYkjuzVcm1/ADmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABq3EfOrNg1nWuub3ySv6QU0Sc0kzvJEROptKqRViFnhy/iDdMtuzEqIbdO6joIX9WxPYunORPVegGl1HEjj1dVbcse4cQxWtfiRtTKzxFb+1P4Ej8FuJDc+t1bHWW2W1Xe2yJFW0kvdjlToqeqLokHoidtIRXYFt9NxRyvJ2vZDR08bI55EX4ZXcidd+etaA3/ACq+0ePWiWvq3dk0xidXPd5IieZV7Oq2953xCpsPpn81fV6kuMqLttFT734fsq+vubnxXzKS145VZ5eo1Zy7hsVE/wDSevZ6p6+imscELLc7Dj09bKqvyrIkWpq55E2tLTr1Xf7AMzxozG3YjhkOMY63koaZEpGNiXTqiboiMb9FVFVfNDffs24E/EMOSvuUbfy1ddVFW7XVqr15PohCvC6yQcU+NslY1jn4ti68tOjuraiVFVOdfLm7dfYlHjpxlmxi+23DcPijr8hrZWsVvLztgaq62qIBuF1wW5XHirR5bLfZW2+khVkdC3afEvn6G/EdZXmN0slhho+enlvaU3i1cqJ+apkRPic5P4J5kb0XG6+S8LJ7ss9E64wrMslasfLC1rXKjdN31VU662BY003i5il0zHFnWa13dbY98jVkkRFXbUVF10NWdxZbjfBmkzDMEjjuM8Sujp2pyrKvXl0nuh1cK+IOT13D2py7M4IadlS9XW2ljj1I5nkip5qBKVko222101uSZ0qwRI1XOXbl0ncjb7Q/FSkwDH1oYWTS3q4sWKhiY1V5nKmt79t7PDw1utRSw5FxBy68PibzOjbTOm/NQRt+JERO3MaHw5nXi7xDrOKGRtWDGLHzMtkUvRjlTe3qi+elTqBvX2ZJVpcfdR3GS4z3qo/P1ktTG5NOd15UVU8iZyvd74wZBfKe63XDXUlBZLY1zW1lVFz/AHuVOzGJ08/4mfv3E+8UuC09TGyGnuqUKVVbNI3cdOnLvq319gJlBXO3cWs9vtPjlus0NEtZNzT3iufH+Zp4UdpNpvoqtVF7mdj4kZTnF3q6LAn0tPb7Y1Uq7nURc7JHonVrW7T9oE3g1DhFkVfk+EUd0uTWfenoqPexumvVF1tEMjneWWfDcfmvN5qWxQxp8Ld/FI7yRE81Azylf/tD3itzDLbTwnsD3r96kSW6yRLpYoUXqm/dFU82TcUeIFFhM3EF0dHbbRztSlt00XNNO1V6Lzb6b9NHVwpqaTCMTuvFjOHqy7XtyyxQyO29rOqsY38FAn3GrPR2Cx0looImx09LE2NqImt6TWzqy6/UGM47WXu5Stip6WJXuVfYhBnFHPZLvj1bMyjo6O8XCONlsdDzTJTKvxSq7fRO3l5mF4h5JUcaeJ9Nw8sEj/6O26RJbtUxu6P0vVvN28+wGY4HUE2Q3e78Z8xasKPRyW6OZfhhgTrzJvsq6NSpb9/TfMbjxNusU0tBSK+gxyjYxdyyrtPEVPP5k6+xl+MOTvyjILbwUwFWJTrysuU8SbbFGndvTt27k+Yth9jsFmtdupaGFUt0aNge5qK5i60qovqBrHAPBqnCsSlfd5Eku9xmdV1r/wBV7tKrd+iGs8SOMl3TI3Yjw1si328t6SzL/UQL6OXt+83fjjfqjHuHVfV0i8tRNy00TvR0i8qL+1To4H4PQ4XhlNE2PnuNW1Jq6d/V8kjuq7X6gR2y5/aNtMCXi40NkroI9PqKKGJUkVnmjVV2tmR443SpzbgMl4scUroXPR1XE1FVyNbtHt156XoTJe7hS2q11FdWSNjhiYrnKqkSPySj4a8Cp7lcmNSWV876anf/AOK573OaiJ7ooEV8a+ItBlU2McNcerXtts0MbrnLCxVVqIiIsatTqWK4RrKzF46VtuZb6CDUdHFrTljRO6p5EDcAcWpcSxmu4hZJbIpr/eZHS0FMrNOY1dqiaXt9SRcCvbcXwS58Q8vvj5Fr1dOkCyfm4k8mMT6gdf2leKrcStj8WszZZMkuMaNpmMjV3K13RXdPRNmX+zilNQ4bHZ0luNRXxoktZNVsciuld82lVE6bI44M+PnGU3PjVmLfBoafcNngemuVib0vXuqo7RsFy4uXu38QKanqfusFrlpJah1Gsf55Go3caq7yV36ugJ6BW6s44ZNjOF11+ymnp21lxk5bHbmR6lRvXSuTuvkZy9cVcnxbhLbrlf4KeXLLy5GUFFEzSort8qq3z8tgTqCEOIue5zj+B2htHFBU5LLyy1zY4Fc2KJeqrpOyoZrHOIV5zG7W9mM0SttMGluddUxqxF+Hq1iL7+YEqmgYLglzseeZBk1yv0te25uRIKdd8sDEVVROv1NEvPGK85BxipsD4fxwTw0zt3KueznYxE3tqfs7mezvijWyZjDgOCQxV9+eiOqahfihpG+au9V79AJcBGOA5heKeuyG3ZdcaOsW0NY/73TxeG1/NvbUTa9U0aleOMN5ouIFspJH0sVurGOk+5eHzVHI1UTm36qi7RNAT2CFcL4l5FfOMk2Oytpm2yOidPNE1m3U67Tl5n9uqLvRxyXi3XXnKKzHMFfTNitrFfcbvUJzQQa/RT9ZfxAmwGh8EMmvOVYh+U7yjHSLKrYpmR8jZmJ+kieRvgAKafxT4g2XALEtwub/ABJ5F5KalYu5Jnr2RE+pD/EXiZxKxbDYMlrm0MUl2ckVFZ2xbnZz/K5Xb669NAdvFKon4r8ZKDh3QOR1isz21V3e3q2RyaVGbTp2VSwtFTQ0dJDS07EZFExGMankiJpCv+H1tq4HcMW3jIGurMov0njugZ1lnkdtWtRO6IiLo91k4jZpBl9spb/U25kFXEtTVUUcfx0MPq9+9b7ASdxTzGhwfDK2+1rk3ExUhZvq969ERE8+qoRRwYtyYnh964u5w9rbvdmuqV5k14Ua9WRoi9UXfT8TXG3OTjxxc18uE43Ksjnu+WokTz329D7mN9m418Uqfh1jzlTFLRIj7pUR/JIrV6N9FTaJ+0DC2Nblf/ynnVxpXz5HkqOo7LSKm3U9MvTxN+Sad+4lzhrw/fi6WSxcsk1PboHzTq/q1879LzfguyTbbj9nt607qW3wRyU8SQxPRibaxOyIZQCFcD4j4rjGO3N+SV6UtzjrZvvETmKsrk53cmk7r0I1z3M669JJxPySnkt9jt2247bZE1JVz+Ujk/b5IWPvGFYbW3N18umP2yesYnM6plhRXJrz2VujhqOPPHTkRqphuNycrGo34JXoqdPT1A3j7K+JVNrslx4kZU9Uu153M98vRY4u6NXf0NIpmVH2gOPbppUc7D8bl+D9Sd6L0VPLfYz/ANqfiHPE2j4UYU5H3a48sM3g9Vhj7a6dlN1wq1UXCHh5QY3aoWVN8qGeJIidEV+tukevkiIm+vfQEvQxRwxNiiYjGMTTWp2RDmV5xfjTeanHL26pqaKsraSsmiiqYmckLI2fpO6/s9TZ+H/FSVvCCozXNJoIkjmkSJ7WeGkzE+VURfUDfeI1juGR4dcLNa7j+TqmqidG2fS/DtPY7MAx92L4nQ2R9ZJWPpmafNIu1evmpGfBfibkWU2e7ZhkcUFvx1j1S3s5PzsjU3+1fY89JxOyqr4uWmwxMpUoa6N0slEjNzQRo5ER7neW0XeteYE5AiG38Tq6Xi7kVmqvBp8csVJzVFQ9uvzvRdc30XsaneOM2TXm11+S4392tVgpJkhppKuHnkuD1cifA3aKide/UCxQIfzDiVdqPDEnoVp6W4wUaTV1RK3mip3qnRmvNyr015bNco+K+Z3qTHKS0R0jNUkdXe6x8W42tVNq1vXo7ovQCwSuaioiuRFXsmw5FVqoi6XXRSGseuVyzLihUXStuE1us9khRYqdknKk3N153+3Qxlm4w3rNuM64thUUK2O3bW4VsjOZH6VNoi+S9wNhsNpXhTQ5Ll2VX+a4x1UyzuXTlSJqJ0TRGvCjMqjLuJ9Vmt6bdG26R/hWenbE9Wcu/nVda9T1cZ8uqeJ2fU3CbFJlkomvR14qol21rEXq3p3NtvWc02MVlt4X8O7fHX3iONI3cqIsVI39Z/8AkB8wC4ZCv2kMqoLxXzJQpQRy0NO53wq1Xu7J66JsKs3TL8zfxqtmKUjbbdMliXc9ygp+SOKLrtj035dfPzLRwo9ImpK5HP18Somk2BzBE3EXinLT5NFhmGxxV17enNPK5dxUrfNzv8j18DssyHJai+QXmpp66GhmZHBVwQrGyRdLzInVd6VNAScDX8/zCy4Tjs97vlU2GniTom/ie7yaieakLZDxTz+kwqfiFLHR2uzOX/Q7bPFueoRey82+i+2gPT9om7VmaZVauE2PTfFVSJNdXt6oyFF3yrrsu0Jvxu0UdgsNFZrfGkdLRwtiiankiEA8KamiwXD7nxczuRI7vfl8VkSp8fKvVsbU773/ABPS3ifxBdX2O4VEdDR015n3T2p0XNO2n6L4j3b+HpvunkBOGXX+gxnHqu9XKVsdPTRq9yqut6TsnuQfwOoJ73erxxlzF/hMkRyW5siaSGnTz6+qIhh8/wAjm418TYOHthe5cetsqSXWob8sitX5P3KfeMGSLld/t3BHBHf6MxGx3KeJ3SKFukVu09gMlwppKzizxUrOIt6gVLJanrT2aF6bRyovWRPxb+8sWQreM0osFjtPDHAaGO433w2sSKPXJTp0RZH/AIrvXuavfuJ3Ey28QKLh7RT2263mpe18tRFTcrKZnm1yb7+4Fkj45EVFRU2noddIkyU0SVDmum5U51RNJvXU7QNBwrlvWb3m7zNRzaN33SnavaNWqqKqemzG8fOIv9E7G20WVq1mSXNfAoqaJduaq9OdfRE6HDIsKzegv1XXYLkNHQU9wdzVMNVTrLyvXu5vVNGhZzZ7ZwfxytzK83CW/wCZV6LFSySrzakd2SNq9URFAiHLp6L79ZOGE1e6O208337I6tjVer5XLzK3aenM5PwJtzq7Vme4zQ8P+F0arb5o2xV1xVitjhhRNKidtu+h6vs8cL6Ow4LW33MaSCqud5ctZVeO1HJGioqoib7dFPD9jW8zXSLMI4meHbKa6KykYifCxvXaJ7bAmLhxiNuwjEqLH7a1fCp2Ijnu7vd5qpgqvBLnWcXqbM579L9wpabw4aBqqjefrty+S9FNP42cZKyyZRbsJweKK4ZFVSokjVTmbC3fVV9zNcQuKEuJ0ttsFPCy8ZZXNRjaaDojXL3cqddIn8gJWBBWJ8TMotWU3ikzqopfybbqNs09QynWFsUiqu2Iqr8XbyMTX8Xs0uVujya1xUtrtE9YynoKWoh5565qrrmb1RWp28vMCxYIV4rcUbzacVmrLC6mgnpYWrNPMznY6ZU2kTU81Xr27aPIvFLJrjldC23uo6XH7dSRz3utmZtj3K1rlaxd6Req/sAnUFcr5xgza72utyXFaJlHYqWRIqd81Msrqx2/0UTXKnfqbJfeL1x1aMYsNtSuy6via6eJv9XRov6T/wDICaQVsvHFDiVbeI9Fw4o5bdeLvPySzVcVPyxwMVfiaqb7oiKWPpklbTxpO9r5UanO5E0iqB2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+OTaKnqQ1Q0ssFfd8Xdd3WW6ff311FO5fgma9d8qJ+lrXUmYw2TYxZsiiay50qPcz5ZGLyvb9HJ1QDRb1NlVNbHRX3KqGhp+XUkzGpzyJ5o30U6cNx11/bA1aaaix2lfzsilRUkrX73zv3+j36eezabVw3xa3VCTspqiocnVEqZ3St/Y5VNvY1rGIxjUa1qaREToiAU9+0ncpsr4/Y9htLQzVVJbNLLTRtVWudtNKvoiIpKvEujq8E4I368o/xL1UQI2SbXyoum8qeia8iV4MZskN/lvzLfD+UZU0+dWpzKn1PRkFot9+tM9qulO2opJ28skbvNAIA4JupsI4PUdqx5GVd7uEDq2qVq7SDbduc5fLoi69zTeCltazIbrxBuDZLje7hO6ntETm7d3/AK3X6vX9xZ3E8Jx3F7VJbLRQpHBI1WPV68zlaqdtr117HXimCY1jE881poljfKqqqveruTf6u/l/ACuHFR15vl8puGGOVLqi7XNySX6sYu/CYv6O/RNr0PJkGIW5mZUGAtV1PjGMsjnuOvidXTqiOazXmq/FpC0GOYXj1gu1bdbbQtZW1ruaaZy8zlX6r2OE2EY5NlDskkoea4P1zOVy8rlTsqt7bT1ArJxAs82fcU7Rar8qUdltECVM8Cu5WxRtVOVn95UVFNul4hWFUvlyuLJaeGwQrBb6NWaRXcumr/e69iabpgWM3LJIsgq6FXV0beXaPVGuT/ab2X8TH3bhVhV0yNt+rLXz1aORyokipG5U7KrOygVTuFNluR4Bj+N18UlGl9rXPdG9VaqtROZz3e3KnY3LjPSVsPB2HGcHkdQ4/SzQ0T6lqaWqe5yNVUX9XqnXzLG5Tg+OZJ9x/KVEqrQO5qdYnrGrOmtdPLXkey6YxZLlj62GpoY1oFRE8Nqa1rsqa7KBA1twRtgstmx+qrGXS4U7GLSUNOxGxwv6blkRPm9evoapxDpbjnWW0fCfF5XSU8ciTZBcI+yr+rzJ6bXoWdxnDrFj1O+K3U8m3t5VklkWSTXpzL1PuLYfj+MzVc9ooGQS1ciyTyL1c9fqBXHiLh+UYJwkutktrY6OmkckT61snPLVJpURF/V0nQ2qmp0xLhhQcPsIp/v15q6dr6mSNf6vmTaueqefXXUnHJrHbcjstRaLrB41JUNVr270uvZfI8mJYlZMWpVgtNKrN9FfI5XvVPTmXqBheFNgu9ltbWXPkp2NYjIaSN3M2Jvfv5rvZEfHyyPyzj9jNkudc6KxUsKVdTGrtMRWoqoq+vVqFkzV8swPG8nulHc7tSPkqqRdxPZIrN+y67p7KBXfP8hpOIvFWjsDt0mJ481tS9NcqVLv0Gtb+kiq3oeTijYcpzji1iNDNKy3W5GOqaajkZ8EbGKipzJ2VdeRY13DjEXZS3JPyWxK9sTIk0umcrfl+Ht0PVl2E2DKZqWa608iy0u/CkilWNzUXum08gIF4iU7LPj98uFtqn3S6xUzop7giaY3p0hhT9HaJ3TzQ82AWpnDXhbWUVp1LeaunWtu1Y1eb7ujk2jd/raVOhYiqw+wVONTY9LQt+4TMVr2ounL77779zjbcMx+349LY6ehRaOZvJKj3K5z093L1UCu3AGxVGM26Suo4lq8uyCRZOd7d/dod93+haK2xTw0MMVTL40zWoj361tTE4hiNixaB8VopVj516vker3fTa9dexngNH432CpyHA56Wkar5qeeKrRid3eG5HaT66MVbq+uyujo7pjWSx22pbGjKujljR6tcifKqKvwqhJqoi9zU75w8xi71jquellgld1ctNM6LmX1Xl1sDSssWhtaMuHEHLo65lMviQW+BqMdK5P0eVF+PfoavZcRv3F/LqXK8wopLZjFudu2WqRuleidnPav0/eS1ZuG+J2yqSpjt61MrV211VIs3Kvtzb0bcjWo1GoiI1E0iIBAnEnPMSoLPkF3oZXTXO1N/J1JTvTTfEVOiMTzXXmQ7eLXkeTWTCMJvyvt0EkSVFTG7ojItq7mf6KutaLTScKcIkyl2SS2lJK50niqjnqsav8A1uTtsyOTYJjeQ3OkuVyonPqKVESJzHqzp6LrunsBEuQXa12fD/yrLGtJi1li8K2UqppayVE012vNu+XRo3Djhhl+Usl4n3uFam6V1QyWmt80qxsbEi7Ta+nXsWZyXC8dyGnoqe6UDJYKJ6PgiRdMaqeydF7GehijghbDCxrI2JprWppEQCobLG3KuOVXkWXTNfQ44jOSBF6PmXq2NjfPWte524pdp8x4h1fEPJaRzILZItNYra/ppyL86+iIrevpssjDgGMRZPNkTKD/AE6ZUV6q9VYqp2Xl7b9zppuG+J063FYre5PygipN+cXpvvy/q/gBAWe33JlxG83ywsSemj/OXS4uXlSdN68KFfROyqnmhsF1zqtTgbHJaqBtA5lEjq5Ye0SuXlRqKn6SqqftJtrcPx+rxGTFJaFqWqSPw3QtXl6fVDrZhOOMxR+MpQN/JsjUa+PfV2u2177ArnwisVZhvD64Ns6JLld2pZKqsquXf3WPlVyNX36L+09f2dkp8K4YVOUVm7jld/lc6FqfFLLvq3p30ir1UsPjeJWPH7VJbbdS8sErVZIr3K9zkVNaVy9VMfifDvFcYrJKq1UDmyPcrk8SRXozf6qL8v4AQ+2krcUw2syPOGRUNJHK+sdB4m31U7via1V9EXyNAxuzXePHr7xvySmct3qWOZZKV7P6vovIvL+CFrsxxCxZbTwU99pPvUMEiSMjVyo3mTttPM771jdnu+PusNbSNdQOZ4fht+HlTWuip2Aq1a7Rd8W4S5C+0zST5HXUq1l1uCLzeHzJtI2r5LpU6ex3cLcCba+F1E6+XZZm3J3jrbqdv52qkVem1TqqexZ214xZbbYnWWlo2JRvZyPa74lenuq9zX6XE8XwK3VF4t9qrKlYEVzYmuWZ6bXsxFXp+AHismTW/DY7PjmQVMUFwuTtUlLCxEbC1E+X/mSMnYhrHMQrs24oU/EnIrfLb4aCLwrbRTIqP8/je1ey6XsTKBWfL7NT3r7Us9wyOtR1msNDFOyCR2mpI7elRPXoa8mSxcRuME+R3WB/5FxtyRW2gVNPnnXq1UTz6oWOvHD3F7tlDMkraJ0lwa1Gq5JFRrkTtzN7L+Jxs3DrErRkdRf6K2NZW1Cor1Vyq3adlRvZFArVV45lmYfaQknu9zjo22ulSogSZm2U/Rqppq9F79T18T7X90xmupcffPVVF2qEpZLm7auqZFT5WL+oib7ehY3JcAxrILzDd7hSy/fImqxJIpXR8yejtd+3mem/4bj97ssForaJEpIHI6JsTuRWL6oqdlArrXw/0J4LVeNYoiubTxNS5VkfTxZXqjeVFTz2qGf4E47Nh2O0mLY2jH3ysc2ovFfy8zafelWPfmvTWvLZNVVhWO1OKvxqShT8nSIiPYjtOcqLtFV3ffuezGMdtWOUH3O1U/hR91c5eZzl93L1UDKRorY2tcu1ROq+pyAAjX7Sl5rLRwpuTbfzJV1zfukTmrpWuci6U1Xh7SxYNg9BhmKNZV3yqjSWtqGptIVcm1c9fXr2Ul/K8eteT2aa0XiBZqWVPiRHK1U90VOqKdWK4vZsaoUpLVS8jUTSvevO9ye7l6qBWrhfZbVa+KGUZpcpVr62mqPulBC5OaWSVURVcid17r+B6OM94vMDosXtUjqnM8lXllSNd/coF8k/eWBtOCYzbMiq79SW9G11U/xJHOcqojvVEXoi/Q50WE45SZVPk8VA1brMmnTvXmVE9t9vwAq1k+BxY1BYuFNFOtLTvY2uyCtXqsqa2jUXy2rVRE9z1cVLTU5jXYzg0TEttgROdsb3cqNp49be73VCzd8wnHb1fqe93Cj8Wsp00x3OqIqeSKnZfxOvI8Exu/3KiuFxoldPRorYVY9WJpe6Kid09gI4ZTQMxaW5spVhxXG6ZX0kHLyrVPjT519un47NR4PxyWO03HiHd2Or8syBz20NK1PjZFtUamu6JpG9SyFTbKGotMlqkp2LRyR+E6JE6K3WtGGxXB8dxpd2ykcioq8qyvWRWb8k32T6AVW4uYnm9NgVHBVctBPfLmiVqtfzLUKvZXL5IidNexINLg8dvbZrO+ubeLnSRI2lpmN5YKNuur3onTffqpO+V45acntTrbeKfxqdy76O5XNX1RU6op0Y9idlsVDJR2+nc1srVa973q+RU1rXMvUCruY22t4k5xDwuxWpkS0W6VJr3cGp/Wy76ov4tQ3Gy2+kwy80+B35Y6K2rJNWJI2TndUsYnMnO79FOnbzJwxHEbDisc7LLQsp1qHq+V/dz1X1Xup4c54eYvmc9PPfaJ8stPvkeyRWLpe6Kqd09gKsVmX5FdbbnOQW+lfTWqunjoqOZia8XlRzWtZ6ovsbJitCnDjhBcKGxp4l0fSurbxWtT5UVNpGi+TtO/cWMr8JxutxhmNyW2JltZrlij+DlVOyoqefucqfDMegxifHGUKLQVEaxytcu3PT3d3UCunBeyVGGYbVvtjEny69RvqKmZU5vucaoqptfVU0ujx8Iq+j4Z8L7txAur1ueS3lz3xaXmkVu1RN+etlmsZxCxY7b5KK20nLHI3le6Ryvcqa1rmXqYWg4VYXRUNZRQ2xzoKtFSRr5Vdyoq7+Hfy9fQCE+BFBdo/Fv0PLU5dksiVNVUOZttHCq75VTyXuhZC8pU0+L1aMlV1Qylfp6J1V3KvU6MQxWy4pbkobNS+DEia25yucqeiuXqZpyI5qtciKippUUCnvBTDKl9lyHKr7kC0sFwrpI50RP9IlRrl+Bi72irvshY3hJaqm22R3+jMoqF6otJSo3TmN/Wcvm5e6nfaeG+KWy7y3OloXpLLIsrmOlV0aPVdqqMXoim3oiIiIiIiJ2Arjx8sS5bx2xay3OuRtjpKV9fVQvXTFRj0Ta+/U1rPMjpeI/FCkxtWLS4pjjUqJGuTX3pzeiI318ixmWYJjmT3OkuV2pHyVNK3ljeyRWfDvel13T2U87OG+IsyVuQttbUrmsSPaOXkVE9W9gK18TbLlGc8Y8YtVVKlBbEhSopaaRnwRIm9bRe69DYeINKyx2S8XK31kl1uSMSnqrly/BG568rY4k/RXa9UTyUn7L8Ix/KZqSa600izUiqsMkUixuTprW0669jtrMPsFXjTsdmoWrb3a5mJ0VVTsqr337gV2wGg/6POGFZTWVFlvdTSurLrVInWFOXfIq+vc48CrFJidkqrlRxpVZdkHNUc7vi+6wr1Rzl9dKi68yxVsw3H7fj89jp6JPuc7FZKj3K5z0VNdXL1UYnh1hximdBaqRWNcmldI5Xu16bXrr2ArNwTq6Hh9hOR8TL/M66ZDcJ50gbvml5WPc1U9UbtEPdwOp7u+tqcpc1KvMMik5+dybSig3+knr0QnS28K8Lt8VfFBbFWOuR6TNkkVyJzLt3Ki/LtfQzGHYfYcSo1pbLSeExe7nuV7vpteugMzRMljpI2TyeJKjU53a7qRD9qjiNf+HuOWmXHYmrVXCsSDxHs5mxptO/13omQw2YYxZcss77VfKNlVTPXel6K1fVF7ooGOhyyktOD0V5ySrhgnfTNfI1HJt79dmp5qRlimJ3XibnDM6zGldT2mif8A9UUEidVTfzuRe3ZCQrDwvxGzPiWCkqKhIvkbVVDpmt/ByqboxrWMRjGo1qJpERNIgGi8equotvBzJJ6FqpJHb5EZy/o9CJeBdS3DuDNFbbQjKi/3Jj6ioVvXwu/xuLG3OiprlQT0FZE2WnnYrJGO7ORfIwWJ4PjeMUM1HaaBI45to9XuV7tL3Ta9dewFauBdrWiulzz2pgWvyK8yujtsK/ErGovWRy+SbRTOfZ5s60/EXN83zKvZUVlHVOpmyS9PDVOvwovbvonjEMFxvFHyPs9EsTnqq7e9X8u12qJvsn0PNNw4xWXIJr46ik+9Tu55USVyRvd6qzsqgV2+0mzIM7umMU1Cz8n2m6VzmNjc3Xjtbped/su+iG6Jh8cd1o6BtzS6XKkg8JJmt5YLfEiaXp2R2vP2JlyzD7Dk9uhoLrSc0MDkdF4TlY6Nf9lU6oc7bitlt9mmtVLTK2CdislcrlV70X1d3UCrNTZazjJxCixexyy0uJ4/JupqW9PvEyL1X6731O7jJh+V0OBY9iMiQ2m21F4bSvSKTndUo5XKjnu6eXkWjxPGLLi1AtFZKJlNE5yudru5fVV8z7l2NWjKbX+TrzTrNAjke3Tla5rk80VOqKBod7rKSw4nT4Xi1LDNWRUfVGtRzKdEbtXL+JDXBOvpMAwO+cQ7zK+5ZFdXv8BE+KRzU7dPqWex7FrNYqOSmoKZUSRvK98jle9ya1pXL1MLa+FuGW6Otjp7YqsrEVJGvkVyN335d/L+AEG8C7dd2zz5T8FXl2UuSeR6/E2hp1Xab/VX5kLQ0McsNHFFPL4srWIj361zL6mHwzEbHiNuSgslJ4MSJrbnK52vTmXrozwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKiOTSoip6KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/Z" alt="MIUR" style="width:52px;display:block;margin:0 auto 4px;filter:brightness(0) invert(1);">
            <strong style="display:block;font-size:.72rem;color:var(--accento)">Accreditato MIUR</strong>
            <span style="display:block;font-size:.68rem;color:rgba(255,255,255,.6)">Ente di Ricerca</span>
          </div>
        </div>
        <div class="urgenza-strip" id="urgenza-strip">
          <div class="urgenza-icon">⏳</div>
          <div class="urgenza-text">
            <h4 id="urgenza-title">Il momento di agire è adesso — non dopo la verifica OIV</h4>
            <p id="urgenza-body">La Relazione sulla Performance viene validata dall'OIV entro giugno. Chi non ha ancora un sistema CS documentato e metodologicamente corretto non potrà far validare il proprio ciclo. La finestra operativa utile è ora.</p>
          </div>
          <div class="urgenza-deadline">
            <b>24h</b>
            <small>Risposta<br>garantita</small>
          </div>
        </div>
        <div class="cta-btns">
          <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-cta-primary">📅 Avvia il percorso di conformità — prima della prossima validazione OIV</a>
          <a href="mailto:customerpa@troisiricerche.it?subject=Richiesta%20percorso%20conformità%20CS" class="btn-cta-secondary">✉️ Invia questo report a customerpa@troisiricerche.it</a>
          <button onclick="stampaSoloReport()" class="btn-pdf">📄 Scarica il CustomerPA Report in PDF</button>
        </div>
      </div>
      <div class="cta-footer-note">
        🛡️ <span><strong style="color:var(--testo)">Colloquio operativo gratuito — nessun impegno.</strong> Non vendiamo consulenze generiche. In 30 minuti analizziamo i gap specifici del tuo ente e proponiamo un piano d'azione con tempi, costi e output documentati. Risposta entro 24 ore lavorative. Troisi Ricerche S.r.l. · P.IVA 07216100722 · Accreditato MIUR come Ente di Ricerca · 200+ PA servite · Dal 2006.</span>
      </div>
    </div>

  </div><!-- /step-result -->

</div><!-- /audit-wrap -->

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">CustomerPA</div>
        <p>La piattaforma italiana per la misurazione della soddisfazione dei cittadini nei servizi pubblici locali. CustomerPA Index, benchmark comuni, calcolatore campione statistico.</p>
        <p class="brand-legal">CustomerPA · Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari (BA) · CF/P.IVA 07216100722 · SDI KRRH6B9</p>
      </div>
      <div class="footer-col">
        <h4>Piattaforma</h4>
        <ul>
          <li><a href="#cpi">CustomerPA Index</a></li>
          <li><a href="#strumenti">Strumenti</a></li>
          <li><a href="#grafici">Grafici</a></li>
          <li><a href="#calcolatore">Calcolatore campione</a></li>
          <li><a href="#benchmark">Benchmark comuni</a></li>
          <li><a href="#questionario">Genera questionario</a></li>
          <li><a href="#metodo">Metodologia</a></li>
          <li><a href="#faq">FAQ</a></li>
          <li><a href="#">Accedi</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Ecosistema Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">Troisi Ricerche</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.mappaturadellecompetenze.it" target="_blank">Mappatura delle Competenze</a></li>
          <li><a href="https://www.registrodellecompetenze.it" target="_blank">Registro delle Competenze</a></li>
          <li><a href="https://www.benessereorganizzativo.it" target="_blank">BenessereOrg.</a></li>
          <li><a href="https://www.troisiformazione.it" target="_blank">Troisi Formazione</a></li>
          <li><a href="https://www.tiplive.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
          <li><a href="https://www.digitalizzazionenellapa.it" target="_blank">DigitalizzazionePA</a></li>
          <li><a href="https://www.dibattito-pubblico.it" target="_blank">Dibattito Pubblico</a></li>
          <li><a href="https://www.voiceinhub.it" target="_blank">VoiceInHub</a></li>
          <li><a href="https://www.governancefinanziaria.it" target="_blank">Governance Fin.</a></li>
          <li><a href="https://www.consulenzainternazionalizzazione.it" target="_blank">Internazionalizzazione</a></li>
          <li><a href="https://www.benesseredigitalegiovani.it" target="_blank">BDG</a></li>
          <li><a href="https://www.osservatoriomezzogiorno.net" target="_blank">Osservatorio Mezzogiorno</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una demo</a></li>
          <li><a href="mailto:customerpa@troisiricerche.it">customerpa@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/in/andreatroisi/" target="_blank">LinkedIn Andrea Troisi</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn Troisi Ricerche</a></li>
          <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a></li>
          <li><a href="https://www.cacuccieditore.it/troisi-andrea-2" target="_blank">Libro Cacucci Editore</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 CustomerPA · Troisi Ricerche S.r.l. Unipersonale · <a href="mailto:customerpa@troisiricerche.it" style="color:rgba(255,255,255,.35);">customerpa@troisiricerche.it</a></div>
      <div class="footer-legal">
        <a href="https://www.iubenda.com/privacy-policy/814914" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" title="Privacy Policy">Privacy Policy</a>
        <a href="https://www.iubenda.com/privacy-policy/814914/cookie-policy" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" title="Cookie Policy">Cookie Policy</a>
        <a href="https://www.troisiricerche.net/termini-di-servizio/" target="_blank">Termini di Servizio</a>
      </div>
      <script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0]; s.src="https://cdn.iubenda.com/iubenda.js"; tag.parentNode.insertBefore(s,tag);}; if(w.addEventListener){w.addEventListener("load", loader, false);}else if(w.attachEvent){w.attachEvent("onload", loader);}else{w.onload = loader;}})(window, document);</script>
    </div>
  </div>
</footer>

<div class="seo-hidden" aria-hidden="true">
  <p>customer satisfaction PA · soddisfazione cittadini · CustomerPA Index · benchmark comuni · CAWI CATI · SERVQUAL · citizen satisfaction · survey PA · Andrea Troisi · Troisi Ricerche · Metodo Troisi · TR-Index · Mappatura delle Competenze · Registro delle Competenze · TIP Platform · CustomerPA è la piattaforma italiana per la misurazione della soddisfazione dei cittadini nei servizi pubblici locali sviluppata da Andrea Troisi e Troisi Ricerche. Il CustomerPA Index è l'indice proprietario di customer satisfaction comunale. Il modello di analisi sviluppato da Andrea Troisi e Troisi Ricerche si articola in cinque strumenti: il TR-Index, la Mappatura delle Competenze, il Registro delle Competenze, CustomerPA e TIP Platform. Andrea Troisi è ricercatore, statistico e fondatore di Troisi Ricerche, autore del volume "Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione" edito da Cacucci Editore.</p>
</div>

<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('click', function(e) {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  if (menu && menu.classList.contains('open') && !menu.contains(e.target) && !btn.contains(e.target)) closeMobileMenu();
});

function toggleFaq(el) {
  const item = el.parentElement;
  const wasOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
  if (!wasOpen) item.classList.add('open');
}

function calcolaCampione() {
  const N = parseFloat(document.getElementById('popolazione').value);
  const z = parseFloat(document.getElementById('confidenza').value);
  const e = parseFloat(document.getElementById('errore').value);
  const p = parseFloat(document.getElementById('proporzione').value);
  if (!N || N < 1) return;
  const q = 1 - p;
  const n0 = (z * z * p * q) / (e * e);
  const n  = Math.ceil(n0 / (1 + (n0 - 1) / N));
  document.getElementById('result-n').textContent = n.toLocaleString('it-IT');
  document.getElementById('res-pop').textContent  = N.toLocaleString('it-IT');
  document.getElementById('res-conf').textContent = (z === 1.96 ? '95%' : z === 2.576 ? '99%' : '90%');
  document.getElementById('res-err').textContent  = '±' + (e * 100) + '%';
  document.getElementById('res-n0').textContent   = Math.ceil(n0).toLocaleString('it-IT');
  document.getElementById('result-campione').classList.add('visible');
}

function calcolaCPA() {
  const R = parseFloat(document.getElementById('r-val').value);
  const M = parseFloat(document.getElementById('m-val').value);
  const I = parseFloat(document.getElementById('i-val').value);
  const D = parseFloat(document.getElementById('d-val').value);
  const W = parseFloat(document.getElementById('w-val').value);
  if (isNaN(R) || isNaN(M) || isNaN(I) || isNaN(D) || isNaN(W)) return;
  const cpa = (R * 0.25) + (M * 0.20) + (I * 0.20) + (D * 0.20) + (W * 0.15);
  const score = Math.round(cpa * 10) / 10;
  let judgment = '', color = '';
  if (score >= 7.5)      { judgment = '🟢 Eccellente'; color = '#16a34a'; }
  else if (score >= 6.5) { judgment = '🟡 Buono'; color = '#ca8a04'; }
  else if (score >= 5.5) { judgment = '🟠 Sufficiente'; color = '#ea580c'; }
  else                   { judgment = '🔴 Da migliorare'; color = '#dc2626'; }
  document.getElementById('cpa-score').textContent = score.toFixed(1);
  const jEl = document.getElementById('cpa-judgment');
  jEl.textContent = judgment;
  jEl.style.color = color;
  document.getElementById('cpa-breakdown').innerHTML =
    `<span>Rifiuti (×0.25): <strong>${(R*0.25).toFixed(2)}</strong></span>
     <span>Mobilità (×0.20): <strong>${(M*0.20).toFixed(2)}</strong></span>
     <span>Idrico (×0.20): <strong>${(I*0.20).toFixed(2)}</strong></span>
     <span>Digitale (×0.20): <strong>${(D*0.20).toFixed(2)}</strong></span>
     <span>Welfare (×0.15): <strong>${(W*0.15).toFixed(2)}</strong></span>`;
  document.getElementById('result-cpa').classList.add('visible');
}

const domande = {
  rifiuti: {
    titolo: '🗑️ Rifiuti & Raccolta differenziata',
    items: [
      'Come valuta la pulizia delle strade e degli spazi pubblici?',
      'Come valuta la frequenza della raccolta dei rifiuti?',
      'Come valuta la qualità del servizio di raccolta differenziata?',
      'Come valuta la disponibilità di contenitori per la differenziata?',
      'Come valuta la gestione dei rifiuti ingombranti?',
      'Come valuta la manutenzione del verde pubblico?',
      'Come valuta la comunicazione del Comune sui servizi ambientali?',
      'In generale, come valuta il servizio di igiene urbana del suo Comune?'
    ]
  },
  mobilita: {
    titolo: '🚌 Mobilità & Trasporto pubblico',
    items: [
      'Come valuta la frequenza dei mezzi di trasporto pubblico?',
      'Come valuta la puntualità del trasporto pubblico?',
      'Come valuta la copertura territoriale del trasporto pubblico?',
      'Come valuta lo stato di manutenzione dei mezzi pubblici?',
      'Come valuta la disponibilità di piste ciclabili?',
      'Come valuta la gestione del traffico e dei parcheggi?',
      'In generale, come valuta la mobilità nella sua città?'
    ]
  },
  idrico: {
    titolo: '💧 Servizi Idrici & Acqua',
    items: [
      'Come valuta la qualità dell\'acqua potabile?',
      'Come valuta la continuità del servizio idrico?',
      'Come valuta il costo delle bollette idriche?',
      'Come valuta la gestione delle perdite idriche?',
      'Come valuta la comunicazione sulle interruzioni del servizio?',
      'In generale, come valuta il servizio idrico del suo Comune?'
    ]
  },
  digitale: {
    titolo: '💻 Servizi Digitali PA',
    items: [
      'Come valuta la facilità d\'uso del portale web del Comune?',
      'Come valuta la disponibilità di servizi online (certificati, permessi)?',
      'Come valuta i tempi di risposta agli sportelli online?',
      'Come valuta l\'accesso ai servizi tramite SPID?',
      'Come valuta i pagamenti digitali verso il Comune (PagoPA)?',
      'Come valuta la disponibilità di app comunali?',
      'In generale, come valuta la digitalizzazione dei servizi comunali?'
    ]
  },
  welfare: {
    titolo: '🤝 Welfare & Servizi Sociali',
    items: [
      'Come valuta i servizi di assistenza agli anziani?',
      'Come valuta i servizi per persone con disabilità?',
      'Come valuta l\'offerta di asili nido e servizi 0-3 anni?',
      'Come valuta i servizi scolastici comunali (mense, trasporto)?',
      'Come valuta i servizi di sostegno alle famiglie in difficoltà?',
      'In generale, come valuta i servizi sociali del suo Comune?'
    ]
  }
};

function toggleServizio(el) {
  el.classList.toggle('selected');
  const check = el.querySelector('.si-check');
  check.textContent = el.classList.contains('selected') ? '✓' : '';
}

function generaQuestionario() {
  const selezionati = document.querySelectorAll('.servizio-item.selected');
  if (selezionati.length === 0) {
    alert('Seleziona almeno un servizio da indagare.');
    return;
  }
  let html = '<div style="font-size:0.78rem; color:var(--grigio); margin-bottom:12px; font-weight:600;">SCALA DI RISPOSTA: 1=Per nulla soddisfatto · 10=Molto soddisfatto</div>';
  let numDomanda = 1;
  selezionati.forEach(item => {
    const key = item.dataset.servizio;
    const sezione = domande[key];
    html += `<div class="qo-sezione"><div class="qo-titolo">${sezione.titolo}</div>`;
    sezione.items.forEach(d => {
      html += `<div class="qo-domanda"><span class="qo-num">${numDomanda}.</span>${d}</div>`;
      numDomanda++;
    });
    html += '</div>';
  });
  html += `<div style="font-size:0.72rem; color:var(--grigio); margin-top:12px; border-top:1px solid var(--bordo); padding-top:8px;">Totale domande: <strong>${numDomanda-1}</strong> · Metodo Troisi Ricerche · CustomerPA Index · © 2026</div>`;
  const output = document.getElementById('questionario-output');
  output.innerHTML = html;
  output.classList.add('visible');
}




<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
</script>
<script>

// =============================================
// CONFIGURAZIONE SCORING PESATO
// =============================================
var PESI = { 1:3, 2:3, 3:2, 4:3, 5:2, 6:2, 7:1, 8:1 };
var MAX_SCORE = 0;
for (var k in PESI) MAX_SCORE += PESI[k] * 2; // 2 = valore massimo per risposta

var answers = {};
var LABELS = [
  'Piano della Performance / PIAO',
  'Rilevazione Customer Satisfaction',
  'Pubblicazione su Amministrazione Trasparente',
  'Collegamento alla Performance Dirigenziale',
  'Validazione OIV / Nucleo di Valutazione',
  'Metodo statistico e campionamento',
  'CS nel PIAO con indicatori misurabili',
  'Piani di miglioramento formali'
];
var NORMS = [
  'D.Lgs. 150/2009 art. 10 · D.L. 80/2021 (PIAO)',
  'D.Lgs. 150/2009 artt. 8 e 29',
  'D.Lgs. 33/2013 · Trasparenza',
  'D.Lgs. 150/2009 art. 8 c.1 lett. c)',
  'D.Lgs. 150/2009 art. 14',
  'Linee guida DFP 2017',
  'D.L. 80/2021 · PIAO',
  'D.Lgs. 150/2009 · Ciclo performance'
];
var FASE_LABELS = { 1:'Fase 1',2:'Fase 1',3:'Fase 1',4:'Fase 2',5:'Fase 2',6:'Fase 3',7:'Fase 3',8:'Fase 3' };

// Micro-copy per ogni step
var MICRO_COPY = {
  1: '⚖️ <strong>Punto critico — peso massimo.</strong> Il PIAO è il documento che la Corte dei Conti verifica per prima nelle ispezioni sui controlli interni. Un gap qui compromette tutto il ciclo.',
  2: '🔴 <strong>Attenzione: questo è l\'adempimento più spesso contestato.</strong> Il 43% delle PA monitorate non ha condotto rilevazioni metodologicamente valide nell\'ultimo anno. Sei in quella fascia?',
  3: '👁 <strong>Questo dato è pubblico e verificabile ora.</strong> Qualunque cittadino, giornalista o ispettore ANAC può accedere ad Amministrazione Trasparente e verificare l\'inadempimento in tempo reale.',
  4: '⚠️ <strong>Fase 2 — il punto più critico per la valutazione individuale.</strong> Se la CS non è collegata alla performance dirigenziale, l\'OIV può invalidare l\'intera Relazione sulla Performance.',
  5: '🏛 <strong>La firma dell\'OIV ha valore giuridico.</strong> La sua assenza o genericità in sede di validazione espone i dirigenti responsabili a responsabilità personale — non solo dell\'ente.',
  6: '📐 <strong>Fase avanzata — qui si distinguono gli enti seri.</strong> Il DFP ha dichiarato che rilevazioni metodologicamente inadeguate non soddisfano l\'obbligo normativo anche se "formalmente" condotte. Non basta fare la rilevazione.',
  7: '📋 <strong>Un obiettivo senza target non è un obiettivo.</strong> L\'OIV non può validare ciò che non è misurabile. Senza indicatori numerici nel PIAO, la CS non è rendicontabile.',
  8: '🎯 <strong>Ultimo punto — la prova che il ciclo si chiude davvero.</strong> Un ente che rileva ma non migliora ha fatto un esercizio burocratico, non un adempimento normativo. Sei quasi alla fine.',
  reg: '🔒 <strong>Verifica completata.</strong> Stiamo elaborando il tuo CustomerPA Score su scoring pesato a 3 livelli e confrontando il profilo del tuo ente con il benchmark nazionale di 200+ PA italiane.'
};

// Dots
function buildDots() {
  var c = document.getElementById('progress-dots');
  for (var i = 1; i <= 8; i++) {
    var d = document.createElement('div');
    d.className = 'progress-step-dot'; d.id = 'dot-' + i;
    c.appendChild(d);
  }
}
buildDots();

// Selezione risposta
function sel(step, val, type) {
  answers[step] = val;
  // Stile opzione selezionata
  var opts = document.querySelectorAll('#step-' + step + ' .opt');
  opts.forEach(function(o) {
    o.classList.remove('selected','selected-ok','selected-warn','selected-ko');
  });
  var cls = type === 'ok' ? 'selected-ok' : type === 'warn' ? 'selected-warn' : 'selected-ko';
  var radio = document.querySelector('#step-' + step + ' input[value="' + val + '"]');
  if (radio) radio.closest('.opt').classList.add(cls);
  var btn = document.getElementById('btn-' + step);
  if (btn) btn.disabled = false;
}

function goNext(step) {
  document.getElementById('step-' + step).classList.remove('active');
  var next = step < 8 ? 'step-' + (step+1) : 'step-reg';
  document.getElementById(next).classList.add('active');
  updateProgress(step + 1);
  window.scrollTo({top:0,behavior:'smooth'});
}
function goBack(step) {
  var cur = step === 'reg' ? 'step-reg' : 'step-' + step;
  document.getElementById(cur).classList.remove('active');
  var prev = step === 'reg' ? 'step-8' : 'step-' + (step-1);
  document.getElementById(prev).classList.add('active');
  var n = step === 'reg' ? 8 : step - 1;
  updateProgress(n);
  window.scrollTo({top:0,behavior:'smooth'});
}

function updateProgress(n) {
  var isReg = (n === 'reg' || n > 8);
  var num = isReg ? 8 : n;
  var pct = Math.round((num / 8) * 100);
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-pct').textContent = pct + '%';

  var faseMap = {
    1:'🔵 Verifica base · Adempimenti fondamentali',
    2:'🔵 Verifica base · Adempimenti fondamentali',
    3:'🔵 Verifica base · Obbligo di trasparenza',
    4:'🟠 Verifica operativa · Performance dirigenziale',
    5:'🟠 Verifica operativa · Controllo indipendente OIV',
    6:'🟣 Verifica avanzata · Qualità metodologica',
    7:'🟣 Verifica avanzata · Integrazione PIAO',
    8:'🟣 Verifica avanzata · Chiusura ciclo performance'
  };
  document.getElementById('progress-label').textContent = isReg
    ? '🔍 Elaborazione CustomerPA Score in corso...'
    : (faseMap[num] || 'Verifica') + ' · Punto ' + num + ' di 8';

  // Dots
  for (var i = 1; i <= 8; i++) {
    var d = document.getElementById('dot-' + i);
    if (!d) continue;
    d.className = 'progress-step-dot';
    if (i < num) d.classList.add('done');
    else if (i === num) d.classList.add('current');
  }

  // Micro-copy
  var mc = MICRO_COPY[isReg ? 'reg' : num] || '';
  document.getElementById('micro-copy').innerHTML = mc;
}

function ckReg() {
  var ok = document.getElementById('f-nome').value.trim() &&
           document.getElementById('f-cognome').value.trim() &&
           document.getElementById('f-email').value.indexOf('@') > 0 &&
           document.getElementById('f-comune').value.trim() &&
           document.getElementById('f-privacy').checked;
  document.getElementById('btn-reg').disabled = !ok;
}

// PRE-OUTPUT SCREEN — effetto AI
function showPreOutput() {
  document.getElementById('step-reg').classList.remove('active');
  document.getElementById('preoutput').classList.add('active');
  updateProgress(9);

  var steps = [
    ['Acquisizione dati istituzionali...','Verifica D.Lgs. 150/2009 art. 10...', 1],
    ['Analisi adempimenti normativi...','Confronto con linee guida DFP 2017...', 2],
    ['Calcolo punteggio pesato...','Ponderazione criteri critici × 3...', 3],
    ['Generazione CustomerPA Score...','Benchmark su 200+ enti PA italiani...', 4],
    ['Elaborazione scenario di rischio...','Identificazione gap prioritari...', 5],
    ['CustomerPA Report pronto.','Trasmissione sicura in corso...', null],
  ];
  var i = 0;
  var interval = setInterval(function() {
    if (i >= steps.length) {
      clearInterval(interval);
      setTimeout(showResult, 500);
      return;
    }
    document.getElementById('ai-step-text').textContent = steps[i][0];
    document.getElementById('ai-norm-text').textContent = steps[i][1];
    // Attiva bullet progressivi
    if (steps[i][2]) {
      var poi = document.getElementById('poi-' + steps[i][2]);
      if (poi) poi.classList.add('done');
    }
    i++;
  }, 750);
}

// CALCOLO SCORING PESATO
function calcolaScore() {
  var scoreOttenuto = 0;
  for (var i = 1; i <= 8; i++) {
    var val = answers[i] !== undefined ? answers[i] : 0;
    scoreOttenuto += val * PESI[i];
  }
  var pct = Math.round((scoreOttenuto / MAX_SCORE) * 100);
  return { raw: scoreOttenuto, max: MAX_SCORE, pct: pct };
}

function showResult() {
  var score = calcolaScore();
  var pct = score.pct;
  var nome = document.getElementById('f-nome').value;
  var cognome = document.getElementById('f-cognome').value;
  var email = document.getElementById('f-email').value;
  var ente = document.getElementById('f-comune').value;
  var tipo = document.getElementById('f-tipo').value;
  var ruolo = document.getElementById('f-ruolo').value;
  var nomeCompleto = nome + ' ' + cognome;

  var livello = pct >= 70 ? 'VERDE' : pct >= 40 ? 'GIALLO' : 'ROSSO';
  var livelloTxt = pct >= 70 ? 'VERDE — Buona compliance' : pct >= 40 ? 'GIALLO — Compliance parziale' : 'ROSSO — Rischio di inadempimento';

  // Invia lead
  fetch('https://formspree.io/f/mdawbgbw', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      _to: 'customerpa@troisiricerche.it', _replyto: email,
      _subject: '🏛 Audit CustomerPA — ' + ente + ' — ' + livelloTxt + ' (' + pct + '%)',
      strumento: 'CustomerPA Audit v2 (scoring pesato)',
      nome: nomeCompleto, email: email, ruolo: ruolo,
      ente: ente, tipo: tipo,
      score_pesato: score.raw + '/' + score.max,
      pct: pct + '%', livello: livelloTxt,
      data: new Date().toLocaleDateString('it-IT'),
      risposte: JSON.stringify(answers)
    })
  }).catch(function(){});

  // Email conferma
  fetch('https://formspree.io/f/mdawbgbw', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      _to: email, _replyto: 'customerpa@troisiricerche.it',
      _subject: 'Il tuo CustomerPA Report — ' + ente,
      messaggio: 'Gentile ' + nome + ', il CustomerPA Score di ' + ente + ' è ' + pct + '% — Livello ' + livelloTxt + '. Il team di Troisi Ricerche ha ricevuto il tuo report e ti contatterà entro 24 ore lavorative. customerpa@troisiricerche.it — Troisi Ricerche S.r.l. · Accreditato MIUR come Ente di Ricerca · Dal 2006.'
    })
  }).catch(function(){});

  // Nascondi preoutput, mostra risultato
  document.getElementById('preoutput').classList.remove('active');
  document.getElementById('step-result').classList.add('active');
  document.getElementById('progress-fill').style.width = '100%';
  document.getElementById('progress-pct').textContent = '100%';
  document.getElementById('progress-label').textContent = 'CustomerPA Report generato';
  document.getElementById('micro-copy').innerHTML = '🏅 Audit CustomerPA completato · Score calcolato su <strong>modello a pesi differenziati — standard Metodo Troisi</strong> · Questo documento è utilizzabile come base per la Certificazione CustomerPA';
  window.scrollTo({top:0,behavior:'smooth'});

  // Gauge
  var gauge = document.getElementById('result-gauge');
  gauge.innerHTML = '<div class="gauge-score">' + pct + '%</div><div class="gauge-label">CustomerPA Score</div>';
  gauge.className = 'cpa-gauge ' + (livello==='VERDE'?'gauge-verde':livello==='GIALLO'?'gauge-giallo':'gauge-rosso');

  // Badge
  var badge = document.getElementById('result-badge');
  badge.textContent = livello === 'VERDE' ? '🟢 Livello VERDE — Buona compliance' : livello === 'GIALLO' ? '🟡 Livello GIALLO — Compliance parziale' : '🔴 Livello ROSSO — Rischio di inadempimento';
  badge.className = 'cpa-index-badge ' + (livello==='VERDE'?'badge-verde':livello==='GIALLO'?'badge-giallo':'badge-rosso');

  // Titolo con anno corrente
  var anno = new Date().getFullYear();
  document.getElementById('result-title').textContent =
    livello==='VERDE' ? ente + ' — conformità sostanziale al ciclo ' + anno :
    livello==='GIALLO' ? ente + ' — gap normativi da colmare prima del prossimo ciclo OIV' :
    ente + ' — rischio di inadempimento documentabile al ciclo ' + anno;

  document.getElementById('result-sub').innerHTML =
    livello==='VERDE'
      ? 'Il sistema CS è strutturato correttamente. <strong>Obiettivo di consolidamento:</strong> alcune aree di ottimizzazione possono essere colmate per raggiungere la piena conformità e accedere alla <strong>Certificazione CustomerPA — Metodo Troisi</strong>.'
      : livello==='GIALLO'
      ? 'Sono presenti gap normativi documentabili. <strong>Ogni ciclo della performance che passa senza intervento consolida le criticità</strong> e aumenta il rischio di rilievo formale da parte di OIV, DFP e Corte dei Conti. La finestra operativa utile si chiude con la prossima Relazione sulla Performance.'
      : '<strong>Carenze significative e documentabili</strong> nel ciclo della Customer Satisfaction. L\'esposizione a rilievi è crescente: ogni ciclo senza intervento rende la posizione dell\'ente meno difendibile. La responsabilità degli amministratori è personale.';

  // --- BLOCCO A: SCENARIO DI RISCHIO ---
  var gapCritici = [];
  if ((answers[1]||0) < 2) gapCritici.push('PIAO non conforme o CS assente → rilievo Corte dei Conti in sede di controllo interno');
  if ((answers[2]||0) < 2) gapCritici.push('Rilevazione CS assente o inadeguata → ciclo performance non validabile dall\'OIV');
  if ((answers[3]||0) < 2) gapCritici.push('Pubblicazione AT mancante → inadempimento sanzionabile da ANAC su segnalazione di chiunque');
  if ((answers[4]||0) < 2) gapCritici.push('CS non collegata alla valutazione dirigenziale → sistema di valutazione individuale non conforme');
  if ((answers[5]||0) < 2) gapCritici.push('OIV non ha validato → Relazione sulla Performance contestabile, premi a rischio');
  if ((answers[6]||0) < 2) gapCritici.push('Metodo inadeguato → la rilevazione è formalmente presente ma giuridicamente irrilevante');

  var rischioHtml = '';
  if (livello !== 'VERDE' && gapCritici.length > 0) {
    rischioHtml = '<div class="rischio-box">' +
      '<div class="rischio-box-header">🚨 Scenario di rischio — cosa succede se non si interviene</div>' +
      '<div class="rischio-items">';
    gapCritici.forEach(function(g) {
      rischioHtml += '<div class="rischio-item"><div class="rischio-item-icon">⚠️</div><div>' + g + '</div></div>';
    });
    if (livello === 'ROSSO') {
      rischioHtml += '<div class="rischio-item" style="margin-top:6px;padding-top:10px;border-top:1px solid #fecaca">' +
        '<div class="rischio-item-icon">⛔</div>' +
        '<div><strong>Esposizione massima:</strong> La Corte dei Conti può irrogare sanzioni da 5x a 20x la retribuzione mensile lorda dei dirigenti responsabili. La responsabilità è personale, non dell\'ente.</div></div>';
    }
    rischioHtml += '</div></div>';
  } else if (livello === 'VERDE') {
    rischioHtml = '<div class="rischio-box" style="background:linear-gradient(135deg,#f0fdf4,#dcfce7);border-color:#bbf7d0">' +
      '<div class="rischio-box-header" style="color:var(--verde)">✅ Scenario positivo — il tuo ente è in una posizione difendibile</div>' +
      '<div class="rischio-items">' +
      '<div class="rischio-item"><div class="rischio-item-icon">🛡️</div><div>Il sistema CS è strutturato in modo da reggere un audit OIV o un\'ispezione DFP. Alcuni gap minori possono essere colmati nel prossimo ciclo.</div></div>' +
      '<div class="rischio-item"><div class="rischio-item-icon">📈</div><div>Il tuo CustomerPA Score ti posiziona sopra la media PA italiana. Consolidare questo livello e puntare alla certificazione CustomerPA è il passo naturale.</div></div>' +
      '</div></div>';
  }

  // --- BLOCCO B: PERCORSO OPERATIVO ---
  var percorsoHtml = '<div class="percorso-box">' +
    '<div class="percorso-header">📍 Percorso operativo — i 4 step per la conformità piena</div>' +
    '<div class="percorso-steps">' +
    '<div class="percorso-step"><div class="ps-num">1</div><div class="ps-label">Audit completo</div><div class="ps-desc">Analisi approfondita del sistema CS esistente con gap specifici per servizio</div></div>' +
    '<div class="percorso-step"><div class="ps-num">2</div><div class="ps-label">Indagine sul campo</div><div class="ps-desc">Rilevazione con metodo Troisi: tablet, QR code, survey online GDPR-compliant</div></div>' +
    '<div class="percorso-step"><div class="ps-num">3</div><div class="ps-label">Report & CustomerPA Score</div><div class="ps-desc">Report ufficiale con score, benchmark e piano di miglioramento per il PIAO</div></div>' +
    '<div class="percorso-step"><div class="ps-num">4</div><div class="ps-label">Validazione OIV</div><div class="ps-desc">Supporto alla presentazione all\'OIV e alla Giunta — documentazione completa</div></div>' +
    '</div></div>';

  // --- BLOCCO C: CROSS-SYSTEM BO ---
  var crossHtml = '<div class="cross-box">' +
    '<div class="cross-icon">🧠</div>' +
    '<div class="cross-text">' +
    '<h4>Hai verificato la Customer Satisfaction. E il Benessere Organizzativo?</h4>' +
    '<p>Il D.Lgs. 81/2008 obbliga tutti i datori di lavoro — PA e privati — a valutare il rischio da stress lavoro-correlato. Il D.Lgs. 150/2009 impone l\'indagine annuale sul BO per la PA. Troisi Ricerche offre uno strumento equivalente, integrato con CustomerPA, che completa il quadro istituzionale del tuo ente.</p>' +
    '<a href="https://www.benessereorganizzativo.it/sei-in-regola-bo" target="_blank" class="cross-link">🧠 Verifica la conformità BO del tuo ente →</a>' +
    '</div></div>';

  // Urgenza strip dinamica per livello
  var urgTitle = livello==='VERDE'
    ? 'Sei vicino alla Certificazione CustomerPA — consolida ora'
    : livello==='GIALLO'
    ? 'Finestra operativa limitata — agisci prima della prossima validazione OIV'
    : 'Ogni ciclo che passa aumenta il rischio — intervento urgente';
  var urgBody = livello==='VERDE'
    ? 'Il tuo ente ha un buon sistema CS. Il passo successivo è documentarlo formalmente e ottenere la Certificazione CustomerPA — Metodo Troisi, che attesta la conformità al D.Lgs. 150/2009 davanti a OIV, DFP e Corte dei Conti.'
    : livello==='GIALLO'
    ? 'Gli OIV validano la Relazione sulla Performance entro giugno. Chi non ha un sistema CS documentato e metodologicamente corretto non potrà far validare il proprio ciclo. La finestra utile si chiude prima di quanto si pensi.'
    : 'Ogni ciclo della performance che si chiude senza un sistema CS conforme consolida il gap normativo e rende la posizione dell\'ente meno difendibile. La responsabilità degli amministratori è personale e crescente.';
  if (document.getElementById('urgenza-title')) document.getElementById('urgenza-title').textContent = urgTitle;
  if (document.getElementById('urgenza-body')) document.getElementById('urgenza-body').textContent = urgBody;
  document.getElementById('result-items').insertAdjacentHTML('afterend',
    rischioHtml + percorsoHtml + crossHtml
  );

  // CustomerPA Score box — con riferimento certificazione
  var scoreColor = livello==='VERDE'?'#16a34a':livello==='GIALLO'?'#d97706':'#dc2626';
  var certMsg = livello==='VERDE'
    ? '✅ Questo score costituisce la base documentale per accedere alla <strong>Certificazione CustomerPA — Metodo Troisi</strong>'
    : livello==='GIALLO'
    ? '⚠️ Score insufficiente per la Certificazione CustomerPA. Gap da colmare prima della prossima validazione OIV'
    : '❌ Score sotto soglia di certificazione. Intervento urgente richiesto prima del prossimo ciclo performance';

  document.getElementById('cpa-score-box').innerHTML =
    '<div class="cpa-score-icon">🏆</div>' +
    '<div class="cpa-score-text">' +
    '<h4>CustomerPA Score — Metodo Troisi</h4>' +
    '<p>Scoring pesato su 3 fasi · ' + score.raw + '/' + score.max + ' punti · Soglia certificazione: ≥70%</p>' +
    '<p style="font-size:.72rem;margin-top:4px;opacity:.9">' + certMsg + '</p>' +
    '</div>' +
    '<div class="cpa-score-val" style="color:' + scoreColor + '">' + pct + '<small>/ 100</small></div>';

  // Items dettaglio
  var container = document.getElementById('result-items');
  container.innerHTML = '';
  for (var i = 1; i <= 8; i++) {
    var v = answers[i] !== undefined ? answers[i] : 0;
    var cls = v===2?'item-ok':v===1?'item-warn':'item-ko';
    var icon = v===2?'✅':v===1?'⚠️':'❌';
    var msg = v===2?'Conforme':v===1?'Parzialmente conforme — intervento raccomandato':'Non conforme — intervento necessario';
    var peso = PESI[i];
    var dotsFilled = peso;
    var dotsHtml = '<div class="peso-dots">';
    for (var d=1;d<=3;d++) dotsHtml += '<div class="peso-dot' + (d<=dotsFilled?' filled':'') + '"></div>';
    dotsHtml += '</div><div style="font-size:.6rem;color:var(--grigio);margin-top:2px">peso ' + peso + '</div>';

    container.innerHTML +=
      '<div class="result-item ' + cls + '">' +
      '<div class="item-icon">' + icon + '</div>' +
      '<div class="item-text"><strong>' + FASE_LABELS[i] + ' · ' + LABELS[i-1] + '</strong>' +
      msg + ' · <em style="font-size:.76rem;color:var(--grigio)">' + NORMS[i-1] + '</em></div>' +
      '<div class="item-peso-bar">' + dotsHtml + '</div>' +
      '</div>';
  }

  // Benchmark — messaggi incisivi per livello
  var benchMsg, benchColor, benchIcon;
  if (pct >= 70) {
    benchMsg = '<strong style="color:#6ee7b7">Ottimo posizionamento.</strong> ' + ente + ' supera il <strong style="color:#6ee7b7">68% degli enti analizzati</strong> nella banca dati CustomerPA. È tra il 32% più virtuoso delle PA italiane monitorate. Obiettivo: consolidare e ottenere la <strong style="color:#6ee7b7">Certificazione CustomerPA — Metodo Troisi</strong>.';
  } else if (pct >= 40) {
    benchMsg = '<strong style="color:#fbbf24">Attenzione.</strong> ' + ente + ' si colloca <strong style="color:#fbbf24">sotto il 61% degli enti analizzati</strong>. Ogni ciclo della performance che passa senza intervento consolida le criticità e aumenta il rischio di rilievo OIV. <strong style="color:#fbbf24">Il momento di agire è prima della prossima validazione.</strong>';
  } else {
    benchMsg = '<strong style="color:#f87171">Situazione critica.</strong> ' + ente + ' si colloca <strong style="color:#f87171">nella fascia di rischio: sotto l\'88% degli enti analizzati</strong>. A ogni ciclo performance senza intervento il gap normativo si consolida e l\'esposizione a sanzioni cresce. <strong style="color:#f87171">L\'intervento immediato è l\'unica scelta difendibile.</strong>';
  }

  // Calcola percentile e delta rispetto alla media
  var delta = pct - 61;
  var deltaStr = delta >= 0 ? '+' + delta : '' + delta;
  var deltaCls = delta >= 0 ? '#6ee7b7' : '#f87171';

  document.getElementById('benchmark-box').innerHTML =
    '<div class="bench-stat"><span class="bench-num">' + pct + '%</span><small class="bench-lbl">CustomerPA<br>Score</small></div>' +
    '<div class="bench-divider"></div>' +
    '<div class="bench-stat"><span class="bench-num" style="color:' + deltaCls + '">' + deltaStr + '</span><small class="bench-lbl">vs media<br>PA italiana</small></div>' +
    '<div class="bench-divider"></div>' +
    '<div class="bench-stat"><span class="bench-num">61%</span><small class="bench-lbl">Media<br>nazionale</small></div>' +
    '<div class="bench-divider"></div>' +
    '<div style="flex:1;color:rgba(255,255,255,.85);font-size:.79rem;line-height:1.55">' + benchMsg + '</div>';
}

function stampaSoloReport() {
  var r = document.getElementById('step-result').innerHTML;
  var w = window.open('','_blank','width=820,height=900');
  w.document.write('<html><head><title>CustomerPA Report Audit</title>');
  w.document.write('<style>');
  w.document.write('@page{size:A4;margin:1.2cm}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;box-sizing:border-box}');
  w.document.write('body{font-family:Segoe UI,sans-serif;font-size:8.5pt;color:#1a1a2e;margin:0;padding:0}');
  w.document.write('.hr{text-align:center;border-bottom:2px solid #1d4ed8;padding-bottom:10px;margin-bottom:12px}.hr h1{color:#1e3a8a;font-size:12pt;margin:0 0 2px}.hr p{color:#6b7280;font-size:7pt;margin:0}');
  w.document.write('.result-top{text-align:center;padding:8px 0 6px}');
  w.document.write('.cpa-gauge{width:65px;height:65px;border-radius:50%;display:inline-flex;flex-direction:column;align-items:center;justify-content:center;border:4px solid;margin-bottom:4px}');
  w.document.write('.gauge-verde{border-color:#16a34a;color:#16a34a;background:#f0fdf4}.gauge-giallo{border-color:#d97706;color:#d97706;background:#fffbeb}.gauge-rosso{border-color:#dc2626;color:#dc2626;background:#fef2f2}');
  w.document.write('.gauge-score{font-size:1.2rem;font-weight:900;line-height:1}.gauge-label{font-size:5.5pt;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-top:1px}');
  w.document.write('.cpa-index-badge{display:inline-block;font-size:6.5pt;font-weight:700;text-transform:uppercase;padding:2px 10px;border-radius:20px;margin-bottom:5px}');
  w.document.write('.badge-verde{background:#dcfce7;color:#16a34a}.badge-giallo{background:#fef9c3;color:#d97706}.badge-rosso{background:#fee2e2;color:#dc2626}');
  w.document.write('.result-ente-title{font-size:10pt;font-weight:900;color:#1e3a8a;margin-bottom:3px}.result-sub{font-size:7.5pt;color:#6b7280;line-height:1.4;margin-bottom:6px}');
  w.document.write('.cpa-score-finale{background:#1e3a8a!important;border-radius:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;margin-bottom:6px}');
  w.document.write('.cpa-score-icon{font-size:1.2rem;flex-shrink:0}.cpa-score-text h4{color:#fff;font-size:7.5pt;font-weight:800;margin:0 0 1px}.cpa-score-text p{color:rgba(255,255,255,.75);font-size:6.5pt;line-height:1.3;margin:0}.cpa-score-val{margin-left:auto;font-size:1.4rem;font-weight:900;flex-shrink:0;text-align:right}.cpa-score-val small{display:block;font-size:5.5pt;font-weight:600;color:rgba(255,255,255,.6);text-transform:uppercase}');
  w.document.write('.integration-strip{display:none}');
  w.document.write('.result-items{display:flex;flex-direction:column;gap:3px;margin:6px 0}');
  w.document.write('.result-item{display:flex;gap:6px;align-items:flex-start;padding:5px 8px;border-radius:5px;border:1pt solid}');
  w.document.write('.item-ok{background:#f0fdf4;border-color:#bbf7d0}.item-warn{background:#fffbeb;border-color:#fde68a}.item-ko{background:#fef2f2;border-color:#fecaca}');
  w.document.write('.item-icon{font-size:.9rem;flex-shrink:0;margin-top:1px}.item-text{font-size:7pt;line-height:1.3;flex:1}.item-text strong{display:block;font-size:7.5pt;margin-bottom:1px}');
  w.document.write('.item-peso-bar{display:none}');
  w.document.write('.benchmark-box{background:#1e3a8a!important;border-radius:6px;padding:7px 10px;display:flex;gap:8px;align-items:center;margin:6px 0;flex-wrap:wrap}');
  w.document.write('.bench-stat{text-align:center}.bench-num{font-size:1rem;font-weight:900;color:#e8a020;display:block}.bench-lbl{font-size:5.5pt;color:rgba(255,255,255,.65);line-height:1.2}.bench-divider{width:1pt;background:rgba(255,255,255,.2);align-self:stretch}');
  w.document.write('.rischio-box{background:#fef2f2!important;border:1pt solid #fecaca;border-radius:6px;padding:8px 10px;margin:6px 0}.rischio-box-header{font-size:7pt;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#dc2626;margin-bottom:6px}.rischio-items{display:flex;flex-direction:column;gap:4px}.rischio-item{display:flex;gap:6px;align-items:flex-start;font-size:7pt;color:#1a1a2e;line-height:1.4}.rischio-item-icon{font-size:.8rem;flex-shrink:0}');
  w.document.write('.percorso-box{background:#eff6ff!important;border:1pt solid #bfdbfe;border-radius:6px;padding:8px 10px;margin:6px 0}.percorso-header{font-size:7pt;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#1d4ed8;margin-bottom:8px}.percorso-steps{display:flex;gap:0}.percorso-step{flex:1;text-align:center;padding:0 4px;position:relative}.percorso-step:not(:last-child)::after{content:"→";position:absolute;right:-6px;top:6px;font-size:.8rem;color:#1d4ed8;font-weight:700}.ps-num{width:22px;height:22px;border-radius:50%;background:#1e3a8a!important;color:#fff;display:flex;align-items:center;justify-content:center;font-size:7pt;font-weight:800;margin:0 auto 4px}.ps-label{font-size:7pt;font-weight:700;color:#1e3a8a;margin-bottom:2px}.ps-desc{font-size:6pt;color:#6b7280;line-height:1.3}');
  w.document.write('.cross-box{background:#fdf4ff!important;border:1pt solid #c4b5fd;border-radius:6px;padding:8px 10px;margin:6px 0;display:flex;gap:8px}.cross-icon{font-size:1.2rem;flex-shrink:0}.cross-text h4{font-size:7.5pt;font-weight:800;color:#4c1d95;margin:0 0 3px}.cross-text p{font-size:6.5pt;color:#6b7280;line-height:1.4;margin:0 0 4px}.cross-link{display:none}');
  w.document.write('.urgenza-strip{background:#1e3a8a!important;border-radius:5px;padding:7px 9px;display:flex;gap:8px;align-items:center;margin-bottom:7px}.urgenza-icon{font-size:1rem;flex-shrink:0}.urgenza-text h4{color:#e8a020;font-size:7pt;font-weight:800;margin:0 0 2px}.urgenza-text p{color:rgba(255,255,255,.8);font-size:6.5pt;line-height:1.3;margin:0}.urgenza-deadline{margin-left:auto;text-align:center;background:rgba(232,160,32,.15);border:1pt solid rgba(232,160,32,.4);border-radius:5px;padding:5px 8px}.urgenza-deadline b{display:block;color:#e8a020;font-size:.9rem;font-weight:900}.urgenza-deadline small{color:rgba(255,255,255,.6);font-size:5.5pt}');
  w.document.write('#cert-block{background:#1e3a8a!important;border-radius:6px;padding:10px 12px;margin:6px 0}#cert-block *{color:#fff}#cert-block .urgenza-deadline{display:none}');
  w.document.write('.cta-section{page-break-before:always}');
  w.document.write('.cta-head{background:#064e3b!important;padding:12px;text-align:center;border-radius:6px 6px 0 0}');
  w.document.write('.cta-head h3{color:#fff;font-size:10pt;font-weight:800;margin:0 0 3px}.cta-head h3 em{color:#6ee7b7;font-style:normal}.cta-head p{color:rgba(255,255,255,.8);font-size:7pt;margin:0}');
  w.document.write('.cta-head-eyebrow{font-size:6.5pt;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.55);margin-bottom:5px}');
  w.document.write('.cta-body{padding:10px 12px}');
  w.document.write('.servizi-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:8px}');
  w.document.write('.serv-card{display:flex;gap:5px;align-items:flex-start;padding:6px;background:#f0fdf4!important;border-radius:5px;border:1pt solid #bbf7d0}');
  w.document.write('.serv-card h4{font-size:7pt;font-weight:700;color:#064e3b;margin:0 0 1px}.serv-card p{font-size:6.5pt;color:#6b7280;line-height:1.3;margin:0}');
  w.document.write('.output-box{background:#eff6ff!important;border:1pt solid #bfdbfe;border-radius:5px;padding:7px 8px;margin-bottom:7px;display:flex;gap:7px}');
  w.document.write('.output-box h4{font-size:7.5pt;font-weight:700;color:#1e3a8a;margin:0 0 3px}.output-box p{font-size:7pt;color:#6b7280;line-height:1.4;margin:0 0 4px}');
  w.document.write('.pills{display:flex;gap:3px;flex-wrap:wrap}.pill{font-size:6pt;font-weight:600;background:#dbeafe!important;color:#1d4ed8;padding:2px 5px;border-radius:8px}');
  w.document.write('.proof-bar{background:#1e3a8a!important;border-radius:5px;padding:7px 9px;display:flex;gap:8px;align-items:center;margin-bottom:7px}');
  w.document.write('.proof-stats{display:flex;gap:10px;flex:1}.proof-stat{text-align:center}.proof-stat b{display:block;font-size:9pt;font-weight:700;color:#e8a020}.proof-stat small{font-size:5.5pt;color:rgba(255,255,255,.7);line-height:1.2}');
  w.document.write('.cta-btns{display:flex;gap:5px;margin-bottom:5px}');
  w.document.write('.btn-cta-primary{flex:1;background:#064e3b!important;color:#fff;font-weight:700;font-size:7pt;padding:6px;border-radius:5px;text-align:center;text-decoration:none;display:block}');
  w.document.write('.btn-cta-secondary{flex:1;color:#1d4ed8;font-weight:600;font-size:7pt;padding:6px;border-radius:5px;text-align:center;text-decoration:none;border:1pt solid #1d4ed8;display:block}');
  w.document.write('.btn-pdf{display:none!important}');
  w.document.write('.cta-footer-note{background:#f8fafa;border-top:1pt solid #e5e7eb;padding:5px 8px;font-size:6pt;color:#6b7280;line-height:1.3;display:flex;gap:5px}');
  w.document.write('<\/style><\/head><body>');
  w.document.write('<div class="hr"><h1>CustomerPA — Audit di Conformità Customer Satisfaction PA<<\/h1><p>Troisi Ricerche S.r.l. · customerpa.it · Accreditato MIUR come Ente di Ricerca · ' + new Date().toLocaleDateString('it-IT') + '<\/p><\/div>');
  w.document.write(r);
  w.document.write('<\/body><\/html>');
  w.document.close();
  setTimeout(function(){ w.print(); }, 600);
}

</script>
</body>
</html>
