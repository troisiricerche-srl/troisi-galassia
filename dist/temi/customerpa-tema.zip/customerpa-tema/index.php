<?php
// Elenco articoli: archivio "Analisi", categorie, tag, date, ricerca
get_template_part('inc/tr-head'); ?>
<main class="tr-single">
  <div class="tr-archivio">
    <div class="tr-ultime-label">CustomerPA</div>
    <h1 class="tr-archivio-title"><?php
      if (is_category()) { single_cat_title(); }
      elseif (is_tag()) { echo 'Tag: '; single_tag_title(); }
      elseif (is_search()) { echo 'Ricerca: ' . esc_html(get_search_query()); }
      elseif (is_date()) { echo esc_html(get_the_archive_title()); }
      else { echo 'Tutte le analisi'; } ?></h1>
    <?php if (have_posts()) : ?>
    <div class="tr-lista">
      <?php while (have_posts()) : the_post(); ?>
      <a class="tr-lista-item" href="<?php the_permalink(); ?>">
        <div class="tr-card-meta"><span class="tr-card-tag"><?php echo esc_html(cpa_tema()); ?></span> <?php echo esc_html(get_the_date('j F Y')); ?></div>
        <h2><?php the_title(); ?></h2>
        <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 34, '…')); ?></p>
      </a>
      <?php endwhile; ?>
    </div>
    <div class="tr-paginazione"><?php the_posts_pagination(['prev_text' => '← Più recenti', 'next_text' => 'Meno recenti →']); ?></div>
    <?php else : ?>
      <p>Nessun articolo trovato. <a href="<?php echo esc_url(home_url('/')); ?>">Torna alla home</a>.</p>
    <?php endif; ?>
  </div>
</main>
<?php get_template_part('inc/tr-footer'); ?>
