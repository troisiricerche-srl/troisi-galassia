<?php get_header(); ?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/favicon-32.png">
<link rel="icon" type="image/png" sizes="192x192" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/apple-touch-icon.png">
<title>CustomerPA — Customer Satisfaction nella Pubblica Amministrazione | Comuni, ASL, Partecipate | Troisi Ricerche</title>
<meta name="description" content="CustomerPA è il primo strumento avanzato in Italia per la valutazione della customer satisfaction nella Pubblica Amministrazione. Sviluppato da Andrea Troisi e Troisi Ricerche. Strumenti per Comuni, ASL, Società partecipate, CCIAA, Scuole.">
<meta name="keywords" content="customer satisfaction pubblica amministrazione, customer experience PA, valutazione servizi pubblici, qualità servizi pubblici locali, misurazione soddisfazione cittadini, CustomerPA Troisi Ricerche, Metodo Troisi customer satisfaction, Andrea Troisi customer experience PA, TR-Index pubblica amministrazione, customer satisfaction comuni, customer satisfaction ASL, customer satisfaction società partecipate, PIAO performance PA, D.Lgs. 150/2009 customer satisfaction, Corte dei Conti qualità servizi, benchmark pubblica amministrazione, indicatori performance comune, strumento AI customer satisfaction PA, data driven public administration, PNRR qualità servizi pubblici, CustomerPA Score, Metodo Troisi, Certificazione CustomerPA, audit customer satisfaction PA, verifica conformità CS comuni, D.Lgs. 150/2009 customer satisfaction, OIV validazione customer satisfaction, PIAO customer satisfaction, Corte dei Conti sanzioni PA, benchmark customer satisfaction comuni italiani, Andrea Troisi ricercatore PA, Troisi Ricerche ente accreditato MIUR, come misurare customer satisfaction pubblica amministrazione, customer satisfaction obbligo legge PA, certificazione standard qualità servizi pubblici">
<meta property="og:title" content="CustomerPA — Customer Satisfaction nella Pubblica Amministrazione | Troisi Ricerche">
<meta property="og:description" content="Il primo strumento avanzato in Italia per la valutazione della customer satisfaction nella PA. Sviluppato da Andrea Troisi e Troisi Ricerche. Gratuito per Comuni, ASL, Partecipate.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.customerpa.it">

<!-- Flourish embed script — caricato una sola volta -->
<script src="https://public.flourish.studio/resources/embed.js"></script>

<!-- Schema.org -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Andrea Troisi",
  "jobTitle": "Statistical Researcher and Innovation Analyst",
  "affiliation": "Troisi Ricerche",
  "url": "https://www.andreatroisi.it"
}
</script>

<style>
/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --blu:        #1a3a5c;
  --blu-pa:     #1d4ed8;
  --blu-dark:   #1e3a8a;
  --accento:    #e8a020;
  --testo:      #1a1a2e;
  --grigio:     #6b7280;
  --grigio-bg:  #f8f9fa;
  --bordo:      #e5e7eb;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --verde-bg:   #f0fdf4;
  --celeste-bg: #eff6ff;
}
body { font-family: 'Segoe UI', system-ui, sans-serif; color: var(--testo); background: var(--bianco); line-height: 1.6; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; height: auto; }

/* =============================================
   TOPBAR
   ============================================= */
.topbar { background: var(--blu-dark); padding: 6px 0; font-size: 0.72rem; }
.topbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; gap: 16px; flex-wrap: wrap; align-items: center; }
.topbar a { color: rgba(255,255,255,.7); transition: color .2s; }
.topbar a:hover { color: var(--accento); }
.topbar a.topbar-personal { color: var(--accento); font-weight: 700; }
.topbar a.topbar-active { color: var(--bianco); font-weight: 700; }

/* =============================================
   NAVBAR
   ============================================= */
.navbar { background: var(--bianco); border-bottom: 3px solid var(--blu-pa); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.08); }
.navbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.navbar-brand { display: flex; align-items: center; gap: 10px; font-weight: 800; font-size: 1.05rem; color: var(--blu-dark); }
.navbar-brand .logo-text { font-size: 1.1rem; font-weight: 900; }
.navbar-brand .logo-text span { color: var(--blu-pa); }
.navbar-brand .subtitle { font-size: 0.68rem; color: var(--grigio); font-weight: 400; display: block; line-height: 1.2; }
.navbar-links { display: flex; gap: 4px; align-items: center; }
.navbar-links a { padding: 6px 11px; border-radius: 6px; font-size: 0.83rem; color: var(--testo); font-weight: 500; transition: all .2s; }
.navbar-links a:hover { background: var(--celeste-bg); color: var(--blu-pa); }
.navbar-links .btn-accedi { border: 1.5px solid var(--bordo); color: var(--blu); font-weight: 600; }
.navbar-links .btn-demo { background: var(--blu-pa); color: var(--bianco) !important; font-weight: 700; padding: 7px 16px; }
.navbar-links .btn-demo:hover { background: var(--blu-dark); }

/* HAMBURGER */
.hamburger { display: none; flex-direction: column; justify-content: center; gap: 5px; cursor: pointer; padding: 8px; border: none; background: none; }
.hamburger span { display: block; width: 24px; height: 2px; background: var(--blu-pa); border-radius: 2px; transition: all .3s; }
.hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.mobile-menu { display: none; position: fixed; top: 64px; left: 0; right: 0; bottom: 0; background: var(--bianco); z-index: 99; padding: 20px; flex-direction: column; gap: 4px; overflow-y: auto; box-shadow: 0 4px 20px rgba(0,0,0,.15); }
.mobile-menu.open { display: flex; }
.mobile-menu a { padding: 14px 16px; border-radius: 8px; font-size: 1rem; color: var(--testo); font-weight: 500; border-bottom: 1px solid var(--bordo); transition: background .2s; }
.mobile-menu a:hover { background: var(--celeste-bg); }
.mobile-menu .btn-demo { background: var(--blu-pa); color: var(--bianco) !important; font-weight: 700; margin-top: 8px; text-align: center; border-bottom: none; }
.mobile-menu-social { display: flex; gap: 12px; padding: 16px 0 0; }
.mobile-menu-social a { font-size: 0.8rem; color: var(--blu-pa) !important; font-weight: 700; border: 1px solid var(--bordo) !important; padding: 8px 14px !important; border-radius: 6px !important; text-align: center; flex: 1; border-bottom: 1px solid var(--bordo) !important; }

/* =============================================
   HERO
   ============================================= */
.hero { background: linear-gradient(135deg, var(--blu-dark) 0%, #1e40af 50%, var(--blu-pa) 100%); color: var(--bianco); padding: 72px 20px 56px; position: relative; overflow: hidden; }
.hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 75% 30%, rgba(99,102,241,.15) 0%, transparent 60%); }
.hero .inner { max-width: 1100px; margin: 0 auto; position: relative; display: grid; grid-template-columns: 1fr 360px; gap: 48px; align-items: center; }
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.9); font-size: 0.7rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; padding: 5px 14px; border-radius: 20px; margin-bottom: 18px; }
.hero h1 { font-size: clamp(1.9rem, 4vw, 2.9rem); font-weight: 900; line-height: 1.15; margin-bottom: 10px; }
.hero h1 em { color: #93c5fd; font-style: normal; }
.hero-sub { font-size: 0.88rem; color: rgba(255,255,255,.6); margin-bottom: 16px; }
.hero-desc { font-size: 0.95rem; color: rgba(255,255,255,.82); margin-bottom: 32px; line-height: 1.7; max-width: 520px; }
.hero-cta { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 28px; }
.btn-primary-hero { background: var(--bianco); color: var(--blu-dark); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-primary-hero:hover { background: #dbeafe; transform: translateY(-1px); }
.btn-outline-hero { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.35); transition: all .2s; display: inline-block; }
.btn-outline-hero:hover { border-color: rgba(255,255,255,.7); }
.hero-badges { display: flex; gap: 8px; flex-wrap: wrap; }
.hb { font-size: 0.68rem; font-weight: 700; padding: 5px 12px; border-radius: 6px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.85); }

/* Hero dashboard card */
.hero-card { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); border-radius: 16px; padding: 22px; backdrop-filter: blur(8px); }
.hc-title { font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,.6); margin-bottom: 4px; text-transform: uppercase; letter-spacing: .06em; }
.hc-year { font-size: 0.65rem; color: rgba(255,255,255,.35); margin-bottom: 16px; }
.hc-score { font-size: 4rem; font-weight: 900; color: var(--bianco); line-height: 1; margin-bottom: 4px; }
.hc-index { font-size: 0.78rem; color: rgba(255,255,255,.6); margin-bottom: 6px; }
.hc-rank { font-size: 0.78rem; color: var(--accento); font-weight: 700; margin-bottom: 20px; }
.hc-dims { display: flex; flex-direction: column; gap: 8px; }
.hc-dim { display: flex; align-items: center; gap: 8px; }
.hc-dim .hd-icon { font-size: 0.9rem; width: 20px; flex-shrink: 0; }
.hc-dim .hd-label { font-size: 0.65rem; color: rgba(255,255,255,.6); flex: 1; }
.hc-dim .hd-bar { width: 80px; height: 4px; background: rgba(255,255,255,.12); border-radius: 2px; }
.hc-dim .hd-fill { height: 100%; border-radius: 2px; background: var(--accento); }
.hc-dim .hd-val { font-size: 0.7rem; color: rgba(255,255,255,.8); font-weight: 700; width: 24px; text-align: right; }
.hc-footer { margin-top: 14px; font-size: 0.6rem; color: rgba(255,255,255,.3); border-top: 1px solid rgba(255,255,255,.08); padding-top: 10px; }
.hc-camera { font-size: 0.68rem; color: #93c5fd; font-weight: 600; margin-top: 8px; }

/* =============================================
   SEZIONI GENERALI
   ============================================= */
section { padding: 64px 20px; }
.section-inner { max-width: 1100px; margin: 0 auto; }
.section-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .1em; color: var(--blu-pa); font-weight: 700; margin-bottom: 8px; }
.section-title { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; color: var(--blu); margin-bottom: 12px; line-height: 1.2; }
.section-title em { color: var(--blu-pa); font-style: normal; }
.section-desc { color: var(--grigio); max-width: 640px; margin-bottom: 36px; line-height: 1.7; }

/* =============================================
   STRUMENTI
   ============================================= */
#strumenti { background: var(--grigio-bg); }
.strumenti-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.strumento-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; text-align: center; transition: all .2s; cursor: pointer; }
.strumento-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); border-color: var(--blu-pa); transform: translateY(-2px); }
.sc-icon { font-size: 1.8rem; margin-bottom: 10px; }
.sc-title { font-size: 0.9rem; font-weight: 700; color: var(--blu); margin-bottom: 6px; }
.sc-desc { font-size: 0.75rem; color: var(--grigio); margin-bottom: 10px; }
.sc-badge { font-size: 0.65rem; background: var(--celeste-bg); color: var(--blu-pa); border: 1px solid #bae6fd; padding: 3px 9px; border-radius: 4px; font-weight: 600; display: inline-block; }

/* =============================================
   CPA INDEX
   ============================================= */
#cpi { background: var(--bianco); }
.cpi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.formula-box { background: var(--blu-dark); color: var(--bianco); border-radius: 12px; padding: 28px; font-family: 'Courier New', monospace; }
.fb-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: .1em; color: var(--accento); font-family: 'Segoe UI', sans-serif; font-weight: 700; margin-bottom: 16px; }
.fb-formula { font-size: 1rem; font-weight: 700; color: var(--bianco); margin-bottom: 14px; line-height: 1.6; }
.fb-vars { font-size: 0.75rem; color: rgba(255,255,255,.6); line-height: 1.8; font-family: 'Segoe UI', sans-serif; }
.dim-list { display: flex; flex-direction: column; gap: 10px; }
.dim-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: var(--grigio-bg); border-radius: 8px; border: 1px solid var(--bordo); }
.di-letter { width: 32px; height: 32px; background: var(--blu-pa); color: var(--bianco); border-radius: 8px; display: grid; place-items: center; font-weight: 900; font-size: 0.9rem; flex-shrink: 0; }
.di-info { flex: 1; }
.di-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); }
.di-sub { font-size: 0.7rem; color: var(--grigio); }
.di-pct { font-size: 1rem; font-weight: 900; color: var(--blu-pa); flex-shrink: 0; }
.di-bar { width: 50px; height: 5px; background: var(--bordo); border-radius: 3px; }
.di-fill { height: 100%; border-radius: 3px; background: var(--blu-pa); }

/* =============================================
   CALCOLATORI
   ============================================= */
.calcolatori-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.calc-box { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 28px; box-shadow: 0 2px 12px rgba(0,0,0,.04); }
.calc-box h3 { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
.calc-box .cb-sub { font-size: 0.8rem; color: var(--grigio); margin-bottom: 20px; line-height: 1.5; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 0.78rem; font-weight: 600; color: var(--testo); margin-bottom: 5px; }
.form-group input, .form-group select { width: 100%; padding: 9px 12px; border: 1.5px solid var(--bordo); border-radius: 7px; font-size: 0.85rem; outline: none; transition: border-color .2s; background: var(--bianco); }
.form-group input:focus, .form-group select:focus { border-color: var(--blu-pa); }
.btn-calc { width: 100%; background: var(--blu-pa); color: var(--bianco); border: none; padding: 11px; border-radius: 8px; font-size: 0.9rem; font-weight: 700; cursor: pointer; transition: background .2s; margin-top: 4px; }
.btn-calc:hover { background: var(--blu-dark); }
.result-box { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 10px; padding: 18px; margin-top: 16px; display: none; }
.result-box.visible { display: block; }
.rb-main { font-size: 2rem; font-weight: 900; color: var(--blu-pa); line-height: 1; margin-bottom: 6px; }
.rb-label { font-size: 0.78rem; color: var(--grigio); margin-bottom: 12px; }
.rb-details { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.rb-detail { font-size: 0.72rem; color: var(--grigio); }
.rb-detail strong { color: var(--blu); }
.rb-formula { font-size: 0.68rem; color: var(--grigio); margin-top: 10px; font-family: 'Courier New', monospace; border-top: 1px solid var(--bordo); padding-top: 8px; }
.cpa-result-box { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 10px; padding: 18px; margin-top: 16px; display: none; }
.cpa-result-box.visible { display: block; }
.cpa-score { font-size: 2.5rem; font-weight: 900; color: var(--blu-pa); line-height: 1; margin-bottom: 4px; }
.cpa-judgment { font-size: 0.85rem; font-weight: 700; margin-bottom: 12px; }
.cpa-breakdown { display: flex; flex-direction: column; gap: 4px; font-size: 0.72rem; color: var(--grigio); }
.cpa-breakdown span strong { color: var(--blu); }

/* =============================================
   GRAFICI FLOURISH
   ============================================= */
#grafici { background: var(--grigio-bg); }
.grafici-intro { margin-bottom: 32px; }
.flourish-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; margin-bottom: 28px; }
.flourish-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; overflow: hidden; transition: box-shadow .2s; }
.flourish-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.flourish-card.full-width { grid-column: 1 / -1; }
.fc-header { padding: 16px 20px 12px; border-bottom: 1px solid var(--bordo); }
.fc-report { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--blu-pa); margin-bottom: 4px; }
.fc-title { font-size: 0.92rem; font-weight: 700; color: var(--blu); }
.fc-body { padding: 0; }
.fc-body .flourish-embed { margin: 0; }
.fc-footer { padding: 10px 20px; border-top: 1px solid var(--bordo); display: flex; justify-content: space-between; align-items: center; background: var(--grigio-bg); }
.fc-source { font-size: 0.68rem; color: var(--grigio); }
.fc-link { font-size: 0.72rem; color: var(--blu-pa); font-weight: 600; border: 1px solid var(--bordo); padding: 4px 10px; border-radius: 5px; transition: all .2s; }
.fc-link:hover { background: var(--blu-pa); color: var(--bianco); }
.flourish-cta { text-align: center; }
.flourish-cta a { font-size: 0.85rem; color: var(--blu-pa); font-weight: 700; border: 1.5px solid var(--blu-pa); padding: 10px 24px; border-radius: 8px; display: inline-block; transition: all .2s; }
.flourish-cta a:hover { background: var(--blu-pa); color: var(--bianco); }

/* =============================================
   BENCHMARK
   ============================================= */
#benchmark { background: var(--bianco); }
.benchmark-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
.benchmark-table th { text-align: left; padding: 10px 14px; background: var(--blu-dark); color: var(--bianco); font-size: 0.72rem; text-transform: uppercase; letter-spacing: .06em; }
.benchmark-table th:first-child { border-radius: 8px 0 0 0; }
.benchmark-table th:last-child { border-radius: 0 8px 0 0; }
.benchmark-table td { padding: 12px 14px; border-bottom: 1px solid var(--bordo); }
.benchmark-table tr:hover td { background: var(--celeste-bg); }
.rank-pos { font-weight: 900; color: var(--grigio); font-size: 0.8rem; }
.rank-pos.top3 { color: var(--accento); }
.rank-nome { font-weight: 700; color: var(--blu); }
.rank-regione { font-size: 0.72rem; color: var(--grigio); display: block; }
.rank-score { font-size: 1rem; font-weight: 900; color: var(--blu-pa); }
.rank-bar-cell { width: 100px; }
.rank-bar { height: 5px; background: var(--bordo); border-radius: 3px; }
.rank-bar-fill { height: 100%; border-radius: 3px; background: linear-gradient(90deg, var(--blu-pa), var(--accento)); }
.rank-trend { font-size: 0.78rem; font-weight: 700; }
.rank-trend.up { color: var(--verde); }
.rank-nota { font-size: 0.72rem; color: var(--grigio); font-style: italic; margin-top: 12px; padding: 10px 14px; background: var(--grigio-bg); border-radius: 6px; border-left: 3px solid var(--bordo); }

/* =============================================
   GENERATORE QUESTIONARI
   ============================================= */
#questionario { background: var(--grigio-bg); }
.questionario-box { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 28px; max-width: 700px; }
.servizi-list { display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px; }
.servizio-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border: 1.5px solid var(--bordo); border-radius: 8px; cursor: pointer; transition: all .2s; }
.servizio-item:hover { border-color: var(--blu-pa); background: var(--celeste-bg); }
.servizio-item.selected { border-color: var(--blu-pa); background: var(--celeste-bg); }
.si-left { display: flex; align-items: center; gap: 10px; }
.si-icon { font-size: 1.1rem; }
.si-name { font-size: 0.88rem; font-weight: 600; color: var(--blu); }
.si-domande { font-size: 0.68rem; color: var(--grigio); background: var(--grigio-bg); padding: 3px 8px; border-radius: 4px; }
.si-check { width: 20px; height: 20px; border: 2px solid var(--bordo); border-radius: 4px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: all .2s; }
.servizio-item.selected .si-check { background: var(--blu-pa); border-color: var(--blu-pa); color: var(--bianco); font-size: 0.7rem; }
.questionario-output { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 8px; padding: 16px; margin-top: 16px; max-height: 360px; overflow-y: auto; display: none; font-size: 0.8rem; }
.questionario-output.visible { display: block; }
.qo-sezione { margin-bottom: 14px; }
.qo-titolo { font-size: 0.82rem; font-weight: 800; color: var(--blu); margin-bottom: 8px; border-bottom: 1px solid var(--bordo); padding-bottom: 4px; }
.qo-domanda { padding: 5px 0; color: var(--testo); border-bottom: 1px solid var(--bordo); }
.qo-domanda:last-child { border-bottom: none; }
.qo-num { color: var(--blu-pa); font-weight: 700; margin-right: 6px; }

/* =============================================
   METODOLOGIA
   ============================================= */
#metodo { background: var(--bianco); }
.fasi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
.fase-card { border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; position: relative; transition: box-shadow .2s; }
.fase-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.fase-num { font-size: 2rem; font-weight: 900; color: var(--bordo); line-height: 1; margin-bottom: 10px; }
.fase-icon { font-size: 1.3rem; margin-bottom: 8px; }
.fase-title { font-size: 0.9rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.fase-desc { font-size: 0.78rem; color: var(--grigio); line-height: 1.6; }
.fase-arrow { position: absolute; top: 50%; right: -14px; transform: translateY(-50%); font-size: 1.2rem; color: var(--bordo); z-index: 1; }
.fase-card:last-child .fase-arrow { display: none; }
.libro-section { background: var(--celeste-bg); border: 1px solid #bae6fd; border-radius: 14px; padding: 28px; display: grid; grid-template-columns: auto 1fr; gap: 24px; align-items: center; margin-top: 28px; }
.libro-cover { width: 120px; background: var(--blu-dark); border-radius: 8px; padding: 16px; text-align: center; color: var(--bianco); flex-shrink: 0; }
.libro-cover .lc-icon { font-size: 2rem; margin-bottom: 8px; }
.libro-cover .lc-editore { font-size: 0.65rem; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .08em; }
.libro-cover .lc-titolo { font-size: 0.72rem; font-weight: 700; line-height: 1.3; margin-top: 6px; }
.libro-info h4 { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.libro-info .li-autore { font-size: 0.82rem; color: var(--grigio); margin-bottom: 10px; }
.libro-info p { font-size: 0.85rem; color: var(--testo); line-height: 1.7; margin-bottom: 14px; }
.libro-info .camera-badge { display: inline-flex; align-items: center; gap: 6px; background: #dbeafe; border: 1px solid #93c5fd; color: var(--blu-dark); font-size: 0.75rem; font-weight: 700; padding: 6px 14px; border-radius: 6px; margin-bottom: 14px; }
.btn-libro { display: inline-block; background: var(--blu-pa); color: var(--bianco); padding: 10px 22px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; transition: background .2s; }
.btn-libro:hover { background: var(--blu-dark); }

/* =============================================
   ECOSISTEMA
   ============================================= */
#ecosistema { background: var(--grigio-bg); }
.eco-intro { font-size: 0.9rem; color: var(--testo); line-height: 1.7; margin-bottom: 28px; max-width: 780px; background: var(--bianco); border: 1px solid var(--bordo); border-left: 4px solid var(--blu-pa); border-radius: 8px; padding: 16px 20px; }
.eco-intro strong { color: var(--blu); }
.eco-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; margin-bottom: 20px; }
.eco-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px; text-align: center; transition: all .2s; }
.eco-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.08); border-color: var(--blu-pa); }
.eco-card.active { border-color: var(--accento); background: #fffbeb; }
.ec-step { font-size: 0.6rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--grigio); margin-bottom: 6px; }
.ec-icon { font-size: 1.4rem; margin-bottom: 6px; }
.ec-name { font-size: 0.82rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.ec-desc { font-size: 0.68rem; color: var(--grigio); margin-bottom: 8px; }
.ec-link { font-size: 0.68rem; color: var(--blu-pa); font-weight: 600; }
.eco-card.active .ec-link { color: var(--accento); }
.eco-grid-2 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }

/* =============================================
   CHI SIAMO
   ============================================= */
#chi-siamo { background: var(--bianco); }
.chi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.at-card { background: var(--grigio-bg); border-radius: 12px; padding: 24px; border: 1px solid var(--bordo); }
.at-avatar { width: 48px; height: 48px; background: var(--blu-pa); border-radius: 10px; display: grid; place-items: center; font-size: 1rem; font-weight: 900; color: var(--bianco); margin-bottom: 14px; }
.at-name { font-size: 1rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.at-ruolo { font-size: 0.72rem; color: var(--grigio); margin-bottom: 12px; }
.at-desc { font-size: 0.82rem; color: var(--testo); line-height: 1.7; margin-bottom: 14px; }
.at-links { display: flex; gap: 8px; flex-wrap: wrap; }
.at-links a { font-size: 0.75rem; color: var(--blu-pa); font-weight: 600; border: 1px solid var(--bordo); padding: 5px 12px; border-radius: 6px; transition: all .2s; }
.at-links a:hover { background: var(--blu-pa); color: var(--bianco); border-color: var(--blu-pa); }
.troisi-box { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; }
.troisi-box h4 { font-size: 0.8rem; font-weight: 800; color: var(--blu); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 12px; }
.troisi-box p { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; margin-bottom: 14px; }
.tb-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px; }
.tb-stat { text-align: center; background: var(--bianco); border-radius: 8px; padding: 10px 6px; border: 1px solid var(--bordo); }
.tb-stat .ts-val { font-size: 1.2rem; font-weight: 900; color: var(--blu-pa); }
.tb-stat .ts-lbl { font-size: 0.6rem; color: var(--grigio); text-transform: uppercase; letter-spacing: .04em; }

/* =============================================
   FAQ
   ============================================= */
#faq { background: var(--grigio-bg); }
.faq-list { max-width: 780px; }
.faq-item { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; margin-bottom: 10px; overflow: hidden; }
.faq-question { padding: 18px 20px; font-size: 0.9rem; font-weight: 700; color: var(--blu); cursor: pointer; display: flex; justify-content: space-between; align-items: center; transition: background .2s; }
.faq-question:hover { background: var(--celeste-bg); }
.faq-question .fq-icon { font-size: 1rem; color: var(--blu-pa); transition: transform .3s; flex-shrink: 0; }
.faq-item.open .fq-icon { transform: rotate(45deg); }
.faq-answer { display: none; padding: 14px 20px 18px; font-size: 0.83rem; color: var(--grigio); line-height: 1.7; border-top: 1px solid var(--bordo); }
.faq-item.open .faq-answer { display: block; }

/* =============================================
   CTA FINALE
   ============================================= */
.cta-finale { background: linear-gradient(135deg, var(--blu-dark) 0%, #1e40af 100%); color: var(--bianco); padding: 64px 20px; text-align: center; }
.cta-finale h2 { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; margin-bottom: 10px; }
.cta-finale p { color: rgba(255,255,255,.7); margin-bottom: 28px; max-width: 500px; margin-left: auto; margin-right: auto; }
.cta-btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.btn-cta-white { background: var(--bianco); color: var(--blu-dark); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-cta-white:hover { background: #dbeafe; }
.btn-cta-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.3); transition: all .2s; display: inline-block; }
.btn-cta-outline:hover { border-color: rgba(255,255,255,.7); }

/* =============================================
   FOOTER
   ============================================= */
.site-footer { background: #0d1f35; color: rgba(255,255,255,.7); padding: 48px 20px 24px; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 36px; }
.footer-brand .brand-name { font-size: 1rem; font-weight: 800; color: var(--bianco); margin-bottom: 8px; }
.footer-brand p { font-size: 0.78rem; line-height: 1.6; margin-bottom: 10px; }
.footer-brand .brand-legal { font-size: 0.68rem; color: rgba(255,255,255,.3); line-height: 1.6; }
.footer-col h4 { font-size: 0.72rem; font-weight: 700; color: var(--bianco); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 7px; }
.footer-col ul li a { font-size: 0.8rem; color: rgba(255,255,255,.55); transition: color .2s; }
.footer-col ul li a:hover { color: var(--accento); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,.1); padding-top: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
.footer-bottom .copy { font-size: 0.7rem; color: rgba(255,255,255,.35); }
.footer-legal { display: flex; gap: 16px; }
.footer-legal a { font-size: 0.7rem; color: rgba(255,255,255,.35); transition: color .2s; }
.footer-legal a:hover { color: rgba(255,255,255,.7); }
.seo-hidden { position: absolute; left: -9999px; width: 1px; height: 1px; overflow: hidden; }

/* =============================================
   RESPONSIVE
   ============================================= */
@media (max-width: 960px) {
  .hero .inner { grid-template-columns: 1fr; }
  .hero-card { display: none; }
  .cpi-grid { grid-template-columns: 1fr; }
  .calcolatori-grid { grid-template-columns: 1fr; }
  .fasi-grid { grid-template-columns: 1fr 1fr; }
  .fase-arrow { display: none; }
  .eco-grid { grid-template-columns: repeat(3, 1fr); }
  .eco-grid-2 { grid-template-columns: repeat(2, 1fr); }
  .chi-grid { grid-template-columns: 1fr; }
  .flourish-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .navbar-links { display: none !important; }
  .hamburger { display: flex; }
  .topbar .inner { gap: 8px; font-size: 0.65rem; }
  .strumenti-grid { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr 1fr; gap: 24px; }
  section { padding: 44px 16px; }
  .libro-section { grid-template-columns: 1fr; text-align: center; }
  .benchmark-table th:nth-child(6),
  .benchmark-table td:nth-child(6),
  .benchmark-table th:nth-child(7),
  .benchmark-table td:nth-child(7) { display: none; }
}
@media (max-width: 480px) {
  .strumenti-grid { grid-template-columns: 1fr; }
  .eco-grid { grid-template-columns: 1fr 1fr; }
  .eco-grid-2 { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr; }
  .topbar { display: none; }
  .cta-btns { flex-direction: column; align-items: center; }
  .fasi-grid { grid-template-columns: 1fr; }
}

/* ===== RESPONSIVE NUOVE SEZIONI HOMEPAGE ===== */
@media (max-width: 768px) {
  /* Hero nuova */
  .hero .inner { grid-template-columns: 1fr !important; }
  .hero-card { display: none; }
  /* Riquadro checker */
  #checker-riquadro-grid { grid-template-columns: 1fr !important; gap: 24px !important; }
  /* Sezione perché obbligatorio */
  #perche-obbligatorio .section-inner > div { grid-template-columns: 1fr !important; }
  /* Sezione cosa ottieni */
  #cosa-ottieni .section-inner > div { grid-template-columns: 1fr 1fr !important; }
  /* Sezione certificazione */
  #cert-section .section-inner > div { grid-template-columns: 1fr !important; }
  /* Hero bullet */
  .hero-desc { max-width: 100% !important; }
}
@media (max-width: 480px) {
  /* Cosa ottieni — 1 colonna su mobile stretto */
  #cosa-ottieni .section-inner > div { grid-template-columns: 1fr !important; }
  /* Hero h1 */
  .hero h1 { font-size: 1.5rem !important; }
  /* Riquadro checker score */
  #checker-riquadro-grid [style*="font-size:2.8rem"] { font-size: 2rem !important; }
}
</style>

<!-- Structured Data per AI e SEO -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://www.customerpa.it/#organization",
      "name": "CustomerPA — Troisi Ricerche S.r.l.",
      "url": "https://www.customerpa.it",
      "logo": "https://www.customerpa.it/wp-content/themes/customerpa-tema/favicon.png",
      "description": "CustomerPA è il sistema nazionale di valutazione della Customer Satisfaction nella Pubblica Amministrazione italiana. Genera il CustomerPA Score e la Certificazione CustomerPA — Metodo Troisi.",
      "foundingDate": "2006",
      "vatID": "07216100722",
      "areaServed": "IT",
      "knowsAbout": ["Customer Satisfaction PA", "D.Lgs. 150/2009", "PIAO", "OIV", "CustomerPA Score"],
      "sameAs": [
        "https://www.troisiricerche.net",
        "https://www.linkedin.com/company/troisi-ricerche"
      ]
    },
    {
      "@type": "Person",
      "@id": "https://www.customerpa.it/#andrea-troisi",
      "name": "Andrea Troisi",
      "jobTitle": "Ricercatore — Customer Satisfaction PA",
      "affiliation": {"@id": "https://www.customerpa.it/#organization"},
      "url": "https://www.andreatroisi.it",
      "sameAs": "https://www.andreatroisi.it"
    },
    {
      "@type": "Book",
      "name": "Customer Satisfaction nei servizi pubblici locali",
      "author": {"@id": "https://www.customerpa.it/#andrea-troisi"},
      "publisher": {"@type": "Organization", "name": "Cacucci Editore"},
      "inLanguage": "it",
      "about": "Customer Satisfaction nella Pubblica Amministrazione italiana"
    },
    {
      "@type": "SoftwareApplication",
      "name": "CustomerPA Score",
      "applicationCategory": "BusinessApplication",
      "operatingSystem": "Web",
      "description": "CustomerPA Score è il primo indice nazionale di conformità normativa sulla Customer Satisfaction nella PA italiana, sviluppato da Troisi Ricerche. Basato su D.Lgs. 150/2009.",
      "offers": {"@type": "Offer", "price": "0", "priceCurrency": "EUR"},
      "provider": {"@id": "https://www.customerpa.it/#organization"}
    }
  ]
}
</script>
</head>
<body>


<!-- POPUP CHECKER — appare dopo 4 secondi, una volta per sessione -->
<div id="cpa-popup" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,15,40,.75);backdrop-filter:blur(4px);align-items:center;justify-content:center;padding:20px;">
  <div style="background:#fff;border-radius:16px;max-width:460px;width:100%;box-shadow:0 24px 60px rgba(0,0,0,.3);overflow:hidden;animation:popupIn .4s cubic-bezier(.34,1.56,.64,1);">
    <div style="background:linear-gradient(135deg,#0f172a,#1e3a8a);padding:22px 26px 18px;position:relative;">
      <button onclick="closePopup()" style="position:absolute;top:12px;right:14px;background:rgba(255,255,255,.12);border:none;color:#fff;width:26px;height:26px;border-radius:50%;cursor:pointer;font-size:.9rem;display:flex;align-items:center;justify-content:center;">✕</button>
      <div style="font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#f87171;margin-bottom:8px;">⚖️ Adempimento obbligatorio — D.Lgs. 150/2009</div>
      <h3 style="font-size:1.15rem;color:#fff;line-height:1.3;margin:0 0 8px;font-weight:800;">Il tuo ente è in regola con la Customer Satisfaction?</h3>
      <p style="font-size:.8rem;color:rgba(255,255,255,.7);margin:0;line-height:1.5;">L'OIV non può validare la Relazione sulla Performance senza una CS documentata. Scopri il livello di conformità del tuo ente in 3 minuti.</p>
    </div>
    <div style="padding:18px 26px 22px;">
      <div style="display:flex;gap:8px;margin-bottom:14px;">
        <div style="flex:1;background:#fef2f2;border:1px solid #fecaca;border-radius:7px;padding:8px 10px;font-size:.75rem;color:#dc2626;font-weight:600;text-align:center;">🏛 Comuni</div>
        <div style="flex:1;background:#fef2f2;border:1px solid #fecaca;border-radius:7px;padding:8px 10px;font-size:.75rem;color:#dc2626;font-weight:600;text-align:center;">🏥 ASL / AO</div>
        <div style="flex:1;background:#fef2f2;border:1px solid #fecaca;border-radius:7px;padding:8px 10px;font-size:.75rem;color:#dc2626;font-weight:600;text-align:center;">🏢 In-house</div>
      </div>
      <a href="<?php echo home_url('/sei-in-regola'); ?>" style="display:block;text-align:center;background:#1e3a8a;color:#fff;font-weight:700;font-size:.9rem;padding:13px;border-radius:10px;text-decoration:none;margin-bottom:8px;" onclick="closePopup()">🔍 Avvia la verifica di conformità →</a>
      <button onclick="closePopup()" style="display:block;width:100%;background:none;border:none;color:#9ca3af;font-size:.75rem;cursor:pointer;padding:4px;">Chiudi — verificherò in seguito</button>
    </div>
  </div>
</div>
<style>
@keyframes popupIn { from { opacity:0; transform:scale(.85) translateY(20px); } to { opacity:1; transform:scale(1) translateY(0); } }
</style>
<script>
function closePopup() {
  document.getElementById('cpa-popup').style.display = 'none';
  sessionStorage.setItem('cpa-popup-closed','1');
}
window.addEventListener('load', function() {
  if (!sessionStorage.getItem('cpa-popup-closed')) {
    setTimeout(function() {
      var p = document.getElementById('cpa-popup');
      p.style.display = 'flex';
    }, 4000);
  }
});
</script>

<!-- TOPBAR -->
<div class="topbar">
  <div class="inner">
    <a href="https://andreatroisi.it" class="topbar-personal">andreatroisi.it</a>
    <a href="https://www.troisiricerche.net">troisiricerche.net</a>
    <a href="https://www.t-index.it">TR-Index</a>
    <a href="https://www.mappaturadellecompetenze.it">Mappatura Competenze</a>
    <a href="https://www.registrodellecompetenze.it">Registro Competenze</a>
    <a href="https://www.customerpa.it" class="topbar-active">CustomerPA</a>
    <a href="https://www.benessereorganizzativo.it">BenessereOrg.</a>
    <a href="https://www.troisiformazione.it">Formazione</a>
    <a href="https://www.tiplive.it">TIP</a>
    <a href="https://www.troisiinsight.it">TroisiInsight</a>
    <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
    <a href="https://www.dibattito-pubblico.it">Dibattito Pubblico</a>
    <a href="https://www.voiceinhub.it">VoiceInHub</a>
    <a href="https://www.governancefinanziaria.it">Governance Fin.</a>
    <a href="https://www.consulenzainternazionalizzazione.it">Internazionalizzazione</a>
    <a href="https://www.benesseredigitalegiovani.it">BDG</a>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="#" class="navbar-brand">
      <div>
        <div class="logo-text">Customer<span>PA</span></div>
        <span class="subtitle">Piattaforma nazionale · Customer Satisfaction PA · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="#cpi">CPA Index</a>
      <a href="#strumenti">Strumenti</a>
      <a href="#grafici">Grafici</a>
      <a href="#metodo">Metodologia</a>
      <a href="#benchmark">Benchmark</a>
      <a href="#ecosistema">Ecosistema</a>
      <a href="#chi-siamo">Chi siamo</a>
      <a href="#" class="btn-accedi">Accedi</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi demo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" aria-label="Menu" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile menu -->
<div class="mobile-menu" id="mobile-menu">
  <a href="#cpi" onclick="closeMobileMenu()">CPA Index</a>
  <a href="#strumenti" onclick="closeMobileMenu()">Strumenti</a>
  <a href="#grafici" onclick="closeMobileMenu()">Grafici</a>
  <a href="#metodo" onclick="closeMobileMenu()">Metodologia</a>
  <a href="#benchmark" onclick="closeMobileMenu()">Benchmark</a>
  <a href="#ecosistema" onclick="closeMobileMenu()">Ecosistema</a>
  <a href="#chi-siamo" onclick="closeMobileMenu()">Chi siamo</a>
  <a href="#faq" onclick="closeMobileMenu()">FAQ</a>
  <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo" onclick="closeMobileMenu()">Richiedi demo ↗</a>
  <div class="mobile-menu-social">
    <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a>
    <a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a>
  </div>
</div>

<!-- HERO -->
<section class="hero">
  <div class="inner">
    <div>
      <div class="hero-badge">⚖️ D.Lgs. 150/2009 · PIAO · D.Lgs. 33/2013 · Standard nazionale</div>
      <h1>Il tuo ente è in regola con la <em>Customer Satisfaction?</em></h1>
      <p class="hero-sub">Verifica di conformità obbligatoria per Comuni, ASL, Società in-house, Province e Regioni</p>
      <p class="hero-desc">La rilevazione della Customer Satisfaction è un <strong>obbligo di legge</strong> per ogni PA italiana. L'inadempimento è documentabile, verificabile da chiunque su Amministrazione Trasparente e sanzionabile dalla <strong>Corte dei Conti</strong>. CustomerPA è lo strumento di verifica e conformità sviluppato da Troisi Ricerche — presentato alla <strong>Camera dei Deputati</strong>.</p>

      <!-- Bullet di rischio -->
      <div style="display:flex;flex-direction:column;gap:7px;margin-bottom:24px;">
        <div style="display:flex;align-items:flex-start;gap:9px;font-size:.84rem;color:rgba(255,255,255,.85);line-height:1.4;">
          <span style="color:#f87171;font-size:.9rem;flex-shrink:0;margin-top:1px;">⚠</span>
          <span>Senza rilevazione annuale l'OIV <strong style="color:#fff">non può validare</strong> la Relazione sulla Performance — bloccando i premi al personale</span>
        </div>
        <div style="display:flex;align-items:flex-start;gap:9px;font-size:.84rem;color:rgba(255,255,255,.85);line-height:1.4;">
          <span style="color:#f87171;font-size:.9rem;flex-shrink:0;margin-top:1px;">⚠</span>
          <span>La Corte dei Conti può irrogare sanzioni <strong style="color:#fff">da 5x a 20x la retribuzione mensile lorda</strong> degli amministratori responsabili</span>
        </div>
        <div style="display:flex;align-items:flex-start;gap:9px;font-size:.84rem;color:rgba(255,255,255,.85);line-height:1.4;">
          <span style="color:#f87171;font-size:.9rem;flex-shrink:0;margin-top:1px;">⚠</span>
          <span>L'inadempimento su Amministrazione Trasparente è <strong style="color:#fff">verificabile da chiunque</strong> — cittadini, giornalisti, ANAC</span>
        </div>
        <div style="display:flex;align-items:flex-start;gap:9px;font-size:.84rem;color:rgba(255,255,255,.85);line-height:1.4;">
          <span style="color:#fbbf24;font-size:.9rem;flex-shrink:0;margin-top:1px;">⏳</span>
          <span>Ogni ciclo della performance che si chiude senza CS documentata <strong style="color:#fff">consolida il gap normativo</strong></span>
        </div>
      </div>

      <div class="hero-cta">
        <a href="<?php echo home_url('/sei-in-regola'); ?>" class="btn-primary-hero">🔍 Avvia la verifica di conformità</a>
        <a href="#perche-obbligatorio" class="btn-outline-hero">Perché è obbligatorio →</a>
      </div>
      <div class="hero-badges">
        <span class="hb">D.Lgs. 150/2009</span>
        <span class="hb">Accreditato MIUR</span>
        <span class="hb">Benchmark Nazionale</span>
        <span class="hb">CustomerPA Score</span>
        <span class="hb">Camera dei Deputati</span>
      </div>
    </div>

    <!-- HERO CARD — anteprima audit con rischio -->
    <div class="hero-card">
      <div class="hc-title" style="color:rgba(255,255,255,.6);font-size:.65rem;letter-spacing:.08em;text-transform:uppercase;margin-bottom:4px;">📊 Anteprima verifica — simulazione</div>
      <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(220,38,38,.2);border:1px solid rgba(220,38,38,.4);border-radius:20px;padding:3px 10px;font-size:.65rem;font-weight:700;color:#f87171;letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px;">🔴 Rischio ALTO — intervento necessario</div>
      <div class="hc-score" style="font-size:3rem">38%</div>
      <div class="hc-index">CustomerPA Score</div>
      <div style="font-size:.7rem;color:rgba(255,255,255,.5);margin-bottom:12px;">Sotto il 61% della media PA italiana</div>
      <div class="hc-dims">
        <div class="hc-dim"><span class="hd-icon">❌</span><span class="hd-label">CS annuale</span><div class="hd-bar"><div class="hd-fill" style="width:0%;background:#f87171"></div></div><span class="hd-val" style="color:#f87171">Non eseguita</span></div>
        <div class="hc-dim"><span class="hd-icon">❌</span><span class="hd-label">Pubbl. AT</span><div class="hd-bar"><div class="hd-fill" style="width:0%;background:#f87171"></div></div><span class="hd-val" style="color:#f87171">Mancante</span></div>
        <div class="hc-dim"><span class="hd-icon">⚠️</span><span class="hd-label">PIAO/CS</span><div class="hd-bar"><div class="hd-fill" style="width:40%;background:#fbbf24"></div></div><span class="hd-val" style="color:#fbbf24">Parziale</span></div>
        <div class="hc-dim"><span class="hd-icon">✅</span><span class="hd-label">Piano Perf.</span><div class="hd-bar"><div class="hd-fill" style="width:100%"></div></div><span class="hd-val">OK</span></div>
      </div>
      <div style="margin-top:12px;padding:9px;background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.3);border-radius:8px;text-align:center;">
        <div style="font-size:.72rem;font-weight:700;color:#f87171;">Scenario OIV: Relazione Performance non validabile</div>
        <div style="font-size:.65rem;color:rgba(255,255,255,.45);margin-top:2px;">Questa è una simulazione — verifica il tuo ente</div>
      </div>
      <a href="<?php echo home_url('/sei-in-regola'); ?>" style="display:block;text-align:center;background:#fff;color:#1e3a8a;font-weight:700;font-size:.82rem;padding:10px;border-radius:8px;text-decoration:none;margin-top:10px;">🔍 Verifica ora il tuo ente →</a>
    </div>
  </div>
</section>

<?php get_template_part('inc/tr-ultime'); ?>

<!-- RIQUADRO CHECKER — dopo hero -->
<section style="background:linear-gradient(135deg,#0f172a,#1e3a8a);padding:48px 20px;">
  <div style="max-width:1100px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;" id="checker-riquadro-grid">
    <div>
      <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.35);border-radius:4px;padding:5px 14px;font-size:.68rem;font-weight:700;color:#f87171;letter-spacing:.1em;text-transform:uppercase;margin-bottom:16px;">⚖️ Adempimento obbligatorio — D.Lgs. 150/2009 · PIAO · D.Lgs. 33/2013</div>
      <h2 style="font-size:clamp(1.3rem,3vw,1.85rem);font-weight:900;color:#fff;line-height:1.2;margin:0 0 14px;">Il tuo ente ha un sistema<br>CS <em style="color:#93c5fd;font-style:normal;">conforme e difendibile?</em></h2>
      <p style="font-size:.88rem;color:rgba(255,255,255,.7);line-height:1.7;margin:0 0 20px;">L'audit di conformità CustomerPA verifica in 8 punti se il sistema di Customer Satisfaction del tuo ente soddisfa gli obblighi normativi e genera il <strong style="color:#fff">CustomerPA Score</strong> — base per la Certificazione CustomerPA Metodo Troisi, il primo standard nazionale indipendente.</p>

      <!-- Mini bullet normativi -->
      <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:22px;">
        <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#60a5fa">→</span> PIAO vigente con CS come obiettivo misurabile</div>
        <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#60a5fa">→</span> Rilevazione annuale con metodo statistico validato</div>
        <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#60a5fa">→</span> Pubblicazione risultati su Amministrazione Trasparente</div>
        <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#60a5fa">→</span> Validazione OIV nella Relazione sulla Performance</div>
      </div>

      <a href="<?php echo home_url('/sei-in-regola'); ?>" style="display:inline-flex;align-items:center;gap:10px;background:#fff;color:#1e3a8a;font-weight:800;font-size:.95rem;padding:14px 26px;border-radius:10px;text-decoration:none;box-shadow:0 4px 20px rgba(0,0,0,.3);">🔍 Avvia la verifica di conformità <span style="opacity:.5">→</span></a>
      <div style="margin-top:10px;font-size:.72rem;color:rgba(255,255,255,.35);">Strumento gratuito · 8 domande · 3 minuti · CustomerPA Score incluso</div>
    </div>

    <!-- ANTEPRIMA RISULTATI POTENZIATA -->
    <div style="background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.1);border-radius:16px;padding:20px;backdrop-filter:blur(8px);">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <div style="font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.4);">Anteprima audit — esempio simulato</div>
        <div style="font-size:.65rem;font-weight:700;background:rgba(220,38,38,.2);border:1px solid rgba(220,38,38,.4);color:#f87171;padding:2px 9px;border-radius:20px;">🔴 RISCHIO ALTO</div>
      </div>

      <!-- Score prominente -->
      <div style="text-align:center;margin-bottom:14px;padding:12px;background:rgba(220,38,38,.1);border-radius:10px;border:1px solid rgba(220,38,38,.2);">
        <div style="font-size:2.8rem;font-weight:900;color:#f87171;line-height:1;">38%</div>
        <div style="font-size:.7rem;font-weight:700;color:rgba(255,255,255,.6);margin-top:2px;letter-spacing:.06em;text-transform:uppercase;">CustomerPA Score</div>
        <div style="font-size:.68rem;color:rgba(255,255,255,.35);margin-top:3px;">−23 punti rispetto alla media PA italiana (61%)</div>
      </div>

      <!-- Checklist punti -->
      <div style="display:flex;flex-direction:column;gap:6px;">
        <div style="display:flex;align-items:center;gap:9px;padding:8px 10px;background:rgba(220,38,38,.1);border-radius:7px;border:1px solid rgba(220,38,38,.2);">
          <span style="font-size:.9rem;flex-shrink:0;">❌</span>
          <div style="flex:1;"><div style="font-size:.78rem;font-weight:600;color:#f87171;">Rilevazione CS annuale</div><div style="font-size:.68rem;color:rgba(255,255,255,.4);">D.Lgs. 150/2009 artt. 8 e 29</div></div>
          <span style="font-size:.65rem;font-weight:700;color:#f87171;background:rgba(220,38,38,.2);padding:2px 7px;border-radius:10px;white-space:nowrap;">NON ESEGUITA</span>
        </div>
        <div style="display:flex;align-items:center;gap:9px;padding:8px 10px;background:rgba(220,38,38,.1);border-radius:7px;border:1px solid rgba(220,38,38,.2);">
          <span style="font-size:.9rem;flex-shrink:0;">❌</span>
          <div style="flex:1;"><div style="font-size:.78rem;font-weight:600;color:#f87171;">Pubblicazione AT</div><div style="font-size:.68rem;color:rgba(255,255,255,.4);">D.Lgs. 33/2013</div></div>
          <span style="font-size:.65rem;font-weight:700;color:#f87171;background:rgba(220,38,38,.2);padding:2px 7px;border-radius:10px;white-space:nowrap;">MANCANTE</span>
        </div>
        <div style="display:flex;align-items:center;gap:9px;padding:8px 10px;background:rgba(217,119,6,.08);border-radius:7px;border:1px solid rgba(217,119,6,.2);">
          <span style="font-size:.9rem;flex-shrink:0;">⚠️</span>
          <div style="flex:1;"><div style="font-size:.78rem;font-weight:600;color:#fbbf24;">CS nel PIAO</div><div style="font-size:.68rem;color:rgba(255,255,255,.4);">D.L. 80/2021</div></div>
          <span style="font-size:.65rem;font-weight:700;color:#fbbf24;background:rgba(217,119,6,.15);padding:2px 7px;border-radius:10px;white-space:nowrap;">PARZIALE</span>
        </div>
        <div style="display:flex;align-items:center;gap:9px;padding:8px 10px;background:rgba(22,163,74,.08);border-radius:7px;border:1px solid rgba(22,163,74,.2);">
          <span style="font-size:.9rem;flex-shrink:0;">✅</span>
          <div style="flex:1;"><div style="font-size:.78rem;font-weight:600;color:#4ade80;">Piano della Performance</div><div style="font-size:.68rem;color:rgba(255,255,255,.4);">D.Lgs. 150/2009 art. 10</div></div>
          <span style="font-size:.65rem;font-weight:700;color:#4ade80;background:rgba(22,163,74,.15);padding:2px 7px;border-radius:10px;">CONFORME</span>
        </div>
      </div>

      <!-- Messaggio urgenza -->
      <div style="margin-top:12px;padding:10px;background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.25);border-radius:8px;">
        <div style="font-size:.72rem;font-weight:700;color:#f87171;margin-bottom:2px;">⚠ Scenario OIV: Relazione sulla Performance non validabile</div>
        <div style="font-size:.68rem;color:rgba(255,255,255,.4);">Simulazione · Il tuo punteggio reale potrebbe essere diverso</div>
      </div>

      <a href="<?php echo home_url('/sei-in-regola'); ?>" style="display:block;text-align:center;background:linear-gradient(135deg,#1d4ed8,#1e3a8a);color:#fff;font-weight:700;font-size:.82rem;padding:11px;border-radius:8px;text-decoration:none;margin-top:12px;border:1px solid rgba(255,255,255,.15);">🔍 Verifica il punteggio reale del tuo ente →</a>
    </div>
  </div>
</section>
<style>
@media(max-width:640px){
  #checker-riquadro-grid { grid-template-columns:1fr !important; }
}
</style>

<!-- SEZIONE: PERCHÉ È OBBLIGATORIO -->
<section id="perche-obbligatorio" style="background:#fff;padding:60px 20px;">
  <div class="section-inner">
    <div class="section-label">Quadro normativo</div>
    <div class="section-title">Perché è un <em>obbligo di legge</em></div>
    <p class="section-desc">Non una scelta strategica. Non un'opportunità. Un adempimento previsto da norme vigenti, verificabile e sanzionabile.</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-top:8px;">
      <div style="background:#f8faff;border:1.5px solid #e0e7ff;border-radius:12px;padding:20px;border-left:4px solid #1d4ed8;">
        <div style="font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#1d4ed8;margin-bottom:8px;">D.Lgs. 150/2009 — Riforma Brunetta/Madia</div>
        <div style="font-size:.9rem;font-weight:700;color:#1e3a8a;margin-bottom:6px;">Obbligo di rilevazione annuale</div>
        <p style="font-size:.8rem;color:#6b7280;line-height:1.6;margin:0;">Artt. 8 e 29: ogni PA deve condurre annualmente indagini sulla soddisfazione degli utenti. L'OIV deve validare il processo nella Relazione sulla Performance.</p>
      </div>
      <div style="background:#f8faff;border:1.5px solid #e0e7ff;border-radius:12px;padding:20px;border-left:4px solid #1d4ed8;">
        <div style="font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#1d4ed8;margin-bottom:8px;">D.L. 80/2021 — PIAO</div>
        <div style="font-size:.9rem;font-weight:700;color:#1e3a8a;margin-bottom:6px;">CS come obiettivo misurabile nel PIAO</div>
        <p style="font-size:.8rem;color:#6b7280;line-height:1.6;margin:0;">La Customer Satisfaction deve essere presente nel Piano Integrato con indicatori numerici e target espliciti. Non come enunciazione di principio.</p>
      </div>
      <div style="background:#f8faff;border:1.5px solid #e0e7ff;border-radius:12px;padding:20px;border-left:4px solid #1d4ed8;">
        <div style="font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#1d4ed8;margin-bottom:8px;">D.Lgs. 33/2013 — Trasparenza</div>
        <div style="font-size:.9rem;font-weight:700;color:#1e3a8a;margin-bottom:6px;">Pubblicazione obbligatoria su AT</div>
        <p style="font-size:.8rem;color:#6b7280;line-height:1.6;margin:0;">I risultati delle rilevazioni devono essere pubblicati su Amministrazione Trasparente. L'omissione è sanzionabile da ANAC su segnalazione di chiunque.</p>
      </div>
      <div style="background:#fff1f2;border:1.5px solid #fecaca;border-radius:12px;padding:20px;border-left:4px solid #dc2626;">
        <div style="font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#dc2626;margin-bottom:8px;">Corte dei Conti — Sanzioni</div>
        <div style="font-size:.9rem;font-weight:700;color:#991b1b;margin-bottom:6px;">Responsabilità personale degli amministratori</div>
        <p style="font-size:.8rem;color:#6b7280;line-height:1.6;margin:0;">La Corte dei Conti può irrogare sanzioni <strong style="color:#dc2626;">da 5x a 20x la retribuzione mensile lorda</strong> agli amministratori responsabili dell'inadempimento. La responsabilità è personale.</p>
      </div>
    </div>
    <div style="text-align:center;margin-top:28px;">
      <a href="<?php echo home_url('/sei-in-regola'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:#1e3a8a;color:#fff;font-weight:700;font-size:.9rem;padding:13px 26px;border-radius:10px;text-decoration:none;">🔍 Verifica ora il livello del tuo ente →</a>
    </div>
  </div>
</section>

<!-- SEZIONE: COSA OTTIENI DALL'AUDIT -->
<section id="cosa-ottieni" style="background:#f8faff;padding:60px 20px;">
  <div class="section-inner">
    <div class="section-label">Output dell'audit</div>
    <div class="section-title">Cosa ottieni dalla <em>verifica di conformità</em></div>
    <p class="section-desc">Non un semplice questionario. Un sistema di valutazione istituzionale che produce documenti utilizzabili in ogni sede formale.</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-top:8px;">
      <div style="background:#fff;border:1.5px solid #e5e7eb;border-radius:12px;padding:18px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">🏆</div>
        <div style="font-size:.88rem;font-weight:800;color:#1e3a8a;margin-bottom:6px;">CustomerPA Score</div>
        <p style="font-size:.76rem;color:#6b7280;line-height:1.5;margin:0;">Punteggio pesato da 0 a 100 su modello a 3 livelli. Soglia di certificazione: ≥70%.</p>
      </div>
      <div style="background:#fff;border:1.5px solid #e5e7eb;border-radius:12px;padding:18px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">📊</div>
        <div style="font-size:.88rem;font-weight:800;color:#1e3a8a;margin-bottom:6px;">Benchmark nazionale</div>
        <p style="font-size:.76rem;color:#6b7280;line-height:1.5;margin:0;">Posizionamento rispetto a 200+ enti PA italiani monitorati. Delta rispetto alla media.</p>
      </div>
      <div style="background:#fff;border:1.5px solid #e5e7eb;border-radius:12px;padding:18px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">🚨</div>
        <div style="font-size:.88rem;font-weight:800;color:#1e3a8a;margin-bottom:6px;">Scenario di rischio</div>
        <p style="font-size:.76rem;color:#6b7280;line-height:1.5;margin:0;">Gap normativi specifici con riferimento OIV, ANAC e Corte dei Conti. Personalizzato per il tuo ente.</p>
      </div>
      <div style="background:#fff;border:1.5px solid #e5e7eb;border-radius:12px;padding:18px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">📋</div>
        <div style="font-size:.88rem;font-weight:800;color:#1e3a8a;margin-bottom:6px;">Report allegabile</div>
        <p style="font-size:.76rem;color:#6b7280;line-height:1.5;margin:0;">PDF scaricabile, allegabile alla Relazione sulla Performance, presentabile all'OIV e in Giunta.</p>
      </div>
      <div style="background:#fff;border:1.5px solid #e5e7eb;border-radius:12px;padding:18px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">🏅</div>
        <div style="font-size:.88rem;font-weight:800;color:#1e3a8a;margin-bottom:6px;">Base per certificazione</div>
        <p style="font-size:.76rem;color:#6b7280;line-height:1.5;margin:0;">Questo audit è il punto di partenza per la Certificazione CustomerPA — Metodo Troisi.</p>
      </div>
      <div style="background:#fff;border:1.5px solid #e5e7eb;border-radius:12px;padding:18px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">📍</div>
        <div style="font-size:.88rem;font-weight:800;color:#1e3a8a;margin-bottom:6px;">Percorso operativo</div>
        <p style="font-size:.76rem;color:#6b7280;line-height:1.5;margin:0;">4 step chiari: audit → indagine → report → validazione OIV. Piano operativo personalizzato.</p>
      </div>
    </div>
  </div>
</section>

<!-- SEZIONE: CERTIFICAZIONE CUSTOMERPA -->
<section id="cert-section" style="background:linear-gradient(135deg,#1e3a8a,#0f172a);padding:56px 20px;">
  <div class="section-inner">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;">
      <div>
        <div style="font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.4);margin-bottom:10px;">🏅 Standard nazionale</div>
        <h2 style="font-size:clamp(1.3rem,2.5vw,1.8rem);font-weight:900;color:#fff;line-height:1.2;margin-bottom:12px;">Certificazione CustomerPA<br><span style="color:#fbbf24;">Metodo Troisi</span></h2>
        <p style="font-size:.87rem;color:rgba(255,255,255,.75);line-height:1.7;margin-bottom:16px;">Il primo standard nazionale indipendente per la valutazione della conformità del sistema Customer Satisfaction nella Pubblica Amministrazione italiana. Rilasciata da Troisi Ricerche S.r.l. — Istituto accreditato MIUR come Ente di Ricerca.</p>
        <div style="display:flex;flex-direction:column;gap:7px;margin-bottom:20px;">
          <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#fbbf24">✓</span> Attestazione di conformità al D.Lgs. 150/2009</div>
          <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#fbbf24">✓</span> Allegabile al PIAO e alla Relazione sulla Performance</div>
          <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#fbbf24">✓</span> Validabile dall'OIV come documentazione di supporto</div>
          <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#fbbf24">✓</span> Presentabile alla Giunta Comunale o al CdA</div>
          <div style="font-size:.8rem;color:rgba(255,255,255,.75);display:flex;gap:8px;align-items:center;"><span style="color:#fbbf24">✓</span> Basata su CustomerPA Score ≥ 70%</div>
        </div>
        <a href="<?php echo home_url('/sei-in-regola'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:#fbbf24;color:#1e3a8a;font-weight:800;font-size:.9rem;padding:13px 24px;border-radius:10px;text-decoration:none;">🔍 Avvia l'audit per la certificazione →</a>
      </div>
      <div style="background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.1);border-radius:16px;padding:24px;">
        <div style="text-align:center;margin-bottom:16px;">
          <div style="font-size:3rem;margin-bottom:6px;">🏅</div>
          <div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.4);margin-bottom:4px;">Certificazione CustomerPA</div>
          <div style="font-size:1rem;font-weight:800;color:#fbbf24;">Metodo Troisi — Standard Nazionale</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <div style="display:flex;gap:10px;align-items:center;padding:8px 10px;background:rgba(251,191,36,.08);border-radius:8px;border:1px solid rgba(251,191,36,.2);">
            <span style="color:#fbbf24;font-size:.85rem;">⭐</span>
            <span style="font-size:.78rem;color:rgba(255,255,255,.75);">CustomerPA Score ≥ 70%</span>
          </div>
          <div style="display:flex;gap:10px;align-items:center;padding:8px 10px;background:rgba(251,191,36,.08);border-radius:8px;border:1px solid rgba(251,191,36,.2);">
            <span style="color:#fbbf24;font-size:.85rem;">⭐</span>
            <span style="font-size:.78rem;color:rgba(255,255,255,.75);">Rilevazione con metodo Cochran + SERVQUAL</span>
          </div>
          <div style="display:flex;gap:10px;align-items:center;padding:8px 10px;background:rgba(251,191,36,.08);border-radius:8px;border:1px solid rgba(251,191,36,.2);">
            <span style="color:#fbbf24;font-size:.85rem;">⭐</span>
            <span style="font-size:.78rem;color:rgba(255,255,255,.75);">CS presente nel PIAO con indicatori numerici</span>
          </div>
          <div style="display:flex;gap:10px;align-items:center;padding:8px 10px;background:rgba(251,191,36,.08);border-radius:8px;border:1px solid rgba(251,191,36,.2);">
            <span style="color:#fbbf24;font-size:.85rem;">⭐</span>
            <span style="font-size:.78rem;color:rgba(255,255,255,.75);">Validazione OIV documentata</span>
          </div>
          <div style="display:flex;gap:10px;align-items:center;padding:8px 10px;background:rgba(251,191,36,.08);border-radius:8px;border:1px solid rgba(251,191,36,.2);">
            <span style="color:#fbbf24;font-size:.85rem;">⭐</span>
            <span style="font-size:.78rem;color:rgba(255,255,255,.75);">Pubblicazione risultati su AT aggiornata</span>
          </div>
        </div>
        <div style="margin-top:14px;text-align:center;font-size:.7rem;color:rgba(255,255,255,.35);">Accreditato MIUR come Ente di Ricerca · Troisi Ricerche S.r.l.</div>
      </div>
    </div>
  </div>
</section>

<!-- STRUMENTI -->
<section id="strumenti">
  <div class="section-inner">
    <div class="section-label">Servizi disponibili</div>
    <div class="section-title">Strumenti e risorse per la <em>PA</em></div>
    <p class="section-desc">Quattro strumenti integrati per misurare, calcolare, confrontare e rilevare la soddisfazione dei cittadini.</p>
    <div class="strumenti-grid">
      <div class="strumento-card" onclick="document.getElementById('calcolatore').scrollIntoView({behavior:'smooth'})">
        <div class="sc-icon">📐</div>
        <div class="sc-title">Calcolatore campione statistico</div>
        <p class="sc-desc">Dimensione ottimale del campione secondo la formula di Cochran.</p>
        <span class="sc-badge">Strumento gratuito</span>
      </div>
      <div class="strumento-card" onclick="document.getElementById('cpi-calc').scrollIntoView({behavior:'smooth'})">
        <div class="sc-icon">🔢</div>
        <div class="sc-title">Calcola il CustomerPA Index</div>
        <p class="sc-desc">Inserisci i punteggi per dimensione e ottieni il CPA Index.</p>
        <span class="sc-badge">Indice proprietario</span>
      </div>
      <div class="strumento-card" onclick="document.getElementById('benchmark').scrollIntoView({behavior:'smooth'})">
        <div class="sc-icon">📊</div>
        <div class="sc-title">Benchmark comuni italiani</div>
        <p class="sc-desc">Confronta la soddisfazione tra comuni con ranking e trend annuale.</p>
        <span class="sc-badge">Benchmark nazionale</span>
      </div>
      <div class="strumento-card" onclick="document.getElementById('questionario').scrollIntoView({behavior:'smooth'})">
        <div class="sc-icon">📋</div>
        <div class="sc-title">Genera questionario per la PA</div>
        <p class="sc-desc">Questionario strutturato secondo il metodo Troisi Ricerche.</p>
        <span class="sc-badge">Generatore automatico</span>
      </div>
    </div>
  </div>
</section>

<!-- CPA INDEX -->
<section id="cpi">
  <div class="section-inner">
    <div class="section-label">Indice proprietario</div>
    <div class="section-title">CustomerPA Index<em></em></div>
    <p class="section-desc">Un numero da 0 a 10, scientificamente fondato e comparabile nel tempo. Media ponderata di 5 dimensioni di servizio.</p>
    <div class="cpi-grid">
      <div class="formula-box">
        <div class="fb-label">Formula CustomerPA Index — Metodo Troisi Ricerche</div>
        <div class="fb-formula">CPA = (R × 0.25) + (M × 0.20) + (I × 0.20) + (D × 0.20) + (W × 0.15)</div>
        <div class="fb-vars">
          R = Rifiuti &amp; Ambiente · M = Mobilità &amp; Trasporti<br>
          I = Servizi Idrici · D = Servizi Digitali PA · W = Welfare Sociale
        </div>
      </div>
      <div class="dim-list">
        <div class="dim-item">
          <div class="di-letter">R</div>
          <div class="di-info"><div class="di-name">Rifiuti &amp; Ambiente</div><div class="di-sub">raccolta differenziata · pulizia città · verde pubblico</div></div>
          <div class="di-bar"><div class="di-fill" style="width:100%"></div></div>
          <div class="di-pct">25%</div>
        </div>
        <div class="dim-item">
          <div class="di-letter">M</div>
          <div class="di-info"><div class="di-name">Mobilità &amp; Trasporti</div><div class="di-sub">TPL · ciclabilità · parcheggi · traffico</div></div>
          <div class="di-bar"><div class="di-fill" style="width:80%"></div></div>
          <div class="di-pct">20%</div>
        </div>
        <div class="dim-item">
          <div class="di-letter">I</div>
          <div class="di-info"><div class="di-name">Servizi Idrici</div><div class="di-sub">qualità acqua · continuità servizio · tariffe</div></div>
          <div class="di-bar"><div class="di-fill" style="width:80%"></div></div>
          <div class="di-pct">20%</div>
        </div>
        <div class="dim-item">
          <div class="di-letter">D</div>
          <div class="di-info"><div class="di-name">Servizi Digitali PA</div><div class="di-sub">sportelli online · app · SPID · pagamenti</div></div>
          <div class="di-bar"><div class="di-fill" style="width:80%"></div></div>
          <div class="di-pct">20%</div>
        </div>
        <div class="dim-item">
          <div class="di-letter">W</div>
          <div class="di-info"><div class="di-name">Welfare Sociale</div><div class="di-sub">assistenza · scuola · servizi anziani · disabilità</div></div>
          <div class="di-bar"><div class="di-fill" style="width:60%"></div></div>
          <div class="di-pct">15%</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CALCOLATORI -->
<section id="calcolatori" style="background:var(--grigio-bg);">
  <div class="section-inner">
    <div class="section-label">Strumenti interattivi</div>
    <div class="section-title">Calcola <em>subito</em></div>
    <div class="calcolatori-grid">
      <div class="calc-box" id="calcolatore">
        <h3>📐 Calcolatore del campione statistico</h3>
        <p class="cb-sub">Calcola la dimensione ottimale del campione per la tua indagine di customer satisfaction comunale. Formula di Cochran con correzione per popolazioni finite — stesso metodo di <a href="https://www.troisiricerche.net" target="_blank" style="color:var(--blu-pa);">Troisi Ricerche</a>.</p>
        <div class="form-group">
          <label>Popolazione del comune (abitanti)</label>
          <input type="number" id="popolazione" placeholder="es. 50000" min="100">
        </div>
        <div class="form-group">
          <label>Livello di confidenza</label>
          <select id="confidenza">
            <option value="1.96">95% — Standard (raccomandato)</option>
            <option value="2.576">99% — Alta precisione</option>
            <option value="1.645">90% — Esplorativo</option>
          </select>
        </div>
        <div class="form-group">
          <label>Margine di errore</label>
          <select id="errore">
            <option value="0.03">±3% — Alta precisione</option>
            <option value="0.05" selected>±5% — Standard PA</option>
            <option value="0.07">±7% — Esplorativo</option>
            <option value="0.10">±10% — Pilota</option>
          </select>
        </div>
        <div class="form-group">
          <label>Proporzione attesa di soddisfatti</label>
          <select id="proporzione">
            <option value="0.5">50% — Massima variabilità (cautelativo)</option>
            <option value="0.6">60%</option>
            <option value="0.7">70%</option>
          </select>
        </div>
        <button class="btn-calc" onclick="calcolaCampione()">Calcola campione →</button>
        <div class="result-box" id="result-campione">
          <div class="rb-main" id="result-n">—</div>
          <div class="rb-label">Interviste raccomandate</div>
          <div class="rb-details">
            <div class="rb-detail">Popolazione N: <strong id="res-pop">—</strong></div>
            <div class="rb-detail">Livello confidenza: <strong id="res-conf">—</strong></div>
            <div class="rb-detail">Margine errore: <strong id="res-err">—</strong></div>
            <div class="rb-detail">Campione teorico ∞: <strong id="res-n0">—</strong></div>
          </div>
          <div class="rb-formula">n₀ = (z² × p × q) / e² &nbsp;·&nbsp; n = n₀ / (1 + (n₀ − 1) / N)<br>Metodo Cochran · Troisi Ricerche © 2026</div>
        </div>
      </div>
      <div class="calc-box" id="cpi-calc">
        <h3>🔢 Calcola il CustomerPA Index del tuo comune</h3>
        <p class="cb-sub">Inserisci i punteggi medi di soddisfazione (scala 0–10) per ciascuna dimensione e ottieni il CustomerPA Index.</p>
        <div class="form-group">
          <label>🗑️ Rifiuti &amp; Ambiente (peso 25%)</label>
          <input type="number" id="r-val" placeholder="es. 7.2" min="0" max="10" step="0.1">
        </div>
        <div class="form-group">
          <label>🚌 Mobilità &amp; Trasporti (peso 20%)</label>
          <input type="number" id="m-val" placeholder="es. 6.4" min="0" max="10" step="0.1">
        </div>
        <div class="form-group">
          <label>💧 Servizi Idrici (peso 20%)</label>
          <input type="number" id="i-val" placeholder="es. 6.9" min="0" max="10" step="0.1">
        </div>
        <div class="form-group">
          <label>💻 Servizi Digitali PA (peso 20%)</label>
          <input type="number" id="d-val" placeholder="es. 5.8" min="0" max="10" step="0.1">
        </div>
        <div class="form-group">
          <label>🤝 Welfare Sociale (peso 15%)</label>
          <input type="number" id="w-val" placeholder="es. 6.5" min="0" max="10" step="0.1">
        </div>
        <button class="btn-calc" onclick="calcolaCPA()">Calcola CPA Index →</button>
        <div class="cpa-result-box" id="result-cpa">
          <div class="cpa-score" id="cpa-score">—</div>
          <div class="cpa-judgment" id="cpa-judgment"></div>
          <div class="cpa-breakdown" id="cpa-breakdown"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- GRAFICI FLOURISH -->
<section id="grafici">
  <div class="section-inner">
    <div class="section-label">📊 Analisi e visualizzazioni · da TroisiInsight</div>
    <div class="section-title">I dati del <em>CustomerPA Index</em> in grafici</div>
    <p class="section-desc">Visualizzazioni interattive sui dati del CustomerPA Index 2025. Elaborazione Troisi Ricerche · Metodo Troisi. <a href="https://www.troisiinsight.it" target="_blank" style="color:var(--blu-pa); font-weight:600;">Archivio completo su TroisiInsight →</a></p>
    <div class="flourish-grid">
      <div class="flourish-card">
        <div class="fc-header">
          <div class="fc-report">CustomerPA Index 2025 · Ranking</div>
          <div class="fc-title">Top comuni italiani per soddisfazione cittadini</div>
        </div>
        <div class="fc-body">
          <div class="flourish-embed flourish-chart" data-src="visualisation/28068780">
            <noscript><img src="https://public.flourish.studio/visualisation/28068780/thumbnail" width="100%" alt="Ranking CustomerPA Index 2025"></noscript>
          </div>
        </div>
        <div class="fc-footer">
          <span class="fc-source">Fonte: Troisi Ricerche · CustomerPA Index 2025 · customerpa.it</span>
          <a href="https://public.flourish.studio/visualisation/28068780/" target="_blank" class="fc-link">Apri ↗</a>
        </div>
      </div>
      <div class="flourish-card">
        <div class="fc-header">
          <div class="fc-report">CustomerPA Index 2025 · Dimensioni</div>
          <div class="fc-title">Soddisfazione per dimensione e area geografica</div>
        </div>
        <div class="fc-body">
          <div class="flourish-embed flourish-chart" data-src="visualisation/28068957">
            <noscript><img src="https://public.flourish.studio/visualisation/28068957/thumbnail" width="100%" alt="Soddisfazione per dimensione"></noscript>
          </div>
        </div>
        <div class="fc-footer">
          <span class="fc-source">Fonte: Troisi Ricerche · CustomerPA Index 2025 · customerpa.it</span>
          <a href="https://public.flourish.studio/visualisation/28068957/" target="_blank" class="fc-link">Apri ↗</a>
        </div>
      </div>
      <div class="flourish-card full-width">
        <div class="fc-header">
          <div class="fc-report">CustomerPA Index 2025 · Mappa Italia</div>
          <div class="fc-title">La soddisfazione dei cittadini regione per regione</div>
        </div>
        <div class="fc-body">
          <div class="flourish-embed flourish-chart" data-src="visualisation/28069169">
            <noscript><img src="https://public.flourish.studio/visualisation/28069169/thumbnail" width="100%" alt="Mappa regionale CustomerPA Index 2025"></noscript>
          </div>
        </div>
        <div class="fc-footer">
          <span class="fc-source">Fonte: Troisi Ricerche · CustomerPA Index 2025 · customerpa.it · Dati: Openpolis, Simplemaps</span>
          <a href="https://public.flourish.studio/visualisation/28069169/" target="_blank" class="fc-link">Apri ↗</a>
        </div>
      </div>
    </div>
    <div class="flourish-cta">
      <a href="https://www.troisiinsight.it" target="_blank">📊 Tutti i grafici e i report su TroisiInsight →</a>
    </div>
  </div>
</section>

<!-- BENCHMARK -->
<section id="benchmark">
  <div class="section-inner">
    <div class="section-label">Benchmark nazionale</div>
    <div class="section-title">Ranking CustomerPA Index — <em>Comuni italiani</em></div>
    <p class="section-desc">Confronta la soddisfazione dei cittadini tra comuni italiani. Dati CustomerPA Index 2025.</p>
    <div style="overflow-x:auto;">
      <table class="benchmark-table">
        <thead>
          <tr><th>#</th><th>Comune</th><th>CPA Index</th><th>Barra</th><th>vs 2024</th><th>Punto di forza</th><th>Area critica</th></tr>
        </thead>
        <tbody>
          <tr><td class="rank-pos top3">01</td><td><span class="rank-nome">Bergamo</span><span class="rank-regione">Lombardia</span></td><td class="rank-score">8.1</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:81%"></div></div></td><td><span class="rank-trend up">▲ +0.3</span></td><td style="font-size:.78rem;color:var(--grigio);">Trasporti (ATB)</td><td style="font-size:.78rem;color:var(--grigio);">Biglietteria digitale</td></tr>
          <tr><td class="rank-pos top3">02</td><td><span class="rank-nome">Bologna</span><span class="rank-regione">Emilia-Romagna</span></td><td class="rank-score">7.9</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:79%"></div></div></td><td><span class="rank-trend up">▲ +0.2</span></td><td style="font-size:.78rem;color:var(--grigio);">Servizi digitali</td><td style="font-size:.78rem;color:var(--grigio);">Tempi attesa sportelli</td></tr>
          <tr><td class="rank-pos top3">03</td><td><span class="rank-nome">Trento</span><span class="rank-regione">Trentino-AA</span></td><td class="rank-score">7.8</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:78%"></div></div></td><td><span class="rank-trend up">▲ +0.1</span></td><td style="font-size:.78rem;color:var(--grigio);">Anagrafe digitale</td><td style="font-size:.78rem;color:var(--grigio);">Trasporto notturno</td></tr>
          <tr><td class="rank-pos">04</td><td><span class="rank-nome">Bolzano</span><span class="rank-regione">Alto Adige</span></td><td class="rank-score">7.7</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:77%"></div></div></td><td><span class="rank-trend up">▲ +0.2</span></td><td style="font-size:.78rem;color:var(--grigio);">Pulizia città</td><td style="font-size:.78rem;color:var(--grigio);">Accessibilità web</td></tr>
          <tr><td class="rank-pos">05</td><td><span class="rank-nome">Milano</span><span class="rank-regione">Lombardia</span></td><td class="rank-score">7.4</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:74%"></div></div></td><td><span class="rank-trend up">▲ +0.3</span></td><td style="font-size:.78rem;color:var(--grigio);">Mobilità integrata</td><td style="font-size:.78rem;color:var(--grigio);">Affollamento mezzi</td></tr>
          <tr style="opacity:.6;"><td colspan="7" style="text-align:center;font-size:.78rem;color:var(--grigio);padding:12px;">… dati completi disponibili per i comuni aderenti alla piattaforma · <a href="https://calendly.com/andreatroisi/30min" target="_blank" style="color:var(--blu-pa);font-weight:600;">Contatta Troisi Ricerche</a></td></tr>
          <tr><td class="rank-pos">45</td><td><span class="rank-nome">Napoli</span><span class="rank-regione">Campania</span></td><td class="rank-score">5.2</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:52%"></div></div></td><td><span class="rank-trend up">▲ +0.4</span></td><td style="font-size:.78rem;color:var(--grigio);">Servizi culturali</td><td style="font-size:.78rem;color:var(--grigio);">Trasporti, rifiuti</td></tr>
          <tr><td class="rank-pos">48</td><td><span class="rank-nome">Palermo</span><span class="rank-regione">Sicilia</span></td><td class="rank-score">4.9</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:49%"></div></div></td><td><span class="rank-trend up">▲ +0.3</span></td><td style="font-size:.78rem;color:var(--grigio);">Turismo e accoglienza</td><td style="font-size:.78rem;color:var(--grigio);">Digitalizzazione</td></tr>
          <tr><td class="rank-pos">50</td><td><span class="rank-nome">Reggio Calabria</span><span class="rank-regione">Calabria</span></td><td class="rank-score">4.6</td><td class="rank-bar-cell"><div class="rank-bar"><div class="rank-bar-fill" style="width:46%"></div></div></td><td><span class="rank-trend up">▲ +0.3</span></td><td style="font-size:.78rem;color:var(--grigio);">Ospitalità</td><td style="font-size:.78rem;color:var(--grigio);">Quasi tutti i servizi</td></tr>
        </tbody>
      </table>
    </div>
    <p class="rank-nota">* Dati CustomerPA Index 2025 · Troisi Ricerche · Indagine su 200 comuni italiani. Fonte: indagini CAWI/CATI Troisi Ricerche. Dati completi disponibili per i comuni aderenti alla piattaforma. La correlazione tra CPA Index e TR-Index è <strong>r=0.84</strong> — i comuni che investono nella qualità dei servizi ottengono performance territoriali migliori.</p>
  </div>
</section>

<!-- GENERATORE QUESTIONARI -->
<section id="questionario">
  <div class="section-inner">
    <div class="section-label">Generatore automatico</div>
    <div class="section-title">Genera il <em>questionario</em> per la PA</div>
    <p class="section-desc">Seleziona i servizi da indagare e genera un questionario strutturato secondo il metodo Troisi Ricerche, pronto per somministrazione CAWI o CATI.</p>
    <div class="questionario-box">
      <p style="font-size:0.82rem; color:var(--grigio); margin-bottom:14px;">Seleziona i servizi:</p>
      <div class="servizi-list">
        <div class="servizio-item" onclick="toggleServizio(this)" data-servizio="rifiuti">
          <div class="si-left"><span class="si-icon">🗑️</span><span class="si-name">Rifiuti &amp; Raccolta differenziata</span></div>
          <span class="si-domande">8 domande</span>
          <div class="si-check"></div>
        </div>
        <div class="servizio-item" onclick="toggleServizio(this)" data-servizio="mobilita">
          <div class="si-left"><span class="si-icon">🚌</span><span class="si-name">Mobilità &amp; Trasporto pubblico</span></div>
          <span class="si-domande">7 domande</span>
          <div class="si-check"></div>
        </div>
        <div class="servizio-item" onclick="toggleServizio(this)" data-servizio="idrico">
          <div class="si-left"><span class="si-icon">💧</span><span class="si-name">Servizi Idrici &amp; Acqua</span></div>
          <span class="si-domande">6 domande</span>
          <div class="si-check"></div>
        </div>
        <div class="servizio-item" onclick="toggleServizio(this)" data-servizio="digitale">
          <div class="si-left"><span class="si-icon">💻</span><span class="si-name">Servizi Digitali PA</span></div>
          <span class="si-domande">7 domande</span>
          <div class="si-check"></div>
        </div>
        <div class="servizio-item" onclick="toggleServizio(this)" data-servizio="welfare">
          <div class="si-left"><span class="si-icon">🤝</span><span class="si-name">Welfare &amp; Servizi Sociali</span></div>
          <span class="si-domande">6 domande</span>
          <div class="si-check"></div>
        </div>
      </div>
      <button class="btn-calc" onclick="generaQuestionario()">Genera questionario →</button>
      <div class="questionario-output" id="questionario-output"></div>
    </div>
  </div>
</section>

<!-- METODOLOGIA -->
<section id="metodo">
  <div class="section-inner">
    <div class="section-label">Metodologia scientifica</div>
    <div class="section-title">Il metodo statistico di <em>Troisi Ricerche</em></div>
    <p class="section-desc">Basato su tecniche statistiche consolidate internazionalmente — CAWI, CATI, SERVQUAL — adattate al contesto dei servizi pubblici locali italiani da Andrea Troisi.</p>
    <div class="fasi-grid">
      <div class="fase-card">
        <div class="fase-num">01</div>
        <div class="fase-icon">📐</div>
        <div class="fase-title">Campionamento</div>
        <p class="fase-desc">Formula di Cochran con correzione per popolazioni finite. Margine di errore garantito e livello di confidenza scelto dal committente.</p>
        <div class="fase-arrow">→</div>
      </div>
      <div class="fase-card">
        <div class="fase-num">02</div>
        <div class="fase-icon">📋</div>
        <div class="fase-title">Rilevazione CAWI/CATI</div>
        <p class="fase-desc">Somministrazione web (CAWI) o telefonica (CATI). Questionari strutturati secondo il modello SERVQUAL adattato alla PA italiana.</p>
        <div class="fase-arrow">→</div>
      </div>
      <div class="fase-card">
        <div class="fase-num">03</div>
        <div class="fase-icon">📊</div>
        <div class="fase-title">Analisi statistica</div>
        <p class="fase-desc">Calcolo del CustomerPA Index ponderato, analisi per dimensione, identificazione gap critici e confronto con benchmark nazionale.</p>
        <div class="fase-arrow">→</div>
      </div>
      <div class="fase-card">
        <div class="fase-num">04</div>
        <div class="fase-icon">📄</div>
        <div class="fase-title">Benchmark &amp; Report</div>
        <p class="fase-desc">Confronto con comuni di dimensione simile e media nazionale. Report PDF per dirigenti e organi di controllo (OIV, PIAO).</p>
      </div>
    </div>
    <div class="libro-section">
      <div class="libro-cover">
        <div class="lc-icon">📘</div>
        <div class="lc-editore">Cacucci Editore</div>
        <div class="lc-titolo">Un modello statistico per la Customer Satisfaction nella PA</div>
      </div>
      <div class="libro-info">
        <div class="camera-badge">🏛️ Presentato alla Camera dei Deputati</div>
        <h4>Un modello statistico per la Customer Satisfaction nella PA</h4>
        <div class="li-autore">Andrea Troisi · Cacucci Editore · Bari</div>
        <p>Il volume pubblicato da Cacucci Editore presenta il metodo statistico sviluppato da Andrea Troisi per la misurazione della customer satisfaction nella Pubblica Amministrazione. Tecniche di campionamento, modelli SERVQUAL, analisi CAWI/CATI e strumenti per l'analisi della qualità dei servizi pubblici locali. Il modello alla base di CustomerPA e del CustomerPA Index.</p>
        <a href="https://www.cacuccieditore.it/troisi-andrea-2" target="_blank" class="btn-libro">Acquista su Cacucci Editore ↗</a>
      </div>
    </div>
  </div>
</section>

<!-- ECOSISTEMA -->
<section id="ecosistema">
  <div class="section-inner">
    <div class="section-label">Metodo Troisi · Ecosistema</div>
    <div class="section-title">La galassia degli indicatori di <em>Troisi Ricerche</em></div>
    <div class="eco-intro">
      "Il modello di analisi sviluppato da <strong>Andrea Troisi</strong> e <strong>Troisi Ricerche</strong> si articola in cinque strumenti: il <strong>TR-Index</strong> (misurazione territoriale), <strong>Mappatura delle Competenze</strong>, <strong>Registro delle Competenze</strong>, <strong>CustomerPA</strong> (customer satisfaction PA) e <strong>TIP Platform</strong> (data analytics). Un ecosistema scientifico integrato per l'analisi del capitale umano, del territorio e dei servizi pubblici."
    </div>
    <div class="eco-grid">
      <a href="https://www.t-index.it" target="_blank" class="eco-card">
        <div class="ec-step">Misurare · Fase 01</div>
        <div class="ec-icon">📐</div>
        <div class="ec-name">TR-Index</div>
        <div class="ec-desc">Territorial Performance Index · 7.901 comuni</div>
        <div class="ec-link">t-index.it ↗</div>
      </a>
      <a href="https://www.mappaturadellecompetenze.it" target="_blank" class="eco-card">
        <div class="ec-step">Analizzare · Fase 02</div>
        <div class="ec-icon">🗺️</div>
        <div class="ec-name">Mappatura delle Competenze</div>
        <div class="ec-desc">Skill mapping e human capital analytics</div>
        <div class="ec-link">mappaturadellecompetenze.it ↗</div>
      </a>
      <a href="https://www.registrodellecompetenze.it" target="_blank" class="eco-card">
        <div class="ec-step">Registrare · Fase 03</div>
        <div class="ec-icon">📜</div>
        <div class="ec-name">Registro delle Competenze</div>
        <div class="ec-desc">Registro competenze · Indice IMC · D.Lgs. 13/2013</div>
        <div class="ec-link">registrodellecompetenze.it ↗</div>
      </a>
      <div class="eco-card active">
        <div class="ec-step">Ascoltare · Fase 04 · Sei qui</div>
        <div class="ec-icon">😊</div>
        <div class="ec-name">CustomerPA</div>
        <div class="ec-desc">Customer satisfaction PA · CPA Index</div>
        <div class="ec-link">customerpa.it ◉</div>
      </div>
      <a href="https://www.tiplive.it" target="_blank" class="eco-card">
        <div class="ec-step">Tecnologia proprietaria</div>
        <div class="ec-icon">⚡</div>
        <div class="ec-name">TIP Platform</div>
        <div class="ec-desc">Data analytics · Business intelligence</div>
        <div class="ec-link">tiplive.it ↗</div>
      </a>
    </div>
    <div class="eco-grid-2" style="margin-top:14px;">
      <a href="https://www.troisiinsight.it" target="_blank" class="eco-card">
        <div class="ec-icon">📊</div>
        <div class="ec-name">TroisiInsight</div>
        <div class="ec-desc">Laboratorio pubblico di analisi · report e dashboard</div>
        <div class="ec-link">troisiinsight.it ↗</div>
      </a>
      <a href="https://www.digitalizzazionenellapa.it" target="_blank" class="eco-card">
        <div class="ec-icon">🏛️</div>
        <div class="ec-name">DigitalizzazionePA</div>
        <div class="ec-desc">Hub istituzionale PA digitale</div>
        <div class="ec-link">digitalizzazionenellapa.it ↗</div>
      </a>
      <a href="https://www.voiceinhub.it" target="_blank" class="eco-card">
        <div class="ec-icon">🎙️</div>
        <div class="ec-name">VoiceInHub</div>
        <div class="ec-desc">Podcast PA, innovazione, territorio</div>
        <div class="ec-link">voiceinhub.it ↗</div>
      </a>
      <a href="https://www.osservatoriomezzogiorno.net" target="_blank" class="eco-card">
        <div class="ec-icon">🗺️</div>
        <div class="ec-name">Osservatorio Mezzogiorno</div>
        <div class="ec-desc">Innovazione e sviluppo nel Sud Italia</div>
        <div class="ec-link">osservatoriomezzogiorno.net ↗</div>
      </a>
    </div>
  </div>
</section>

<!-- CHI SIAMO -->
<section id="chi-siamo">
  <div class="section-inner">
    <div class="section-label">Chi siamo</div>
    <div class="section-title">Andrea Troisi e <em>Troisi Ricerche</em></div>
    <div class="chi-grid">
      <div class="at-card">
        <div class="at-avatar">AT</div>
        <div class="at-name">Andrea Troisi</div>
        <div class="at-ruolo">Ricercatore · Statistico · Fondatore Troisi Ricerche<br>Professore Univ. Bari "Aldo Moro"</div>
        <p class="at-desc"><strong>Andrea Troisi</strong> è ricercatore, statistico e fondatore di Troisi Ricerche S.r.l. Unipersonale. Ha sviluppato il <strong>CustomerPA Index</strong> e il framework di misurazione della customer satisfaction nella PA, pubblicato da Cacucci Editore. Autore del <strong>Metodo Troisi</strong> che integra TR-Index, Mappatura delle Competenze, Registro delle Competenze, CustomerPA e TIP Platform.</p>
        <div class="at-links">
          <a href="https://andreatroisi.it" target="_blank">andreatroisi.it ↗</a>
          <a href="https://www.linkedin.com/in/andreatroisi/" target="_blank">LinkedIn ↗</a>
          <a href="https://www.cacuccieditore.it/troisi-andrea-2" target="_blank">Libro Cacucci ↗</a>
          <a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota ↗</a>
        </div>
      </div>
      <div class="troisi-box">
        <h4>Troisi Ricerche S.r.l. Unipersonale</h4>
        <p>Istituto di ricerca specializzato in analisi statistica, ricerche di mercato, customer satisfaction e human capital analytics. Certificazione TÜV ISO 9001. Dal 2006 al servizio di imprese, PA e università.</p>
        <div class="tb-stats">
          <div class="tb-stat"><div class="ts-val">20+</div><div class="ts-lbl">anni</div></div>
          <div class="tb-stat"><div class="ts-val">400k+</div><div class="ts-lbl">interviste</div></div>
          <div class="tb-stat"><div class="ts-val">3</div><div class="ts-lbl">sedi</div></div>
        </div>
        <p style="font-size:0.75rem; margin-bottom:0;">🏢 Via de Rossi, 57 · 70122 Bari<br>📋 P.IVA 07216100722 · TÜV ISO 9001:2015<br>🌐 <a href="https://www.troisiricerche.net" target="_blank" style="color:var(--blu-pa);">troisiricerche.net</a><br>📧 <a href="mailto:customerpa@troisiricerche.it" style="color:var(--blu-pa);">customerpa@troisiricerche.it</a></p>
      </div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section id="faq">
  <div class="section-inner">
    <div class="section-label">FAQ</div>
    <div class="section-title">Domande <em>frequenti</em></div>
    <div class="faq-list">
      <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Cos'è la customer satisfaction nella Pubblica Amministrazione? <span class="fq-icon">+</span></div>
        <div class="faq-answer">La <strong>customer satisfaction nella PA</strong> è la misurazione sistematica del grado di soddisfazione dei cittadini rispetto ai servizi pubblici erogati. Il metodo CustomerPA sviluppato da Andrea Troisi e Troisi Ricerche usa tecniche statistiche rigorose (CAWI, CATI, SERVQUAL) per rilevare, misurare e confrontare la qualità percepita dei servizi pubblici locali, producendo il <strong>CustomerPA Index</strong>. Il modello è pubblicato nel volume edito da Cacucci Editore.</div>
      </div>
      <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Cos'è il CustomerPA Index e come si calcola? <span class="fq-icon">+</span></div>
        <div class="faq-answer">Il <strong>CustomerPA Index</strong> è l'indice proprietario sviluppato da Andrea Troisi e Troisi Ricerche. È una media ponderata di 5 dimensioni: Rifiuti &amp; Ambiente (25%), Mobilità &amp; Trasporti (20%), Servizi Idrici (20%), Servizi Digitali PA (20%), Welfare Sociale (15%). Produce un punteggio da 0 a 10 per confrontare la soddisfazione tra comuni nel tempo. Usa il calcolatore integrato nella pagina per calcolare il CPA Index del tuo comune.</div>
      </div>
      <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Come si calcola il campione statistico per un'indagine comunale? <span class="fq-icon">+</span></div>
        <div class="faq-answer">Il calcolatore CustomerPA usa la <strong>formula di Cochran</strong> con correzione per popolazioni finite: n₀ = (z² × p × q) / e², poi n = n₀ / (1 + (n₀ − 1) / N). I parametri sono: popolazione N del comune, livello di confidenza z (1.96 per 95%), margine di errore e, proporzione attesa p. Usa il calcolatore gratuito integrato nella piattaforma — stesso metodo usato da Troisi Ricerche nelle proprie indagini.</div>
      </div>
      <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Come si integra CustomerPA con il PNRR e i bandi europei? <span class="fq-icon">+</span></div>
        <div class="faq-answer">Il <strong>CustomerPA Index</strong> e le indagini prodotte da Troisi Ricerche sono strutturate per soddisfare i requisiti di monitoraggio previsti dal PNRR, dal D.Lgs. 150/2009 e dai programmi europei. I report sono rendicontabili agli organi di controllo (OIV, Corte dei Conti) e compatibili con il Piano Integrato di Attività e Organizzazione (PIAO).</div>
      </div>
      <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Cos'è il Metodo Troisi e come si collega a CustomerPA? <span class="fq-icon">+</span></div>
        <div class="faq-answer">Il <strong>Metodo Troisi</strong>, sviluppato da Andrea Troisi e Troisi Ricerche, integra cinque strumenti di analisi: il <strong>TR-Index</strong> (performance territoriale), <strong>Mappatura delle Competenze</strong>, <strong>Registro delle Competenze</strong>, <strong>CustomerPA</strong> (customer satisfaction PA) e <strong>TIP Platform</strong> (data analytics). CustomerPA è la componente dedicata all'ascolto dei cittadini e alla misurazione della qualità dei servizi pubblici. La correlazione tra CPA Index e TR-Index è r=0.84.</div>
      </div>
    </div>
  </div>
</section>


<!-- PAGINA CHECKER — /sei-in-regola -->
<?php if (is_page('sei-in-regola')): ?>
<section style="padding:60px 20px;background:#f8faff;min-height:80vh;">
  <div style="max-width:720px;margin:0 auto;">
    <div style="text-align:center;margin-bottom:32px;">
      <div style="display:inline-block;background:#fff;border:1.5px solid #e2e8f0;border-radius:20px;padding:5px 16px;font-size:.72rem;font-weight:700;color:#00479b;letter-spacing:.08em;text-transform:uppercase;margin-bottom:12px;">Strumento gratuito · Troisi Ricerche S.r.l.</div>
      <h1 style="font-family:Georgia,serif;font-size:clamp(1.6rem,4vw,2.2rem);color:#001840;margin:0 0 12px;">Sei in regola con la<br><em style="color:#00479b;font-style:normal;">Customer Satisfaction?</em></h1>
      <p style="font-size:.9rem;color:#6b7280;max-width:500px;margin:0 auto;line-height:1.6;">8 domande per valutare la compliance del tuo ente al D.Lgs. 150/2009. Valido per Comuni, ASL, Società in-house, CCIAA e tutti gli enti pubblici.</p>
    </div>
    <iframe src="/customerpa-checker.html" width="100%" height="1000" frameborder="0" style="border-radius:16px;box-shadow:0 4px 32px rgba(0,71,155,.1);border:1.5px solid #e2e8f0;" loading="lazy"></iframe>
  </div>
</section>
<?php endif; ?>

<!-- CTA FINALE -->
<div class="cta-finale">
  <div style="max-width:640px; margin:0 auto;">
    <div style="font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.4);margin-bottom:10px;">⚖️ Adempimento obbligatorio · D.Lgs. 150/2009</div>
    <h2>Avvia il percorso di conformità<br>prima della prossima validazione OIV</h2>
    <p>Il team di Troisi Ricerche analizza il sistema CS del tuo ente e propone un piano operativo documentato, difendibile in ogni sede istituzionale. Risposta entro 24 ore lavorative.</p>
    <div class="cta-btns">
      <a href="<?php echo home_url('/sei-in-regola'); ?>" class="btn-cta-white">🔍 Avvia la verifica di conformità</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-cta-outline">📅 Colloquio con Andrea Troisi →</a>
    </div>
    <div style="margin-top:16px;font-size:.72rem;color:rgba(255,255,255,.3);">Troisi Ricerche S.r.l. · Accreditato MIUR come Ente di Ricerca · 200+ PA servite · Dal 2006</div>
  </div>
</div>

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">CustomerPA</div>
        <p>La piattaforma italiana per la misurazione della soddisfazione dei cittadini nei servizi pubblici locali. CustomerPA Index, benchmark comuni, calcolatore campione statistico.</p>
        <p class="brand-legal">CustomerPA · Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari (BA) · CF/P.IVA 07216100722 · SDI KRRH6B9</p>
      </div>
      <div class="footer-col">
        <h4>Piattaforma</h4>
        <ul>
          <li><a href="#cpi">CustomerPA Index</a></li>
          <li><a href="#strumenti">Strumenti</a></li>
          <li><a href="#grafici">Grafici</a></li>
          <li><a href="#calcolatore">Calcolatore campione</a></li>
          <li><a href="#benchmark">Benchmark comuni</a></li>
          <li><a href="#questionario">Genera questionario</a></li>
          <li><a href="#metodo">Metodologia</a></li>
          <li><a href="#faq">FAQ</a></li>
          <li><a href="#">Accedi</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Ecosistema Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">Troisi Ricerche</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.mappaturadellecompetenze.it" target="_blank">Mappatura delle Competenze</a></li>
          <li><a href="https://www.registrodellecompetenze.it" target="_blank">Registro delle Competenze</a></li>
          <li><a href="https://www.benessereorganizzativo.it" target="_blank">BenessereOrg.</a></li>
          <li><a href="https://www.troisiformazione.it" target="_blank">Troisi Formazione</a></li>
          <li><a href="https://www.tiplive.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
          <li><a href="https://www.digitalizzazionenellapa.it" target="_blank">DigitalizzazionePA</a></li>
          <li><a href="https://www.dibattito-pubblico.it" target="_blank">Dibattito Pubblico</a></li>
          <li><a href="https://www.voiceinhub.it" target="_blank">VoiceInHub</a></li>
          <li><a href="https://www.governancefinanziaria.it" target="_blank">Governance Fin.</a></li>
          <li><a href="https://www.consulenzainternazionalizzazione.it" target="_blank">Internazionalizzazione</a></li>
          <li><a href="https://www.benesseredigitalegiovani.it" target="_blank">BDG</a></li>
          <li><a href="https://www.osservatoriomezzogiorno.net" target="_blank">Osservatorio Mezzogiorno</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una demo</a></li>
          <li><a href="mailto:customerpa@troisiricerche.it">customerpa@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/in/andreatroisi/" target="_blank">LinkedIn Andrea Troisi</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn Troisi Ricerche</a></li>
          <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a></li>
          <li><a href="https://www.cacuccieditore.it/troisi-andrea-2" target="_blank">Libro Cacucci Editore</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 CustomerPA · Troisi Ricerche S.r.l. Unipersonale · <a href="mailto:customerpa@troisiricerche.it" style="color:rgba(255,255,255,.35);">customerpa@troisiricerche.it</a></div>
      <div class="footer-legal">
        <a href="https://www.iubenda.com/privacy-policy/814914" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" title="Privacy Policy">Privacy Policy</a>
        <a href="https://www.iubenda.com/privacy-policy/814914/cookie-policy" class="iubenda-white no-brand iubenda-noiframe iubenda-embed" title="Cookie Policy">Cookie Policy</a>
        <a href="https://www.troisiricerche.net/termini-di-servizio/" target="_blank">Termini di Servizio</a>
      </div>
      <script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0]; s.src="https://cdn.iubenda.com/iubenda.js"; tag.parentNode.insertBefore(s,tag);}; if(w.addEventListener){w.addEventListener("load", loader, false);}else if(w.attachEvent){w.attachEvent("onload", loader);}else{w.onload = loader;}})(window, document);</script>
    </div>
  </div>

  <!-- BLOCCO SEO ISTITUZIONALE -->
  <div style="border-top:1px solid rgba(255,255,255,.08);margin-top:32px;padding-top:24px;">
    <div style="max-width:1100px;margin:0 auto;padding:0 20px;">
      <p style="font-size:.75rem;color:rgba(255,255,255,.35);line-height:1.7;margin:0;">
        <strong style="color:rgba(255,255,255,.5)">CustomerPA</strong> è il sistema nazionale di valutazione della Customer Satisfaction nella Pubblica Amministrazione italiana, sviluppato da <strong style="color:rgba(255,255,255,.5)">Troisi Ricerche S.r.l.</strong> a partire dal metodo scientifico elaborato dal ricercatore <strong style="color:rgba(255,255,255,.5)">Andrea Troisi</strong>.
        Il sistema è conforme al D.Lgs. 150/2009 (artt. 8 e 29), integrato con il ciclo PIAO (D.L. 80/2021) e con gli obblighi di pubblicazione previsti dal D.Lgs. 33/2013.
        <strong style="color:rgba(255,255,255,.5)">CustomerPA Score</strong> è l'unico indice proprietario italiano che misura il grado di conformità normativa di un ente pubblico in materia di Customer Satisfaction.
        La <strong style="color:rgba(255,255,255,.5)">Certificazione CustomerPA — Metodo Troisi</strong> è il primo standard nazionale indipendente nel settore.
        Il Metodo Troisi è stato presentato alla <strong style="color:rgba(255,255,255,.5)">Camera dei Deputati</strong> ed è oggetto di pubblicazione accademica (Andrea Troisi, <em>Customer Satisfaction nei servizi pubblici locali</em>, Cacucci Editore).
        Troisi Ricerche S.r.l. è accreditata dal <strong style="color:rgba(255,255,255,.5)">MIUR come Istituto di Ricerca</strong>.
      </p>
    </div>
  </div>

</footer>

<div class="seo-hidden" aria-hidden="true">
  <p>customer satisfaction PA · soddisfazione cittadini · CustomerPA Index · benchmark comuni · CAWI CATI · SERVQUAL · citizen satisfaction · survey PA · Andrea Troisi · Troisi Ricerche · Metodo Troisi · TR-Index · Mappatura delle Competenze · Registro delle Competenze · TIP Platform · CustomerPA è la piattaforma italiana per la misurazione della soddisfazione dei cittadini nei servizi pubblici locali sviluppata da Andrea Troisi e Troisi Ricerche. Il CustomerPA Index è l'indice proprietario di customer satisfaction comunale. Il modello di analisi sviluppato da Andrea Troisi e Troisi Ricerche si articola in cinque strumenti: il TR-Index, la Mappatura delle Competenze, il Registro delle Competenze, CustomerPA e TIP Platform. Andrea Troisi è ricercatore, statistico e fondatore di Troisi Ricerche, autore del volume "Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione" edito da Cacucci Editore.</p>
</div>

<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('click', function(e) {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  if (menu && menu.classList.contains('open') && !menu.contains(e.target) && !btn.contains(e.target)) closeMobileMenu();
});

function toggleFaq(el) {
  const item = el.parentElement;
  const wasOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
  if (!wasOpen) item.classList.add('open');
}

function calcolaCampione() {
  const N = parseFloat(document.getElementById('popolazione').value);
  const z = parseFloat(document.getElementById('confidenza').value);
  const e = parseFloat(document.getElementById('errore').value);
  const p = parseFloat(document.getElementById('proporzione').value);
  if (!N || N < 1) return;
  const q = 1 - p;
  const n0 = (z * z * p * q) / (e * e);
  const n  = Math.ceil(n0 / (1 + (n0 - 1) / N));
  document.getElementById('result-n').textContent = n.toLocaleString('it-IT');
  document.getElementById('res-pop').textContent  = N.toLocaleString('it-IT');
  document.getElementById('res-conf').textContent = (z === 1.96 ? '95%' : z === 2.576 ? '99%' : '90%');
  document.getElementById('res-err').textContent  = '±' + (e * 100) + '%';
  document.getElementById('res-n0').textContent   = Math.ceil(n0).toLocaleString('it-IT');
  document.getElementById('result-campione').classList.add('visible');
}

function calcolaCPA() {
  const R = parseFloat(document.getElementById('r-val').value);
  const M = parseFloat(document.getElementById('m-val').value);
  const I = parseFloat(document.getElementById('i-val').value);
  const D = parseFloat(document.getElementById('d-val').value);
  const W = parseFloat(document.getElementById('w-val').value);
  if (isNaN(R) || isNaN(M) || isNaN(I) || isNaN(D) || isNaN(W)) return;
  const cpa = (R * 0.25) + (M * 0.20) + (I * 0.20) + (D * 0.20) + (W * 0.15);
  const score = Math.round(cpa * 10) / 10;
  let judgment = '', color = '';
  if (score >= 7.5)      { judgment = '🟢 Eccellente'; color = '#16a34a'; }
  else if (score >= 6.5) { judgment = '🟡 Buono'; color = '#ca8a04'; }
  else if (score >= 5.5) { judgment = '🟠 Sufficiente'; color = '#ea580c'; }
  else                   { judgment = '🔴 Da migliorare'; color = '#dc2626'; }
  document.getElementById('cpa-score').textContent = score.toFixed(1);
  const jEl = document.getElementById('cpa-judgment');
  jEl.textContent = judgment;
  jEl.style.color = color;
  document.getElementById('cpa-breakdown').innerHTML =
    `<span>Rifiuti (×0.25): <strong>${(R*0.25).toFixed(2)}</strong></span>
     <span>Mobilità (×0.20): <strong>${(M*0.20).toFixed(2)}</strong></span>
     <span>Idrico (×0.20): <strong>${(I*0.20).toFixed(2)}</strong></span>
     <span>Digitale (×0.20): <strong>${(D*0.20).toFixed(2)}</strong></span>
     <span>Welfare (×0.15): <strong>${(W*0.15).toFixed(2)}</strong></span>`;
  document.getElementById('result-cpa').classList.add('visible');
}

const domande = {
  rifiuti: {
    titolo: '🗑️ Rifiuti & Raccolta differenziata',
    items: [
      'Come valuta la pulizia delle strade e degli spazi pubblici?',
      'Come valuta la frequenza della raccolta dei rifiuti?',
      'Come valuta la qualità del servizio di raccolta differenziata?',
      'Come valuta la disponibilità di contenitori per la differenziata?',
      'Come valuta la gestione dei rifiuti ingombranti?',
      'Come valuta la manutenzione del verde pubblico?',
      'Come valuta la comunicazione del Comune sui servizi ambientali?',
      'In generale, come valuta il servizio di igiene urbana del suo Comune?'
    ]
  },
  mobilita: {
    titolo: '🚌 Mobilità & Trasporto pubblico',
    items: [
      'Come valuta la frequenza dei mezzi di trasporto pubblico?',
      'Come valuta la puntualità del trasporto pubblico?',
      'Come valuta la copertura territoriale del trasporto pubblico?',
      'Come valuta lo stato di manutenzione dei mezzi pubblici?',
      'Come valuta la disponibilità di piste ciclabili?',
      'Come valuta la gestione del traffico e dei parcheggi?',
      'In generale, come valuta la mobilità nella sua città?'
    ]
  },
  idrico: {
    titolo: '💧 Servizi Idrici & Acqua',
    items: [
      'Come valuta la qualità dell\'acqua potabile?',
      'Come valuta la continuità del servizio idrico?',
      'Come valuta il costo delle bollette idriche?',
      'Come valuta la gestione delle perdite idriche?',
      'Come valuta la comunicazione sulle interruzioni del servizio?',
      'In generale, come valuta il servizio idrico del suo Comune?'
    ]
  },
  digitale: {
    titolo: '💻 Servizi Digitali PA',
    items: [
      'Come valuta la facilità d\'uso del portale web del Comune?',
      'Come valuta la disponibilità di servizi online (certificati, permessi)?',
      'Come valuta i tempi di risposta agli sportelli online?',
      'Come valuta l\'accesso ai servizi tramite SPID?',
      'Come valuta i pagamenti digitali verso il Comune (PagoPA)?',
      'Come valuta la disponibilità di app comunali?',
      'In generale, come valuta la digitalizzazione dei servizi comunali?'
    ]
  },
  welfare: {
    titolo: '🤝 Welfare & Servizi Sociali',
    items: [
      'Come valuta i servizi di assistenza agli anziani?',
      'Come valuta i servizi per persone con disabilità?',
      'Come valuta l\'offerta di asili nido e servizi 0-3 anni?',
      'Come valuta i servizi scolastici comunali (mense, trasporto)?',
      'Come valuta i servizi di sostegno alle famiglie in difficoltà?',
      'In generale, come valuta i servizi sociali del suo Comune?'
    ]
  }
};

function toggleServizio(el) {
  el.classList.toggle('selected');
  const check = el.querySelector('.si-check');
  check.textContent = el.classList.contains('selected') ? '✓' : '';
}

function generaQuestionario() {
  const selezionati = document.querySelectorAll('.servizio-item.selected');
  if (selezionati.length === 0) {
    alert('Seleziona almeno un servizio da indagare.');
    return;
  }
  let html = '<div style="font-size:0.78rem; color:var(--grigio); margin-bottom:12px; font-weight:600;">SCALA DI RISPOSTA: 1=Per nulla soddisfatto · 10=Molto soddisfatto</div>';
  let numDomanda = 1;
  selezionati.forEach(item => {
    const key = item.dataset.servizio;
    const sezione = domande[key];
    html += `<div class="qo-sezione"><div class="qo-titolo">${sezione.titolo}</div>`;
    sezione.items.forEach(d => {
      html += `<div class="qo-domanda"><span class="qo-num">${numDomanda}.</span>${d}</div>`;
      numDomanda++;
    });
    html += '</div>';
  });
  html += `<div style="font-size:0.72rem; color:var(--grigio); margin-top:12px; border-top:1px solid var(--bordo); padding-top:8px;">Totale domande: <strong>${numDomanda-1}</strong> · Metodo Troisi Ricerche · CustomerPA Index · © 2026</div>`;
  const output = document.getElementById('questionario-output');
  output.innerHTML = html;
  output.classList.add('visible');
}
</script>

<?php get_footer(); ?>
</body>
</html>