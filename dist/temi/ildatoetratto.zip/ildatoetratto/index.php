<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<header class="page-head"><div class="wrap"><h1><?php echo esc_html( is_archive() ? wp_strip_all_tags( get_the_archive_title() ) : ( is_search() ? 'Risultati della ricerca' : 'Tutti i numeri' ) ); ?></h1></div></header>
<div class="contenuto"><div class="wrap">
	<?php if ( have_posts() ) : ?>
	<div class="elenco-numeri">
		<?php while ( have_posts() ) : the_post(); get_template_part( 'templates/card-numero' ); endwhile; ?>
	</div>
	<div style="margin-top:28px"><?php the_posts_pagination( array( 'prev_text' => '← Più recenti', 'next_text' => 'Precedenti →' ) ); ?></div>
	<?php else : ?>
	<p>Nessun contenuto trovato. <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Torna alla pagina iniziale</a>.</p>
	<?php endif; ?>
</div></div>
<?php
get_footer();
