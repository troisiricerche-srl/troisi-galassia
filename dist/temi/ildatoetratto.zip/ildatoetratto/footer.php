<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
</main>
<footer class="site-foot">
	<div class="wrap">
		<div class="cols">
			<div>
				<h3>Il dato è tratto<sup class="tm">™</sup></h3>
				<p>La newsletter e il canale WhatsApp di <a href="https://www.troisiricerche.net/">Troisi Ricerche</a>, istituto di ricerca statistica applicata attivo dal 2006. A cura di <a href="https://www.andreatroisi.it/">Andrea Troisi</a>.</p>
				<p><a href="<?php echo esc_url( IDT_WHATSAPP ); ?>" target="_blank" rel="noopener">Segui il canale WhatsApp →</a><br><a href="https://www.instagram.com/troisiricerche/" target="_blank" rel="noopener">Seguici su Instagram →</a><br><a href="<?php echo esc_url( idt_link( 'iscriviti' ) ); ?>">Iscriviti via email →</a></p>
			</div>
			<div>
				<h3>Il sito</h3>
				<ul>
					<li><a href="<?php echo esc_url( idt_link( 'archivio' ) ); ?>">Archivio degli articoli</a></li>
					<li><a href="<?php echo esc_url( idt_link( 'numeri' ) ); ?>">Tutti i numeri</a></li>
					<li><a href="<?php echo esc_url( idt_link( 'la-storia' ) ); ?>">La storia</a></li>
					<li><a href="<?php echo esc_url( idt_link( 'podcast' ) ); ?>">Podcast</a></li>
					<li><a href="<?php echo esc_url( IDT_WHATSAPP ); ?>" target="_blank" rel="noopener">Canale WhatsApp</a></li>
					<li><a href="https://www.instagram.com/troisiricerche/" target="_blank" rel="noopener">Instagram @troisiricerche</a></li>
					<li><a href="<?php echo esc_url( get_feed_link() ); ?>">Feed RSS</a></li>
					<li><a href="<?php echo esc_url( idt_link( 'privacy-newsletter' ) ); ?>">Informativa privacy</a></li>
				</ul>
			</div>
			<div>
				<h3>Troisi Ricerche</h3>
				<ul>
					<li><a href="https://www.troisiricerche.net/">troisiricerche.net</a></li>
					<li><a href="https://www.troisiricerche.net/giochi-statistica/">Gioca con la statistica</a></li>
					<li><a href="https://www.troisiinsight.it/">TroisiInsight</a></li>
					<li><a href="https://www.voiceinhub.it/">VoiceInHub</a></li>
					<li><a href="https://calendly.com/andreatroisi/30min">Fissiamo 30 minuti</a></li>
				</ul>
			</div>
		</div>
		<div class="legal">
			«Il dato è tratto»: marchio di Andrea Troisi, domanda di registrazione UIBM n. 302026000166693. Editore della newsletter: Troisi Ricerche S.r.l. Unipersonale · Bari · Roma · Milano · Sede legale: Via De Rossi 57, Bari · P.IVA 07216100722.
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
