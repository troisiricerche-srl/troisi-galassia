<?php
/**
 * Il dato è tratto — funzioni del tema.
 *
 * 1. Impostazioni del tema
 * 2. Installazione automatica (pagine, categoria, primo numero, permalink)
 * 3. Iscritti: archivio privato con prova del consenso
 * 4. Iscrizione con doppia conferma, conferma, cancellazione
 * 5. Esportazione CSV (per Brevo o altro servizio di invio)
 * 6. SEO: descrizioni, Open Graph, dati strutturati, robots
 * 7. Pannello di controllo del sito (checker)
 * 8. Funzioni di supporto per i modelli
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IDT_VERSION', '1.4.3' );
define( 'IDT_CONSENSO_V', '2026-09-29' ); // versione del testo del consenso e dell'informativa
define( 'IDT_REPLY_TO', 'troisi@troisiricerche.it' );

require_once __DIR__ . '/inc/archivio.php';
require_once __DIR__ . '/inc/dato.php';

function idt_consenso_testo() {
	return 'Voglio ricevere «Il dato è tratto», la newsletter di Troisi Ricerche S.r.l. (ogni due settimane), e dichiaro di aver letto l\'informativa sul trattamento dei dati personali.';
}

function idt_mittente() {
	$host = preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	$def  = 'newsletter@' . ( $host ? $host : 'ildatoetratto.it' );
	$m    = get_option( 'idt_mittente', $def );
	return is_email( $m ) ? $m : $def;
}

/* ==================================================================
 * 1. Impostazioni del tema
 * ================================================================== */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'idt-style', get_stylesheet_uri(), array(), IDT_VERSION );
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );
}, 20 );

// Niente script delle emoji: pagine più leggere, nessuna chiamata esterna.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
add_filter( 'emoji_svg_url', '__return_false' );

add_filter( 'document_title_separator', function () {
	return '·';
} );

add_action( 'wp_head', function () {
	$u = get_template_directory_uri() . '/assets/';
	echo '<link rel="icon" type="image/png" href="' . esc_url( $u . 'favicon.png' ) . '">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
	echo '<meta name="theme-color" content="#003366">' . "\n";
}, 2 );

/* ==================================================================
 * 2. Installazione automatica
 * ================================================================== */
function idt_pagine() {
	return array(
		'iscriviti'          => array( 'Iscriviti', 'Un\'email ogni due settimane con i numeri che contano sull\'Italia. Gratis, senza pubblicità, ci si cancella con un clic.' ),
		'archivio'           => array( 'Archivio degli articoli', 'Tutti gli articoli degli osservatori di Troisi Ricerche in un unico archivio, divisi per tema e con la ricerca per parola.' ),
		'numeri'             => array( 'Tutti i numeri', 'L\'archivio di «Il dato è tratto»: ogni numero, con il dato del mese, le analisi e i grafici.' ),
		'la-storia'          => array( 'La storia', 'Dalla rubrica su Controradio Bari del 2016 alla newsletter di Troisi Ricerche: da dove viene «Il dato è tratto».' ),
		'podcast'            => array( 'Podcast', '«Il dato è tratto» tornerà anche in voce: il podcast è in preparazione.' ),
		'privacy-newsletter' => array( 'Informativa privacy', 'Come trattiamo i dati di chi si iscrive a «Il dato è tratto».' ),
	);
}

function idt_installa() {
	// Nome e motto del sito.
	if ( in_array( get_option( 'blogname' ), array( '', 'Il mio sito', 'My WordPress Blog', 'WordPress' ), true ) || false !== stripos( (string) get_option( 'blogname' ), 'ildatoetratto' ) ) {
		update_option( 'blogname', 'Il dato è tratto' );
	}
	update_option( 'blogdescription', 'La newsletter di Troisi Ricerche, ogni due settimane: i numeri che contano sull\'Italia' );
	if ( ! get_option( 'timezone_string' ) ) {
		update_option( 'timezone_string', 'Europe/Rome' );
	}
	update_option( 'date_format', 'j F Y' );

	// Indirizzi leggibili (servono anche a robots.txt, sitemap e llms.txt).
	if ( '' === (string) get_option( 'permalink_structure' ) ) {
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( '/%postname%/' );
	}

	// Pagine.
	foreach ( idt_pagine() as $slug => $p ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array(
				'post_title'   => $p[0],
				'post_name'    => $slug,
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_excerpt' => $p[1],
				'post_content' => '',
			) );
		}
	}
	$priv = get_page_by_path( 'privacy-newsletter' );
	if ( $priv ) {
		update_option( 'wp_page_for_privacy_policy', $priv->ID );
	}

	// Categoria dei numeri.
	$cat = get_term_by( 'slug', 'numeri-newsletter', 'category' );
	if ( ! $cat ) {
		$r      = wp_insert_term( 'Numeri', 'category', array( 'slug' => 'numeri-newsletter', 'description' => 'I numeri della newsletter «Il dato è tratto».' ) );
		$cat_id = is_wp_error( $r ) ? 0 : (int) $r['term_id'];
	} else {
		$cat_id = (int) $cat->term_id;
	}

	// Primo numero.
	$n1 = include get_template_directory() . '/inc/numero-01.php';
	if ( is_array( $n1 ) && ! get_page_by_path( $n1['slug'], OBJECT, 'post' ) ) {
		$id = wp_insert_post( array(
			'post_title'    => $n1['title'],
			'post_name'     => $n1['slug'],
			'post_status'   => 'publish',
			'post_type'     => 'post',
			'post_date'     => ( strtotime( $n1['date'] ) < current_time( 'timestamp' ) ) ? $n1['date'] : current_time( 'mysql' ),
			'post_excerpt'  => $n1['excerpt'],
			'post_content'  => "<!-- wp:html -->\n" . $n1['content'] . "\n<!-- /wp:html -->",
			'post_category' => $cat_id ? array( $cat_id ) : array(),
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			$m = $n1['meta'];
			update_post_meta( $id, '_idt_numero', (int) $m['numero'] );
			update_post_meta( $id, '_idt_mese', $m['mese'] );
			update_post_meta( $id, '_idt_dato_num', $m['dato_num'] );
			update_post_meta( $id, '_idt_dato_testo', $m['dato_testo'] );
			update_post_meta( $id, '_idt_tre', wp_slash( wp_json_encode( $m['tre'], JSON_UNESCAPED_UNICODE ) ) );
			update_post_meta( $id, '_idt_img', $m['img'] );
		}
	}

	// Contenuti di prova di WordPress: nel cestino (recuperabili), solo se mai modificati.
	$hello = get_page_by_path( 'ciao-mondo', OBJECT, 'post' );
	if ( ! $hello ) {
		$hello = get_page_by_path( 'hello-world', OBJECT, 'post' );
	}
	if ( $hello && $hello->post_date === $hello->post_modified ) {
		wp_trash_post( $hello->ID );
	}
	$ex = get_page_by_path( 'pagina-di-esempio' );
	if ( ! $ex ) {
		$ex = get_page_by_path( 'sample-page' );
	}
	if ( $ex && $ex->post_date === $ex->post_modified ) {
		wp_trash_post( $ex->ID );
	}

	// Commenti chiusi di default (è una newsletter, non un blog).
	update_option( 'default_comment_status', 'closed' );
	update_option( 'default_ping_status', 'closed' );

	// 1.4.0: si ricarica l'archivio per avere l'id di ogni articolo (pagine /dato/).
	wp_schedule_single_event( time() + 5, 'idt_archivio_cron' );
	flush_rewrite_rules();
	update_option( 'idt_installato', IDT_VERSION );
}
add_action( 'after_switch_theme', 'idt_installa' );
add_action( 'init', function () {
	if ( get_option( 'idt_installato' ) !== IDT_VERSION && is_admin() && current_user_can( 'manage_options' ) ) {
		idt_installa();
	}
}, 20 );

/* ==================================================================
 * 3. Iscritti: archivio privato
 * ================================================================== */
add_action( 'init', function () {
	$solo_admin = array(
		'edit_post'          => 'manage_options',
		'read_post'          => 'manage_options',
		'delete_post'        => 'manage_options',
		'edit_posts'         => 'manage_options',
		'edit_others_posts'  => 'manage_options',
		'delete_posts'       => 'manage_options',
		'publish_posts'      => 'manage_options',
		'read_private_posts' => 'manage_options',
		'create_posts'       => 'do_not_allow',
	);
	register_post_type( 'idt_iscritto', array(
		'labels'          => array(
			'name'          => 'Iscritti',
			'singular_name' => 'Iscritto',
			'menu_name'     => 'Iscritti',
			'all_items'     => 'Tutti gli iscritti',
			'search_items'  => 'Cerca iscritti',
			'not_found'     => 'Nessun iscritto',
			'edit_item'     => 'Dettaglio iscritto',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-email-alt',
		'menu_position'   => 25,
		'supports'        => array( 'title' ),
		'capabilities'    => $solo_admin,
		'map_meta_cap'    => false,
		'show_in_rest'    => false,
		'rewrite'         => false,
		'query_var'       => false,
	) );
} );

add_filter( 'manage_idt_iscritto_posts_columns', function () {
	return array(
		'cb'       => '<input type="checkbox" />',
		'title'    => 'Email',
		'idt_nome' => 'Nome / ente',
		'idt_st'   => 'Stato',
		'idt_rich' => 'Richiesta',
		'idt_conf' => 'Conferma',
	);
} );
add_action( 'manage_idt_iscritto_posts_custom_column', function ( $col, $id ) {
	$stati = array( 'attesa' => 'In attesa di conferma', 'confermato' => 'Confermato', 'cancellato' => 'Cancellato' );
	switch ( $col ) {
		case 'idt_nome':
			echo esc_html( trim( get_post_meta( $id, '_idt_nome', true ) . ' · ' . get_post_meta( $id, '_idt_ente', true ), ' ·' ) );
			break;
		case 'idt_st':
			$s = get_post_meta( $id, '_idt_stato', true );
			echo esc_html( isset( $stati[ $s ] ) ? $stati[ $s ] : $s );
			break;
		case 'idt_rich':
			echo esc_html( get_post_meta( $id, '_idt_data_richiesta', true ) );
			break;
		case 'idt_conf':
			echo esc_html( get_post_meta( $id, '_idt_data_conferma', true ) );
			break;
	}
}, 10, 2 );

// Scheda dell'iscritto: tutti i dati di prova del consenso, in sola lettura.
add_action( 'add_meta_boxes_idt_iscritto', function () {
	add_meta_box( 'idt_prova', 'Prova del consenso', function ( $post ) {
		$campi = array(
			'_idt_stato'           => 'Stato',
			'_idt_nome'            => 'Nome',
			'_idt_ente'            => 'Ente / organizzazione',
			'_idt_fonte'           => 'Modulo di provenienza',
			'_idt_data_richiesta'  => 'Data e ora della richiesta',
			'_idt_ip_richiesta'    => 'IP della richiesta',
			'_idt_data_conferma'   => 'Data e ora della conferma (doppio opt-in)',
			'_idt_ip_conferma'     => 'IP della conferma',
			'_idt_consenso_testo'  => 'Testo del consenso accettato',
			'_idt_consenso_v'      => 'Versione informativa',
			'_idt_data_revoca'     => 'Data della cancellazione',
		);
		echo '<table class="widefat striped"><tbody>';
		foreach ( $campi as $k => $l ) {
			echo '<tr><th style="width:260px">' . esc_html( $l ) . '</th><td>' . esc_html( (string) get_post_meta( $post->ID, $k, true ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
		$ev = get_post_meta( $post->ID, '_idt_evento' );
		if ( $ev ) {
			echo '<h4>Storico</h4><ol>';
			foreach ( $ev as $e ) {
				echo '<li>' . esc_html( $e ) . '</li>';
			}
			echo '</ol>';
		}
	}, 'idt_iscritto', 'normal', 'high' );
} );

function idt_trova_iscritto( $email ) {
	$q = get_posts( array(
		'post_type'      => 'idt_iscritto',
		'post_status'    => 'any',
		'posts_per_page' => 1,
		'meta_key'       => '_idt_email',
		'meta_value'     => strtolower( $email ),
		'fields'         => 'ids',
	) );
	return $q ? (int) $q[0] : 0;
}

function idt_trova_token( $meta, $token ) {
	if ( ! is_string( $token ) || ! preg_match( '/^[a-f0-9]{40}$/', $token ) ) {
		return 0;
	}
	$q = get_posts( array(
		'post_type'      => 'idt_iscritto',
		'post_status'    => 'any',
		'posts_per_page' => 1,
		'meta_key'       => $meta,
		'meta_value'     => $token,
		'fields'         => 'ids',
	) );
	return $q ? (int) $q[0] : 0;
}

function idt_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
}

function idt_ora() {
	return wp_date( 'Y-m-d H:i:s' );
}

function idt_evento( $id, $testo ) {
	add_post_meta( $id, '_idt_evento', idt_ora() . ' · ' . $testo . ' · IP ' . idt_ip() );
}

function idt_token() {
	return bin2hex( random_bytes( 20 ) );
}

/* ==================================================================
 * 4. Iscrizione, conferma, cancellazione
 * ================================================================== */
function idt_url_esito( $esito ) {
	$p = get_page_by_path( 'iscriviti' );
	$u = $p ? get_permalink( $p ) : home_url( '/' );
	return add_query_arg( 'esito', $esito, $u ) . '#modulo';
}

function idt_firma_tempo( $t ) {
	return hash_hmac( 'sha256', (string) $t, wp_salt( 'nonce' ) );
}

add_action( 'admin_post_nopriv_idt_iscrizione', 'idt_gestisci_iscrizione' );
add_action( 'admin_post_idt_iscrizione', 'idt_gestisci_iscrizione' );
function idt_gestisci_iscrizione() {
	// Trappola per i robot: campo nascosto che una persona non compila.
	if ( ! empty( $_POST['sito_web'] ) ) {
		wp_safe_redirect( idt_url_esito( 'inviata' ) );
		exit;
	}
	// Modulo inviato troppo in fretta (meno di 3 secondi) o manomesso.
	$t = isset( $_POST['t'] ) ? (int) $_POST['t'] : 0;
	$f = isset( $_POST['f'] ) ? sanitize_text_field( wp_unslash( $_POST['f'] ) ) : '';
	if ( ! $t || ! hash_equals( idt_firma_tempo( $t ), $f ) || ( time() - $t ) < 3 || ( time() - $t ) > DAY_IN_SECONDS ) {
		wp_safe_redirect( idt_url_esito( 'errore' ) );
		exit;
	}
	// Massimo 5 richieste all'ora dallo stesso indirizzo.
	$ip  = idt_ip();
	$key = 'idt_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		wp_safe_redirect( idt_url_esito( 'troppe' ) );
		exit;
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );

	$email = isset( $_POST['email'] ) ? strtolower( trim( sanitize_email( wp_unslash( $_POST['email'] ) ) ) ) : '';
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( idt_url_esito( 'email' ) );
		exit;
	}
	if ( empty( $_POST['consenso'] ) ) {
		wp_safe_redirect( idt_url_esito( 'consenso' ) );
		exit;
	}
	$nome  = isset( $_POST['nome'] ) ? sanitize_text_field( wp_unslash( $_POST['nome'] ) ) : '';
	$ente  = isset( $_POST['ente'] ) ? sanitize_text_field( wp_unslash( $_POST['ente'] ) ) : '';
	$fonte = isset( $_POST['fonte'] ) ? sanitize_key( wp_unslash( $_POST['fonte'] ) ) : 'sito';

	$id = idt_trova_iscritto( $email );
	if ( $id && 'confermato' === get_post_meta( $id, '_idt_stato', true ) ) {
		wp_safe_redirect( idt_url_esito( 'gia' ) );
		exit;
	}
	if ( ! $id ) {
		$id = wp_insert_post( array(
			'post_type'   => 'idt_iscritto',
			'post_status' => 'private',
			'post_title'  => $email,
		) );
		if ( ! $id || is_wp_error( $id ) ) {
			wp_safe_redirect( idt_url_esito( 'errore' ) );
			exit;
		}
		update_post_meta( $id, '_idt_email', $email );
		update_post_meta( $id, '_idt_token_cancella', idt_token() );
	}
	// Se l'indirizzo è già in attesa, riusa lo stesso link: così funziona qualunque email di conferma si apra.
	$tok = ( 'attesa' === get_post_meta( $id, '_idt_stato', true ) ) ? (string) get_post_meta( $id, '_idt_token_conferma', true ) : '';
	if ( ! preg_match( '/^[a-f0-9]{40}$/', $tok ) ) {
		$tok = idt_token();
	}
	update_post_meta( $id, '_idt_stato', 'attesa' );
	update_post_meta( $id, '_idt_token_conferma', $tok );
	if ( '' !== $nome ) {
		update_post_meta( $id, '_idt_nome', $nome );
	}
	if ( '' !== $ente ) {
		update_post_meta( $id, '_idt_ente', $ente );
	}
	update_post_meta( $id, '_idt_fonte', $fonte );
	update_post_meta( $id, '_idt_data_richiesta', idt_ora() );
	update_post_meta( $id, '_idt_ip_richiesta', $ip );
	update_post_meta( $id, '_idt_consenso_testo', idt_consenso_testo() );
	update_post_meta( $id, '_idt_consenso_v', IDT_CONSENSO_V );
	delete_post_meta( $id, '_idt_data_revoca' );
	delete_post_meta( $id, '_idt_data_conferma' );
	delete_post_meta( $id, '_idt_ip_conferma' );
	idt_evento( $id, 'richiesta di iscrizione (modulo: ' . $fonte . ', informativa ' . IDT_CONSENSO_V . ')' );

	$link = add_query_arg( 'conferma', $tok, home_url( '/' ) );
	$ok   = idt_mail(
		$email,
		'Conferma l\'iscrizione a «Il dato è tratto»',
		'Un ultimo passo',
		'<p>Abbiamo ricevuto la richiesta di iscrivere questo indirizzo a <strong>«Il dato è tratto»</strong>, la newsletter di Troisi Ricerche, ogni due settimane.</p><p>Per completare l\'iscrizione basta un clic:</p>',
		'Confermo l\'iscrizione',
		$link,
		'<p style="font-size:13px;color:#6B7280">Se non ha chiesto lei l\'iscrizione, ignori questa email: senza conferma non riceverà nulla e i dati verranno cancellati.</p>'
	);
	wp_safe_redirect( idt_url_esito( $ok ? 'inviata' : 'mail' ) );
	exit;
}

// Conferma e cancellazione arrivano dai link nelle email.
add_action( 'template_redirect', function () {
	if ( isset( $_GET['conferma'] ) ) {
		$id = idt_trova_token( '_idt_token_conferma', sanitize_text_field( wp_unslash( $_GET['conferma'] ) ) );
		if ( ! $id ) {
			wp_safe_redirect( idt_url_esito( 'link' ) );
			exit;
		}
		if ( 'confermato' !== get_post_meta( $id, '_idt_stato', true ) ) {
			update_post_meta( $id, '_idt_stato', 'confermato' );
			update_post_meta( $id, '_idt_data_conferma', idt_ora() );
			update_post_meta( $id, '_idt_ip_conferma', idt_ip() );
			idt_evento( $id, 'conferma dal link nell\'email (doppio opt-in)' );
			$email  = get_post_meta( $id, '_idt_email', true );
			$ultimo = idt_ultimo_numero();
			$canc   = add_query_arg( 'cancella', get_post_meta( $id, '_idt_token_cancella', true ), home_url( '/' ) );
			idt_mail(
				$email,
				'Benvenuto in «Il dato è tratto»',
				'Iscrizione completata',
				'<p>Grazie: da ora riceverà <strong>«Il dato è tratto»</strong> ogni due settimane. Dati ufficiali, grafici originali, fonti sempre citate.</p>' . ( $ultimo ? '<p>Nel frattempo può leggere l\'ultimo numero:</p>' : '' ),
				$ultimo ? 'Leggi l\'ultimo numero' : 'Vai al sito',
				$ultimo ? get_permalink( $ultimo ) : home_url( '/' ),
				'<p style="font-size:13px;color:#6B7280">Può cancellarsi quando vuole da <a href="' . esc_url( $canc ) . '" style="color:#6B7280">questo link</a>. Per domande o suggerimenti risponda pure a questa email.</p>'
			);
			delete_post_meta( $id, '_idt_token_conferma' );
		}
		wp_safe_redirect( idt_url_esito( 'confermata' ) );
		exit;
	}
	if ( isset( $_GET['cancella'] ) && ! is_page( 'iscriviti' ) ) {
		$p = get_page_by_path( 'iscriviti' );
		if ( $p ) {
			wp_safe_redirect( add_query_arg( 'cancella', sanitize_text_field( wp_unslash( $_GET['cancella'] ) ), get_permalink( $p ) ) . '#modulo' );
			exit;
		}
	}
} );

// La cancellazione si completa con un pulsante (i filtri antispam delle email aprono i link da soli).
add_action( 'admin_post_nopriv_idt_cancella', 'idt_gestisci_cancella' );
add_action( 'admin_post_idt_cancella', 'idt_gestisci_cancella' );
function idt_gestisci_cancella() {
	$tok = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
	$id  = idt_trova_token( '_idt_token_cancella', $tok );
	if ( ! $id ) {
		wp_safe_redirect( idt_url_esito( 'link' ) );
		exit;
	}
	update_post_meta( $id, '_idt_stato', 'cancellato' );
	update_post_meta( $id, '_idt_data_revoca', idt_ora() );
	idt_evento( $id, 'cancellazione' );
	delete_post_meta( $id, '_idt_token_conferma' );
	wp_safe_redirect( idt_url_esito( 'cancellata' ) );
	exit;
}

// Iscrizioni mai confermate: cancellate dopo 30 giorni.
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'idt_pulizia' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'idt_pulizia' );
	}
} );
add_action( 'idt_pulizia', function () {
	$vecchi = get_posts( array(
		'post_type'      => 'idt_iscritto',
		'post_status'    => 'any',
		'posts_per_page' => 200,
		'fields'         => 'ids',
		'meta_query'     => array(
			array( 'key' => '_idt_stato', 'value' => 'attesa' ),
			array( 'key' => '_idt_data_richiesta', 'value' => wp_date( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ), 'compare' => '<', 'type' => 'DATETIME' ),
		),
	) );
	foreach ( $vecchi as $id ) {
		wp_delete_post( $id, true );
	}
} );

// Email di servizio in HTML, con i colori del sito.
function idt_mail( $to, $oggetto, $titolo, $corpo, $bottone, $link, $nota ) {
	$html  = '<!doctype html><html lang="it"><body style="margin:0;background:#F3F4F6;font-family:Arial,Helvetica,sans-serif;">';
	$html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F3F4F6"><tr><td align="center" style="padding:24px 10px">';
	$html .= '<table role="presentation" width="560" cellpadding="0" cellspacing="0" style="width:100%;max-width:560px;background:#fff">';
	$html .= '<tr><td style="background:#003366;padding:22px 28px;color:#fff;font-size:24px;font-weight:bold;font-family:Georgia,serif">Il dato è tratto</td></tr>';
	$html .= '<tr><td style="height:5px;background:#F5A623;font-size:0;line-height:0">&nbsp;</td></tr>';
	$html .= '<tr><td style="padding:26px 28px;font-size:16px;line-height:1.6;color:#1F2937"><h1 style="font-family:Georgia,serif;color:#003366;font-size:22px;margin:0 0 12px">' . esc_html( $titolo ) . '</h1>' . $corpo;
	$html .= '<p style="margin:22px 0"><a href="' . esc_url( $link ) . '" style="display:inline-block;background:#F5A623;color:#003366;font-weight:bold;text-decoration:none;padding:13px 22px;border-radius:6px">' . esc_html( $bottone ) . '</a></p>';
	$html .= '<p style="font-size:13px;color:#6B7280;word-break:break-all">Se il pulsante non funziona, copi questo indirizzo nel browser:<br>' . esc_html( $link ) . '</p>' . $nota . '</td></tr>';
	$html .= '<tr><td style="padding:18px 28px;border-top:1px solid #E5E7EB;font-size:11px;color:#6B7280;line-height:1.6">Troisi Ricerche S.r.l. Unipersonale · Via De Rossi 57, Bari · P.IVA 07216100722<br><a href="' . esc_url( home_url( '/privacy-newsletter/' ) ) . '" style="color:#6B7280">Informativa privacy</a></td></tr>';
	$html .= '</table></td></tr></table></body></html>';
	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		'From: Il dato è tratto <' . idt_mittente() . '>',
		'Reply-To: Andrea Troisi <' . IDT_REPLY_TO . '>',
	);
	return wp_mail( $to, $oggetto, $html, $headers );
}

// Invio autenticato (SMTP) dalla casella del dominio, mittente di busta allineato, versione solo testo.
add_action( 'phpmailer_init', function ( $pm ) {
	$from = idt_mittente();
	$pass = (string) get_option( 'idt_smtp_pass', '' );
	if ( '' !== $pass ) {
		$port = (int) get_option( 'idt_smtp_port', 465 );
		$pm->isSMTP();
		$pm->Host       = (string) get_option( 'idt_smtp_host', 'smtps.aruba.it' );
		$pm->Port       = $port ? $port : 465;
		$pm->SMTPAuth   = true;
		$pm->Username   = $from;
		$pm->Password   = $pass;
		$pm->SMTPSecure = ( 587 === $pm->Port ) ? 'tls' : 'ssl';
		$pm->Timeout    = 20;
	}
	if ( 0 === strcasecmp( (string) $pm->From, $from ) ) {
		$pm->Sender = $from;
	}
	if ( 'text/html' === $pm->ContentType && '' === (string) $pm->AltBody ) {
		$txt         = preg_replace( '/<a [^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/i', '$2 ($1)', $pm->Body );
		$pm->AltBody = trim( html_entity_decode( wp_strip_all_tags( str_replace( array( '</p>', '<br>', '</h1>', '</tr>' ), "\n\n", $txt ) ), ENT_QUOTES, 'UTF-8' ) );
	}
} );

add_action( 'wp_mail_failed', function ( $err ) {
	set_transient( 'idt_ultimo_errore_mail', is_wp_error( $err ) ? $err->get_error_message() : '', HOUR_IN_SECONDS );
} );

/* ==================================================================
 * 5. Esportazione CSV degli iscritti confermati
 * ================================================================== */
add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=idt_iscritto', 'Esporta iscritti', 'Esporta CSV', 'manage_options', 'idt-esporta', function () {
		$conta = array();
		foreach ( array( 'attesa', 'confermato', 'cancellato' ) as $s ) {
			$conta[ $s ] = count( get_posts( array( 'post_type' => 'idt_iscritto', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_idt_stato', 'meta_value' => $s ) ) );
		}
		echo '<div class="wrap"><h1>Esporta iscritti</h1>';
		echo '<p>Confermati: <strong>' . (int) $conta['confermato'] . '</strong> · In attesa di conferma: ' . (int) $conta['attesa'] . ' · Cancellati: ' . (int) $conta['cancellato'] . '</p>';
		echo '<p>Il file contiene solo gli iscritti <strong>confermati</strong>, con data, IP e testo del consenso: è la prova da conservare e il file da importare nel servizio di invio (Brevo o altro).</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="idt_esporta">';
		wp_nonce_field( 'idt_esporta' );
		submit_button( 'Scarica il CSV degli iscritti confermati' );
		echo '</form>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="idt_esporta"><input type="hidden" name="cancellati" value="1">';
		wp_nonce_field( 'idt_esporta' );
		submit_button( 'Scarica l\'elenco dei cancellati (da escludere dagli invii)', 'secondary' );
		echo '</form></div>';
	} );
} );

add_action( 'admin_post_idt_esporta', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'idt_esporta' ) ) {
		wp_die( 'Non autorizzato' );
	}
	$stato = empty( $_POST['cancellati'] ) ? 'confermato' : 'cancellato';
	$ids   = get_posts( array( 'post_type' => 'idt_iscritto', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_idt_stato', 'meta_value' => $stato, 'orderby' => 'date', 'order' => 'ASC' ) );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=UTF-8' );
	header( 'Content-Disposition: attachment; filename=il-dato-e-tratto-' . $stato . '-' . wp_date( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array( 'EMAIL', 'NOME', 'ENTE', 'DATA_RICHIESTA', 'IP_RICHIESTA', 'DATA_CONFERMA', 'IP_CONFERMA', 'CONSENSO', 'VERSIONE_INFORMATIVA', 'FONTE', 'DATA_CANCELLAZIONE' ), ';' );
	foreach ( $ids as $id ) {
		$g = function ( $k ) use ( $id ) {
			return (string) get_post_meta( $id, $k, true );
		};
		fputcsv( $out, array( $g( '_idt_email' ), $g( '_idt_nome' ), $g( '_idt_ente' ), $g( '_idt_data_richiesta' ), $g( '_idt_ip_richiesta' ), $g( '_idt_data_conferma' ), $g( '_idt_ip_conferma' ), $g( '_idt_consenso_testo' ), $g( '_idt_consenso_v' ), $g( '_idt_fonte' ), $g( '_idt_data_revoca' ) ), ';' );
	}
	fclose( $out );
	exit;
} );

/* ==================================================================
 * 6. SEO
 * ================================================================== */
function idt_descrizione() {
	if ( is_front_page() ) {
		return 'Il dato è tratto è la newsletter gratuita di Troisi Ricerche, ogni due settimane: il dato in evidenza, le analisi con i grafici e le fonti ufficiali (Eurostat, ISTAT) su economia, PA, lavoro, giovani e territori italiani.';
	}
	if ( is_singular() ) {
		$p = get_queried_object();
		if ( $p && has_excerpt( $p ) ) {
			return wp_strip_all_tags( get_the_excerpt( $p ) );
		}
		$pg = idt_pagine();
		if ( $p && isset( $pg[ $p->post_name ] ) ) {
			return $pg[ $p->post_name ][1];
		}
	}
	if ( is_category() || is_archive() ) {
		return 'Tutti i numeri della newsletter «Il dato è tratto» di Troisi Ricerche.';
	}
	return get_bloginfo( 'description' );
}

add_action( 'wp_head', function () {
	$desc  = idt_descrizione();
	$url   = is_singular() ? get_permalink() : ( is_front_page() ? home_url( '/' ) : '' );
	if ( get_query_var( 'idt_host' ) ) {
		$url = home_url( '/dato/' . get_query_var( 'idt_host' ) . '/' . (int) get_query_var( 'idt_pid' ) . '/' );
	}
	$title = wp_get_document_title();
	$img   = get_template_directory_uri() . '/assets/og-image.png';
	if ( ! get_query_var( 'idt_host' ) ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta property="og:locale" content="it_IT">' . "\n";
	echo '<meta property="og:site_name" content="Il dato è tratto">' . "\n";
	echo '<meta property="og:type" content="' . ( is_single() ? 'article' : 'website' ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	if ( $url ) {
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	}
	echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	echo '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	if ( is_front_page() && ! get_query_var( 'idt_host' ) ) {
		echo '<link rel="canonical" href="' . esc_url( home_url( '/' ) ) . '">' . "\n";
	}

	// Dati strutturati: la testata (Periodical) e, nei numeri, il singolo fascicolo.
	$org     = array( '@id' => 'https://troisiricerche.net/#organization' );
	$person  = array( '@id' => 'https://andreatroisi.it/#person' );
	$period  = array(
		'@type'       => 'Periodical',
		'@id'         => home_url( '/#periodical' ),
		'name'        => 'Il dato è tratto',
		'url'         => home_url( '/' ),
		'description' => 'Newsletter di Troisi Ricerche, ogni due settimane, con il dato in evidenza, analisi e grafici su dati ufficiali.',
		'inLanguage'  => 'it-IT',
		'publisher'   => $org,
		'creator'     => $person,
		'editor'      => $person,
		'isAccessibleForFree' => true,
		'image'       => $img,
	);
	$graph = array( $period );
	if ( is_single() ) {
		$id    = get_queried_object_id();
		$num   = (int) get_post_meta( $id, '_idt_numero', true );
		$issue = array(
			'@type'         => array( 'PublicationIssue', 'Article' ),
			'@id'           => get_permalink( $id ) . '#issue',
			'headline'      => get_the_title( $id ),
			'name'          => get_the_title( $id ),
			'url'           => get_permalink( $id ),
			'datePublished' => get_the_date( 'c', $id ),
			'dateModified'  => get_the_modified_date( 'c', $id ),
			'isPartOf'      => array( '@id' => home_url( '/#periodical' ) ),
			'author'        => $person,
			'publisher'     => $org,
			'inLanguage'    => 'it-IT',
			'description'   => $desc,
			'image'         => get_post_meta( $id, '_idt_img', true ) ? get_post_meta( $id, '_idt_img', true ) : $img,
		);
		if ( $num ) {
			$issue['issueNumber'] = (string) $num;
		}
		$graph[] = $issue;
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}, 3 );

// Le pagine di esito (conferma, cancellazione) non vanno indicizzate.
add_filter( 'wp_robots', function ( $r ) {
	if ( isset( $_GET['esito'] ) || isset( $_GET['cancella'] ) || isset( $_GET['conferma'] ) ) {
		$r['noindex'] = true;
		$r['follow']  = true;
	}
	return $r;
} );

// Il feed RSS porta con sé il riassunto e il link per iscriversi.
add_filter( 'the_excerpt_rss', function ( $e ) {
	return $e . ' — Iscriviti gratis a «Il dato è tratto»: ' . home_url( '/iscriviti/' );
} );

/* ==================================================================
 * 7. Pannello di controllo del sito
 * ================================================================== */
add_action( 'admin_menu', function () {
	add_management_page( 'Il dato è tratto: stato del sito', 'Stato del sito', 'manage_options', 'idt-stato', 'idt_pagina_stato' );
} );

function idt_pagina_stato() {
	$righe = array();
	foreach ( idt_pagine() as $slug => $p ) {
		$righe[] = array( 'Pagina «' . $p[0] . '» (/' . $slug . '/)', (bool) get_page_by_path( $slug ) );
	}
	$righe[] = array( 'Primo numero pubblicato', (bool) get_page_by_path( 'numero-1-ottobre-2026', OBJECT, 'post' ) );
	$ps      = (string) get_option( 'permalink_structure' );
	$righe[] = array( 'Indirizzi leggibili (Permalink: ' . ( $ps ? $ps : 'semplici' ) . ')', '' !== $ps && 0 !== strpos( $ps, '/index.php' ) );
	$righe[] = array( 'Sito visibile ai motori di ricerca', (bool) get_option( 'blog_public' ) );
	$righe[] = array( 'Sito in https', 0 === strpos( home_url(), 'https://' ) );
	$tg      = defined( 'TG_VERSION' ) ? TG_VERSION : '';
	$righe[] = array( 'Plugin Troisi Galassia attivo' . ( $tg ? ' (versione ' . $tg . ')' : '' ), $tg && version_compare( $tg, '1.4.3', '>=' ) );
	$righe[] = array( 'Mittente delle email: ' . idt_mittente() . ' (la casella va creata nel pannello Aruba)', is_email( idt_mittente() ) );
	$righe[] = array( 'Invio autenticato dalla casella ' . idt_mittente() . ' (SMTP ' . get_option( 'idt_smtp_host', 'smtps.aruba.it' ) . ')', '' !== (string) get_option( 'idt_smtp_pass', '' ) );
	$righe[] = array( 'Pulizia automatica delle iscrizioni non confermate programmata', (bool) wp_next_scheduled( 'idt_pulizia' ) );

	echo '<div class="wrap"><h1>Il dato è tratto: stato del sito</h1>';
	if ( isset( $_GET['mail'] ) ) {
		echo '<div class="notice ' . ( 'ok' === $_GET['mail'] ? 'notice-success' : 'notice-error' ) . '"><p>' . ( 'ok' === $_GET['mail'] ? 'Email di prova inviata a ' . esc_html( wp_get_current_user()->user_email ) . ': controlla la posta (anche lo spam).' : 'Il server non è riuscito a inviare l\'email di prova. ' . esc_html( (string) get_transient( 'idt_ultimo_errore_mail' ) ) ) . '</p></div>';
	}
	echo '<table class="widefat striped" style="max-width:900px"><tbody>';
	foreach ( $righe as $r ) {
		echo '<tr><td>' . esc_html( $r[0] ) . '</td><td style="width:90px;font-weight:bold;color:' . ( $r[1] ? '#00856A' : '#B42318' ) . '">' . ( $r[1] ? '✔ OK' : '✘ Da fare' ) . '</td></tr>';
	}
	echo '</tbody></table>';
	$agg = get_option( 'idt_archivio_agg', array() );
	echo '<h2 style="margin-top:28px">Archivio degli articoli della galassia</h2>';
	if ( isset( $_GET['archivio'] ) ) {
		echo '<div class="notice notice-success"><p>Archivio aggiornato: ' . (int) $_GET['archivio'] . ' articoli.</p></div>';
	}
	echo '<p>Articoli in archivio: <strong>' . (int) count( (array) get_option( 'idt_archivio', array() ) ) . '</strong>' . ( isset( $agg['quando'] ) ? ' · ultimo aggiornamento: ' . esc_html( $agg['quando'] ) : '' ) . ' · si aggiorna da solo due volte al giorno.</p>';
	if ( ! empty( $agg['esito'] ) ) {
		echo '<ul style="columns:2;max-width:900px">';
		foreach ( $agg['esito'] as $h => $e ) {
			echo '<li>' . esc_html( $h . ': ' . $e ) . '</li>';
		}
		echo '</ul>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="idt_archivio_ora">';
	wp_nonce_field( 'idt_archivio_ora' );
	submit_button( 'Aggiorna l\'archivio adesso', 'secondary', 'submit', false );
	echo '</form>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:16px"><input type="hidden" name="action" value="idt_prova_mail">';
	wp_nonce_field( 'idt_prova_mail' );
	submit_button( 'Invia un\'email di prova a me', 'secondary', 'submit', false );
	echo '</form>';
	$pass_ok = '' !== (string) get_option( 'idt_smtp_pass', '' );
	echo '<h2 style="margin-top:28px">Invio delle email</h2>';
	echo '<p>Le email di conferma partono dalla casella del dominio, con nome utente e password, come da un programma di posta: così i filtri antispam le riconoscono come autentiche.</p>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'idt_opzioni' );
	echo '<table class="form-table" role="presentation"><tbody>';
	echo '<tr><th scope="row"><label for="idt_mittente">Casella mittente</label></th><td><input id="idt_mittente" type="email" name="idt_mittente" value="' . esc_attr( idt_mittente() ) . '" class="regular-text"></td></tr>';
	echo '<tr><th scope="row"><label for="idt_smtp_pass">Password della casella</label></th><td><input id="idt_smtp_pass" type="password" name="idt_smtp_pass" value="" class="regular-text" autocomplete="new-password" placeholder="' . ( $pass_ok ? '•••••••• (salvata: lascia vuoto per non cambiarla)' : 'la password della casella mittente' ) . '"></td></tr>';
	echo '<tr><th scope="row"><label for="idt_smtp_host">Server SMTP</label></th><td><input id="idt_smtp_host" type="text" name="idt_smtp_host" value="' . esc_attr( get_option( 'idt_smtp_host', 'smtps.aruba.it' ) ) . '" class="regular-text"> <label>Porta <input type="number" name="idt_smtp_port" value="' . esc_attr( get_option( 'idt_smtp_port', 465 ) ) . '" style="width:90px"></label><p class="description">Per le caselle Aruba: smtps.aruba.it, porta 465.</p></td></tr>';
	echo '</tbody></table>';
	submit_button( 'Salva le impostazioni di invio' );
	echo '</form></div>';
}

add_action( 'admin_init', function () {
	register_setting( 'idt_opzioni', 'idt_mittente', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_email' ) );
	register_setting( 'idt_opzioni', 'idt_smtp_host', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'idt_opzioni', 'idt_smtp_port', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
	register_setting( 'idt_opzioni', 'idt_smtp_pass', array(
		'type'              => 'string',
		'sanitize_callback' => function ( $v ) {
			$v = is_string( $v ) ? trim( wp_unslash( $v ) ) : '';
			return '' === $v ? (string) get_option( 'idt_smtp_pass', '' ) : $v; // vuoto = non cambiare
		},
	) );
} );

add_action( 'admin_post_idt_prova_mail', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'idt_prova_mail' ) ) {
		wp_die( 'Non autorizzato' );
	}
	$ok = idt_mail( wp_get_current_user()->user_email, 'Prova di invio · Il dato è tratto', 'Email di prova', '<p>Se leggi questa email, il sito riesce a spedire le conferme di iscrizione.</p>', 'Vai al sito', home_url( '/' ), '' );
	wp_safe_redirect( admin_url( 'tools.php?page=idt-stato&mail=' . ( $ok ? 'ok' : 'ko' ) ) );
	exit;
} );

/* ==================================================================
 * 8. Funzioni di supporto per i modelli
 * ================================================================== */
function idt_ultimo_numero() {
	$q = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'category_name' => 'numeri-newsletter', 'fields' => 'ids' ) );
	return $q ? (int) $q[0] : 0;
}

function idt_tre( $id ) {
	$t = json_decode( (string) get_post_meta( $id, '_idt_tre', true ), true );
	return is_array( $t ) ? $t : array();
}

function idt_link( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? get_permalink( $p ) : home_url( '/' . $slug . '/' );
}

function idt_esito_html() {
	$e = isset( $_GET['esito'] ) ? sanitize_key( wp_unslash( $_GET['esito'] ) ) : '';
	$m = array(
		'inviata'    => array( 'ok', '<strong>Quasi fatto.</strong> Le abbiamo scritto: apra l\'email che le abbiamo appena inviato e clicchi su «Confermo l\'iscrizione». Se non la trova, controlli nella cartella spam o promozioni.' ),
		'confermata' => array( 'ok', '<strong>Iscrizione completata.</strong> Grazie: riceverà «Il dato è tratto» ogni due settimane.' ),
		'gia'        => array( 'info', 'Questo indirizzo è già iscritto: riceverà il prossimo numero.' ),
		'cancellata' => array( 'ok', 'Cancellazione completata: non riceverà più «Il dato è tratto». Se cambia idea, può iscriversi di nuovo da qui.' ),
		'email'      => array( 'ko', 'L\'indirizzo email non sembra corretto. Può controllarlo e riprovare?' ),
		'consenso'   => array( 'ko', 'Per iscriversi serve spuntare la casella del consenso.' ),
		'troppe'     => array( 'ko', 'Troppi tentativi in poco tempo. Riprovi fra un\'ora.' ),
		'link'       => array( 'ko', 'Il link non è valido o è già stato usato. Se serve, ripeta l\'iscrizione.' ),
		'mail'       => array( 'ko', 'Non siamo riusciti a spedire l\'email di conferma. Riprovi fra qualche minuto o ci scriva a ' . IDT_REPLY_TO . '.' ),
		'errore'     => array( 'ko', 'Qualcosa non ha funzionato. Ricarichi la pagina e riprovi.' ),
	);
	if ( ! isset( $m[ $e ] ) ) {
		return '';
	}
	return '<div class="avviso ' . esc_attr( $m[ $e ][0] ) . '" role="status">' . wp_kses_post( $m[ $e ][1] ) . '</div>';
}

function idt_modulo( $fonte = 'sito', $titolo = 'Iscriviti gratis', $completo = false ) {
	$t = time();
	ob_start();
	?>
	<div class="iscrizione" id="<?php echo esc_attr( 'home-basso' === $fonte ? 'modulo-2' : 'modulo' ); ?>">
		<?php
		echo idt_esito_html(); // phpcs:ignore
		$esito = isset( $_GET['esito'] ) ? sanitize_key( wp_unslash( $_GET['esito'] ) ) : '';
		if ( in_array( $esito, array( 'inviata', 'confermata', 'gia' ), true ) ) {
			echo '<p style="margin:0"><a href="' . esc_url( idt_link( 'numeri' ) ) . '">Intanto legga l\'ultimo numero →</a></p>';
			echo '<p class="nota"><a href="' . esc_url( remove_query_arg( 'esito' ) ) . '">Iscrivere un altro indirizzo</a></p></div>';
			return ob_get_clean();
		}
		?>
		<h2><?php echo esc_html( $titolo ); ?></h2>
		<p style="margin:0;font-size:.95rem">Un'email ogni due settimane. Gratis, senza pubblicità.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="idt_iscrizione">
			<input type="hidden" name="fonte" value="<?php echo esc_attr( $fonte ); ?>">
			<input type="hidden" name="t" value="<?php echo (int) $t; ?>">
			<input type="hidden" name="f" value="<?php echo esc_attr( idt_firma_tempo( $t ) ); ?>">
			<div class="hp" aria-hidden="true"><label>Sito web <input type="text" name="sito_web" tabindex="-1" autocomplete="off"></label></div>
			<label for="idt-email-<?php echo esc_attr( $fonte ); ?>">Email</label>
			<input id="idt-email-<?php echo esc_attr( $fonte ); ?>" type="email" name="email" required autocomplete="email" placeholder="nome@esempio.it">
			<?php if ( $completo ) : ?>
			<div class="riga2">
				<div><label for="idt-nome">Nome <span style="font-weight:400;color:#6B7280">(facoltativo)</span></label><input id="idt-nome" type="text" name="nome" autocomplete="name"></div>
				<div><label for="idt-ente">Ente o azienda <span style="font-weight:400;color:#6B7280">(facoltativo)</span></label><input id="idt-ente" type="text" name="ente" autocomplete="organization"></div>
			</div>
			<?php endif; ?>
			<label class="consenso"><input type="checkbox" name="consenso" value="1" required> <span><?php echo esc_html( str_replace( 'l\'informativa sul trattamento dei dati personali.', '', idt_consenso_testo() ) ); ?><a href="<?php echo esc_url( idt_link( 'privacy-newsletter' ) ); ?>">l'informativa sul trattamento dei dati personali</a>.</span></label>
			<button type="submit" class="btn">Iscrivimi</button>
		</form>
		<p class="nota">Le invieremo un'email per confermare l'indirizzo. Ci si cancella con un clic, quando si vuole.</p>
	</div>
	<?php
	return ob_get_clean();
}

function idt_osservatori() {
	return array(
		array( 'TroisiInsight', 'troisiinsight.it', 'economia e territori' ),
		array( 'CustomerPA', 'customerpa.it', 'PA e cittadini' ),
		array( 'DigitalizzazionePA', 'digitalizzazionenellapa.it', 'PA digitale' ),
		array( 'Benessere Organizzativo', 'benessereorganizzativo.it', 'organizzazioni e lavoro' ),
		array( 'Benessere Digitale Giovani', 'benesseredigitalegiovani.it', 'giovani e digitale' ),
		array( 'Mappatura delle Competenze', 'mappaturadellecompetenze.it', 'competenze' ),
		array( 'Governance Finanziaria', 'governancefinanziaria.it', 'imprese e finanza' ),
		array( 'Consulenza Internazionalizzazione', 'consulenzainternazionalizzazione.it', 'export' ),
		array( 'Dibattito Pubblico', 'dibattito-pubblico.it', 'partecipazione e territori' ),
	);
}


/* 1.1.1 — correzione storica: la rubrica su Controradio Bari è del 2016 (non 2017).
 * Aggiorna una sola volta il sommario della pagina «La storia» già creata. */
add_action( 'init', function () {
	if ( get_option( 'idt_fix_storia_2016' ) ) { return; }
	$p = get_page_by_path( 'la-storia' );
	if ( $p && false !== strpos( (string) $p->post_excerpt, '2017' ) ) {
		wp_update_post( array( 'ID' => $p->ID, 'post_excerpt' => str_replace( '2017', '2016', $p->post_excerpt ) ) );
	}
	update_option( 'idt_fix_storia_2016', 1, false );
}, 20 );

/* ------------------------------------------------------------------
 * 1.2.0 – Titoli dei numeri già pubblicati: «Il dato è tratto n. 1 ·
 * Ottobre 2026: …» diventa «Il dato è tratto™ 2016–2026: …».
 * Gira una sola volta (opzione idt_titoli_120).
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	if ( get_option( 'idt_titoli_120' ) ) {
		return;
	}
	$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
	foreach ( $ids as $id ) {
		$t = get_post_field( 'post_title', $id );
		$n = preg_replace( '/^Il dato è tratto\s+n\.\s*\d+\s*·\s*[^:]+:/u', 'Il dato è tratto™ 2016–2026:', $t );
		if ( $n && $n !== $t ) {
			wp_update_post( array( 'ID' => $id, 'post_title' => $n ) );
		}
	}
	update_option( 'idt_titoli_120', 1, false );
}, 20 );

/* ------------------------------------------------------------------
 * 1.3.0 – Canale WhatsApp in evidenza, apertura con il dato,
 * archivio della home per schede di tema.
 * ------------------------------------------------------------------ */
if ( ! defined( 'IDT_WHATSAPP' ) ) {
	define( 'IDT_WHATSAPP', 'https://whatsapp.com/channel/0029VbE9Kx9DeONGCBFx5v42' );
}

/** Icona generica di messaggio (non è il logo di WhatsApp). */
function idt_icona_chat() {
	return '<svg class="ico-chat" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2C6.5 2 2 6.1 2 11.2c0 2.6 1.2 5 3.1 6.7L4 22l4.5-2.1c1.1.3 2.3.5 3.5.5 5.5 0 10-4.1 10-9.2S17.5 2 12 2zm-4 10.5a1.3 1.3 0 1 1 0-2.6 1.3 1.3 0 0 1 0 2.6zm4 0a1.3 1.3 0 1 1 0-2.6 1.3 1.3 0 0 1 0 2.6zm4 0a1.3 1.3 0 1 1 0-2.6 1.3 1.3 0 0 1 0 2.6z"/></svg>';
}

/** Schede dei temi per la home: nome, numero di articoli, ultimo titolo. */
function idt_temi_card() {
	$items = get_option( 'idt_archivio', array() );
	if ( ! $items ) {
		return '<p>L\'archivio si sta caricando: torni fra qualche minuto.</p>';
	}
	$fonti = idt_fonti();
	$per   = array();
	foreach ( $items as $it ) {
		$per[ $it['s'] ][] = $it;
	}
	uksort( $per, function ( $a, $b ) use ( $per ) {
		return count( $per[ $b ] ) - count( $per[ $a ] );
	} );
	$arch = idt_link( 'archivio' );
	$out  = '<div class="temi-card">';
	foreach ( $per as $h => $lista ) {
		if ( ! isset( $fonti[ $h ] ) ) {
			continue;
		}
		$u    = $lista[0];
		$out .= '<a class="tema-card" style="--c:' . esc_attr( $fonti[ $h ][2] ) . '" href="' . esc_url( add_query_arg( 'tema', $h, $arch ) ) . '">'
			. '<span class="tema-n">' . (int) count( $lista ) . '</span>'
			. '<span class="tema-nome">' . esc_html( $fonti[ $h ][0] ) . '</span>'
			. '<span class="tema-ultimo">' . esc_html( wp_trim_words( $u['t'], 14, '…' ) ) . '</span>'
			. '<span class="tema-vai">Tutti gli articoli →</span></a>';
	}
	return $out . '</div>';
}

// 1.3.0: il numero in evidenza «conta» fino al valore (solo in home, rispetta la riduzione del movimento).
add_action( 'wp_footer', function () {
	if ( ! is_front_page() ) {
		return;
	}
	?>
	<script>
	(function(){
		var el=document.querySelector('.dato-card-n'); if(!el||window.matchMedia('(prefers-reduced-motion: reduce)').matches){return;}
		var t=el.getAttribute('data-conta')||'', m=t.match(/^([^\d−-]*)([−-]?)(\d+(?:[.,]\d+)?)(.*)$/); if(!m){return;}
		var dec=(m[3].split(/[.,]/)[1]||'').length, sep=m[3].indexOf(',')>-1?',':'.', fine=parseFloat(m[3].replace(',','.')), t0=null, dur=1200;
		function fmt(v){var s=v.toFixed(dec); return m[1]+m[2]+(sep===','?s.replace('.',','):s)+m[4];}
		function passo(ts){if(!t0){t0=ts;} var p=Math.min(1,(ts-t0)/dur), e=1-Math.pow(1-p,3); el.textContent=fmt(fine*e); if(p<1){requestAnimationFrame(passo);} else {el.textContent=t;}}
		el.textContent=fmt(0); requestAnimationFrame(passo);
	})();
	</script>
	<?php
}, 30 );
