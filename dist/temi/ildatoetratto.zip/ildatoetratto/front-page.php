<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$ultimo = idt_ultimo_numero();
$wa     = IDT_WHATSAPP;
?>
<?php $apertura = idt_apertura_dati(); if ( $apertura ) : $p0 = $apertura[0]; ?>
<section class="hero3" style="--tema:<?php echo esc_attr( $p0['c'] ); ?>" data-idt-parole="<?php echo esc_attr( wp_json_encode( $apertura ) ); ?>">
	<div class="wrap hero3-in">
		<div class="hero3-testo">
			<h1>I numeri che contano su <span class="riga-parola"><span class="pillola"><span class="parola"><?php echo esc_html( $p0['p'] ); ?></span></span></span></h1>
			<p class="sub">Ogni settimana i dati ufficiali sull'Italia, letti e spiegati dagli osservatori di Troisi Ricerche. In pochi secondi, con la fonte.</p>
			<div class="cta2">
				<a class="btn-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo idt_icona_chat(); // phpcs:ignore ?> Segui il canale WhatsApp</a>
				<a class="btn-ghost" href="#iscriviti">Ricevila via email</a>
			</div>
		</div>
		<div class="hero3-dato">
			<div class="campo"><canvas aria-hidden="true"></canvas></div>
			<div class="scheda" aria-live="polite">
				<div class="sch-tema"><?php echo esc_html( $p0['t'] ); ?></div>
				<p><b class="sch-n"><?php echo esc_html( $p0['n'] ); ?></b> <span class="sch-testo"><?php echo esc_html( $p0['x'] ); ?></span></p>
				<div class="sch-fonte"><?php echo esc_html( $p0['f'] ); ?></div>
				<a class="sch-link" href="<?php echo esc_url( $p0['u'] ); ?>">Leggi l'analisi →</a>
			</div>
			<div class="punti-nav" role="group" aria-label="Scegli il tema">
				<?php foreach ( $apertura as $j => $x ) : ?>
				<button type="button" style="--c:<?php echo esc_attr( $x['c'] ); ?>" aria-current="<?php echo 0 === $j ? 'true' : 'false'; ?>"><?php echo esc_html( $x['p'] ); ?></button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
<?php else : ?>
<section class="hero2">
	<div class="wrap">
		<div class="hero2-testo">
			<p class="kicker">Troisi Ricerche · dati ufficiali, spiegati</p>
			<h1>Il dato è tratto<sup class="tm">™</sup></h1>
			<p class="sub">I numeri che contano sull'Italia, spiegati in due righe. Dati ufficiali, fonti sempre citate, grafici originali.</p>
			<div class="cta2">
				<a class="btn-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo idt_icona_chat(); // phpcs:ignore ?> Segui il canale WhatsApp</a>
				<a class="btn-ghost" href="#iscriviti">Ricevila via email</a>
			</div>
			<p class="hero2-nota">Gratis · senza pubblicità · ci si cancella con un tocco</p>
		</div>
		<?php if ( $ultimo ) :
			$tre = idt_tre( $ultimo );
			?>
		<a class="dato-card" href="<?php echo esc_url( get_permalink( $ultimo ) ); ?>">
			<span class="dato-card-k">Il dato in evidenza</span>
			<strong class="dato-card-n" data-conta="<?php echo esc_attr( get_post_meta( $ultimo, '_idt_dato_num', true ) ); ?>"><?php echo esc_html( get_post_meta( $ultimo, '_idt_dato_num', true ) ); ?></strong>
			<span class="dato-card-t"><?php echo esc_html( get_post_meta( $ultimo, '_idt_dato_testo', true ) ); ?></span>
			<?php if ( $tre ) : ?>
			<span class="dato-card-tre">
				<?php foreach ( $tre as $n ) : ?>
				<span style="--c:<?php echo esc_attr( $n[2] ); ?>"><b><?php echo esc_html( $n[0] ); ?></b><?php echo esc_html( $n[1] ); ?></span>
				<?php endforeach; ?>
			</span>
			<?php endif; ?>
			<span class="dato-card-l">Leggi il numero completo →</span>
		</a>
		<?php endif; ?>
	</div>
</section>
<?php endif; ?>

<section class="sez due-modi" id="iscriviti">
	<div class="wrap">
		<div class="sez-head">
			<p class="kicker">Due modi per riceverlo</p>
			<h2>Scegli dove leggerci</h2><div class="linea"></div>
		</div>
		<div class="modi">
			<div class="modo-wa">
				<p class="modo-k"><?php echo idt_icona_chat(); // phpcs:ignore ?> Canale WhatsApp</p>
				<h3>Il dato, sul telefono, appena esce</h3>
				<ul class="spunte">
					<li>Un messaggio con il numero della settimana e il link all'analisi.</li>
					<li>È un canale, non un gruppo: nessuno vede il tuo numero di telefono.</li>
					<li>Lo leggi quando vuoi e smetti di seguirlo con un tocco.</li>
				</ul>
				<div class="modo-wa-az">
					<a class="btn-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo idt_icona_chat(); // phpcs:ignore ?> Segui il canale</a>
					<figure class="qr">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/qr-whatsapp.svg' ); ?>" alt="Codice QR del canale WhatsApp «Il dato è tratto»" width="132" height="132">
						<figcaption>Dal computer: inquadralo con il telefono</figcaption>
					</figure>
				</div>
			</div>
			<div class="modo-mail">
				<?php echo idt_modulo( 'home-alto', 'Via email, ogni due settimane' ); // phpcs:ignore ?>
			</div>
		</div>
	</div>
</section>

<?php if ( $ultimo ) : ?>
<section class="sez alt">
	<div class="wrap">
		<div class="sez-head">
			<p class="kicker">L'ultimo numero</p>
			<h2><a href="<?php echo esc_url( get_permalink( $ultimo ) ); ?>" style="text-decoration:none;color:inherit"><?php echo esc_html( get_the_title( $ultimo ) ); ?></a></h2>
			<div class="linea"></div>
		</div>
		<div class="ultimo">
			<div>
				<?php $img = get_post_meta( $ultimo, '_idt_img', true ); if ( $img ) : ?>
				<a href="<?php echo esc_url( get_permalink( $ultimo ) ); ?>" class="ultimo-img"><img src="<?php echo esc_url( $img ); ?>" alt="Il grafico del dato in evidenza" loading="lazy"></a>
				<?php endif; ?>
			</div>
			<div>
				<p class="ultimo-ex"><?php echo esc_html( get_the_excerpt( $ultimo ) ); ?></p>
				<p><a class="btn" href="<?php echo esc_url( get_permalink( $ultimo ) ); ?>">Leggi il numero completo</a> <a class="btn btn-sec" href="<?php echo esc_url( idt_link( 'numeri' ) ); ?>" style="margin-left:6px">Tutti i numeri</a></p>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>

<section class="sez" id="archivio">
	<div class="wrap">
		<div class="sez-head">
			<p class="kicker">L'archivio</p>
			<h2>Esplora per tema</h2><div class="linea"></div>
			<p style="margin-top:14px">Tutte le analisi degli osservatori di Troisi Ricerche, in un unico posto. Ogni titolo porta all'articolo completo sul sito d'origine.</p>
		</div>
		<form class="cerca-home" action="<?php echo esc_url( idt_link( 'archivio' ) ); ?>" method="get" role="search">
			<label for="cerca-home" class="screen-reader-text">Cerca negli articoli</label>
			<input id="cerca-home" type="search" name="cerca" placeholder="Cerca: salari, PNRR, giovani, export, Puglia…">
			<button type="submit" class="btn">Cerca</button>
		</form>
		<?php echo idt_temi_card(); // phpcs:ignore ?>
	</div>
</section>

<section class="sez alt">
	<div class="wrap">
		<div class="sez-head"><h2>Cosa trovi in ogni numero</h2><div class="linea"></div></div>
		<div class="griglia4">
			<div class="voce"><div class="ico">1</div><h3>Il dato in evidenza</h3><p>Un solo numero, scelto perché dice qualcosa di importante sull'Italia, spiegato in due righe e con il suo grafico.</p></div>
			<div class="voce"><div class="ico">%</div><h3>Le analisi</h3><p>Economia, PA, lavoro, giovani, imprese, export, territori: le analisi dei nostri osservatori, ognuna con il link alla versione completa.</p></div>
			<div class="voce"><div class="ico">?</div><h3>Gioca con la statistica</h3><p>Una domanda per mettere alla prova l'intuito sui numeri, con la risposta sul sito di Troisi Ricerche.</p></div>
			<div class="voce"><div class="ico">→</div><h3>In breve</h3><p>Le altre uscite dai siti della rete Troisi Ricerche, in una riga ciascuna.</p></div>
		</div>
	</div>
</section>

<section class="sez scura">
	<div class="wrap storia">
		<div>
			<p class="kicker" style="color:#F5A623">La storia del nome</p>
			<h2>Il dado è tratto. Anzi, il dato.</h2>
			<p>«Il dato è tratto» nasce nel 2016 come rubrica di Andrea Troisi su Controradio Bari: pochi minuti per raccontare un numero e quello che c'è dietro. Oggi torna come newsletter e canale WhatsApp di Troisi Ricerche, e presto anche come podcast.</p>
			<p><a href="<?php echo esc_url( idt_link( 'la-storia' ) ); ?>">Leggi la storia →</a></p>
		</div>
		<ul class="tappe">
			<li><b>2006</b>Nasce Troisi Ricerche, istituto di ricerca statistica applicata.</li>
			<li><b>2016</b>La rubrica «Il dato è tratto» su Controradio Bari, ogni lunedì.</li>
			<li><b>2026</b>«Il dato è tratto» diventa newsletter e canale WhatsApp.</li>
			<li><b>Presto</b>Il podcast.</li>
		</ul>
	</div>
</section>

<section class="sez fonti-sez">
	<div class="wrap">
		<div class="sez-head">
			<h2>Da dove vengono i numeri</h2><div class="linea"></div>
			<p style="margin-top:14px">Ogni dato viene da una fonte ufficiale ed è citato sotto il suo grafico. Le analisi sono pubblicate dagli osservatori tematici di Troisi Ricerche, dove si trovano per intero.</p>
		</div>
		<div class="oss">
			<?php foreach ( idt_osservatori() as $o ) : ?>
			<a href="https://www.<?php echo esc_attr( $o[1] ); ?>/"><b><?php echo esc_html( $o[0] ); ?></b><span><?php echo esc_html( $o[2] ); ?> · <?php echo esc_html( $o[1] ); ?></span></a>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="fascia-wa">
	<div class="wrap">
		<p><strong>Il prossimo dato, direttamente sul telefono.</strong> Seguici sul canale WhatsApp «Il dato è tratto™».</p>
		<a class="btn-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo idt_icona_chat(); // phpcs:ignore ?> Segui il canale</a>
	</div>
</section>
<?php
get_footer();
