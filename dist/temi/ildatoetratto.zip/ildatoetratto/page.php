<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Instradamento: le pagine del sito hanno un modello dedicato in templates/.
$slug = get_post_field( 'post_name', get_queried_object_id() );
$tpl  = get_template_directory() . '/templates/page-' . sanitize_file_name( $slug ) . '.php';
get_header();
if ( $slug && file_exists( $tpl ) ) {
	include $tpl;
} else {
	while ( have_posts() ) :
		the_post();
		?>
		<header class="page-head"><div class="wrap-t"><h1><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><p><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?></div></header>
		<div class="contenuto"><div class="wrap-t"><?php the_content(); ?></div></div>
		<?php
	endwhile;
}
get_footer();
