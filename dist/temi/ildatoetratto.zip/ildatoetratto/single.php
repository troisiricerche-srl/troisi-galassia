<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$id  = get_the_ID();
	$num = (int) get_post_meta( $id, '_idt_numero', true );
	?>
	<header class="page-head">
		<div class="wrap-t">
			<p class="kicker">Il dato è tratto<sup class="tm">™</sup> · 2016–2026</p>
			<h1><?php the_title(); ?></h1>
			<p style="font-size:.95rem;color:#6B7280">A cura di <a href="https://www.andreatroisi.it/">Andrea Troisi</a> e del gruppo di <a href="https://www.troisiricerche.net/">Troisi Ricerche</a> · pubblicato il <?php echo esc_html( get_the_date() ); ?></p>
		</div>
	</header>
	<article class="contenuto">
		<div class="wrap-t">
			<?php the_content(); ?>
			<div class="box-iscriviti">
				<h2>Il prossimo numero, direttamente nella sua casella</h2>
				<p>«Il dato è tratto» esce ogni due settimane. Gratis, senza pubblicità.</p>
				<a class="btn" href="<?php echo esc_url( idt_link( 'iscriviti' ) ); ?>">Iscriviti</a>
			</div>
			<nav class="numero-nav" aria-label="Altri numeri">
				<span><?php previous_post_link( '%link', '← %title', true ); ?></span>
				<span><?php next_post_link( '%link', '%title →', true ); ?></span>
			</nav>
		</div>
	</article>
	<?php
endwhile;
get_footer();
