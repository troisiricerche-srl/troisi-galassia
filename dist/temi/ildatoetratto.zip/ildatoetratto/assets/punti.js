/* Il dato è tratto – campo di puntini che compone i numeri (1.4.0). Nessuna dipendenza. */
(function(){
  var ridotto = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function hex(h){ h=h.replace('#',''); return [parseInt(h.substr(0,2),16),parseInt(h.substr(2,2),16),parseInt(h.substr(4,2),16)]; }
  function Campo(cv){
    var ctx=cv.getContext('2d'), W=0,H=0, dpr=Math.min(2,window.devicePixelRatio||1), N=1600, P=[], self=this, corrente=null;
    function dim(){ var r=cv.getBoundingClientRect(); W=r.width; H=r.height; cv.width=W*dpr; cv.height=H*dpr; ctx.setTransform(dpr,0,0,dpr,0,0); N=W<520?1000:1700;
      while(P.length<N)P.push({x:Math.random()*W,y:Math.random()*H,vx:0,vy:0,tx:null,ty:null,r:[148,167,195],t:[148,167,195],a:.15,ta:.15,rad:1.3,rit:0}); P.length=N; }
    function punti(str,col){
      var o=document.createElement('canvas'),c=o.getContext('2d'),fs=200; o.width=1600;o.height=300;
      c.font='900 '+fs+'px "Arial Black","Helvetica Neue",Arial,sans-serif'; c.fillText(str,10,fs*1.05);
      var d=c.getImageData(0,0,o.width,o.height).data,pts=[],x0=1e9,y0=1e9,x1=-1,y1=-1,st=5;
      for(var y=0;y<o.height;y+=st)for(var x=0;x<o.width;x+=st){ if(d[(y*o.width+x)*4+3]>128){pts.push([x,y]);if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;} }
      if(!pts.length)return [];
      var s=Math.min(W*.94/(x1-x0+1),H*.72/(y1-y0+1)), ox=(W-(x1-x0)*s)/2, oy=(H-(y1-y0)*s)/2;
      return pts.map(function(q){return {x:ox+(q[0]-x0)*s,y:oy+(q[1]-y0)*s,c:col};});
    }
    this.forma=function(str,col){
      corrente=[str,col]; var pts=punti(str,hex(col)); for(var i=pts.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var z=pts[i];pts[i]=pts[j];pts[j]=z;}
      var t0=performance.now();
      for(var n=0;n<N;n++){ var p=P[n],q=pts[n]; p.rit=t0+Math.random()*420;
        if(q){p.tx=q.x;p.ty=q.y;p.t=q.c;p.ta=1;p.rad=W<520?1.5:1.9;} else {p.tx=null;p.t=[148,167,195];p.ta=.12;p.rad=1;p.vx=(Math.random()-.5)*.5;p.vy=(Math.random()-.5)*.5;}
        if(ridotto&&q){p.x=q.x;p.y=q.y;p.r=p.t.slice();p.a=1;} }
      if(ridotto)disegna(performance.now(),true);
    };
    function disegna(now,una){
      ctx.clearRect(0,0,W,H);
      for(var i=0;i<N;i++){ var p=P[i];
        if(p.tx!==null&&now>p.rit){p.vx+=(p.tx-p.x)*.045;p.vy+=(p.ty-p.y)*.045;p.vx*=.8;p.vy*=.8;}
        p.x+=p.vx;p.y+=p.vy;
        if(p.tx===null){if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;}
        for(var c=0;c<3;c++)p.r[c]+=(p.t[c]-p.r[c])*.08; p.a+=(p.ta-p.a)*.06;
        ctx.fillStyle='rgba('+(p.r[0]|0)+','+(p.r[1]|0)+','+(p.r[2]|0)+','+p.a.toFixed(2)+')';
        ctx.beginPath();ctx.arc(p.x,p.y,p.rad,0,6.283);ctx.fill(); }
      if(!una&&!ridotto)requestAnimationFrame(disegna);
    }
    dim(); if(!ridotto)requestAnimationFrame(disegna);
    var rt; window.addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(function(){dim(); if(corrente)self.forma(corrente[0],corrente[1]);},200);});
  }
  function lettere(el,str,cls){ el.textContent=''; str.split('').forEach(function(ch){var i=document.createElement('i');i.textContent=ch===' '?' ':ch;if(cls)i.className=cls;el.appendChild(i);}); return [].slice.call(el.children); }
  function cambiaParola(el,str){
    if(ridotto){el.textContent=str;return;}
    var vecchie=[].slice.call(el.children);
    vecchie.forEach(function(i,k){setTimeout(function(){i.className='su';},k*18);});
    setTimeout(function(){ var nuove=lettere(el,str,'giu'); requestAnimationFrame(function(){ nuove.forEach(function(i,k){setTimeout(function(){i.className='';},k*22);}); }); },260+vecchie.length*18);
  }
  function avvia(){
    // Apertura della home: parola che scorre + numero a puntini + scheda.
    var hero=document.querySelector('[data-idt-parole]');
    if(hero){
      var T=[]; try{T=JSON.parse(hero.getAttribute('data-idt-parole'));}catch(e){}
      if(T.length){
        var campo=new Campo(hero.querySelector('canvas')), par=hero.querySelector('.parola'), k=0, timer=null;
        var $=function(s){return hero.querySelector(s);};
        function vai(i){ var d=T[i]; hero.style.setProperty('--tema',d.c);
          cambiaParola(par,d.p); campo.forma(d.n,d.c);
          $('.sch-tema').textContent=d.t; $('.sch-n').textContent=d.n; $('.sch-testo').textContent=d.x; $('.sch-fonte').textContent=d.f; $('.sch-link').href=d.u;
          [].forEach.call(hero.querySelectorAll('.punti-nav button'),function(b,j){b.setAttribute('aria-current',j===i?'true':'false');});
        }
        function giro(){ clearInterval(timer); timer=setInterval(function(){k=(k+1)%T.length;vai(k);},4200); }
        lettere(par,T[0].p,''); vai(0); if(!ridotto)giro();
        [].forEach.call(hero.querySelectorAll('.punti-nav button'),function(b,j){b.addEventListener('click',function(){k=j;vai(j);giro();});});
        hero.addEventListener('mouseenter',function(){clearInterval(timer);}); hero.addEventListener('mouseleave',function(){if(!ridotto)giro();});
      }
    }
    // Pagina del singolo dato: un numero fermo.
    [].forEach.call(document.querySelectorAll('[data-idt-numero]'),function(el){ var c=new Campo(el); c.forma(el.getAttribute('data-idt-numero'),el.getAttribute('data-idt-colore')||'#FFB020'); });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',avvia); else avvia();
})();
