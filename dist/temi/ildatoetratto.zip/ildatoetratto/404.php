<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<header class="page-head"><div class="wrap-t"><h1>Pagina non trovata</h1><p>Il dato non è tratto: questa pagina non esiste o è stata spostata.</p></div></header>
<div class="contenuto"><div class="wrap-t">
	<p><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Torna alla pagina iniziale</a> <a class="btn btn-sec" href="<?php echo esc_url( idt_link( 'numeri' ) ); ?>" style="margin-left:6px">Tutti i numeri</a></p>
</div></div>
<?php
get_footer();
