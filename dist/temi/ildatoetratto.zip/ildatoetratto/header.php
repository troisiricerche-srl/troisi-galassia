<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#contenuto">Vai al contenuto</a>
<header class="site-head">
	<div class="wrap">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Il dato è tratto, pagina iniziale">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/marchio.svg' ); ?>" alt="" width="40" height="40">
			<span><b>Il dato è tratto<sup class="tm">™</sup></b><small>newsletter e canale WhatsApp di Troisi Ricerche</small></span>
		</a>
		<a class="wa-mobile" href="<?php echo esc_url( IDT_WHATSAPP ); ?>" target="_blank" rel="noopener" aria-label="Segui il canale WhatsApp"><?php echo idt_icona_chat(); // phpcs:ignore ?> Segui</a>
		<button class="nav-toggle" aria-expanded="false" aria-controls="nav" onclick="var n=document.getElementById('nav');n.classList.toggle('open');this.setAttribute('aria-expanded',n.classList.contains('open'));">Menu</button>
		<nav class="nav" id="nav" aria-label="Menu principale">
			<?php
			$voci = array(
				'archivio'  => 'Archivio',
				'numeri'    => 'I numeri',
				'la-storia' => 'La storia',
				'podcast'   => 'Podcast',
			);
			foreach ( $voci as $slug => $label ) {
				$cur = is_page( $slug ) ? ' aria-current="page"' : '';
				echo '<a href="' . esc_url( idt_link( $slug ) ) . '"' . $cur . '>' . esc_html( $label ) . '</a>'; // phpcs:ignore
			}
			?>
			<a href="https://www.troisiricerche.net/">Troisi Ricerche</a>
			<a class="btn-nav-wa" href="<?php echo esc_url( IDT_WHATSAPP ); ?>" target="_blank" rel="noopener"><?php echo idt_icona_chat(); // phpcs:ignore ?> WhatsApp</a>
			<a class="btn-nav" href="<?php echo esc_url( idt_link( 'iscriviti' ) ); ?>">Email</a>
		</nav>
	</div>
</header>
<main id="contenuto">
