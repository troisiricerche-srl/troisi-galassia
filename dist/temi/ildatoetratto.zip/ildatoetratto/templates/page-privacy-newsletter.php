<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<header class="page-head"><div class="wrap-t">
	<h1>Informativa privacy</h1>
	<p>Come trattiamo i dati di chi si iscrive a «Il dato è tratto» (art. 13 del Regolamento UE 2016/679).</p>
</div></header>
<div class="contenuto"><div class="wrap-t">
	<p><em>Versione del <?php echo esc_html( wp_date( 'j F Y', strtotime( IDT_CONSENSO_V ) ) ); ?>.</em></p>

	<h2>Titolare del trattamento</h2>
	<p>Troisi Ricerche S.r.l. Unipersonale, Via De Rossi 57, Bari, P.IVA 07216100722. Per qualsiasi richiesta sui dati: <a href="mailto:<?php echo esc_attr( IDT_REPLY_TO ); ?>"><?php echo esc_html( IDT_REPLY_TO ); ?></a>.</p>

	<h2>Quali dati trattiamo</h2>
	<ul>
		<li>l'indirizzo email (obbligatorio per ricevere la newsletter);</li>
		<li>nome ed ente o azienda, se sceglie di indicarli;</li>
		<li>data, ora e indirizzo IP della richiesta di iscrizione e della conferma, e il testo del consenso accettato, per poter dimostrare che il consenso è stato dato;</li>
		<li>se il servizio di invio lo rileva, l'apertura delle email e i clic sui link, in forma di statistiche sull'invio.</li>
	</ul>

	<h2>Perché e su quale base</h2>
	<ul>
		<li><strong>Invio della newsletter (ogni due settimane)</strong>: sulla base del suo consenso (art. 6, par. 1, lett. a GDPR), che può revocare in ogni momento con il link presente in ogni email.</li>
		<li><strong>Prova del consenso e della sua eventuale revoca</strong>: per rispettare l'obbligo di dimostrare il consenso (art. 7, par. 1 GDPR).</li>
	</ul>
	<p>Non usiamo i dati per profilazione pubblicitaria e non li cediamo a terzi per finalità di marketing.</p>

	<h2>Per quanto tempo</h2>
	<p>Finché resta iscritto. Le richieste mai confermate vengono cancellate automaticamente dopo 30 giorni. Dopo la cancellazione conserviamo solo l'email e le date di iscrizione e revoca, per dimostrare il rispetto della sua scelta, per un massimo di 24 mesi.</p>

	<h2>Chi tratta i dati per nostro conto</h2>
	<p>Il fornitore dell'hosting del sito e il servizio di invio delle email, nominati responsabili del trattamento (art. 28 GDPR). Se il servizio di invio comportasse un trasferimento di dati fuori dallo Spazio economico europeo, avverrà solo con le garanzie previste dal Capo V del GDPR.</p>

	<h2>I suoi diritti</h2>
	<p>Può chiedere in ogni momento l'accesso ai suoi dati, la rettifica, la cancellazione, la limitazione del trattamento, la portabilità, e revocare il consenso senza pregiudicare quanto fatto prima della revoca (artt. 15-22 GDPR), scrivendo a <a href="mailto:<?php echo esc_attr( IDT_REPLY_TO ); ?>"><?php echo esc_html( IDT_REPLY_TO ); ?></a>. Ha anche il diritto di proporre reclamo al Garante per la protezione dei dati personali (<a href="https://www.garanteprivacy.it/">garanteprivacy.it</a>).</p>

	<h2>Cookie</h2>
	<p>Questo sito non usa cookie di profilazione né cookie statistici di terze parti. WordPress usa solo cookie tecnici per chi accede all'area riservata del sito.</p>
</div></div>
