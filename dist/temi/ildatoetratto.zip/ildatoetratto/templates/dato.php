<?php
/**
 * Pagina del singolo dato (1.4.0): numero a puntini nel colore del tema, analisi completa, altri dati dello stesso tema.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$d     = idt_dato_corrente();
$par   = idt_parole();
$fonti = idt_fonti();
$h     = $d['h'];
$pc    = idt_parola_titolo( $d['t'], $h );
$col   = $pc[1];
$tema  = isset( $fonti[ $h ] ) ? $fonti[ $h ][0] : $h;
$sito  = isset( $fonti[ $h ] ) ? $fonti[ $h ][1] : $h;
$num   = idt_numero_titolo( $d['t'] );
$mesi  = array( '', 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre' );
$dd    = explode( '-', $d['d'] );
get_header();
?>
<section class="dato-hero" style="--tema:<?php echo esc_attr( $col ); ?>">
	<div class="wrap dato-hero-in">
		<div class="dato-hero-testo">
			<p class="dato-k"><a href="<?php echo esc_url( add_query_arg( 'tema', $h, idt_link( 'archivio' ) ) ); ?>"><?php echo esc_html( $tema ); ?></a></p>
			<h1><?php echo esc_html( $d['t'] ); ?></h1>
			<p class="dato-meta"><?php echo esc_html( (int) $dd[2] . ' ' . $mesi[ (int) $dd[1] ] . ' ' . $dd[0] ); ?> · analisi di <a href="<?php echo esc_url( $d['u'] ); ?>"><?php echo esc_html( $sito ); ?></a></p>
		</div>
		<?php if ( $num ) : ?>
		<div class="dato-hero-num"><canvas data-idt-numero="<?php echo esc_attr( $num ); ?>" data-idt-colore="<?php echo esc_attr( $col ); ?>" aria-hidden="true"></canvas><span class="screen-reader-text"><?php echo esc_html( $num ); ?></span></div>
		<?php endif; ?>
	</div>
</section>

<article class="dato-corpo">
	<div class="wrap-t">
		<?php if ( $d['e'] ) : ?><p class="dato-lead"><?php echo esc_html( $d['e'] ); ?></p><?php endif; ?>
		<div class="dato-testo"><?php echo $d['c']; // phpcs:ignore -- contenuto dei siti di Troisi Ricerche, ripulito in idt_dato_pulisci() ?></div>
		<p class="dato-orig">Questa analisi è pubblicata da <strong><?php echo esc_html( $sito ); ?></strong>, osservatorio di Troisi Ricerche. <a href="<?php echo esc_url( $d['u'] ); ?>">Leggila sul sito originale →</a></p>
	</div>
</article>

<?php $altri = idt_dato_altri( $h, $d['i'] ); if ( $altri ) : ?>
<section class="sez alt dato-altri" style="--tema:<?php echo esc_attr( $col ); ?>">
	<div class="wrap">
		<div class="sez-head"><p class="kicker">Altri dati · <?php echo esc_html( $tema ); ?></p><h2>Continua a leggere</h2><div class="linea"></div></div>
		<div class="altri">
			<?php foreach ( $altri as $a ) : $n = idt_numero_titolo( $a['t'] ); ?>
			<a class="altro" href="<?php echo esc_url( idt_dato_url( $a ) ); ?>">
				<?php if ( $n ) : ?><b><?php echo esc_html( $n ); ?></b><?php endif; ?>
				<span><?php echo esc_html( $a['t'] ); ?></span>
			</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<section class="fascia-wa">
	<div class="wrap">
		<p><strong>Un dato a settimana, spiegato bene.</strong> Seguici sul canale WhatsApp «Il dato è tratto™».</p>
		<a class="btn-wa" href="<?php echo esc_url( IDT_WHATSAPP ); ?>" target="_blank" rel="noopener"><?php echo idt_icona_chat(); // phpcs:ignore ?> Segui il canale</a>
		<a class="btn-ghost" href="https://www.instagram.com/troisiricerche/" target="_blank" rel="noopener">Instagram @troisiricerche</a>
	</div>
</section>
<?php
get_footer();
