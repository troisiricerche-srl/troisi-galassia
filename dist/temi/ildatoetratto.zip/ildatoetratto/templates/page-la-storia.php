<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<header class="page-head"><div class="wrap-t">
	<h1>La storia</h1>
	<p>Da una rubrica radiofonica del 2016 alla newsletter di Troisi Ricerche.</p>
</div></header>
<div class="contenuto"><div class="wrap-t">
	<p class="idt-lead">«Il dado è tratto», disse Cesare passando il Rubicone: una decisione presa, senza ritorno. Per chi lavora con la statistica le decisioni dovrebbero venire dopo i dati. Da qui il gioco di parole: <strong>il dato è tratto</strong>.</p>
	<h2>2016: la rubrica su Controradio Bari</h2>
	<p>Il nome nasce nel 2016 come rubrica di Andrea Troisi su Controradio Bari, in onda ogni lunedì: pochi minuti per prendere un numero, spiegare da dove viene e cosa racconta del Paese e del territorio, spesso con un ospite in studio e i risultati del sondaggio del mese.</p>
	<p>Troisi Ricerche era già di casa su quelle frequenze: nel giugno 2016 festeggiava i suoi primi dieci anni a Controradio Bari.</p>
	<h2>2026: la newsletter</h2>
	<p>Nel 2026 «Il dato è tratto» diventa la newsletter di <a href="https://www.troisiricerche.net/">Troisi Ricerche</a>, l'istituto di ricerca statistica applicata fondato nel 2006, con sedi a Bari, Roma e Milano. Ogni due settimane raccoglie le analisi dei suoi osservatori tematici: economia, pubblica amministrazione, lavoro e organizzazioni, giovani, competenze, imprese, export e territori.</p>
	<p>Le regole sono poche: dati da fonti ufficiali, fonte sempre citata sotto ogni grafico, una lettura breve e il link all'analisi completa per chi vuole approfondire.</p>
	<h2>Presto: il podcast</h2>
	<p>«Il dato è tratto» tornerà anche in voce, come ai tempi della radio. <a href="<?php echo esc_url( idt_link( 'podcast' ) ); ?>">Il podcast è in preparazione</a>.</p>
	<h2>Chi la cura</h2>
	<p><a href="https://www.andreatroisi.it/">Andrea Troisi</a>, fondatore di Troisi Ricerche, giornalista, insegna Economia del turismo all'Università degli Studi di Bari Aldo Moro. Con lui lavora il gruppo di ricerca di Troisi Ricerche.</p>
	<div class="box-iscriviti">
		<h2>Il prossimo numero, direttamente nella sua casella</h2>
		<p>Gratis, ogni due settimane.</p>
		<a class="btn" href="<?php echo esc_url( idt_link( 'iscriviti' ) ); ?>">Iscriviti</a>
	</div>
</div></div>
