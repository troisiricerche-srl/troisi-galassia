<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$q = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'category_name' => 'numeri-newsletter', 'posts_per_page' => 60 ) );
?>
<header class="page-head"><div class="wrap">
	<h1>Tutti i numeri</h1>
	<p>L'archivio di «Il dato è tratto»: ogni numero con il dato del mese, le analisi e i grafici.</p>
</div></header>
<div class="contenuto"><div class="wrap">
	<?php if ( $q->have_posts() ) : ?>
	<div class="elenco-numeri">
		<?php while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'templates/card-numero' ); endwhile; wp_reset_postdata(); ?>
	</div>
	<?php else : ?>
	<p>Il primo numero è in arrivo.</p>
	<?php endif; ?>
	<div style="max-width:640px;margin:48px auto 0"><?php echo idt_modulo( 'archivio', 'Ricevi i prossimi numeri' ); // phpcs:ignore ?></div>
</div></div>
