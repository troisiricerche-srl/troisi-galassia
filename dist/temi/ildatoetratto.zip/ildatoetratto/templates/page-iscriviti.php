<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$canc = isset( $_GET['cancella'] ) ? sanitize_text_field( wp_unslash( $_GET['cancella'] ) ) : '';
?>
<header class="page-head"><div class="wrap-t">
	<h1><?php echo $canc ? 'Cancellazione' : 'Iscriviti a «Il dato è tratto»'; ?></h1>
	<p><?php echo $canc ? 'Ci dispiace vederla andare via.' : 'Un\'email ogni due settimane con i numeri che contano sull\'Italia. Gratis, senza pubblicità, ci si cancella con un clic.'; ?></p>
</div></header>
<div class="contenuto"><div class="wrap-t">
<?php if ( $canc ) : ?>
	<div class="iscrizione" id="modulo">
		<h2>Vuole davvero cancellarsi?</h2>
		<p>Premendo il pulsante non riceverà più «Il dato è tratto». Potrà iscriversi di nuovo quando vuole.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="idt_cancella">
			<input type="hidden" name="token" value="<?php echo esc_attr( $canc ); ?>">
			<button type="submit" class="btn">Sì, cancellami</button>
		</form>
	</div>
<?php else : ?>
	<?php echo idt_modulo( 'pagina-iscriviti', 'I suoi dati', true ); // phpcs:ignore ?>
	<h2>Come funziona</h2>
	<ol>
		<li>Scrive la sua email e spunta la casella del consenso.</li>
		<li>Riceve subito un'email: clicca su «Confermo l'iscrizione». Senza questo passaggio non riceverà nulla.</li>
		<li>Da quel momento riceve «Il dato è tratto» ogni due settimane. In fondo a ogni numero c'è il link per cancellarsi.</li>
	</ol>
	<h2>Cosa riceverà</h2>
	<p>Il dato del mese, tre numeri chiave, le analisi degli osservatori di Troisi Ricerche con i grafici originali, un gioco di statistica e le altre uscite del mese. Può vedere com'è fatto nell'<a href="<?php echo esc_url( idt_link( 'numeri' ) ); ?>">archivio dei numeri</a>.</p>
	<h2>I suoi dati</h2>
	<p>Usiamo l'email solo per inviare la newsletter; nome ed ente sono facoltativi. Non cediamo i dati a terzi per pubblicità. Tutti i dettagli sono nell'<a href="<?php echo esc_url( idt_link( 'privacy-newsletter' ) ); ?>">informativa privacy</a>.</p>
<?php endif; ?>
</div></div>
