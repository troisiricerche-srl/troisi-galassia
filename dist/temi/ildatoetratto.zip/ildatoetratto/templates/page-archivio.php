<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<header class="page-head"><div class="wrap">
	<h1>Archivio degli articoli</h1>
	<p>Tutte le analisi degli osservatori di Troisi Ricerche, divise per tema. Si cerca per parola o si sceglie un tema; ogni titolo porta all'articolo completo sul sito d'origine.</p>
</div></header>
<div class="contenuto"><div class="wrap">
	<?php echo idt_archivio_html( false ); // phpcs:ignore ?>
	<div style="max-width:640px;margin:48px auto 0"><?php echo idt_modulo( 'archivio-articoli', 'Il meglio del mese, in una email' ); // phpcs:ignore ?></div>
</div></div>
