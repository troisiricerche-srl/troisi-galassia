<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$id  = get_the_ID();
$num = (int) get_post_meta( $id, '_idt_numero', true );
$big = get_post_meta( $id, '_idt_dato_num', true );
?>
<article class="numero-card">
	<div class="n">2016–2026 · <?php echo esc_html( get_the_date() ); ?></div>
	<?php if ( $big ) : ?><div class="big"><?php echo esc_html( $big ); ?></div><?php endif; ?>
	<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<p><?php echo esc_html( get_the_excerpt() ); ?></p>
	<a class="idt-more" href="<?php the_permalink(); ?>">Leggi il numero →</a>
</article>
