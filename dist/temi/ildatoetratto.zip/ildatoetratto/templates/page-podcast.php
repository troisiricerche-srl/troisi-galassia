<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<header class="page-head"><div class="wrap-t">
	<h1>Il podcast</h1>
	<p>«Il dato è tratto» tornerà anche in voce.</p>
</div></header>
<div class="contenuto"><div class="wrap-t">
	<p class="idt-lead">Il podcast è in preparazione: un numero alla volta, raccontato in pochi minuti, come nella rubrica radiofonica nata nel 2016.</p>
	<p>Nel frattempo, i contenuti audio di Andrea Troisi su pubblica amministrazione, innovazione e territorio sono su <a href="https://www.voiceinhub.it/">VoiceInHub</a>.</p>
	<p>Gli iscritti alla newsletter saranno i primi a sapere quando esce la prima puntata.</p>
	<div style="margin-top:28px"><?php echo idt_modulo( 'podcast', 'Avvisami quando esce' ); // phpcs:ignore ?></div>
</div></div>
