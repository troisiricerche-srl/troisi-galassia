<?php
/**
 * Archivio della galassia: raccoglie gli articoli di tutti i siti di Troisi Ricerche
 * (titolo, data, riassunto, categorie, link all'originale) e li tiene aggiornati.
 * Gli articoli restano sui siti d'origine: qui ci sono solo schede e link.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function idt_fonti() {
	// dominio => [tema mostrato, nome del sito, colore]
	return array(
		'troisiinsight.it'                    => array( 'Economia e territori', 'TroisiInsight', '#004D8C' ),
		'customerpa.it'                       => array( 'PA e cittadini', 'CustomerPA', '#D95C14' ),
		'digitalizzazionenellapa.it'          => array( 'PA digitale', 'DigitalizzazionePA', '#0B6E99' ),
		'benessereorganizzativo.it'           => array( 'Organizzazioni e lavoro', 'Benessere Organizzativo', '#00856A' ),
		'benesseredigitalegiovani.it'         => array( 'Giovani e digitale', 'Benessere Digitale Giovani', '#7A3E9D' ),
		'mappaturadellecompetenze.it'         => array( 'Competenze', 'Mappatura delle Competenze', '#B45309' ),
		'governancefinanziaria.it'            => array( 'Imprese e finanza', 'Governance Finanziaria', '#1F2937' ),
		'consulenzainternazionalizzazione.it' => array( 'Export e mercati esteri', 'Consulenza Internazionalizzazione', '#0F766E' ),
		'dibattito-pubblico.it'               => array( 'Partecipazione e territori', 'Dibattito Pubblico', '#9F1239' ),
		'registrodellecompetenze.it'          => array( 'Certificazione delle competenze', 'Registro delle Competenze', '#6B7280' ),
		't-index.it'                          => array( 'Performance dei comuni', 'Indice di Performance Territoriale', '#6B7280' ),
		'troisiformazione.it'                 => array( 'Formazione', 'Troisi Formazione', '#6B7280' ),
		'svegliadigitale.it'                  => array( 'Consapevolezza digitale', 'Sveglia Digitale', '#6B7280' ),
		'voiceinhub.it'                       => array( 'Podcast', 'VoiceInHub', '#6B7280' ),
		'troisiricerche.net'                  => array( 'Notizie da Troisi Ricerche', 'Troisi Ricerche', '#003366' ),
		'andreatroisi.it'                     => array( 'Andrea Troisi', 'andreatroisi.it', '#003366' ),
	);
}

function idt_archivio_url_api( $host, $route, $args ) {
	// ?rest_route= funziona con qualunque impostazione dei permalink (anche su IIS).
	return add_query_arg( array_merge( array( 'rest_route' => $route ), $args ), 'https://www.' . $host . '/' );
}

function idt_archivio_scarica_sito( $host ) {
	$cats = array();
	$r    = wp_remote_get( idt_archivio_url_api( $host, '/wp/v2/categories', array( 'per_page' => 100, '_fields' => 'id,name' ) ), array( 'timeout' => 15 ) );
	if ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) {
		foreach ( (array) json_decode( wp_remote_retrieve_body( $r ), true ) as $c ) {
			if ( isset( $c['id'], $c['name'] ) ) {
				$cats[ (int) $c['id'] ] = html_entity_decode( $c['name'], ENT_QUOTES, 'UTF-8' );
			}
		}
	}
	$out  = array();
	$page = 1;
	do {
		$r = wp_remote_get( idt_archivio_url_api( $host, '/wp/v2/posts', array( 'per_page' => 100, 'page' => $page, '_fields' => 'id,date,link,title,excerpt,categories' ) ), array( 'timeout' => 20 ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return 1 === $page ? null : $out; // null = sito non raggiungibile: si tengono i dati precedenti
		}
		$tot_pagine = (int) wp_remote_retrieve_header( $r, 'x-wp-totalpages' );
		foreach ( (array) json_decode( wp_remote_retrieve_body( $r ), true ) as $p ) {
			$titolo = trim( html_entity_decode( wp_strip_all_tags( isset( $p['title']['rendered'] ) ? $p['title']['rendered'] : '' ), ENT_QUOTES, 'UTF-8' ) );
			if ( '' === $titolo || in_array( strtolower( $titolo ), array( 'ciao mondo!', 'hello world!' ), true ) ) {
				continue;
			}
			$ex = trim( html_entity_decode( wp_strip_all_tags( isset( $p['excerpt']['rendered'] ) ? $p['excerpt']['rendered'] : '' ), ENT_QUOTES, 'UTF-8' ) );
			$ex = preg_replace( '/\s+/u', ' ', preg_replace( '/\s*(\[&hellip;\]|\[…\]|…)\s*$/u', '', $ex ) );
			if ( mb_strlen( $ex ) > 220 ) {
				$ex = rtrim( mb_substr( $ex, 0, 215 ), " ,.;:" ) . '…';
			}
			$nomi = array();
			foreach ( (array) ( isset( $p['categories'] ) ? $p['categories'] : array() ) as $cid ) {
				if ( isset( $cats[ $cid ] ) && ! in_array( strtolower( $cats[ $cid ] ), array( 'senza categoria', 'uncategorized', 'news', 'notizie', 'articoli', 'analisi' ), true ) ) {
					$nomi[] = $cats[ $cid ];
				}
			}
			$out[] = array(
				's' => $host,
				'i' => isset( $p['id'] ) ? (int) $p['id'] : 0,
				't' => $titolo,
				'u' => esc_url_raw( $p['link'] ),
				'd' => substr( (string) $p['date'], 0, 10 ),
				'e' => $ex,
				'c' => array_slice( array_values( array_unique( $nomi ) ), 0, 3 ),
			);
		}
		$page++;
	} while ( $page <= $tot_pagine && $page <= 20 );
	return $out;
}

function idt_archivio_aggiorna() {
	$vecchio = get_option( 'idt_archivio', array() );
	$per     = array();
	foreach ( (array) $vecchio as $it ) {
		$per[ $it['s'] ][] = $it;
	}
	$tutti = array();
	$esito = array();
	foreach ( array_keys( idt_fonti() ) as $h ) {
		$lista = idt_archivio_scarica_sito( $h );
		if ( null === $lista ) {
			$lista       = isset( $per[ $h ] ) ? $per[ $h ] : array();
			$esito[ $h ] = 'non raggiungibile (tenuti ' . count( $lista ) . ' articoli già salvati)';
		} else {
			$esito[ $h ] = count( $lista ) . ' articoli';
		}
		$tutti = array_merge( $tutti, $lista );
	}
	usort( $tutti, function ( $a, $b ) {
		return strcmp( $b['d'], $a['d'] );
	} );
	update_option( 'idt_archivio', $tutti, false );
	update_option( 'idt_archivio_agg', array( 'quando' => idt_ora(), 'esito' => $esito ), false );
	return count( $tutti );
}

// Aggiornamento automatico due volte al giorno.
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'idt_archivio_cron' ) ) {
		wp_schedule_event( time() + 60, 'twicedaily', 'idt_archivio_cron' );
	}
} );
add_action( 'idt_archivio_cron', 'idt_archivio_aggiorna' );

// Pulsante in Strumenti → Stato del sito.
add_action( 'admin_post_idt_archivio_ora', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'idt_archivio_ora' ) ) {
		wp_die( 'Non autorizzato' );
	}
	$n = idt_archivio_aggiorna();
	wp_safe_redirect( admin_url( 'tools.php?page=idt-stato&archivio=' . (int) $n ) );
	exit;
} );

/**
 * Stampa l'archivio con ricerca e filtri.
 *
 * @param bool $compatto In home: 5 articoli per tema e pulsante «tutti».
 */
function idt_archivio_html( $compatto = false ) {
	$items = get_option( 'idt_archivio', array() );
	if ( ! $items ) {
		return '<p>L\'archivio si sta caricando: torni fra qualche minuto.</p>';
	}
	$fonti = idt_fonti();
	$per   = array();
	foreach ( $items as $it ) {
		$per[ $it['s'] ][] = $it;
	}
	// Temi in ordine di numero di articoli.
	uksort( $per, function ( $a, $b ) use ( $per ) {
		return count( $per[ $b ] ) - count( $per[ $a ] );
	} );
	$mesi = array( '', 'gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic' );
	ob_start();
	?>
	<div class="arch" data-compatto="<?php echo $compatto ? '1' : '0'; ?>">
		<div class="arch-cerca">
			<label for="arch-q" class="screen-reader-text">Cerca negli articoli</label>
			<input id="arch-q" type="search" placeholder="Cerca fra <?php echo (int) count( $items ); ?> articoli: salari, PNRR, giovani, export, Puglia…" autocomplete="off">
			<p class="arch-conta" aria-live="polite"><span id="arch-n"><?php echo (int) count( $items ); ?></span> articoli da <?php echo (int) count( $per ); ?> siti</p>
		</div>
		<div class="arch-temi" role="group" aria-label="Filtra per tema">
			<button type="button" class="on" data-tema="">Tutti i temi</button>
			<?php foreach ( $per as $h => $lista ) : ?>
			<button type="button" data-tema="<?php echo esc_attr( $h ); ?>" style="--c:<?php echo esc_attr( $fonti[ $h ][2] ); ?>"><?php echo esc_html( $fonti[ $h ][0] ); ?> <small><?php echo (int) count( $lista ); ?></small></button>
			<?php endforeach; ?>
		</div>
		<?php foreach ( $per as $h => $lista ) : ?>
		<section class="arch-tema" data-tema="<?php echo esc_attr( $h ); ?>" style="--c:<?php echo esc_attr( $fonti[ $h ][2] ); ?>">
			<h3><?php echo esc_html( $fonti[ $h ][0] ); ?> <a href="https://www.<?php echo esc_attr( $h ); ?>/"><?php echo esc_html( $h ); ?></a></h3>
			<ul>
				<?php
				foreach ( $lista as $i => $it ) :
					$d   = explode( '-', $it['d'] );
					$txt = strtolower( remove_accents( $it['t'] . ' ' . $it['e'] . ' ' . implode( ' ', $it['c'] ) . ' ' . $fonti[ $h ][0] . ' ' . $h ) );
					?>
				<li data-q="<?php echo esc_attr( $txt ); ?>"<?php echo ( $compatto && $i >= 5 ) ? ' class="extra" hidden' : ''; ?>>
					<time datetime="<?php echo esc_attr( $it['d'] ); ?>"><?php echo esc_html( (int) $d[2] . ' ' . $mesi[ (int) $d[1] ] . ' ' . $d[0] ); ?></time>
					<a href="<?php echo esc_url( function_exists( 'idt_dato_url' ) ? idt_dato_url( $it ) : $it['u'] ); ?>"><?php echo esc_html( $it['t'] ); ?></a>
					<?php if ( $it['e'] ) : ?><p><?php echo esc_html( $it['e'] ); ?></p><?php endif; ?>
					<?php if ( $it['c'] ) : ?><span class="arch-cat"><?php echo esc_html( implode( ' · ', $it['c'] ) ); ?></span><?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php if ( $compatto && count( $lista ) > 5 ) : ?>
			<button type="button" class="arch-tutti">Mostra tutti i <?php echo (int) count( $lista ); ?> articoli di «<?php echo esc_html( $fonti[ $h ][0] ); ?>»</button>
			<?php endif; ?>
		</section>
		<?php endforeach; ?>
		<p class="arch-vuoto" hidden>Nessun articolo trovato. Provi con un'altra parola.</p>
	</div>
	<script>
	(function(){
		var root=document.currentScript.previousElementSibling, q=root.querySelector('#arch-q'), n=root.querySelector('#arch-n'), tema='';
		var norm=function(s){return s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');};
		function filtra(){
			var parole=norm(q.value.trim()).split(/\s+/).filter(Boolean), tot=0, cerca=parole.length>0;
			root.querySelectorAll('.arch-tema').forEach(function(sec){
				var vis=0, okTema=!tema||sec.dataset.tema===tema;
				sec.querySelectorAll('li').forEach(function(li){
					var ok=okTema&&parole.every(function(p){return li.dataset.q.indexOf(p)>-1;});
					var espanso=cerca||tema||sec.classList.contains('aperto')||!li.classList.contains('extra');
					li.hidden=!(ok&&espanso); if(ok){vis++;}
				});
				sec.hidden=vis===0; tot+=vis;
				var b=sec.querySelector('.arch-tutti'); if(b){b.hidden=cerca||!!tema||sec.classList.contains('aperto');}
			});
			n.textContent=tot; root.querySelector('.arch-vuoto').hidden=tot>0;
		}
		q.addEventListener('input',filtra);
		root.querySelectorAll('.arch-temi button').forEach(function(b){b.addEventListener('click',function(){
			tema=b.dataset.tema; root.querySelectorAll('.arch-temi button').forEach(function(x){x.classList.toggle('on',x===b);}); filtra();
		});});
		root.querySelectorAll('.arch-tutti').forEach(function(b){b.addEventListener('click',function(){b.closest('.arch-tema').classList.add('aperto'); filtra();});});
		var sp=new URLSearchParams(location.search), h=sp.get('cerca'), tm=sp.get('tema'); if(h){q.value=h;} if(tm){root.querySelectorAll('.arch-temi button').forEach(function(x){if(x.dataset.tema===tm){tema=tm;} x.classList.toggle('on',x.dataset.tema===tema);});} if(h||tema){filtra();}
	})();
	</script>
	<?php
	return ob_get_clean();
}
