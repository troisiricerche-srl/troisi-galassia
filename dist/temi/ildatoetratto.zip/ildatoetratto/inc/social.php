<?php
/**
 * 1.5.0 – Uscita automatica del martedì su Instagram e Facebook.
 *
 * Come funziona
 * - Ogni martedì alle 7 la redazione prepara le slide e i testi e li mette nel repository pubblico
 *   github.com/troisiricerche-srl/troisi-galassia, cartella uscite/<data>/, con il file uscite/prossima.json.
 * - Questo modulo legge prossima.json e, quando arriva l'ora indicata (le 9), pubblica:
 *   Instagram: carosello di immagini (o Reel, se indicato) + primo commento con i link;
 *   Facebook (pagina): post con le stesse immagini e il testo.
 * - La chiave di accesso di Meta la inserisce Andrea in Strumenti → Uscite social. Nessuno la vede dopo il salvataggio.
 * - «Ferma»: pulsante nella stessa pagina, oppure "stato": "ferma" in prossima.json.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IDT_SOCIAL_JSON', 'https://raw.githubusercontent.com/troisiricerche-srl/troisi-galassia/main/uscite/prossima.json' );

function idt_social_opt( $k, $def = '' ) {
	$o = get_option( 'idt_social', array() );
	return isset( $o[ $k ] ) && '' !== $o[ $k ] ? $o[ $k ] : $def;
}
function idt_social_log( $msg ) {
	$log   = get_option( 'idt_social_log', array() );
	array_unshift( $log, idt_ora() . ' – ' . $msg );
	update_option( 'idt_social_log', array_slice( $log, 0, 80 ), false );
}
function idt_graph( $metodo, $path, $args = array() ) {
	$url = 'https://graph.facebook.com/' . idt_social_opt( 'versione', 'v23.0' ) . '/' . ltrim( $path, '/' );
	if ( 'GET' === $metodo ) {
		$r = wp_remote_get( add_query_arg( $args, $url ), array( 'timeout' => 30 ) );
	} else {
		$r = wp_remote_post( $url, array( 'timeout' => 60, 'body' => $args ) );
	}
	if ( is_wp_error( $r ) ) {
		return array( 'error' => array( 'message' => $r->get_error_message() ) );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	return is_array( $j ) ? $j : array( 'error' => array( 'message' => 'risposta non valida (' . wp_remote_retrieve_response_code( $r ) . ')' ) );
}
function idt_graph_err( $j ) {
	return isset( $j['error']['message'] ) ? $j['error']['message'] : '';
}

/** Token della pagina Facebook (serve per pubblicare sulla pagina), ricavato dalla chiave salvata. */
function idt_social_token_pagina() {
	$t = get_transient( 'idt_social_ptok' );
	if ( $t ) {
		return $t;
	}
	$j = idt_graph( 'GET', idt_social_opt( 'pagina' ), array( 'fields' => 'access_token', 'access_token' => idt_social_opt( 'token' ) ) );
	if ( ! empty( $j['access_token'] ) ) {
		set_transient( 'idt_social_ptok', $j['access_token'], 12 * HOUR_IN_SECONDS );
		return $j['access_token'];
	}
	return idt_social_opt( 'token' ); // la chiave salvata può già essere quella della pagina
}

/** Legge prossima.json da GitHub. */
function idt_social_prossima() {
	$r = wp_remote_get( IDT_SOCIAL_JSON . '?t=' . time(), array( 'timeout' => 15 ) );
	if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
		return null;
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	return ( is_array( $j ) && ! empty( $j['data'] ) ) ? $j : null;
}

/** Controllo: se c'è un'uscita dovuta e non ancora fatta, la pubblica. Idempotente. */
function idt_social_controlla( $forza = false ) {
	if ( ! idt_social_opt( 'token' ) || ! idt_social_opt( 'attivo' ) ) {
		return 'non attivo';
	}
	$u = idt_social_prossima();
	if ( ! $u ) {
		return 'nessuna uscita';
	}
	$fatte = get_option( 'idt_social_fatte', array() );
	$k     = $u['data'];
	if ( ! empty( $fatte[ $k ]['ok'] ) ) {
		return 'già pubblicata';
	}
	if ( in_array( $k, (array) get_option( 'idt_social_ferme', array() ), true ) || ( isset( $u['stato'] ) && 'pronta' !== $u['stato'] ) ) {
		return 'ferma';
	}
	$quando = strtotime( isset( $u['pubblica_alle'] ) ? $u['pubblica_alle'] : '' );
	if ( ! $forza && ( ! $quando || time() < $quando ) ) {
		return 'non ancora';
	}
	if ( get_transient( 'idt_social_lock' ) ) {
		return 'in corso';
	}
	set_transient( 'idt_social_lock', 1, 10 * MINUTE_IN_SECONDS );
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore
	}
	ignore_user_abort( true );
	$esito = isset( $fatte[ $k ] ) ? $fatte[ $k ] : array();
	if ( empty( $esito['ig'] ) && ! empty( $u['instagram'] ) ) {
		$esito['ig'] = idt_social_instagram( $u );
	}
	if ( empty( $esito['fb'] ) && ! empty( $u['facebook'] ) ) {
		$esito['fb'] = idt_social_facebook( $u );
	}
	$esito['ok'] = ( empty( $u['instagram'] ) || ! empty( $esito['ig'] ) ) && ( empty( $u['facebook'] ) || ! empty( $esito['fb'] ) );
	$fatte[ $k ] = $esito;
	update_option( 'idt_social_fatte', $fatte, false );
	delete_transient( 'idt_social_lock' );
	return $esito['ok'] ? 'pubblicata' : 'incompleta (vedi registro)';
}

function idt_social_instagram( $u ) {
	$ig  = idt_social_opt( 'instagram' );
	$tok = idt_social_opt( 'token' );
	$cap = (string) $u['instagram']['caption'];
	if ( ! empty( $u['instagram']['reel'] ) ) {
		// Il Reel va elaborato da Instagram: si crea il contenitore e si pubblica a un controllo successivo, quando è pronto.
		$sosp = get_option( 'idt_social_reel', array() );
		if ( empty( $sosp[ $u['data'] ] ) ) {
			$c = idt_graph( 'POST', $ig . '/media', array( 'media_type' => 'REELS', 'video_url' => $u['instagram']['reel'], 'caption' => $cap, 'share_to_feed' => 'true', 'access_token' => $tok ) );
			if ( empty( $c['id'] ) ) {
				idt_social_log( 'Instagram Reel: ' . idt_graph_err( $c ) );
				return '';
			}
			$sosp[ $u['data'] ] = $c['id'];
			update_option( 'idt_social_reel', $sosp, false );
			idt_social_log( 'Instagram Reel in elaborazione' );
		}
		$cid = $sosp[ $u['data'] ];
		for ( $i = 0; $i < 4; $i++ ) {
			$s = idt_graph( 'GET', $cid, array( 'fields' => 'status_code', 'access_token' => $tok ) );
			if ( isset( $s['status_code'] ) && 'FINISHED' === $s['status_code'] ) {
				break;
			}
			if ( isset( $s['status_code'] ) && 'ERROR' === $s['status_code'] ) {
				idt_social_log( 'Instagram Reel: elaborazione non riuscita' );
				unset( $sosp[ $u['data'] ] );
				update_option( 'idt_social_reel', $sosp, false );
				return '';
			}
			if ( 3 === $i ) {
				return ''; // non ancora pronto: si riprova al prossimo controllo (15 minuti)
			}
			sleep( 8 );
		}
		$creazione = $cid;
	} else {
		$figli = array();
		foreach ( array_slice( (array) $u['slide'], 0, 10 ) as $img ) {
			$c = idt_graph( 'POST', $ig . '/media', array( 'image_url' => $img, 'is_carousel_item' => 'true', 'access_token' => $tok ) );
			if ( empty( $c['id'] ) ) {
				idt_social_log( 'Instagram immagine ' . basename( $img ) . ': ' . idt_graph_err( $c ) );
				return '';
			}
			$figli[] = $c['id'];
		}
		$c = idt_graph( 'POST', $ig . '/media', array( 'media_type' => 'CAROUSEL', 'children' => implode( ',', $figli ), 'caption' => $cap, 'access_token' => $tok ) );
		if ( empty( $c['id'] ) ) {
			idt_social_log( 'Instagram carosello: ' . idt_graph_err( $c ) );
			return '';
		}
		sleep( 5 );
		$creazione = $c['id'];
	}
	$p = idt_graph( 'POST', $ig . '/media_publish', array( 'creation_id' => $creazione, 'access_token' => $tok ) );
	if ( empty( $p['id'] ) ) {
		idt_social_log( 'Instagram pubblicazione: ' . idt_graph_err( $p ) );
		return '';
	}
	idt_social_log( 'Instagram pubblicato (' . $p['id'] . ')' );
	if ( ! empty( $u['instagram']['commento'] ) ) {
		$cm = idt_graph( 'POST', $p['id'] . '/comments', array( 'message' => $u['instagram']['commento'], 'access_token' => $tok ) );
		idt_social_log( empty( $cm['id'] ) ? 'Instagram primo commento: ' . idt_graph_err( $cm ) : 'Instagram primo commento pubblicato' );
	}
	return $p['id'];
}

function idt_social_facebook( $u ) {
	$pg  = idt_social_opt( 'pagina' );
	$tok = idt_social_token_pagina();
	$arg = array( 'message' => (string) $u['facebook']['testo'], 'access_token' => $tok );
	$i   = 0;
	foreach ( array_slice( (array) $u['slide'], 0, 10 ) as $img ) {
		$f = idt_graph( 'POST', $pg . '/photos', array( 'url' => $img, 'published' => 'false', 'access_token' => $tok ) );
		if ( empty( $f['id'] ) ) {
			idt_social_log( 'Facebook immagine ' . basename( $img ) . ': ' . idt_graph_err( $f ) );
			return '';
		}
		$arg[ 'attached_media[' . $i . ']' ] = wp_json_encode( array( 'media_fbid' => $f['id'] ) );
		$i++;
	}
	$p = idt_graph( 'POST', $pg . '/feed', $arg );
	if ( empty( $p['id'] ) ) {
		idt_social_log( 'Facebook post: ' . idt_graph_err( $p ) );
		return '';
	}
	idt_social_log( 'Facebook pubblicato (' . $p['id'] . ')' );
	return $p['id'];
}

/* ---------- quando controllare ---------- */
add_filter( 'cron_schedules', function ( $s ) {
	$s['idt_15min'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'Ogni 15 minuti' );
	return $s;
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'idt_social_cron' ) ) {
		wp_schedule_event( time() + 120, 'idt_15min', 'idt_social_cron' );
	}
} );
add_action( 'idt_social_cron', function () {
	idt_social_controlla();
} );
// Indirizzo da «svegliare» alle 9 (se il sito non ha visite, WP-Cron non parte da solo): ?idt_social=controlla
add_action( 'template_redirect', function () {
	if ( isset( $_GET['idt_social'] ) && 'controlla' === $_GET['idt_social'] ) { // phpcs:ignore
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo esc_html( idt_social_controlla() );
		exit;
	}
} );

/* ---------- pagina in Strumenti ---------- */
add_action( 'admin_menu', function () {
	add_management_page( 'Uscite social', 'Uscite social', 'manage_options', 'idt-social', 'idt_social_pagina' );
} );
add_action( 'admin_post_idt_social_salva', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'idt_social' ) ) {
		wp_die( 'Non autorizzato' );
	}
	$o = get_option( 'idt_social', array() );
	foreach ( array( 'instagram', 'pagina', 'versione' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$o[ $k ] = sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
		}
	}
	if ( ! empty( $_POST['token'] ) ) {
		$o['token'] = trim( sanitize_text_field( wp_unslash( $_POST['token'] ) ) );
		delete_transient( 'idt_social_ptok' );
	}
	$o['attivo'] = empty( $_POST['attivo'] ) ? '' : '1';
	update_option( 'idt_social', $o, false );
	wp_safe_redirect( admin_url( 'tools.php?page=idt-social&salvato=1' ) );
	exit;
} );
add_action( 'admin_post_idt_social_azione', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'idt_social_az' ) ) {
		wp_die( 'Non autorizzato' );
	}
	$a   = isset( $_POST['azione'] ) ? sanitize_key( $_POST['azione'] ) : '';
	$msg = '';
	if ( 'prova' === $a ) {
		$tok = idt_social_opt( 'token' );
		$ig  = idt_graph( 'GET', idt_social_opt( 'instagram' ), array( 'fields' => 'username', 'access_token' => $tok ) );
		$pg  = idt_graph( 'GET', idt_social_opt( 'pagina' ), array( 'fields' => 'name', 'access_token' => idt_social_token_pagina() ) );
		$msg = 'Instagram: ' . ( isset( $ig['username'] ) ? '@' . $ig['username'] . ' ✔' : 'errore – ' . idt_graph_err( $ig ) ) . ' · Facebook: ' . ( isset( $pg['name'] ) ? $pg['name'] . ' ✔' : 'errore – ' . idt_graph_err( $pg ) );
		idt_social_log( 'Prova collegamento: ' . $msg );
	} elseif ( 'ferma' === $a || 'riprendi' === $a ) {
		$u     = idt_social_prossima();
		$ferme = (array) get_option( 'idt_social_ferme', array() );
		if ( $u ) {
			$ferme = 'ferma' === $a ? array_values( array_unique( array_merge( $ferme, array( $u['data'] ) ) ) ) : array_values( array_diff( $ferme, array( $u['data'] ) ) );
			update_option( 'idt_social_ferme', $ferme, false );
			$msg = ( 'ferma' === $a ? 'Uscita del ' : 'Ripresa l\'uscita del ' ) . $u['data'] . ( 'ferma' === $a ? ' fermata.' : '.' );
			idt_social_log( $msg );
		}
	} elseif ( 'ora' === $a ) {
		$msg = 'Pubblica adesso: ' . idt_social_controlla( true );
	}
	wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $msg ), admin_url( 'tools.php?page=idt-social' ) ) );
	exit;
} );

function idt_social_pagina() {
	$o = get_option( 'idt_social', array() );
	$u = idt_social_prossima();
	?>
	<div class="wrap">
		<h1>Uscite social del martedì</h1>
		<?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-info"><p><?php echo esc_html( wp_unslash( $_GET['msg'] ) ); // phpcs:ignore ?></p></div><?php endif; ?>
		<?php if ( isset( $_GET['salvato'] ) ) : ?><div class="notice notice-success"><p>Impostazioni salvate.</p></div><?php endif; ?>
		<h2>Prossima uscita</h2>
		<?php if ( $u ) : ?>
		<p><strong><?php echo esc_html( $u['data'] ); ?></strong> · pubblicazione alle <?php echo esc_html( isset( $u['pubblica_alle'] ) ? $u['pubblica_alle'] : '?' ); ?> · stato: <?php echo esc_html( in_array( $u['data'], (array) get_option( 'idt_social_ferme', array() ), true ) ? 'FERMATA' : ( isset( $u['stato'] ) ? $u['stato'] : '' ) ); ?> · <?php echo (int) count( (array) $u['slide'] ); ?> immagini</p>
		<?php else : ?><p>Nessuna uscita preparata.</p><?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px;flex-wrap:wrap">
			<?php wp_nonce_field( 'idt_social_az' ); ?><input type="hidden" name="action" value="idt_social_azione">
			<button class="button" name="azione" value="prova">Prova il collegamento</button>
			<button class="button" name="azione" value="ferma">Ferma questa uscita</button>
			<button class="button" name="azione" value="riprendi">Riprendi</button>
			<button class="button button-primary" name="azione" value="ora">Pubblica adesso</button>
		</form>
		<h2>Collegamento a Meta</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'idt_social' ); ?><input type="hidden" name="action" value="idt_social_salva">
			<table class="form-table">
				<tr><th>Pubblicazione automatica</th><td><label><input type="checkbox" name="attivo" value="1" <?php checked( ! empty( $o['attivo'] ) ); ?>> attiva</label></td></tr>
				<tr><th><label for="t">Chiave di accesso (token)</label></th><td><input id="t" type="password" name="token" class="regular-text" autocomplete="off" placeholder="<?php echo empty( $o['token'] ) ? 'incolla qui la chiave' : 'già salvata – lascia vuoto per non cambiarla'; ?>"></td></tr>
				<tr><th><label for="i">ID account Instagram</label></th><td><input id="i" name="instagram" class="regular-text" value="<?php echo esc_attr( isset( $o['instagram'] ) ? $o['instagram'] : '17841465667170223' ); ?>"></td></tr>
				<tr><th><label for="p">ID pagina Facebook</label></th><td><input id="p" name="pagina" class="regular-text" value="<?php echo esc_attr( isset( $o['pagina'] ) ? $o['pagina'] : '112947764837' ); ?>"></td></tr>
				<tr><th><label for="v">Versione Graph API</label></th><td><input id="v" name="versione" class="small-text" value="<?php echo esc_attr( isset( $o['versione'] ) ? $o['versione'] : 'v23.0' ); ?>"></td></tr>
			</table>
			<?php submit_button( 'Salva' ); ?>
		</form>
		<h2>Registro</h2>
		<pre style="background:#fff;padding:12px;max-height:340px;overflow:auto"><?php echo esc_html( implode( "\n", (array) get_option( 'idt_social_log', array() ) ) ); ?></pre>
	</div>
	<?php
}
