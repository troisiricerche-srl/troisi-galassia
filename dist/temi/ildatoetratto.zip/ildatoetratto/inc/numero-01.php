<?php
/* Numero 1 – Ottobre 2026: versione web della newsletter (generata da build_numero.py). */
if ( ! defined( 'ABSPATH' ) ) { exit; }
return array(
	'title' => 'Il dato è tratto™ 2016–2026: solo l\'11,8% degli italiani fa da sé la dichiarazione online',
	'slug' => 'numero-1-ottobre-2026',
	'date' => '2026-09-29 10:00:00',
	'excerpt' => 'Il dato del mese, tre numeri, otto analisi con i grafici e un gioco: salari e inflazione, PA digitale, benessere al lavoro, giovani, competenze, imprese, export e partecipazione.',
	'meta' => json_decode('{"numero": 1, "mese": "Ottobre 2026", "data": "2026-10-01", "dato_num": "11,8%", "dato_testo": "degli italiani presenta da sé, online, la dichiarazione dei redditi. La media UE è 38,2%, la Danimarca arriva a 84,9%.", "tre": [["−7,1%", "il potere d\'acquisto dei salari orari italiani in cinque anni", "#D95C14"], ["43,5%", "l\'elettricità prodotta in Italia da fonti rinnovabili nel 2025", "#00856A"], ["68,9%", "le imprese italiane che formano il personale, sopra la media UE", "#004D8C"]], "img": "https://www.customerpa.it/wp-content/uploads/2026/09/newsletter-01-dichiarazione-redditi-online.png"}', true),
	'content' => <<<'IDTHTML'
<p class="idt-lead">«Il dato è tratto»: i numeri che i nostri osservatori hanno analizzato nelle ultime settimane, con i grafici originali e una lettura in poche righe. Dati ufficiali, fonti sempre citate.</p>
<section class="idt-sec"><h2 class="idt-kicker">Il mese in tre numeri</h2><div class="idt-tre">
<div class="idt-num" style="--c:#D95C14"><strong>−7,1%</strong><span>il potere d&#x27;acquisto dei salari orari italiani in cinque anni</span></div>
<div class="idt-num" style="--c:#00856A"><strong>43,5%</strong><span>l&#x27;elettricità prodotta in Italia da fonti rinnovabili nel 2025</span></div>
<div class="idt-num" style="--c:#004D8C"><strong>68,9%</strong><span>le imprese italiane che formano il personale, sopra la media UE</span></div>
</div></section>
<section class="idt-sec idt-dato"><h2 class="idt-kicker">Il dato del mese</h2>
<div class="idt-dato-top"><strong>11,8%</strong><p>degli italiani presenta da sé, online, la dichiarazione dei redditi. La media UE è 38,2%, la Danimarca arriva a 84,9%.</p></div>
<p class="idt-tema">PA e cittadini · <a href="https://www.customerpa.it/2026/09/01/dichiarazione-redditi-online-italia-europa-2025/">customerpa.it</a></p>
<figure><a href="https://www.customerpa.it/2026/09/01/dichiarazione-redditi-online-italia-europa-2025/"><img src="https://www.customerpa.it/wp-content/uploads/2026/09/newsletter-01-dichiarazione-redditi-online.png" alt="Persone che hanno presentato online la propria dichiarazione dei redditi, 2025 (%)" loading="lazy"></a><figcaption>Persone che hanno presentato online la propria dichiarazione dei redditi, 2025 (%). Fonte: Eurostat. Elaborazione Troisi Ricerche.</figcaption></figure>
<p><a class="idt-more" href="https://www.customerpa.it/2026/09/01/dichiarazione-redditi-online-italia-europa-2025/">Leggi l'analisi completa →</a></p></section>
<section class="idt-sec"><h2>Le analisi del mese</h2>
<article class="idt-card"><p class="idt-tema">Economia · <a href="https://www.troisiinsight.it/">troisiinsight.it</a></p>
<h3><a href="https://www.troisiinsight.it/2026/09/28/salari-orari-inflazione-italia-secondo-trimestre-2026/">Salari orari, l&#x27;Italia torna sotto l&#x27;inflazione: +2,1% contro il 3,0%</a></h3><p>Nel secondo trimestre 2026 le retribuzioni orarie italiane crescono del 2,1%, meno dell&#x27;inflazione (3,0%): non succedeva da metà 2023. In cinque anni la perdita reale è del 7,1%.</p>
<figure><a href="https://www.troisiinsight.it/2026/09/28/salari-orari-inflazione-italia-secondo-trimestre-2026/"><img src="https://www.troisiinsight.it/wp-content/uploads/2026/09/newsletter-01-salari-inflazione.png" alt="Italia: retribuzioni orarie e inflazione, variazione annua, 2022-2026" loading="lazy"></a><figcaption>Italia: retribuzioni orarie e inflazione, variazione annua, 2022-2026. Fonte: Eurostat. Elaborazione Troisi Ricerche.</figcaption></figure>
<p><a class="idt-more" href="https://www.troisiinsight.it/2026/09/28/salari-orari-inflazione-italia-secondo-trimestre-2026/">Leggi l'analisi completa →</a></p></article>
<article class="idt-card"><p class="idt-tema">PA digitale · <a href="https://www.digitalizzazionenellapa.it/">digitalizzazionenellapa.it</a></p>
<h3><a href="https://www.digitalizzazionenellapa.it/2026/09/24/decennio-digitale-2030-pagella-italia/">Decennio digitale 2030: la pagella dell&#x27;Italia, obiettivo per obiettivo</a></h3><p>Competenze digitali, reti e digitalizzazione delle imprese: quanto manca all&#x27;Italia per ciascun obiettivo europeo del 2030.</p>
<figure><a href="https://www.digitalizzazionenellapa.it/2026/09/24/decennio-digitale-2030-pagella-italia/"><img src="https://www.digitalizzazionenellapa.it/wp-content/uploads/2026/09/newsletter-01-decennio-digitale.png" alt="Quanto manca agli obiettivi 2030" loading="lazy"></a><figcaption>Quanto manca agli obiettivi 2030. Fonte: Eurostat. Elaborazione Troisi Ricerche.</figcaption></figure>
<p><a class="idt-more" href="https://www.digitalizzazionenellapa.it/2026/09/24/decennio-digitale-2030-pagella-italia/">Leggi l'analisi completa →</a></p></article>
<article class="idt-card"><p class="idt-tema">Organizzazioni · <a href="https://www.benessereorganizzativo.it/">benessereorganizzativo.it</a></p>
<h3><a href="https://www.benessereorganizzativo.it/benessere-lavoro-italia-12-indicatori-sintesi/">Il benessere al lavoro in Italia in 12 indicatori</a></h3><p>Dodici indicatori europei messi in fila: dove l&#x27;Italia fa meglio della media UE e dove resta indietro. Una sintesi per chi gestisce persone, nel pubblico e nel privato.</p>
<figure><a href="https://www.benessereorganizzativo.it/benessere-lavoro-italia-12-indicatori-sintesi/"><img src="https://www.benessereorganizzativo.it/wp-content/uploads/2026/09/newsletter-01-benessere-12-indicatori.png" alt="Differenza tra Italia e media UE su 12 indicatori" loading="lazy"></a><figcaption>Differenza tra Italia e media UE su 12 indicatori. Fonte: Eurostat. Elaborazione Troisi Ricerche.</figcaption></figure>
<p><a class="idt-more" href="https://www.benessereorganizzativo.it/benessere-lavoro-italia-12-indicatori-sintesi/">Leggi l'analisi completa →</a></p></article>
<article class="idt-card"><p class="idt-tema">Giovani · <a href="https://www.benesseredigitalegiovani.it/">benesseredigitalegiovani.it</a></p>
<h3><a href="https://www.benesseredigitalegiovani.it/quadro-insieme-benessere-digitale-giovani-italia/">Sei mesi di dati sul benessere digitale dei giovani italiani</a></h3><p>Diciassette indicatori europei: rispetto alla media UE i ragazzi italiani sono meno presenti sui social, leggono meno notizie e usano meno l&#x27;intelligenza artificiale.</p>
<figure><a href="https://www.benesseredigitalegiovani.it/quadro-insieme-benessere-digitale-giovani-italia/"><img src="https://www.benesseredigitalegiovani.it/wp-content/uploads/2026/09/newsletter-01-giovani-digitale.png" alt="Giovani 16-24 anni: alcuni indicatori a confronto" loading="lazy"></a><figcaption>Giovani 16-24 anni: alcuni indicatori a confronto. Fonte: Eurostat. Elaborazione Troisi Ricerche.</figcaption></figure>
<p><a class="idt-more" href="https://www.benesseredigitalegiovani.it/quadro-insieme-benessere-digitale-giovani-italia/">Leggi l'analisi completa →</a></p></article>
<div class="idt-grid2">
<article class="idt-card idt-card-sm"><p class="idt-tema">Competenze · <a href="https://www.mappaturadellecompetenze.it/">mappaturadellecompetenze.it</a></p>
<figure><a href="https://www.mappaturadellecompetenze.it/2026/09/20/capitale-umano-inutilizzato-slack-italia/"><img src="https://www.mappaturadellecompetenze.it/wp-content/uploads/2026/09/newsletter-01-lavoro-inutilizzato.png" alt="Componenti del lavoro potenziale inutilizzato, 2025" loading="lazy"></a><figcaption>Componenti del lavoro potenziale inutilizzato, 2025. Fonte: Eurostat.</figcaption></figure>
<h3><a href="https://www.mappaturadellecompetenze.it/2026/09/20/capitale-umano-inutilizzato-slack-italia/">Lavoro potenziale inutilizzato: in Italia è il 14,7%</a></h3><p>Nel 2025 il 14,7% della forza lavoro allargata italiana vorrebbe lavorare, o lavorare di più, senza riuscirci. La media UE è 11,0%; nel 2015 l&#x27;Italia era al 26,1%.</p></article>
<article class="idt-card idt-card-sm"><p class="idt-tema">Imprese · <a href="https://www.governancefinanziaria.it/">governancefinanziaria.it</a></p>
<figure><a href="https://www.governancefinanziaria.it/nascite-cessazioni-imprese-italia-europa-2023/"><img src="https://www.governancefinanziaria.it/wp-content/uploads/2026/09/newsletter-01-natalita-imprese.png" alt="Tassi di natalità e mortalità delle imprese, 2021-2023" loading="lazy"></a><figcaption>Tassi di natalità e mortalità delle imprese, 2021-2023. Fonte: Eurostat.</figcaption></figure>
<h3><a href="https://www.governancefinanziaria.it/nascite-cessazioni-imprese-italia-europa-2023/">Nuove imprese: in Italia ne nascono 7,8 ogni 100 attive</a></h3><p>Nel 2023 il tasso di natalità delle imprese italiane è stato del 7,8%, contro il 10,5% della media UE: l&#x27;Italia è terzultima. Anche il tasso di mortalità (6,5%) è sotto la media.</p></article>
<article class="idt-card idt-card-sm"><p class="idt-tema">Export · <a href="https://www.consulenzainternazionalizzazione.it/">consulenzainternazionalizzazione.it</a></p>
<figure><a href="https://www.consulenzainternazionalizzazione.it/?p=96"><img src="https://www.consulenzainternazionalizzazione.it/wp-content/uploads/2026/09/newsletter-01-export-mezzogiorno.png" alt="Export delle regioni del Mezzogiorno, gennaio-giugno 2026" loading="lazy"></a><figcaption>Export delle regioni del Mezzogiorno, gennaio-giugno 2026. Fonte: ISTAT.</figcaption></figure>
<h3><a href="https://www.consulenzainternazionalizzazione.it/?p=96">Export delle regioni nel primo semestre 2026: Puglia +15,2%</a></h3><p>Il Mezzogiorno ha esportato 35,1 miliardi di euro (+5,2%), in linea con l&#x27;Italia (+4,5%). La Puglia sale a 5,4 miliardi, dopo un primo semestre 2025 in calo.</p></article>
<article class="idt-card idt-card-sm"><p class="idt-tema">Territori · <a href="https://www.dibattito-pubblico.it/">dibattito-pubblico.it</a></p>
<figure><a href="https://www.dibattito-pubblico.it/2026/09/25/quadro-insieme-partecipazione-infrastrutture-italia/"><img src="https://www.dibattito-pubblico.it/wp-content/uploads/2026/09/newsletter-01-partecipazione.png" alt="Partecipazione e inclusione: Italia e media UE" loading="lazy"></a><figcaption>Partecipazione e inclusione: Italia e media UE. Fonte: Eurostat.</figcaption></figure>
<h3><a href="https://www.dibattito-pubblico.it/2026/09/25/quadro-insieme-partecipazione-infrastrutture-italia/">Partecipazione, fiducia e infrastrutture: sei mesi di dati</a></h3><p>Diciassette indicatori europei: l&#x27;Italia fa meglio della media UE in 5, è in linea in 3 e fa peggio in 9. Il punto più debole è la partecipazione civica tradizionale, il più forte quella online.</p></article>
</div></section>
<section class="idt-sec idt-gioca"><h2 class="idt-kicker">Gioca con la statistica</h2>
<h3>Quante auto ci sono in Italia ogni 1.000 abitanti?</h3>
<p class="idt-opzioni"><span>450</span><span>580</span><span>701</span></p>
<p>La risposta, e altre nove domande sull'Italia, sono nel nostro gioco. Trovi anche il sondaggio perfetto, il paradosso del compleanno e le tre porte.</p>
<p><a class="idt-btn" href="https://www.troisiricerche.net/giochi-statistica/">Gioca e scopri la risposta →</a></p></section>
<section class="idt-sec"><h2>In breve</h2><ul class="idt-breve">
<li><span>customerpa.it</span><a href="https://www.customerpa.it/2026/09/22/pa-online-italia-2008-2025-diciotto-anni/">Diciotto anni di PA online: l&#x27;Italia ha raddoppiato gli utenti, ma il divario con l&#x27;Europa non si chiude</a></li>
<li><span>troisiinsight.it</span><a href="https://www.troisiinsight.it/2026/09/21/energia-rinnovabile-2025-italia-20-per-cento-europa/">Rinnovabili: l&#x27;Europa al 26%, l&#x27;Italia al 20,5%. Ma sulla sola elettricità siamo al 43%</a></li>
<li><span>governancefinanziaria.it</span><a href="https://www.governancefinanziaria.it/quadro-insieme-imprese-italiane-finanza-esg-digitale/">Imprese italiane tra finanza, ESG e digitale: meglio della media UE in 8 indicatori su 13</a></li>
<li><span>mappaturadellecompetenze.it</span><a href="https://www.mappaturadellecompetenze.it/2026/09/27/quadro-insieme-competenze-italia-europa/">Competenze in Italia: in linea con la media UE in 3 indicatori su 18, ma la distanza si riduce</a></li>
</ul></section>
IDTHTML
);
