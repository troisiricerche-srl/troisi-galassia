<?php
/**
 * 1.4.0 – Il singolo dato in profondità.
 * Ogni articolo dell'archivio ha una pagina /dato/<sito>/<id>/ con il numero composto a puntini
 * nel colore del suo tema e il testo completo dell'analisi, letto dal sito d'origine.
 * L'originale resta la fonte: la pagina punta a esso con rel=canonical e non viene indicizzata.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Sito => [parola che scorre, colore acceso su fondo scuro]. Il nome del tema viene da idt_fonti(). */
function idt_parole() {
	return array(
		'troisiinsight.it'                    => array( "l'economia", '#FF6F6F' ),
		'digitalizzazionenellapa.it'          => array( 'la PA digitale', '#46C9F2' ),
		'dibattito-pubblico.it'               => array( 'i territori', '#7EA6FF' ),
		'governancefinanziaria.it'            => array( 'le imprese', '#FFB020' ),
		'mappaturadellecompetenze.it'         => array( 'le competenze', '#41DDA0' ),
		'benesseredigitalegiovani.it'         => array( 'i giovani', '#C9A7FF' ),
		'benessereorganizzativo.it'           => array( 'il lavoro', '#F59AD0' ),
		'customerpa.it'                       => array( 'i servizi pubblici', '#FF9F5A' ),
		'consulenzainternazionalizzazione.it' => array( "l'export", '#9BE15D' ),
	);
}

/** Primo numero «da copertina» nel titolo: prima le percentuali, poi gli altri numeri (anni esclusi). */
function idt_numero_titolo( $t ) {
	if ( preg_match( '/[+\-−]?\d{1,3}(?:[.,]\d+)?\s?%/u', $t, $m ) ) {
		return str_replace( array( ' %', '-' ), array( '%', '−' ), $m[0] );
	}
	if ( preg_match_all( '/[+\-−]?\d{1,3}(?:\.\d{3})+|[+\-−]?\d+(?:,\d+)?/u', $t, $mm ) ) {
		foreach ( $mm[0] as $n ) {
			$pulito = ltrim( $n, '+-−' );
			if ( preg_match( '/^(19|20)\d\d$/', $pulito ) || '0' === $pulito ) {
				continue;
			}
			return str_replace( '-', '−', $n );
		}
	}
	return '';
}


/** Parola e colore scelti dal titolo (il tema vero del dato); se nessuna regola combacia, si usa quella del sito. */
function idt_parola_titolo( $t, $h ) {
	$regole = array(
		'/salar|stipend|retribu|potere d.acquisto/iu'                    => array( 'i salari', '#C9A7FF' ),
		'/prezzi delle case|abitazion|affitt|mutu|immobil/iu'           => array( 'la casa', '#F59AD0' ),
		'/laureat|universit|terziari/iu'                                 => array( "l'università", '#46C9F2' ),
		'/scuola|abbandon|pisa|quindicenn|student|istruzion/iu'          => array( 'la scuola', '#41DDA0' ),
		'/pa online|pubblica amministrazione|servizi pubblici|e-gov/iu'  => array( 'la PA digitale', '#7EA6FF' ),
		'/ict|digital|competenz/iu'                                      => array( 'le competenze digitali', '#FFB020' ),
		'/disoccupa|occupat|occupazion|mercato del lavoro/iu'            => array( 'il lavoro', '#FF6F6F' ),
		'/ambient|clima|emission|energi|rifiut/iu'                       => array( "l'ambiente", '#9BE15D' ),
		'/mortalit|sanit|salute|ospedal/iu'                              => array( 'la salute', '#FF9F5A' ),
		'/psicosocial|benessere|stress/iu'                               => array( 'il benessere al lavoro', '#F59AD0' ),
		'/export|esporta|internazionalizz|simest/iu'                     => array( "l'export", '#9BE15D' ),
		'/giovan|ragazz|social/iu'                                       => array( 'i giovani', '#C9A7FF' ),
		'/impres|pmi|credit|finanz/iu'                                   => array( 'le imprese', '#FFB020' ),
		'/inflazion|pil\b|crescita|economi/iu'                          => array( "l'economia", '#FF6F6F' ),
	);
	foreach ( $regole as $re => $v ) {
		if ( preg_match( $re, $t ) ) {
			return $v;
		}
	}
	$p = idt_parole();
	return isset( $p[ $h ] ) ? $p[ $h ] : array( "l'Italia", '#FFB020' );
}

function idt_dato_url( $it ) {
	if ( ! empty( $it['i'] ) && isset( idt_parole()[ $it['s'] ] ) ) {
		return home_url( '/dato/' . $it['s'] . '/' . (int) $it['i'] . '/' );
	}
	return $it['u'];
}

/** I dati dell'apertura: per ogni tema l'ultimo articolo con un numero nel titolo. */
function idt_apertura_dati() {
	$items = get_option( 'idt_archivio', array() );
	$par   = idt_parole();
	$fonti = idt_fonti();
	$out   = array();
	$usate = array();
	foreach ( $par as $h => $p ) {
		foreach ( (array) $items as $it ) {
			if ( $it['s'] !== $h ) {
				continue;
			}
			$n = idt_numero_titolo( $it['t'] );
			if ( '' === $n ) {
				continue;
			}
			$pc = idt_parola_titolo( $it['t'], $h );
			if ( isset( $usate[ $pc[0] ] ) ) {
				$pc = isset( $par[ $h ] ) && ! isset( $usate[ $par[ $h ][0] ] ) ? $par[ $h ] : null;
			}
			if ( ! $pc ) {
				break;
			}
			$usate[ $pc[0] ] = 1;
			$out[] = array(
				'p' => $pc[0],
				'c' => $pc[1],
				't' => mb_strtoupper( mb_substr( $pc[0], 0, 1 ) ) . mb_substr( $pc[0], 1 ),
				'n' => $n,
				'x' => $it['t'],
				'f' => 'Fonte: ' . ( isset( $fonti[ $h ] ) ? $fonti[ $h ][1] : $h ) . ' · ' . $h,
				'u' => idt_dato_url( $it ),
				'd' => $it['d'],
			);
			break;
		}
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( $b['d'], $a['d'] );
	} );
	return array_slice( $out, 0, 9 );
}

/* ---------- indirizzi /dato/<sito>/<id>/ ---------- */
add_action( 'init', function () {
	add_rewrite_rule( '^dato/([a-z0-9.\-]+)/([0-9]+)/?$', 'index.php?idt_host=$matches[1]&idt_pid=$matches[2]', 'top' );
} );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'idt_host';
	$v[] = 'idt_pid';
	return $v;
} );

function idt_dato_corrente() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$h  = get_query_var( 'idt_host' );
	$id = (int) get_query_var( 'idt_pid' );
	if ( ! $h || ! $id || ! isset( idt_parole()[ $h ] ) ) {
		return $cache = false;
	}
	$chiave = 'idt_dato_' . md5( $h . '|' . $id );
	$d      = get_transient( $chiave );
	if ( false === $d ) {
		$r = wp_remote_get( idt_archivio_url_api( $h, '/wp/v2/posts/' . $id, array( '_fields' => 'id,date,link,title,content,excerpt' ) ), array( 'timeout' => 15 ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return $cache = false;
		}
		$p = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $p['id'] ) ) {
			return $cache = false;
		}
		$d = array(
			'h' => $h,
			'i' => (int) $p['id'],
			'd' => substr( (string) $p['date'], 0, 10 ),
			'u' => esc_url_raw( $p['link'] ),
			't' => trim( html_entity_decode( wp_strip_all_tags( $p['title']['rendered'] ), ENT_QUOTES, 'UTF-8' ) ),
			'e' => trim( html_entity_decode( wp_strip_all_tags( $p['excerpt']['rendered'] ), ENT_QUOTES, 'UTF-8' ) ),
			'c' => idt_dato_pulisci( $p['content']['rendered'] ),
		);
		set_transient( $chiave, $d, 6 * HOUR_IN_SECONDS );
	}
	return $cache = $d;
}

/** Il contenuto viene dai siti di Troisi Ricerche: si tolgono comunque script, iframe e gestori di eventi. */
function idt_dato_pulisci( $html ) {
	$html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $html );
	$html = preg_replace( '#<iframe\b[^>]*>.*?</iframe>#is', '', $html );
	$html = preg_replace( '/\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html );
	$html = preg_replace( '/(href|src)\s*=\s*(["\'])\s*javascript:[^"\']*\2/i', '$1="#"', $html );
	return $html;
}

add_filter( 'template_include', function ( $tpl ) {
	if ( get_query_var( 'idt_host' ) ) {
		if ( idt_dato_corrente() ) {
			status_header( 200 );
			global $wp_query;
			$wp_query->is_404 = false;
			return get_template_directory() . '/templates/dato.php';
		}
	}
	return $tpl;
} );

add_filter( 'pre_get_document_title', function ( $t ) {
	$d = get_query_var( 'idt_host' ) ? idt_dato_corrente() : false;
	return $d ? $d['t'] . ' · Il dato è tratto' : $t;
} );

add_action( 'wp_head', function () {
	$d = get_query_var( 'idt_host' ) ? idt_dato_corrente() : false;
	if ( ! $d ) {
		return;
	}
	echo '<link rel="canonical" href="' . esc_url( $d['u'] ) . '">' . "\n";
	echo '<meta name="description" content="' . esc_attr( wp_trim_words( $d['e'], 30, '…' ) ) . '">' . "\n";
}, 1 );
remove_action( 'wp_head', 'rel_canonical' );
add_action( 'wp', function () {
	if ( ! get_query_var( 'idt_host' ) ) {
		add_action( 'wp_head', 'rel_canonical' );
	}
} );

/** Script dei puntini solo dove serve. */
add_action( 'wp_enqueue_scripts', function () {
	if ( is_front_page() || get_query_var( 'idt_host' ) ) {
		wp_enqueue_script( 'idt-punti', get_template_directory_uri() . '/assets/punti.js', array(), IDT_VERSION, true );
	}
} );

/** Altri articoli dello stesso sito, per continuare a leggere. */
function idt_dato_altri( $h, $escludi, $quanti = 3 ) {
	$out = array();
	foreach ( (array) get_option( 'idt_archivio', array() ) as $it ) {
		if ( $it['s'] === $h && ( empty( $it['i'] ) || (int) $it['i'] !== (int) $escludi ) ) {
			$out[] = $it;
			if ( count( $out ) >= $quanti ) {
				break;
			}
		}
	}
	return $out;
}

/** Le pagine /dato/ non si indicizzano: l'originale è sul sito dell'osservatorio. */
add_filter( 'wp_robots', function ( $r ) {
	if ( get_query_var( 'idt_host' ) ) {
		$r['noindex'] = true;
		$r['follow']  = true;
		unset( $r['max-image-preview'] );
	}
	return $r;
}, 99 );
