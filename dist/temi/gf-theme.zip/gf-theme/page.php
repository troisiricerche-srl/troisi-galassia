<?php get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
<div class="gf-page-header"><div class="gf-container"><h1><?php the_title(); ?></h1></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">
  <?php the_content(); ?>
</div></div></section>
<?php endwhile; ?>
<?php get_footer(); ?>
