<?php /** Template Name: Indagine */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>Indagine su 400 Manager</h1><p>I risultati della ricerca nazionale sulle competenze di governance finanziaria</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">

<h2>Metodologia</h2>
<p>L'indagine ha raccolto il parere di <strong>oltre 400 tra imprenditori, manager e dirigenti</strong> provenienti da circa <strong>340 imprese</strong> con sede nel territorio nazionale.</p>
<p>Le indagini sono state svolte in modalità <strong>CATI</strong> (Computer Assisted Telephone Interview) e <strong>CAWI</strong> (Computer Assisted Web Interview), coordinate da <strong>Troisi Ricerche S.r.l.</strong> con la supervisione scientifica dello Steering Group.</p>

<div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.5rem;margin:2rem 0;">
  <h3 style="color:var(--gf-navy);font-size:1rem;margin-bottom:.75rem;">Scheda tecnica</h3>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Campione:</strong> oltre 400 imprenditori, manager e dirigenti</p>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Imprese coinvolte:</strong> circa 340, sede nel territorio nazionale</p>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Metodologia:</strong> CATI + CAWI</p>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Coordinamento:</strong> Troisi Ricerche S.r.l.</p>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Steering Group:</strong> 6 professori universitari (Amministrativo-Finanziario, Digitalizzazione, Sostenibilità)</p>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Comitato scientifico:</strong> prof. Corrado Crocetta, DIRIUM UniBa</p>
  <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Committente:</strong> Fondirigenti</p>
  <p style="font-size:.88rem;"><strong>Progetto:</strong> n. 74/2020 — CIG 833608207D</p>
</div>

<h2>Il modello: dalle 15 alle 10 competenze strategiche</h2>
<p>Lo Steering Group ha inizialmente identificato <strong>15 competenze strategiche</strong> per garantire la crescita sostenibile delle imprese. Dalla survey quantitativa sono state poi selezionate le <strong>10 competenze</strong> che presentavano elevati livelli di importanza ma con livelli non adeguati di presidio.</p>

<div class="gf-grid gf-grid-2" style="margin:1.5rem 0;gap:1rem;">
  <div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.25rem;">
    <h3 style="color:var(--gf-navy);font-size:.95rem;margin-bottom:.5rem;">Dinamiche di Board</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-80);line-height:1.6;">1. Programmazione economico finanziaria (BP/Analisi di scenario)<br>2. Gestione degli Economics (Budget/Costi/Ricavi/Margine)<br>3. Risk Management Finanziario in situazione di incertezza</p>
  </div>
  <div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.25rem;">
    <h3 style="color:var(--gf-navy);font-size:.95rem;margin-bottom:.5rem;">Digital &amp; Innovation</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-80);line-height:1.6;">4. IT Security &amp; Privacy<br>5. Data Governance in contesti di cambiamento continuo</p>
  </div>
  <div style="background:var(--gf-gold-light);border-radius:var(--gf-radius-lg);padding:1.25rem;">
    <h3 style="color:var(--gf-gold-dark);font-size:.95rem;margin-bottom:.5rem;">Sustainability</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-80);line-height:1.6;">6. Valutazione/Monitoraggio impatti del Climate Change<br>7. Orientamento al valore condiviso<br>8. Benefici finanziari da modelli di Economia Circolare</p>
  </div>
  <div style="background:var(--gf-teal-light);border-radius:var(--gf-radius-lg);padding:1.25rem;">
    <h3 style="color:var(--gf-teal);font-size:.95rem;margin-bottom:.5rem;">Competenze Trasversali</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-80);line-height:1.6;">9. Il Change Management<br>10. Leadership etica e sostenibile</p>
  </div>
</div>

<h2>Il Maturity Model</h2>
<p>Il progetto include un <strong>Maturity Model</strong> a 5 livelli — dal "tendenzialmente non presente" al "espresso proattivamente in contesti particolarmente complessi" — per consentire al management di autovalutare il presidio su ciascuna competenza e programmare piani formativi mirati.</p>

<h2>Risultati principali</h2>
<div style="background:var(--gf-gold-light);border-radius:var(--gf-radius-lg);padding:1.5rem;margin:1.5rem 0;">
  <p style="font-size:.88rem;font-style:italic;color:var(--gf-gold-dark);">I risultati completi dell'indagine sono stati presentati alla Camera dei Deputati il 25 marzo e sono disponibili nel report finale del progetto. Se hai partecipato all'indagine o desideri una copia del report, <a href="<?php echo home_url('/contatti/'); ?>">contattaci</a>.</p>
</div>

<p style="text-align:center;margin-top:2rem;"><a href="<?php echo home_url('/camera-deputati/'); ?>" class="gf-btn gf-btn-primary">Vedi la presentazione alla Camera &rarr;</a></p>

</div></div></section>
<?php get_footer(); ?>
