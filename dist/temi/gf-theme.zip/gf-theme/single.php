<?php get_header(); ?>
<?php while(have_posts()):the_post(); ?>
<div class="gf-single-header">
  <div class="gf-single-meta"><?php $cats=get_the_category();if($cats)echo '<span style="color:var(--gf-gold);font-weight:600;">'.esc_html($cats[0]->name).'</span> · '; echo get_the_date('j F Y'); ?></div>
  <h1><?php the_title(); ?></h1>
</div>
<div class="gf-single-content">
  <?php the_content(); ?>
  <div class="gf-author-box">
    <img src="<?php echo GF_URI; ?>/img/andrea-troisi.jpg" alt="prof. Andrea Troisi" class="gf-author-photo">
    <div>
      <div style="font-weight:600;color:var(--gf-ink);margin-bottom:.2rem;">Troisi Ricerche</div>
      <p style="font-size:.82rem;color:var(--gf-ink-50);margin:0;">Istituto di ricerca accreditato MIUR dal 2006. Specializzato in governance finanziaria, ESG, customer satisfaction e metodologie di ricerca applicate. <a href="<?php echo home_url('/servizi/'); ?>">Scopri i servizi →</a></p>
    </div>
  </div>
  <div style="background:var(--gf-gold-light);border-radius:var(--gf-radius-lg);padding:1.5rem;margin-top:2rem;text-align:center;">
    <h3 style="color:var(--gf-gold-dark);font-size:1rem;margin-bottom:.5rem;">Quanto è preparata la tua impresa?</h3>
    <p style="font-size:.88rem;color:var(--gf-ink-80);margin-bottom:1rem;">Fai il test gratuito di governance finanziaria e ESG — 5 minuti, risultato immediato.</p>
    <a href="<?php echo home_url('/checker/'); ?>" class="gf-btn gf-btn-gold">Fai il test →</a>
  </div>
</div>
<?php endwhile; ?>
<?php get_footer(); ?>
