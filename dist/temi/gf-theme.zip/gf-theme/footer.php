<?php if (!defined('ABSPATH')) exit; ?>

<footer class="gf-footer">
  <div class="gf-container">
    <div class="gf-footer-grid">
      <div>
        <div class="gf-logo" style="margin-bottom:1rem;">
          <div class="gf-logo-icon" style="width:28px;height:28px;font-size:12px;border-radius:6px;">GF</div>
          <div><div class="gf-logo-text" style="color:rgba(248,249,252,.7);font-size:.9rem;">Governance Finanziaria</div></div>
        </div>
        <p style="max-width:280px;line-height:1.7;">Progetto promosso da <strong style="color:rgba(248,249,252,.6);">Fondirigenti</strong> e realizzato da Troisi Ricerche, Links Management e SCS Consulting. Modello di competenze per la governance finanziaria d'impresa.</p>
        <p style="margin-top:1rem;font-size:.75rem;"><a href="https://troisiricerche.net" target="_blank" rel="noopener" style="color:rgba(248,249,252,.5);">Troisi Ricerche S.r.l.</a> &middot; Accreditata MIUR &middot; Dal 2006</p>
        <div class="gf-footer-social">
          <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener" aria-label="LinkedIn"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg></a>
          <a href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener" aria-label="YouTube"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a>
        </div>
      </div>
      <div>
        <h4>Progetto</h4>
        <a href="<?php echo home_url('/progetto/'); ?>">Il progetto</a>
        <a href="<?php echo home_url('/indagine/'); ?>">Indagine 400 manager</a>
        <a href="<?php echo home_url('/video-pillole/'); ?>">10 video pillole</a>
        <a href="<?php echo home_url('/webinar/'); ?>">5 webinar</a>
        <a href="<?php echo home_url('/camera-deputati/'); ?>">Camera dei Deputati</a>
      </div>
      <div>
        <h4>Informazioni</h4>
        <a href="<?php echo home_url('/contatti/'); ?>">Contatti</a>
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" title="Privacy Policy">Privacy policy</a>
        <a href="https://www.fondirigenti.it" target="_blank" rel="noopener">Fondirigenti</a>
      </div>
      <div>
        <h4>Galassia Troisi</h4>
        <a href="https://troisiricerche.net" target="_blank" rel="noopener">Troisi Ricerche</a>
        <a href="https://t-index.it" target="_blank" rel="noopener">TR-Index</a>
        <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener">Mappatura delle Competenze</a>
        <a href="https://registrodellecompetenze.it" target="_blank" rel="noopener">Registro delle Competenze</a>
        <a href="https://customerpa.it" target="_blank" rel="noopener">CustomerPA</a>
        <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener">BenessereOrg.</a>
        <a href="https://troisiformazione.it" target="_blank" rel="noopener">Formazione</a>
        <a href="https://tiplive.it" target="_blank" rel="noopener">TIP Platform</a>
        <a href="https://troisiinsight.it" target="_blank" rel="noopener">TroisiInsight</a>
        <a href="https://digitalizzazionenellapa.it" target="_blank" rel="noopener">DigitalizzazionePA</a>
        <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener">Dibattito Pubblico</a>
        <a href="https://voiceinhub.it" target="_blank" rel="noopener">VoiceInHub</a>
        <a href="https://governancefinanziaria.it" class="gf-active-link">Governance Fin.</a>
        <a href="https://consulenzainternazionalizzazione.it" target="_blank" rel="noopener">Internazionalizzazione</a>
        <a href="https://benesseredigitalegiovani.it" target="_blank" rel="noopener">BDG</a>
        <a href="https://andreatroisi.it" target="_blank" rel="noopener">Andrea Troisi</a>
      </div>
    </div>
    <div class="gf-footer-bottom">
      <div>&copy; <?php echo date('Y'); ?> Troisi Ricerche S.r.l. &middot; CF/P.IVA 07216100722 &middot; Via de Rossi 57, 70122 Bari</div>
      <div>Advisor strategico per governance, dati e decision making</div>
    </div>
  </div>
</footer>

<script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0]; s.src="https://cdn.iubenda.com/iubenda.js"; tag.parentNode.insertBefore(s,tag);}; if(w.addEventListener){w.addEventListener("load", loader, false);}else if(w.attachEvent){w.attachEvent("onload", loader);}else{w.onload = loader;}})(window, document);</script>
<?php wp_footer(); ?>
</body>
</html>
