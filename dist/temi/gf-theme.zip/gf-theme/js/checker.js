/**
 * Governance Finanziaria — Checker Assessment
 * Troisi Ricerche S.r.l.
 */
(function(){
'use strict';

var Q=[
{area:'Governance Finanziaria',ai:0,m:'Stai valutando la resilienza finanziaria della tua azienda.',q:'Esiste una pianificazione economico-finanziaria strutturata nella tua azienda?',o:['Non esiste un piano strutturato','Esiste ma non viene aggiornato regolarmente','Viene aggiornata annualmente con obiettivi chiari','Integrata con analisi di scenario e rivista periodicamente']},
{area:'Governance Finanziaria',ai:0,m:'La qualit\u00e0 delle decisioni dipende dalla qualit\u00e0 dei dati.',q:'Il management utilizza KPI finanziari e operativi per guidare le decisioni strategiche?',o:['Non utilizziamo KPI strutturati','Indicatori di base (fatturato, margine)','Cruscotto KPI aggiornato regolarmente','KPI avanzati collegati a obiettivi strategici e condivisi con il board']},
{area:'Governance Finanziaria',ai:0,m:'Questa dimensione \u00e8 critica per CFO e top management.',q:'Il sistema di controllo di gestione \u00e8 aggiornato e utilizzato per le decisioni?',o:['No, decisioni basate su intuizione e storico','Esiste ma utilizzato in modo discontinuo','Funziona regolarmente ma solo per il finance','Integrato nei processi decisionali di tutte le funzioni']},
{area:'Risk Management',ai:1,m:'Il 76% delle PMI italiane non ha un risk management strutturato.',q:'I rischi finanziari della tua azienda sono identificati, mappati e monitorati?',o:['Non abbiamo una mappatura dei rischi','Li identifichiamo solo quando si manifestano','Mappatura di base aggiornata periodicamente','Sistema integrato di identificazione, misurazione e monitoraggio continuo']},
{area:'Risk Management',ai:1,m:'Le nuove regole EBA richiedono previsioni realistiche per il credito.',q:'Vengono elaborati scenari previsionali per le decisioni strategiche?',o:['No, ci basiamo sulle proiezioni del passato','Solo in situazioni di crisi o su richiesta delle banche','Scenari per le principali variabili di business','Analisi multi-scenario strutturata e regolare con stress test']},
{area:'Risk Management',ai:1,m:'Molte aziende scoprono i rischi quando \u00e8 troppo tardi.',q:'Sono presenti strumenti o politiche di mitigazione dei rischi finanziari?',o:['Nessuno strumento di mitigazione','Coperture assicurative di base','Politiche di hedging e diversificazione parziali','Sistema strutturato: assicurazioni, hedging, risk tolerance definita']},
{area:'ESG e Sostenibilit\u00e0',ai:2,m:'Le variabili ESG stanno ridefinendo l\u2019accesso al mercato dei capitali.',q:'La tua azienda ha una strategia ESG definita e integrata nei processi decisionali?',o:['Non abbiamo una strategia ESG','Iniziative sparse di responsabilit\u00e0 sociale','Strategia ESG in fase di definizione','Strategia ESG strutturata e integrata nella governance finanziaria']},
{area:'ESG e Sostenibilit\u00e0',ai:2,m:'Dal 2025, la CSRD estende l\u2019obbligo di rendicontazione ESG.',q:'I fattori ESG influenzano concretamente le decisioni finanziarie e gli investimenti?',o:['No, sono aspetti separati','Solo per obblighi normativi minimi','Iniziano a influenzare alcune decisioni strategiche','Criteri ESG integrati in tutte le valutazioni di investimento e rischio']},
{area:'ESG e Sostenibilit\u00e0',ai:2,m:'Banche e investitori chiedono sempre pi\u00f9 spesso dati ESG.',q:'L\u2019azienda \u00e8 in grado di rispondere a richieste ESG di banche, investitori o clienti strategici?',o:['No, non siamo preparati','Potremmo rispondere ma con difficolt\u00e0','Dati di base pronti','Reporting ESG strutturato, aggiornato e pronto per qualsiasi stakeholder']},
{area:'AI e Decision Making',ai:3,m:'L\u2019AI sta cambiando il modo in cui le imprese prendono decisioni.',q:'La tua azienda utilizza strumenti di analisi dati avanzati o intelligenza artificiale?',o:['No, usiamo Excel e strumenti tradizionali','Strumenti di BI ma li usiamo poco','Analytics e BI regolarmente per le decisioni','AI e machine learning integrati nei processi decisionali chiave']},
{area:'AI e Decision Making',ai:3,m:'Chi non integra l\u2019AI rischia un divario competitivo crescente.',q:'Esiste una strategia per integrare l\u2019AI nei processi decisionali e operativi?',o:['No, non abbiamo considerato l\u2019AI','Ne parliamo ma non abbiamo un piano','Stiamo sperimentando in alcune aree','Strategia AI definita con roadmap, budget e KPI']},
{area:'AI e Decision Making',ai:3,m:'Il 65% dei CEO considera l\u2019AI una priorit\u00e0 strategica entro 2 anni.',q:'L\u2019impatto dell\u2019AI su ruoli, competenze e processi \u00e8 stato valutato?',o:['No, non \u00e8 stato considerato','Ne siamo consapevoli ma non abbiamo agito','Abbiamo iniziato a valutare l\u2019impatto su alcune funzioni','Assessment completo con piano di reskilling e change management']}
];

var AN=['Governance Finanziaria','Risk Management','ESG e Sostenibilit\u00e0','AI e Decision Making'];
var AC=['#1e3a5f','#8b6508','#0d7a6e','#6b21a8'];
var cur=0,ans=[];
var app,introEl;

document.addEventListener('DOMContentLoaded',function(){
  app=document.getElementById('gf-ck-app');
  introEl=document.getElementById('gf-ck-intro');
  var startBtn=document.getElementById('gf-ck-start');
  if(startBtn) startBtn.addEventListener('click',function(){
    introEl.style.display='none';
    app.style.display='block';
    renderQ();
  });
});

function renderQ(){
  var q=Q[cur],pct=Math.round((cur/Q.length)*100);
  var h='<div style="background:#fff;border-radius:20px;padding:2rem;border:1px solid rgba(15,23,42,.06);">';
  h+='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem;">';
  h+='<span style="font-size:.68rem;font-weight:600;color:'+AC[q.ai]+';text-transform:uppercase;letter-spacing:.1em;">'+q.area+'</span>';
  h+='<span style="font-size:.68rem;color:rgba(15,23,42,.4);">'+(cur+1)+' di '+Q.length+'</span></div>';
  h+='<div style="height:3px;background:rgba(15,23,42,.06);border-radius:2px;margin-bottom:1.75rem;"><div style="height:100%;background:'+AC[q.ai]+';border-radius:2px;width:'+pct+'%;transition:width .4s ease;"></div></div>';
  h+='<p style="font-size:.78rem;color:rgba(15,23,42,.4);font-style:italic;margin-bottom:1rem;">'+q.m+'</p>';
  h+='<h2 style="font-size:1.15rem;font-family:Playfair Display,serif;margin-bottom:1.5rem;line-height:1.35;">'+q.q+'</h2>';
  h+='<div style="display:flex;flex-direction:column;gap:.6rem;">';
  for(var i=0;i<q.o.length;i++){
    var lc=i===0?'#c0392b':i===1?'#b8860b':i===2?'#1e3a5f':'#0d7a6e';
    h+='<button class="gf-ck-opt" data-idx="'+i+'" style="text-align:left;padding:.9rem 1rem;border:1px solid rgba(15,23,42,.06);border-radius:10px;background:white;cursor:pointer;font-family:inherit;font-size:.86rem;transition:.2s;line-height:1.5;">';
    h+='<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:'+lc+';margin-right:.6rem;vertical-align:middle;"></span>';
    h+=q.o[i]+'</button>';
  }
  h+='</div></div>';
  app.innerHTML=h;
  // Bind clicks
  var btns=app.querySelectorAll('.gf-ck-opt');
  btns.forEach(function(b){
    b.addEventListener('click',function(){ pickAnswer(parseInt(this.getAttribute('data-idx'))); });
    b.addEventListener('mouseenter',function(){ this.style.borderColor=AC[q.ai]; this.style.background='rgba(15,23,42,.02)'; });
    b.addEventListener('mouseleave',function(){ this.style.borderColor='rgba(15,23,42,.06)'; this.style.background='white'; });
  });
}

function pickAnswer(idx){ ans.push(idx); cur++; if(cur<Q.length) renderQ(); else showLoading(); }

function showLoading(){
  var steps=['Analisi governance finanziaria...','Valutazione risk management...','Verifica compliance ESG...','Assessment integrazione AI...','Calcolo benchmark di mercato...','Elaborazione profilo di rischio...','Generazione report...'];
  var h='<div style="background:#fff;border-radius:20px;padding:3rem 2rem;border:1px solid rgba(15,23,42,.06);text-align:center;">';
  h+='<div style="width:60px;height:60px;border:4px solid rgba(15,23,42,.08);border-top:4px solid #b8860b;border-radius:50%;margin:0 auto 1.5rem;animation:ckspin 1s linear infinite;"></div>';
  h+='<h2 style="font-size:1.1rem;margin-bottom:.75rem;font-family:Playfair Display,serif;">Elaborazione in corso</h2>';
  h+='<p id="ck-step" style="font-size:.88rem;color:rgba(15,23,42,.5);transition:opacity .3s;">'+steps[0]+'</p>';
  h+='<div style="max-width:300px;margin:1.25rem auto 0;height:3px;background:rgba(15,23,42,.06);border-radius:2px;overflow:hidden;">';
  h+='<div id="ck-bar" style="height:100%;background:#b8860b;border-radius:2px;width:0%;transition:width .4s ease;"></div></div></div>';
  app.innerHTML=h;
  app.scrollIntoView({behavior:'smooth',block:'start'});
  var stepEl=document.getElementById('ck-step'),barEl=document.getElementById('ck-bar');
  var i=0;
  var iv=setInterval(function(){
    i++;
    if(i<steps.length){
      stepEl.style.opacity='0';
      setTimeout(function(){stepEl.textContent=steps[i];stepEl.style.opacity='1';},200);
      barEl.style.width=Math.round(((i+1)/steps.length)*100)+'%';
    } else { clearInterval(iv); barEl.style.width='100%'; setTimeout(renderResult,500); }
  },600);
}

function renderResult(){
  var aS=[0,0,0,0],aC=[0,0,0,0];
  Q.forEach(function(q,i){aS[q.ai]+=ans[i];aC[q.ai]++;});
  var aM=aC.map(function(c){return c*3;}),aP=aS.map(function(s,i){return Math.round((s/aM[i])*100);});
  var tot=0;ans.forEach(function(a){tot+=a;});var mx=Q.length*3,pct=Math.round((tot/mx)*100);
  var prof,pc,rt,bt;
  if(pct>=75){prof='Governance evoluta';pc='#0d7a6e';rt='Buon livello di governance con margini di miglioramento. L\u2019evoluzione normativa (CSRD, AI Act) e la pressione competitiva richiedono aggiornamento continuo.';bt='Il tuo livello \u00e8 in linea con le aziende pi\u00f9 evolute. Ma il 78% delle imprese italiane ha un punteggio inferiore: mantenere il vantaggio richiede investimento continuo.';}
  else if(pct>=50){prof='Gap rilevanti';pc='#b8860b';rt='Esistono basi solide ma gap significativi in aree critiche. Senza intervento, questi gap possono tradursi in decisioni meno efficaci, difficolt\u00e0 di accesso al credito e perdita di competitivit\u00e0.';bt='Le aziende pi\u00f9 evolute stanno gi\u00e0 integrando governance, ESG e AI nei processi decisionali. Il divario si amplia nel tempo.';}
  else{prof='Esposizione elevata';pc='#c0392b';rt='La tua azienda \u00e8 esposta a rischi decisionali e competitivi concreti. Una governance non strutturata significa decisioni meno efficaci, minore resilienza e crescente difficolt\u00e0 di accesso a capitale.';bt='Il tuo livello \u00e8 significativamente inferiore al benchmark di mercato. La mancata integrazione di ESG e AI sta gi\u00e0 generando un divario competitivo crescente.';}

  var d=new Date(),ds=d.getDate()+'/'+(d.getMonth()+1)+'/'+d.getFullYear();
  var privUrl=document.getElementById('gf-ck-privacy-url').value;
  var contUrl=document.getElementById('gf-ck-contatti-url').value;
  var ad=[{s:'Pianificazione, KPI, controllo di gestione',w:'Decisioni non data-driven, budget non strutturato'},{s:'Mappatura rischi, scenari previsionali',w:'Risk management reattivo, assenza stress test'},{s:'Strategia ESG, compliance CSRD',w:'ESG non integrato nelle decisioni finanziarie'},{s:'Analytics, strategia AI, reskilling',w:'Strumenti tradizionali, nessuna strategia AI'}];

  var h='<div id="gf-report-card" style="background:#fff;border-radius:20px;padding:2rem;border:1px solid rgba(15,23,42,.06);">';
  h+='<div class="print-header"><h2>Report Assessment Governance, ESG e AI</h2><p>Generato il '+ds+' \u00b7 governancefinanziaria.it \u00b7 Troisi Ricerche S.r.l.</p></div>';
  h+='<div style="text-align:center;margin-bottom:2rem;"><div style="width:120px;height:120px;border-radius:50%;border:5px solid '+pc+';display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;"><div><span style="font-family:Playfair Display,serif;font-size:2.2rem;font-weight:700;color:'+pc+';">'+pct+'</span><span style="font-size:.9rem;color:'+pc+';">%</span></div></div>';
  h+='<h2 style="margin-bottom:.3rem;font-size:1.4rem;">'+prof+'</h2>';
  h+='<p style="font-size:.82rem;color:rgba(15,23,42,.4);">Punteggio '+tot+'/'+mx+' \u00b7 '+ds+'</p></div>';
  h+='<div style="background:'+pc+'10;border-left:3px solid '+pc+';border-radius:0 10px 10px 0;padding:1rem 1.25rem;margin-bottom:1.75rem;"><p style="font-size:.88rem;color:rgba(15,23,42,.8);line-height:1.7;margin:0;">'+rt+'</p></div>';
  h+='<h3 style="font-size:1rem;margin-bottom:1rem;font-family:Playfair Display,serif;">Analisi per area</h3>';
  for(var i=0;i<4;i++){
    var ap=aP[i],al=ap>=75?'Solido':ap>=50?'Parziale':'Critico',alc=ap>=75?'#0d7a6e':ap>=50?'#b8860b':'#c0392b';
    h+='<div style="margin-bottom:1.25rem;padding-bottom:1.25rem;border-bottom:1px solid rgba(15,23,42,.06);">';
    h+='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.4rem;"><span style="font-size:.85rem;font-weight:600;color:'+AC[i]+';">'+AN[i]+'</span><span style="font-size:.7rem;font-weight:600;color:'+alc+';background:'+alc+'15;padding:.15rem .6rem;border-radius:20px;">'+al+' \u00b7 '+ap+'%</span></div>';
    h+='<div style="height:6px;background:rgba(15,23,42,.06);border-radius:3px;margin-bottom:.6rem;"><div style="height:100%;background:'+AC[i]+';border-radius:3px;width:'+ap+'%;transition:width .6s ease;"></div></div>';
    if(ap>=50) h+='<p style="font-size:.78rem;color:rgba(15,23,42,.5);margin:0;"><strong style="color:#0d7a6e;">Punti di forza:</strong> '+ad[i].s+'</p>';
    if(ap<75) h+='<p style="font-size:.78rem;color:rgba(15,23,42,.5);margin:.15rem 0 0;"><strong style="color:#c0392b;">Aree critiche:</strong> '+ad[i].w+'</p>';
    h+='</div>';
  }
  h+='<div style="background:rgba(30,58,95,.05);border-radius:12px;padding:1.15rem 1.25rem;margin:1rem 0;"><p style="font-size:.78rem;font-weight:600;color:rgba(15,23,42,.5);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem;">Benchmark</p><p style="font-size:.88rem;color:rgba(15,23,42,.7);line-height:1.6;margin:0;">'+bt+'</p></div>';
  h+='<div style="background:rgba(15,23,42,.03);border-radius:12px;padding:1.15rem 1.25rem;margin-bottom:1.5rem;"><p style="font-size:.78rem;font-weight:600;color:rgba(15,23,42,.5);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.5rem;">Senza una governance strutturata</p><p style="font-size:.86rem;color:rgba(15,23,42,.7);line-height:1.7;margin:0;">\u2022 Le decisioni strategiche risultano meno efficaci e pi\u00f9 lente<br>\u2022 L\u2019azienda \u00e8 meno resiliente a shock di mercato e normativi<br>\u2022 L\u2019accesso a capitale, credito e opportunit\u00e0 si riduce progressivamente<br>\u2022 La mancata integrazione di ESG e AI genera un divario competitivo crescente</p></div>';

  // Print + Email buttons
  h+='<div class="no-print" style="display:flex;gap:.75rem;margin-bottom:1.5rem;flex-wrap:wrap;">';
  h+='<button id="ck-print-btn" style="flex:1;min-width:200px;padding:.7rem 1rem;background:#fff;border:1px solid rgba(15,23,42,.12);border-radius:8px;font-family:inherit;font-size:.85rem;font-weight:600;color:#1e3a5f;cursor:pointer;">\u{1F5A8} Stampa il report</button>';
  h+='<button id="ck-email-btn" style="flex:1;min-width:200px;padding:.7rem 1rem;background:#fff;border:1px solid rgba(15,23,42,.12);border-radius:8px;font-family:inherit;font-size:.85rem;font-weight:600;color:#1e3a5f;cursor:pointer;">\u{1F4E7} Invia report via email</button>';
  h+='</div>';

  // CTA dark box
  h+='<div class="cta-box-dark no-print" style="background:linear-gradient(135deg,#0f2440,#1e3a5f);border-radius:16px;padding:2rem;text-align:center;">';
  h+='<h3 style="color:#f8f9fc;font-size:1.2rem;margin-bottom:.5rem;font-family:Playfair Display,serif;">Vuoi un quadro completo?</h3>';
  h+='<p style="color:rgba(248,249,252,.5);font-size:.88rem;margin-bottom:1.25rem;max-width:420px;margin-left:auto;margin-right:auto;">Analisi personalizzata della tua governance finanziaria, ESG e AI con il Metodo Troisi.</p>';
  h+='<div style="max-width:380px;margin:0 auto;">';
  h+='<input type="text" id="ck-nome" placeholder="Nome e cognome *" style="width:100%;padding:.65rem .9rem;border:1px solid rgba(248,249,252,.15);border-radius:8px;background:rgba(248,249,252,.08);color:#f8f9fc;font-family:inherit;font-size:.86rem;margin-bottom:.5rem;">';
  h+='<input type="email" id="ck-em" placeholder="Email aziendale *" style="width:100%;padding:.65rem .9rem;border:1px solid rgba(248,249,252,.15);border-radius:8px;background:rgba(248,249,252,.08);color:#f8f9fc;font-family:inherit;font-size:.86rem;margin-bottom:.5rem;">';
  h+='<input type="text" id="ck-org" placeholder="Azienda *" style="width:100%;padding:.65rem .9rem;border:1px solid rgba(248,249,252,.15);border-radius:8px;background:rgba(248,249,252,.08);color:#f8f9fc;font-family:inherit;font-size:.86rem;margin-bottom:.5rem;">';
  h+='<select id="ck-ruolo" style="width:100%;padding:.65rem .9rem;border:1px solid rgba(248,249,252,.15);border-radius:8px;background:rgba(248,249,252,.08);color:rgba(248,249,252,.6);font-family:inherit;font-size:.86rem;margin-bottom:.5rem;"><option value="">Ruolo in azienda *</option><option>CEO / Imprenditore</option><option>CFO / Direttore Finanziario</option><option>Membro CDA</option><option>Dirigente / Manager</option><option>HR / Formazione</option><option>Consulente</option><option>Professionista</option><option>Altro</option></select>';
  h+='<input type="tel" id="ck-tel" placeholder="Telefono (opzionale)" style="width:100%;padding:.65rem .9rem;border:1px solid rgba(248,249,252,.15);border-radius:8px;background:rgba(248,249,252,.08);color:#f8f9fc;font-family:inherit;font-size:.86rem;margin-bottom:.75rem;">';
  h+='<div style="display:flex;align-items:flex-start;gap:.5rem;margin-bottom:1rem;text-align:left;">';
  h+='<input type="checkbox" id="ck-privacy" style="margin-top:.25rem;flex-shrink:0;">';
  h+='<label style="font-size:.72rem;color:rgba(248,249,252,.4);line-height:1.5;">Acconsento al trattamento dei dati personali ai sensi del Reg. UE 2016/679 (GDPR). I dati saranno utilizzati per l\u2019invio del report e comunicazioni relative ai servizi di Troisi Ricerche S.r.l. <a href="'+privUrl+'" target="_blank" style="color:rgba(248,249,252,.6);text-decoration:underline;">Privacy Policy</a></label>';
  h+='</div>';
  h+='<button id="ck-send-btn" style="width:100%;padding:.75rem;background:#b8860b;color:white;border:none;border-radius:8px;font-family:inherit;font-size:.92rem;font-weight:600;cursor:pointer;margin-bottom:.5rem;">Richiedi assessment completo \u2192</button>';
  h+='<a href="'+contUrl+'" style="display:block;color:rgba(248,249,252,.4);font-size:.8rem;text-decoration:underline;">oppure prenota una consulenza strategica</a>';
  h+='</div></div>';

  h+='<div style="text-align:center;margin-top:1.5rem;padding-top:1rem;border-top:1px solid rgba(15,23,42,.06);"><p style="font-size:.75rem;color:rgba(15,23,42,.35);line-height:1.6;">Assessment basato sul modello Fondirigenti validato su 400+ manager \u00b7 Presentato alla Camera dei Deputati (25/03/2022)<br><strong style="color:rgba(15,23,42,.5);">Troisi Ricerche S.r.l.</strong> \u2014 Advisor strategico per governance, dati e decision making \u00b7 Accreditata MIUR dal 2006</p></div>';
  h+='</div>';
  app.innerHTML=h;
  app.scrollIntoView({behavior:'smooth',block:'start'});

  window._gfR={pct:pct,total:tot,maxScore:mx,profile:prof,areasDetail:AN.map(function(n,i){return n+': '+aP[i]+'% ('+(aP[i]>=75?'Solido':aP[i]>=50?'Parziale':'Critico')+')';}).join(' | '),date:ds};

  // Bind buttons
  document.getElementById('ck-print-btn').addEventListener('click',function(){window.print();});
  document.getElementById('ck-email-btn').addEventListener('click',function(){
    var em=prompt('Inserisci la tua email per ricevere il report:');
    if(em&&em.indexOf('@')>0){sendToServer(em,'','','','');alert('Report inviato a '+em+'!');}
  });
  document.getElementById('ck-send-btn').addEventListener('click',function(){
    var nome=document.getElementById('ck-nome').value;
    var em=document.getElementById('ck-em').value;
    var org=document.getElementById('ck-org').value;
    var ruolo=document.getElementById('ck-ruolo').value;
    var tel=document.getElementById('ck-tel').value;
    var priv=document.getElementById('ck-privacy').checked;
    if(!nome){alert('Inserisci nome e cognome');return;}
    if(!em||em.indexOf('@')<0){alert('Inserisci un\'email aziendale valida');return;}
    if(!org){alert('Inserisci il nome dell\'azienda');return;}
    if(!ruolo){alert('Seleziona il tuo ruolo in azienda');return;}
    if(!priv){alert('\u00c8 necessario accettare il trattamento dei dati per procedere');return;}
    var btn=this;btn.textContent='Invio in corso...';btn.disabled=true;
    sendToServer(em,nome,org,ruolo,tel);
    setTimeout(function(){btn.textContent='\u2705 Richiesta inviata \u2014 controlla la tua email';btn.style.background='#0d7a6e';},1000);
  });
}

function sendToServer(email,nome,org,ruolo,tel){
  var r=window._gfR;
  var ajaxUrl=document.getElementById('gf-ck-ajax-url').value;
  var nonce=document.getElementById('gf-ck-nonce').value;
  var fd=new FormData();
  fd.append('action','gf_checker_submit');
  fd.append('nonce',nonce);
  fd.append('email',email);fd.append('nome',nome);fd.append('org',org);fd.append('ruolo',ruolo);fd.append('tel',tel);
  fd.append('score',r.total);fd.append('profile',r.profile);fd.append('pct',r.pct);fd.append('scores_detail',r.areasDetail);
  fetch(ajaxUrl,{method:'POST',body:fd}).catch(function(){});
}

})();
