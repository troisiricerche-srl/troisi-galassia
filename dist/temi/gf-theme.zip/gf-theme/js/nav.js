/**
 * Governance Finanziaria — Navigation + Cookie Banner
 */
(function() {
  'use strict';
  document.addEventListener('DOMContentLoaded', function() {
    var toggle = document.querySelector('.gf-menu-toggle');
    var nav = document.querySelector('.gf-nav');
    var header = document.querySelector('.gf-header');
    if (toggle && nav) {
      toggle.addEventListener('click', function() {
        var expanded = toggle.getAttribute('aria-expanded') === 'true';
        toggle.setAttribute('aria-expanded', !expanded);
        toggle.classList.toggle('is-active');
        nav.classList.toggle('is-open');
        document.body.classList.toggle('menu-open');
      });
      document.addEventListener('click', function(e) {
        if (nav.classList.contains('is-open') && !header.contains(e.target)) {
          toggle.setAttribute('aria-expanded', 'false');
          toggle.classList.remove('is-active');
          nav.classList.remove('is-open');
          document.body.classList.remove('menu-open');
        }
      });
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && nav.classList.contains('is-open')) {
          toggle.setAttribute('aria-expanded', 'false');
          toggle.classList.remove('is-active');
          nav.classList.remove('is-open');
          document.body.classList.remove('menu-open');
        }
      });
    }
    // Cookie
    var banner = document.getElementById('gf-cookie-banner');
    if (banner && !getCookie('gf_cookie_consent')) banner.style.display = 'block';
    var btnAll = document.getElementById('gf-cookie-accept-all');
    var btnEss = document.getElementById('gf-cookie-accept-ess');
    if (btnAll) btnAll.addEventListener('click', function(){ gfAcceptCookies('all'); });
    if (btnEss) btnEss.addEventListener('click', function(){ gfAcceptCookies('essential'); });
  });
  function getCookie(n) { var v = document.cookie.match('(^|;)\\s*'+n+'\\s*=\\s*([^;]+)'); return v ? v.pop() : ''; }
  function setCookie(n,v,d) { var x = new Date(); x.setTime(x.getTime()+(d*864e5)); document.cookie = n+'='+v+';expires='+x.toUTCString()+';path=/;SameSite=Lax'; }
  window.gfAcceptCookies = function(t) {
    setCookie('gf_cookie_consent', t, 365);
    var b = document.getElementById('gf-cookie-banner');
    if (b) { b.style.opacity='0'; b.style.transform='translateY(100%)'; setTimeout(function(){b.style.display='none';},300); }
  };
  window.gfResetCookies = function() { setCookie('gf_cookie_consent','', -1); var b=document.getElementById('gf-cookie-banner'); if(b){b.style.display='block';b.style.opacity='1';b.style.transform='translateY(0)';} };
})();
