<?php
/**
 * Governance Finanziaria — Theme Functions v2
 * Da archivio progetto → piattaforma attiva Troisi Ricerche
 */
if (!defined('ABSPATH')) exit;

define('GF_VERSION', '2.0.0');
define('GF_DIR', get_template_directory());
define('GF_URI', get_template_directory_uri());

/* ═══ SETUP ═══ */
add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_image_size('blog-card', 600, 400, true);
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    register_nav_menus(['primary'=>'Menu principale']);
    add_image_size('card-thumb', 600, 400, true);
});

/* ═══ ENQUEUE ═══ */
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('gf-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,700;1,700&display=swap', [], null);
    wp_enqueue_style('gf-style', get_stylesheet_uri(), ['gf-fonts'], GF_VERSION);
    wp_enqueue_script('gf-nav', GF_URI . '/js/nav.js', [], GF_VERSION, true);
    if (is_page_template('page-checker.php') || is_front_page()) {
        wp_enqueue_script('gf-checker', GF_URI . '/js/checker.js', [], GF_VERSION, true);
        wp_localize_script('gf-checker', 'gf_ajax', [
            'url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('gf_checker_nonce'),
        ]);
    }
});

/* ═══ SEO META ═══ */
add_action('wp_head', function() {
    echo '<link rel="icon" href="' . GF_URI . '/favicon.ico" sizes="any">' . "\n";
    echo '<link rel="icon" href="' . GF_URI . '/img/favicon-192.png" type="image/png" sizes="192x192">' . "\n";
    echo '<link rel="apple-touch-icon" href="' . GF_URI . '/img/apple-touch-icon.png">' . "\n";
    $seo = gf_get_seo();
    if ($seo['desc']) echo '<meta name="description" content="' . esc_attr($seo['desc']) . '">' . "\n";
    if ($seo['kw']) echo '<meta name="keywords" content="' . esc_attr($seo['kw']) . '">' . "\n";
    echo '<meta property="og:site_name" content="Governance Finanziaria — Troisi Ricerche">' . "\n";
    echo '<meta property="og:locale" content="it_IT">' . "\n";
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">' . "\n";

    // JSON-LD Organization
    if (is_front_page()) {
        $org = [
            '@context'=>'https://schema.org','@type'=>'ProfessionalService',
            'name'=>'Governance Finanziaria — Troisi Ricerche',
            'url'=>home_url('/'),
            'description'=>'Analisi della governance finanziaria, assessment ESG e supporto decisionale per imprese e manager. Modello validato con Fondirigenti e presentato alla Camera dei Deputati. Troisi Ricerche S.r.l. — istituto accreditato MIUR.',
            'parentOrganization'=>['@type'=>'ResearchOrganization','name'=>'Troisi Ricerche S.r.l.','url'=>'https://troisiricerche.net','taxID'=>'07216100722'],
            'address'=>['@type'=>'PostalAddress','streetAddress'=>'Via de Rossi 57','addressLocality'=>'Bari','postalCode'=>'70122','addressCountry'=>'IT'],
            'knowsAbout'=>['governance finanziaria aziendale','ESG imprese','risk management aziendale','competenze CFO','sostenibilità finanziaria','digital transformation finance','economia circolare','climate change imprese','data governance','leadership sostenibile'],
        ];
        echo '<script type="application/ld+json">' . wp_json_encode($org, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    // JSON-LD FAQ
    if (is_front_page() || is_page_template('page-checker.php')) {
        $faqs = gf_get_faqs();
        $faq_schema = ['@context'=>'https://schema.org','@type'=>'FAQPage',
            'mainEntity'=>array_map(function($q){return ['@type'=>'Question','name'=>$q['q'],'acceptedAnswer'=>['@type'=>'Answer','text'=>$q['a']]];}, $faqs)];
        echo '<script type="application/ld+json">' . wp_json_encode($faq_schema, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    // JSON-LD Article
    if (is_singular('post')) {
        $art = ['@context'=>'https://schema.org','@type'=>'Article','headline'=>get_the_title(),
            'datePublished'=>get_the_date('c'),'dateModified'=>get_the_modified_date('c'),
            'author'=>['@type'=>'Organization','name'=>'Troisi Ricerche S.r.l.','url'=>'https://troisiricerche.net'],
            'publisher'=>['@type'=>'Organization','name'=>'Governance Finanziaria — Troisi Ricerche'],
            'mainEntityOfPage'=>get_permalink()];
        echo '<script type="application/ld+json">' . wp_json_encode($art, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
});

function gf_get_seo() {
    $s = ['title'=>'','desc'=>'','kw'=>''];
    if (is_front_page()) {
        $s['title'] = 'Governance Finanziaria: analisi, assessment ESG e supporto decisionale | Troisi Ricerche';
        $s['desc'] = 'Governance finanziaria aziendale: analisi delle competenze, assessment ESG, risk management e supporto decisionale per imprese e manager. Modello validato con Fondirigenti e presentato alla Camera dei Deputati. Checker gratuito.';
        $s['kw'] = 'governance finanziaria aziendale, ESG imprese, risk management aziendale, competenze CFO, sostenibilità finanziaria, assessment ESG';
    } elseif (is_page_template('page-checker.php')) {
        $s['title'] = 'La tua azienda è pronta alle sfide finanziarie, ESG e AI? | Checker gratuito';
        $s['desc'] = 'Scopri in 2 minuti se la tua governance espone l\'azienda a rischi decisionali, competitivi e di mercato. 12 domande su governance finanziaria, risk management, ESG e AI. Basato sul modello Fondirigenti validato su 400+ manager.';
        $s['kw'] = 'test governance finanziaria, assessment ESG gratuito, checker competenze CFO, autovalutazione risk management, AI decision making imprese';
    } elseif (is_page_template('page-servizi.php')) {
        $s['title'] = 'Servizi di governance finanziaria e ESG per imprese | Troisi Ricerche';
        $s['desc'] = 'Analisi governance finanziaria, assessment ESG, supporto decisionale per CDA e CFO, formazione manageriale. Il Metodo Troisi applicato alla finanza d\'impresa.';
    }
    return $s;
}

add_filter('pre_get_document_title', function($t) { $s = gf_get_seo(); return $s['title'] ?: $t; });

/* ═══ FAQ ═══ */
function gf_get_faqs() {
    return [
        ['q'=>'Cos\'è la governance finanziaria?','a'=>'La governance finanziaria è il sistema con cui un\'azienda raccoglie, gestisce, monitora e controlla le informazioni finanziarie. Include la gestione delle transazioni, il monitoraggio della performance, il controllo dei dati e la compliance normativa. Una buona governance finanziaria garantisce decisioni strategiche basate su dati affidabili.'],
        ['q'=>'Cos\'è l\'ESG e perché è importante per le imprese?','a'=>'ESG sta per Environmental, Social and Governance. Sono i tre criteri con cui si misura la sostenibilità e l\'impatto etico di un\'azienda. Dal 2024, le normative europee (CSRD, Tassonomia UE) rendono la rendicontazione ESG obbligatoria per un numero crescente di imprese. Le banche valutano il profilo ESG per l\'accesso al credito.'],
        ['q'=>'Perché la governance finanziaria è diventata più importante dopo la pandemia?','a'=>'La pandemia ha evidenziato i limiti dei modelli di governance tradizionali. Le imprese con governance finanziaria solida — business plan multi-scenario, risk management strutturato, competenze digitali — hanno mostrato maggiore resilienza. Le nuove regolamentazioni EBA richiedono budget previsionali realistici per l\'accesso al credito.'],
        ['q'=>'Quali sono le competenze chiave per il CFO di oggi?','a'=>'Il modello Fondirigenti-Troisi Ricerche identifica 10 competenze in 4 ambiti: programmazione economico-finanziaria, gestione economics, risk management (Dinamiche di Board); IT security, data governance (Digital); climate change, valore condiviso, economia circolare (Sustainability); change management, leadership etica (Trasversali).'],
        ['q'=>'Come si misura la maturità della governance finanziaria?','a'=>'Il Maturity Model sviluppato da Troisi Ricerche prevede 5 livelli per ciascuna delle 10 competenze: dal livello 1 (competenza non presente) al livello 5 (espressa proattivamente in contesti complessi). Il checker gratuito su questo sito fornisce una valutazione preliminare in 3 minuti.'],
        ['q'=>'Cos\'è il risk management finanziario?','a'=>'Il risk management finanziario è il processo continuo di identificazione, misurazione, controllo e mitigazione delle fonti di rischio che possono impattare il valore economico dell\'azienda. Include rischio di prezzo delle materie prime, rischio di cambio valute e rischio legato ai tassi di interesse.'],
        ['q'=>'Come si integra la sostenibilità nella governance finanziaria?','a'=>'La sostenibilità ESG non è più separata dalla governance finanziaria. Il Green Deal Europeo, la Tassonomia UE e la CSRD richiedono che i rischi climatici e sociali siano integrati nei processi decisionali finanziari. Le imprese devono misurare carbon footprint, gestire rischi fisici e di transizione, e rendicontare con metriche ESG.'],
        ['q'=>'Cosa ha prodotto il progetto Fondirigenti sulla governance finanziaria?','a'=>'Il progetto (n. 74/2020) ha prodotto: un\'indagine su oltre 400 manager da 340 imprese (CATI+CAWI), un modello di 10 competenze strategiche, 10 video-pillole formative, 5 webinar con testimonial, un Maturity Model a 5 livelli. I risultati sono stati presentati alla Camera dei Deputati il 25 marzo 2022.'],
        ['q'=>'Come può Troisi Ricerche aiutare la mia azienda?','a'=>'Troisi Ricerche offre: assessment della governance finanziaria basato sul modello Fondirigenti, valutazione ESG readiness, supporto alla pianificazione strategica e risk management, formazione manageriale su competenze digitali e sostenibilità. Il Metodo Troisi combina rigore scientifico e applicabilità operativa.'],
        ['q'=>'Il checker è gratuito? Come funziona?','a'=>'Sì, il checker è completamente gratuito. In 12 domande (3 minuti) valuta il livello di maturità della tua impresa su governance finanziaria, digitalizzazione, sostenibilità ESG e competenze trasversali. Ricevi un profilo immediato con indicazioni sulle aree di miglioramento prioritarie.'],
    ];
}

/* ═══ EXCERPT ═══ */
add_filter('excerpt_length', function() { return 20; });
add_filter('excerpt_more', function() { return '&hellip;'; });
remove_action('wp_head', 'wp_generator');

/* ═══ AUTO-INSTALL ═══ */
add_action('after_switch_theme', function() {
    $pages = [
        'home'=>['title'=>'Governance Finanziaria','tpl'=>'front-page.php'],
        'servizi'=>['title'=>'Servizi','tpl'=>'page-servizi.php'],
        'checker'=>['title'=>'Checker Governance e ESG','tpl'=>'page-checker.php'],
        'caso-fondirigenti'=>['title'=>'Il Caso Fondirigenti','tpl'=>'page-progetto.php'],
        'indagine'=>['title'=>'Indagine su 400 Manager','tpl'=>'page-indagine.php'],
        'video-pillole'=>['title'=>'10 Video Pillole','tpl'=>'page-video-pillole.php'],
        'webinar'=>['title'=>'5 Webinar','tpl'=>'page-webinar.php'],
        'camera-deputati'=>['title'=>'Camera dei Deputati','tpl'=>'page-camera-deputati.php'],
        'contatti'=>['title'=>'Contatti','tpl'=>'page-contatti.php'],
        'privacy-policy'=>['title'=>'Privacy Policy','tpl'=>'page-privacy.php'],
    ];
    foreach ($pages as $slug => $d) {
        if (!get_page_by_path($slug)) {
            $pid = wp_insert_post(['post_title'=>$d['title'],'post_name'=>$slug,'post_status'=>'publish','post_type'=>'page','post_content'=>'']);
            if ($pid && !is_wp_error($pid)) update_post_meta($pid, '_wp_page_template', $d['tpl']);
        }
    }
    $front = get_page_by_path('home');
    if ($front) { update_option('show_on_front','page'); update_option('page_on_front',$front->ID); }

    // Categories
    foreach (['Governance'=>'governance','ESG'=>'esg','Digital'=>'digital','Risk Management'=>'risk-management','Competenze'=>'competenze'] as $n=>$sl) {
        if (!term_exists($sl,'category')) wp_insert_term($n,'category',['slug'=>$sl]);
    }

    // Articles
    $articles = [
        ['file'=>'art01-governance-finanziaria.html','title'=>'Governance finanziaria aziendale: cos\'è, perché è importante e come migliorarla nel 2026','slug'=>'governance-finanziaria-aziendale-guida','cat'=>'governance',
         'excerpt'=>'Cos\'è la governance finanziaria aziendale? Definizione, competenze chiave, modello Fondirigenti su 400+ manager e strumenti per migliorare la governance nel 2026.'],
        ['file'=>'art02-esg-imprese.html','title'=>'ESG e imprese: cosa significa, cosa cambia nel 2026 e come prepararsi','slug'=>'esg-imprese-significato-obblighi-2026','cat'=>'esg',
         'excerpt'=>'ESG nelle imprese: cosa significa Environmental, Social and Governance? Obblighi CSRD 2026, impatto su accesso al credito e come valutare la ESG readiness.'],
        ['file'=>'art03-ai-decision-making.html','title'=>'Intelligenza artificiale e decision making: come l\'AI sta cambiando le decisioni nelle imprese','slug'=>'intelligenza-artificiale-decision-making-imprese','cat'=>'digital',
         'excerpt'=>'Come l\'intelligenza artificiale cambia il decision making nelle imprese italiane. Dati su adozione AI, impatto su governance finanziaria e competenze del CFO.'],
    ];
    foreach ($articles as $art) {
        if (get_page_by_path($art['slug'], OBJECT, 'post')) continue;
        $file = GF_DIR . '/articles/' . $art['file'];
        if (!file_exists($file)) continue;
        $content = file_get_contents($file);
        $content = preg_replace('/<!--\s*(?:Titolo|Categoria|Meta|Slug).*?-->\s*/s', '', $content);
        $cat = get_term_by('slug', $art['cat'], 'category');
        wp_insert_post(['post_title'=>$art['title'],'post_name'=>$art['slug'],'post_status'=>'publish','post_type'=>'post','post_content'=>$content,'post_excerpt'=>$art['excerpt'],'post_category'=>$cat?[$cat->term_id]:[]]);
    }

    // Menu
    if (!wp_get_nav_menu_object('Menu principale')) {
        $mid = wp_create_nav_menu('Menu principale');
        $items = [
            ['t'=>'Servizi','u'=>home_url('/servizi/')],
            ['t'=>'Il Caso Fondirigenti','u'=>home_url('/caso-fondirigenti/')],
            ['t'=>'Blog','u'=>home_url('/blog/')],
            ['t'=>'Contatti','u'=>home_url('/contatti/')],
        ];
        foreach ($items as $it) wp_update_nav_menu_item($mid, 0, ['menu-item-title'=>$it['t'],'menu-item-url'=>$it['u'],'menu-item-status'=>'publish','menu-item-type'=>'custom']);
        wp_update_nav_menu_item($mid, 0, ['menu-item-title'=>'Checker gratuito','menu-item-url'=>home_url('/checker/'),'menu-item-status'=>'publish','menu-item-type'=>'custom','menu-item-classes'=>'gf-nav-cta']);
        $locs = get_theme_mod('nav_menu_locations'); $locs['primary'] = $mid; set_theme_mod('nav_menu_locations', $locs);
    }
    flush_rewrite_rules();
});

/* ═══ CHECKER AJAX ═══ */
add_action('wp_ajax_gf_checker_submit', 'gf_handle_checker');
add_action('wp_ajax_nopriv_gf_checker_submit', 'gf_handle_checker');
function gf_handle_checker() {
    check_ajax_referer('gf_checker_nonce', 'nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $nome = sanitize_text_field($_POST['nome'] ?? '');
    $org = sanitize_text_field($_POST['org'] ?? '');
    $ruolo = sanitize_text_field($_POST['ruolo'] ?? '');
    $tel = sanitize_text_field($_POST['tel'] ?? '');
    $score = intval($_POST['score'] ?? 0);
    $pct = intval($_POST['pct'] ?? 0);
    $profile = sanitize_text_field($_POST['profile'] ?? '');
    $detail = sanitize_text_field($_POST['scores_detail'] ?? '');
    if (!is_email($email)) { wp_send_json_error('Email non valida'); return; }

    // Save lead
    $leads = get_option('gf_checker_leads', []);
    $leads[] = ['email'=>$email,'nome'=>$nome,'org'=>$org,'ruolo'=>$ruolo,'tel'=>$tel,'score'=>$score,'pct'=>$pct,'profile'=>$profile,'detail'=>$detail,'date'=>current_time('mysql')];
    update_option('gf_checker_leads', $leads);

    // ═══ EMAIL 1: Report al compilatore ═══
    $user_subject = 'Il tuo report Assessment Governance, ESG e AI — ' . $profile;
    $user_body = "Gentile " . ($nome ?: 'Utente') . ",\n\n";
    $user_body .= "Grazie per aver completato l'Assessment Governance, ESG e AI su governancefinanziaria.it.\n\n";
    $user_body .= "══════════════════════════════════════\n";
    $user_body .= "RISULTATO: " . $profile . " (" . $pct . "%)\n";
    $user_body .= "Punteggio: " . $score . "/36\n";
    $user_body .= "Data: " . current_time('d/m/Y H:i') . "\n";
    $user_body .= "══════════════════════════════════════\n\n";
    $user_body .= "DETTAGLIO PER AREA:\n" . str_replace('|', "\n", $detail) . "\n\n";
    $user_body .= "──────────────────────────────────────\n";
    if ($pct < 50) {
        $user_body .= "⚠ ATTENZIONE: Il tuo livello indica un'esposizione elevata a rischi decisionali e competitivi.\n";
        $user_body .= "Senza intervento, la tua azienda rischia: decisioni meno efficaci, difficoltà di accesso al credito, perdita di competitività su ESG e AI.\n\n";
    } elseif ($pct < 75) {
        $user_body .= "⚠ NOTA: Esistono basi solide ma gap significativi. Le aziende più evolute stanno già integrando governance, ESG e AI. Il divario si amplia nel tempo.\n\n";
    } else {
        $user_body .= "✓ BENE: Il tuo livello è in linea con le aziende più evolute. Ma l'evoluzione normativa (CSRD, AI Act) richiede aggiornamento continuo.\n\n";
    }
    $user_body .= "══════════════════════════════════════\n";
    $user_body .= "PROSSIMO PASSO\n";
    $user_body .= "══════════════════════════════════════\n\n";
    $user_body .= "Per un assessment approfondito e personalizzato:\n";
    $user_body .= "→ Rispondi direttamente a questa email\n";
    $user_body .= "→ Oppure visita: https://governancefinanziaria.it/contatti/\n\n";
    $user_body .= "L'assessment completo con il Metodo Troisi include:\n";
    $user_body .= "• Gap analysis dettagliata sulle 10 competenze del modello Fondirigenti\n";
    $user_body .= "• Benchmark rispetto ai 400+ manager dell'indagine nazionale\n";
    $user_body .= "• Piano d'azione con priorità di intervento\n";
    $user_body .= "• Roadmap ESG e AI personalizzata\n\n";
    $user_body .= "──────────────────────────────────────\n\n";
    $user_body .= "prof. Andrea Troisi\n";
    $user_body .= "Fondatore e Direttore Scientifico\n";
    $user_body .= "Troisi Ricerche S.r.l. — Istituto accreditato MIUR\n\n";
    $user_body .= "Via de Rossi 57, 70122 Bari\n";
    $user_body .= "info@governancefinanziaria.it\n";
    $user_body .= "https://governancefinanziaria.it\n";
    $user_body .= "https://troisiricerche.net\n";
    $user_body .= "https://andreatroisi.it\n\n";
    $user_body .= "──────────────────────────────────────\n";
    $user_body .= "Modello validato con Fondirigenti (Progetto n. 74/2020)\n";
    $user_body .= "Presentato alla Camera dei Deputati — 25 marzo 2022\n";
    $user_body .= "──────────────────────────────────────\n\n";
    $user_body .= "Ai sensi del GDPR (Reg. UE 2016/679), i tuoi dati saranno trattati esclusivamente per l'invio di questo report e per eventuali comunicazioni relative ai servizi di Troisi Ricerche S.r.l. Puoi richiedere la cancellazione in qualsiasi momento scrivendo a info@governancefinanziaria.it.\n";

    wp_mail($email, $user_subject, $user_body, [
        'From: prof. Andrea Troisi — Governance Finanziaria <info@governancefinanziaria.it>',
        'Reply-To: prof. Andrea Troisi <info@governancefinanziaria.it>',
    ]);

    // ═══ EMAIL 2: Notifica ad Andrea ═══
    $admin_body = "══ NUOVO LEAD CHECKER GF ══\n\n";
    $admin_body .= "Nome: {$nome}\nEmail: {$email}\nAzienda: {$org}\nRuolo: {$ruolo}\nTelefono: {$tel}\n\n";
    $admin_body .= "RISULTATO: {$profile} ({$pct}%)\nScore: {$score}/36\n\n";
    $admin_body .= "DETTAGLIO:\n" . str_replace('|', "\n", $detail) . "\n\n";
    $admin_body .= "Data: " . current_time('d/m/Y H:i') . "\n";
    $admin_body .= "IP: " . sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '') . "\n";

    wp_mail('info@governancefinanziaria.it', '[GF Checker] Nuovo lead — ' . $profile . ' — ' . ($org ?: $email), $admin_body);

    wp_send_json_success(['message'=>'Lead salvato e report inviato']);
}

/* ═══ CONTACT AJAX ═══ */
add_action('wp_ajax_gf_contact', 'gf_handle_contact');
add_action('wp_ajax_nopriv_gf_contact', 'gf_handle_contact');
function gf_handle_contact() {
    check_ajax_referer('gf_contact_nonce', 'gf_nonce');
    $name = sanitize_text_field($_POST['gf_name']??'');
    $email = sanitize_email($_POST['gf_email']??'');
    $org = sanitize_text_field($_POST['gf_org']??'');
    $role = sanitize_text_field($_POST['gf_role']??'');
    $msg = sanitize_textarea_field($_POST['gf_message']??'');
    if (!$name||!is_email($email)||!$msg) { wp_send_json_error('Compila tutti i campi.'); return; }
    wp_mail('info@governancefinanziaria.it', "[GF] {$name} — {$org} ({$role})",
        "Da: {$name} ({$email})\nOrg: {$org}\nRuolo: {$role}\n\n{$msg}\n\n".current_time('d/m/Y H:i'),
        ['Reply-To: '.$name.' <'.$email.'>']);
    wp_send_json_success(['message'=>'Inviato']);
}

/* ═══ ADMIN ═══ */
add_action('admin_menu', function() {
    add_menu_page('Lead Checker GF','Lead GF','manage_options','gf-leads','gf_admin_leads','dashicons-chart-bar',30);
});
function gf_admin_leads() {
    $leads = array_reverse(get_option('gf_checker_leads', []));
    echo '<div class="wrap"><h1>Lead Checker GF ('.count($leads).')</h1>';
    if ($leads) {
        echo '<table class="wp-list-table widefat striped"><thead><tr><th>Data</th><th>Nome</th><th>Email</th><th>Azienda</th><th>Ruolo</th><th>Tel</th><th>Score</th><th>Profilo</th><th>Dettaglio</th></tr></thead><tbody>';
        foreach ($leads as $l) echo '<tr><td>'.esc_html($l['date']??'').'</td><td>'.esc_html($l['nome']??'').'</td><td>'.esc_html($l['email']??'').'</td><td>'.esc_html($l['org']??'').'</td><td>'.esc_html($l['ruolo']??'').'</td><td>'.esc_html($l['tel']??'').'</td><td>'.esc_html(($l['pct']??'').'%').'</td><td>'.esc_html($l['profile']??'').'</td><td style="font-size:11px;">'.esc_html($l['detail']??'').'</td></tr>';
        echo '</tbody></table>';
    }
    echo '</div>';
}

/* ═══ v1.0.1 – pagina Privacy Policy sempre presente ═══
   /privacy-policy/ dava 404: la pagina creata all'attivazione del tema non esiste piu'.
   Al primo caricamento la ricrea (o la ripubblica) con il modello del tema. */
add_action('init', function () {
    if (get_option('gf_privacy_ok_101')) return;
    $p = get_page_by_path('privacy-policy');
    if (!$p) {
        $pid = wp_insert_post(['post_title' => 'Privacy Policy', 'post_name' => 'privacy-policy',
            'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '']);
        if ($pid && !is_wp_error($pid)) update_post_meta($pid, '_wp_page_template', 'page-privacy.php');
    } elseif ($p->post_status !== 'publish') {
        wp_update_post(['ID' => $p->ID, 'post_status' => 'publish']);
        update_post_meta($p->ID, '_wp_page_template', 'page-privacy.php');
    }
    update_option('gf_privacy_ok_101', 1);
}, 20);

