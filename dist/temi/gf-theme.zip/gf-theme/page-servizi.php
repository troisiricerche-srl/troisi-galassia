<?php /** Template Name: Servizi */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>Servizi</h1><p>Governance finanziaria, ESG e supporto decisionale per imprese e manager</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:900px;">

<div class="gf-section-header" style="margin-bottom:2rem;">
  <h2>Il Metodo Troisi applicato alla governance finanziaria</h2>
  <p>Dal modello validato con Fondirigenti e presentato alla Camera dei Deputati, Troisi Ricerche offre oggi servizi operativi per imprese, CDA e CFO che vogliono trasformare la governance finanziaria in vantaggio competitivo.</p>
</div>

<!-- SERVIZIO 1 -->
<div class="gf-card" style="margin-bottom:1.5rem;"><div class="gf-card-body" style="padding:2rem;">
  <div style="display:flex;gap:1rem;align-items:flex-start;"><div class="gf-card-icon navy" style="flex-shrink:0;">&#x1F4CA;</div><div>
  <h3>Analisi della Governance Finanziaria</h3>
  <p><strong>La governance finanziaria aziendale è il modo in cui un'impresa gestisce le informazioni finanziarie per prendere decisioni strategiche.</strong> Il nostro assessment valuta le 10 competenze del modello Fondirigenti su 5 livelli di maturità.</p>
  <p><strong>Cosa include:</strong> gap analysis as-is/to-be, benchmark rispetto ai 400+ manager dell'indagine nazionale, piano d'azione con priorità di intervento per ciascuno dei 4 ambiti (Board, Digital, Sustainability, Trasversali).</p>
  <p><strong>Per chi:</strong> CDA, CFO, responsabili HR, imprenditori.</p>
  </div></div>
</div></div>

<!-- SERVIZIO 2 -->
<div class="gf-card" style="margin-bottom:1.5rem;"><div class="gf-card-body" style="padding:2rem;">
  <div style="display:flex;gap:1rem;align-items:flex-start;"><div class="gf-card-icon gold" style="flex-shrink:0;">&#x1F331;</div><div>
  <h3>Assessment ESG</h3>
  <p><strong>ESG (Environmental, Social and Governance) misura la sostenibilità e l'impatto etico di un'azienda.</strong> Valutiamo la ESG readiness dell'impresa rispetto alla Tassonomia UE, alla CSRD e alle aspettative di banche e investitori.</p>
  <p><strong>Cosa include:</strong> valutazione dei rischi fisici e di transizione legati al climate change, analisi dell'orientamento al valore condiviso, assessment dei modelli di economia circolare, roadmap di compliance ESG.</p>
  <p><strong>Per chi:</strong> imprese che devono rendicontare ESG, PMI che vogliono anticipare gli obblighi, aziende che cercano ESG financing.</p>
  </div></div>
</div></div>

<!-- SERVIZIO 3 -->
<div class="gf-card" style="margin-bottom:1.5rem;"><div class="gf-card-body" style="padding:2rem;">
  <div style="display:flex;gap:1rem;align-items:flex-start;"><div class="gf-card-icon teal" style="flex-shrink:0;">&#x1F3AF;</div><div>
  <h3>Supporto Decisionale e Risk Management</h3>
  <p><strong>Il risk management finanziario è il processo continuo di identificazione, misurazione, controllo e mitigazione dei rischi che impattano il valore dell'azienda.</strong></p>
  <p><strong>Cosa include:</strong> business plan multi-scenario (tendenziale/pessimista/ottimista), budget previsionali EBA-compliant, mappatura dei rischi finanziari (prezzo, cambio, tasso), supporto alla pianificazione strategica post-crisi.</p>
  <p><strong>Per chi:</strong> imprese che devono presentare piani alle banche, CFO che gestiscono contesti volatili, CDA che vogliono processi decisionali basati su dati.</p>
  </div></div>
</div></div>

<!-- SERVIZIO 4 -->
<div class="gf-card" style="margin-bottom:1.5rem;"><div class="gf-card-body" style="padding:2rem;">
  <div style="display:flex;gap:1rem;align-items:flex-start;"><div class="gf-card-icon navy" style="flex-shrink:0;">&#x1F393;</div><div>
  <h3>Formazione Manageriale</h3>
  <p>Percorsi formativi basati sul modello Fondirigenti per manager, dirigenti e board. IT security e data governance, sostenibilità ESG, change management e leadership etica. Finanziabili tramite Fondirigenti, Fondimpresa e altri fondi interprofessionali.</p>
  <p><strong>Per chi:</strong> aziende aderenti a fondi interprofessionali, HR manager, imprese che vogliono formare il board.</p>
  </div></div>
</div></div>

<div class="gf-cta-banner" style="margin-top:2rem;">
  <h2>Inizia con il checker gratuito</h2>
  <p>In 3 minuti scopri il livello di maturità della tua impresa. Poi parliamo dei passi successivi.</p>
  <a href="<?php echo home_url('/checker/'); ?>" class="gf-hero-cta">Fai il checker &rarr;</a>
</div>

</div></section>
<?php get_footer(); ?>
