<?php /** Template Name: Privacy Policy */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>Privacy Policy</h1><p>Informativa sul trattamento dei dati personali ai sensi del Reg. UE 2016/679 (GDPR)</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">

<h2>Titolare del trattamento</h2>
<p><strong>Troisi Ricerche S.r.l. Unipersonale</strong><br>Via de Rossi 57, 70122 Bari (BA)<br>CF/P.IVA: 07216100722 — REA: BA-541094<br>PEC: andrea.troisi@pec.it<br>Email: info@governancefinanziaria.it<br>Legale rappresentante: prof. Andrea Troisi</p>

<h2>Dati raccolti e finalit&agrave;</h2>
<p>Il sito governancefinanziaria.it raccoglie dati personali attraverso:</p>
<p><strong>1. Checker Assessment Governance, ESG e AI</strong> — nome, cognome, email aziendale, azienda, ruolo, telefono (opzionale), risposte al questionario di autovalutazione. Finalit&agrave;: generazione del report di assessment e invio via email; eventuale ricontatto per proposta di servizi di consulenza.</p>
<p><strong>2. Modulo contatti</strong> — nome, email, organizzazione, ruolo, messaggio. Finalit&agrave;: risposta alle richieste di informazioni e proposte commerciali.</p>
<p><strong>3. Dati di navigazione</strong> — dati tecnici raccolti automaticamente (indirizzo IP, browser, sistema operativo, pagine visitate) tramite cookie tecnici necessari al funzionamento del sito.</p>

<h2>Base giuridica</h2>
<p>Il trattamento dei dati &egrave; basato su:</p>
<p><strong>Consenso</strong> (art. 6.1.a GDPR) — per l&rsquo;invio del report di assessment, le comunicazioni relative ai servizi e l&rsquo;utilizzo di cookie analitici.</p>
<p><strong>Legittimo interesse</strong> (art. 6.1.f GDPR) — per la sicurezza del sito e la prevenzione di abusi.</p>
<p><strong>Esecuzione precontrattuale</strong> (art. 6.1.b GDPR) — per rispondere a richieste di preventivo o consulenza.</p>

<h2>Destinatari dei dati</h2>
<p>I dati personali non vengono ceduti a terzi. Possono essere trattati da collaboratori e fornitori tecnici di Troisi Ricerche S.r.l. debitamente nominati responsabili del trattamento ai sensi dell&rsquo;art. 28 GDPR. I dati sono conservati su server ubicati nell&rsquo;Unione Europea.</p>

<h2>Conservazione</h2>
<p>I dati del checker e del modulo contatti sono conservati per un periodo massimo di 24 mesi dalla raccolta, salvo diversa indicazione dell&rsquo;interessato. I cookie tecnici hanno durata di sessione. I cookie analitici (se attivati con consenso) hanno durata massima di 13 mesi.</p>

<h2>Cookie</h2>
<p><strong>Cookie tecnici</strong> (sempre attivi): necessari al funzionamento del sito, alla gestione del consenso cookie e alla sessione di navigazione. Non richiedono consenso.</p>
<p><strong>Cookie analitici</strong> (previo consenso): utilizzati per analizzare le visite al sito in forma aggregata e anonima. Attivati solo con il consenso esplicito dell&rsquo;utente tramite il banner cookie.</p>
<p>L&rsquo;utente pu&ograve; gestire le preferenze cookie in qualsiasi momento tramite le impostazioni del browser o il banner di gestione presente sul sito.</p>

<h2>Diritti dell&rsquo;interessato</h2>
<p>Ai sensi degli artt. 15-22 del GDPR, l&rsquo;interessato ha diritto di:</p>
<p>&bull; Accedere ai propri dati personali (art. 15)<br>&bull; Rettificare dati inesatti o incompleti (art. 16)<br>&bull; Ottenere la cancellazione dei dati (art. 17)<br>&bull; Limitare il trattamento (art. 18)<br>&bull; Alla portabilit&agrave; dei dati (art. 20)<br>&bull; Opporsi al trattamento (art. 21)<br>&bull; Revocare il consenso in qualsiasi momento</p>
<p>Per esercitare i propri diritti, scrivere a: <a href="mailto:info@governancefinanziaria.it">info@governancefinanziaria.it</a> oppure a mezzo PEC: andrea.troisi@pec.it.</p>

<h2>Reclamo</h2>
<p>L&rsquo;interessato ha diritto di proporre reclamo all&rsquo;Autorit&agrave; Garante per la Protezione dei Dati Personali: <a href="https://www.garanteprivacy.it" target="_blank" rel="noopener">www.garanteprivacy.it</a> — Piazza Venezia 11, 00187 Roma.</p>

<h2>Aggiornamenti</h2>
<p>La presente informativa pu&ograve; essere aggiornata periodicamente. L&rsquo;ultima revisione &egrave; del <?php echo date('d/m/Y'); ?>. Eventuali modifiche saranno pubblicate su questa pagina.</p>

<p style="margin-top:2rem;font-size:.78rem;color:var(--gf-ink-50);border-top:var(--gf-border);padding-top:1rem;"><strong>Troisi Ricerche S.r.l.</strong> &mdash; Istituto accreditato MIUR &mdash; Certificata T&Uuml;V ISO 9001:2015<br>Membro SIS (Societ&agrave; Italiana di Statistica) &middot; ASSEPRIM &middot; Confindustria Bari-BAT</p>

</div></div></section>
<?php get_footer(); ?>
