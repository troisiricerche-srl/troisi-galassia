<?php /** Template Name: Contatti */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>Contatti</h1><p>Per informazioni sul progetto, materiali e collaborazioni</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">

<div class="gf-grid gf-grid-2" style="margin-bottom:2rem;">
  <div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.5rem;">
    <h3 style="color:var(--gf-navy);font-size:1rem;margin-bottom:.75rem;">Referente progetto</h3>
    <p style="font-size:.88rem;"><strong>prof. Andrea Troisi</strong><br>Troisi Ricerche S.r.l.<br>
    <a href="mailto:info@governancefinanziaria.it">info@governancefinanziaria.it</a></p>
    <p style="font-size:.82rem;color:var(--gf-ink-50);margin-top:.75rem;">
      Via de Rossi 57, 70122 Bari<br>
      CF/P.IVA: 07216100722<br>
      PEC: andrea.troisi@pec.it
    </p>
  </div>
  <div style="background:var(--gf-gold-light);border-radius:var(--gf-radius-lg);padding:1.5rem;">
    <h3 style="color:var(--gf-gold-dark);font-size:1rem;margin-bottom:.75rem;">Prenota un appuntamento</h3>
    <p style="font-size:.88rem;">Parla direttamente con il prof. Andrea Troisi. 30 minuti gratuiti per valutare insieme le esigenze della tua impresa.</p>
    <p style="margin-top:1rem;"><a href="https://calendly.com/andreatroisi/30min" target="_blank" rel="noopener" class="gf-btn gf-btn-gold" style="display:inline-block;">Prenota su Calendly &rarr;</a></p>
  </div>
</div>

<h2>Scrivici</h2>
<p>Per richiedere materiali, report, video o per informazioni sul modello di competenze.</p>

<div id="gf-contact-form" style="background:var(--gf-ivory);border-radius:var(--gf-radius-lg);padding:1.5rem;margin-top:1rem;">
  <div id="gf-contact-success" style="display:none;text-align:center;padding:2rem 0;">
    <div style="font-size:2.5rem;margin-bottom:.75rem;">✅</div>
    <h3 style="color:var(--gf-navy);margin-bottom:.5rem;">Messaggio inviato</h3>
    <p style="color:var(--gf-ink-50);font-size:.88rem;">Risponderemo entro 48 ore.</p>
  </div>
  <form id="gf-contact" style="display:flex;flex-direction:column;gap:1rem;" onsubmit="return gfSendContact(event)">
    <?php wp_nonce_field('gf_contact_nonce', 'gf_nonce'); ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
      <div>
        <label style="font-size:.8rem;font-weight:600;color:var(--gf-ink-50);display:block;margin-bottom:.25rem;">Nome *</label>
        <input type="text" name="gf_name" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--gf-ink-08);border-radius:var(--gf-radius);font-family:var(--gf-font-body);font-size:.88rem;">
      </div>
      <div>
        <label style="font-size:.8rem;font-weight:600;color:var(--gf-ink-50);display:block;margin-bottom:.25rem;">Email *</label>
        <input type="email" name="gf_email" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--gf-ink-08);border-radius:var(--gf-radius);font-family:var(--gf-font-body);font-size:.88rem;">
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
      <div>
        <label style="font-size:.8rem;font-weight:600;color:var(--gf-ink-50);display:block;margin-bottom:.25rem;">Organizzazione</label>
        <input type="text" name="gf_org" style="width:100%;padding:.6rem .75rem;border:1px solid var(--gf-ink-08);border-radius:var(--gf-radius);font-family:var(--gf-font-body);font-size:.88rem;">
      </div>
      <div>
        <label style="font-size:.8rem;font-weight:600;color:var(--gf-ink-50);display:block;margin-bottom:.25rem;">Ruolo</label>
        <select name="gf_role" style="width:100%;padding:.6rem .75rem;border:1px solid var(--gf-ink-08);border-radius:var(--gf-radius);font-family:var(--gf-font-body);font-size:.88rem;background:white;">
          <option value="">Seleziona</option>
          <option value="dirigente">Dirigente / Manager</option>
          <option value="imprenditore">Imprenditore / CEO</option>
          <option value="cfo">CFO / Finance</option>
          <option value="hr">HR / Formazione</option>
          <option value="consulente">Consulente</option>
          <option value="accademico">Accademico / Ricercatore</option>
          <option value="istituzione">Istituzione / PA</option>
          <option value="giornalista">Giornalista</option>
          <option value="altro">Altro</option>
        </select>
      </div>
    </div>
    <div>
      <label style="font-size:.8rem;font-weight:600;color:var(--gf-ink-50);display:block;margin-bottom:.25rem;">Messaggio *</label>
      <textarea name="gf_message" rows="5" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--gf-ink-08);border-radius:var(--gf-radius);font-family:var(--gf-font-body);font-size:.88rem;resize:vertical;"></textarea>
    </div>
    <div style="display:flex;align-items:flex-start;gap:.5rem;">
      <input type="checkbox" id="gf_priv" required style="margin-top:.25rem;">
      <label for="gf_priv" style="font-size:.78rem;color:var(--gf-ink-50);">Acconsento al trattamento dei dati ai sensi del GDPR. <a href="<?php echo home_url('/privacy-policy/'); ?>" target="_blank">Privacy policy</a></label>
    </div>
    <div><button type="submit" id="gf-contact-btn" class="gf-btn gf-btn-primary">Invia messaggio</button></div>
  </form>
</div>

</div></div></section>

<script>
function gfSendContact(e) {
  e.preventDefault();
  var form = document.getElementById('gf-contact');
  var btn = document.getElementById('gf-contact-btn');
  btn.textContent = 'Invio...'; btn.disabled = true;
  var data = new FormData(form);
  data.append('action', 'gf_contact');
  fetch('<?php echo admin_url("admin-ajax.php"); ?>', {method:'POST',body:data})
    .then(function(r){return r.json();})
    .then(function(res){ if(res.success){form.style.display='none';document.getElementById('gf-contact-success').style.display='block';}else{btn.textContent='Invia messaggio';btn.disabled=false;} })
    .catch(function(){btn.textContent='Invia messaggio';btn.disabled=false;});
  return false;
}
</script>
<?php get_footer(); ?>
