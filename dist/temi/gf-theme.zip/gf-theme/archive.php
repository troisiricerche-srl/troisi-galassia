<?php get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1><?php is_category()?single_cat_title():_e('Blog'); ?></h1><p>Approfondimenti su governance finanziaria, ESG, risk management e competenze</p></div></div>
<section class="gf-section"><div class="gf-container">
<div class="gf-grid gf-grid-3">
<?php if(have_posts()):while(have_posts()):the_post();
  $slug = get_post_field('post_name', get_the_ID());
  $chart_map = [
      'governance-finanziaria-aziendale-guida' => 'art1-governance.html',
      'esg-imprese-significato-obblighi-2026' => 'art2-esg.html',
      'intelligenza-artificiale-decision-making-imprese' => 'art3-ai.html',
  ];
  $chart_file = isset($chart_map[$slug]) ? $chart_map[$slug] : '';
?>
<a href="<?php the_permalink(); ?>" class="gf-blog-card" style="display:flex;flex-direction:column;">
  <div class="gf-blog-card-img" style="height:220px;overflow:hidden;background:#f8f9fc;position:relative;">
    <?php if ($chart_file) : ?>
    <iframe src="<?php echo GF_URI . '/charts/' . $chart_file; ?>" style="width:100%;height:100%;border:none;pointer-events:none;" loading="lazy" tabindex="-1"></iframe>
    <?php elseif (has_post_thumbnail()) : ?>
    <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'blog-card'); ?>" alt="<?php the_title_attribute(); ?>" style="width:100%;height:100%;object-fit:cover;">
    <?php else : ?>
    <div style="width:100%;height:100%;background:linear-gradient(135deg,#0f2440,#1e3a5f);display:flex;align-items:center;justify-content:center;color:rgba(248,249,252,.3);font-size:2rem;">&#x1F4CA;</div>
    <?php endif; ?>
  </div>
  <div class="gf-blog-card-body" style="flex:1;display:flex;flex-direction:column;">
    <?php $cats=get_the_category();if($cats): ?><div class="cat"><?php echo esc_html($cats[0]->name); ?></div><?php endif; ?>
    <h3 style="flex:1;"><?php the_title(); ?></h3>
    <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
    <div class="meta"><?php echo get_the_date('j F Y'); ?> &middot; <?php echo ceil(str_word_count(get_the_content()) / 200); ?> min di lettura</div>
  </div>
</a>
<?php endwhile;endif; ?>
</div>
<?php the_posts_pagination(['prev_text'=>'&larr;','next_text'=>'&rarr;']); ?>
</div></section>
<?php get_footer(); ?>
