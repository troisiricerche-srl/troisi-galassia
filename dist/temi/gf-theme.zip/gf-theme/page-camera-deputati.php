<?php /** Template Name: Camera dei Deputati */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>Presentazione alla Camera dei Deputati</h1><p>Venerdì 25 marzo 2022 — Sala Conferenze Stampa — Roma</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">

<div style="background:var(--gf-gold-light);border-left:3px solid var(--gf-gold);border-radius:0 var(--gf-radius) var(--gf-radius) 0;padding:1.25rem;margin-bottom:2rem;">
  <strong style="color:var(--gf-gold-dark);">Evento istituzionale</strong><br>
  <span style="font-size:.88rem;">I risultati dell'iniziativa sulla Governance Finanziaria sono stati presentati il 25 marzo presso la Camera dei Deputati, alla presenza di rappresentanti di Confindustria, Federmanager, AIDP e del mondo accademico.</span>
</div>

<div style="border-radius:var(--gf-radius-lg);overflow:hidden;margin-bottom:2rem;">
  <img src="<?php echo GF_URI; ?>/img/camera-deputati.jpg" alt="Presentazione alla Camera dei Deputati — Governance Finanziaria — Fondirigenti — 25 marzo 2022" style="width:100%;height:auto;display:block;">
  <p style="font-size:.72rem;color:var(--gf-ink-50);margin-top:.5rem;text-align:center;">Sala Conferenze Stampa della Camera dei Deputati, 25 marzo 2022 — Presentazione del modello di competenze per la Governance Finanziaria</p>
</div>

<h2>L'evento</h2>
<p>Venerdì 25 marzo 2022, alle ore 12:00, presso la <strong>Sala Conferenze Stampa della Camera dei Deputati</strong>, sono stati presentati i risultati dell'iniziativa strategica di Fondirigenti sulla Governance Finanziaria. L'evento è stato trasmesso anche in diretta su webtv.camera.it.</p>
<p>La conferenza ha illustrato i risultati dell'indagine su oltre 400 manager e imprenditori da circa 340 imprese nazionali, il modello di competenze per la governance finanziaria (10 competenze su 4 ambiti: Dinamiche di Board, Digital &amp; Innovation, Sustainability, Competenze Trasversali) e il Maturity Model per l'autovalutazione aziendale.</p>
<p>L'evento è stato moderato da <strong>Fabio Savelli</strong>, giornalista del Corriere della Sera.</p>

<h2>Relatori</h2>
<div style="background:var(--gf-ivory);border-radius:var(--gf-radius-lg);padding:1.5rem;margin:1.5rem 0;">
  <p style="font-size:.9rem;line-height:2;">
    <strong>prof. Andrea Troisi</strong> — Referente RTI, Troisi Ricerche S.r.l.<br>
    <strong>prof. Corrado Crocetta</strong> — Docente di Statistica, DIRIUM UniBa, Comitato Scientifico<br>
    <strong>Matilde Marandola</strong> — Presidente AIDP (Associazione Italiana Direttori del Personale)<br>
    <strong>Mario Cardoni</strong> — Direttore Generale Federmanager<br>
    <strong>Riccardo Di Stefano</strong> — Presidente Giovani Imprenditori Confindustria
  </p>
  <p style="font-size:.82rem;color:var(--gf-ink-50);margin-top:.75rem;padding-top:.75rem;border-top:var(--gf-border);">Moderatore: <strong>Fabio Savelli</strong>, Corriere della Sera</p>
</div>

<h2>I risultati presentati</h2>
<p>Il cuore della presentazione è stato il <strong>modello di competenze per la governance finanziaria</strong>, costruito sulla base dell'indagine nazionale e validato dal comitato scientifico. Il modello identifica le competenze chiave che i manager devono possedere per gestire i processi finanziari in modo resiliente, integrando:</p>
<p><strong>Competenze digitali</strong> — data governance, cybersecurity, strumenti AI per il finance</p>
<p><strong>Competenze di governance</strong> — dinamiche di board, processi decisionali, risk management</p>
<p><strong>Competenze ESG</strong> — sostenibilità, rendicontazione non finanziaria, stakeholder management</p>

<h2>Impatto</h2>
<p>L'evento alla Camera dei Deputati ha rappresentato il culmine di un percorso che ha coinvolto centinaia di manager e imprenditori italiani. Il modello è ora a disposizione di tutte le imprese aderenti a Fondirigenti come strumento operativo per riprogettare i percorsi formativi della dirigenza.</p>

<h2>Video dell'evento</h2>
<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:var(--gf-radius-lg);margin:1.5rem 0;">
  <iframe src="https://www.youtube.com/embed/-gykCKwqLxw" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" allowfullscreen loading="lazy" title="Presentazione Governance Finanziaria alla Camera dei Deputati"></iframe>
</div>
<p style="font-size:.78rem;color:var(--gf-ink-50);text-align:center;">Presentazione del modello di competenze per la Governance Finanziaria — Camera dei Deputati, 25 marzo 2022</p>

<div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.5rem;margin:2rem 0;text-align:center;">
  <p style="font-size:.88rem;color:var(--gf-navy);margin-bottom:1rem;">Vuoi una copia del report o dei materiali dell'evento?</p>
  <a href="<?php echo home_url('/contatti/'); ?>" class="gf-btn gf-btn-primary">Richiedi i materiali &rarr;</a>
</div>

</div></div></section>
<?php get_footer(); ?>
