<?php /** Template Name: Webinar */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>5 Webinar</h1><p>Laboratori digitali con testimonial d'eccellenza su governance finanziaria</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">

<p>Un ciclo di 5 webinar realizzati per il confronto e l'approfondimento di buone pratiche, con testimonial d'eccellenza che hanno condiviso scenari e approcci per gestire proattivamente le tematiche chiave di Digital Transformation, Governance Strategica e Sostenibilità d'impresa.</p>

<div class="gf-timeline" style="margin:2rem 0;">
  <div class="gf-timeline-item">
    <div class="gf-timeline-date">Webinar 1</div>
    <div class="gf-timeline-title">Le competenze trasversali come leve per la governance finanziaria</div>
    <div class="gf-timeline-desc">Change management, leadership etica e sostenibile: le competenze trasversali necessarie per gestire in modo resiliente la governance finanziaria d'impresa.</div>
  </div>
  <div class="gf-timeline-item">
    <div class="gf-timeline-date">Webinar 2</div>
    <div class="gf-timeline-title">Benefici dello sviluppo sostenibile per la governance finanziaria</div>
    <div class="gf-timeline-desc">Climate change, valore condiviso, economia circolare: come la sostenibilità ESG si integra nei processi decisionali finanziari delle imprese.</div>
  </div>
  <div class="gf-timeline-item">
    <div class="gf-timeline-date">Webinar 3</div>
    <div class="gf-timeline-title">La digitalizzazione nella governance finanziaria: IT Security &amp; Privacy e Data Governance</div>
    <div class="gf-timeline-desc">Con Marco Mancarella (UniSalento) e Ilaria Rossi (SCS Consulting). Sicurezza informatica, GDPR, gestione dei dati come asset strategico aziendale.</div>
  </div>
  <div class="gf-timeline-item">
    <div class="gf-timeline-date">Webinar 4</div>
    <div class="gf-timeline-title">La pianificazione degli Economics</div>
    <div class="gf-timeline-desc">Budget finanziario e operativo, programmazione economica, analisi di scenario e regolamentazioni EBA per il management resiliente.</div>
  </div>
  <div class="gf-timeline-item">
    <div class="gf-timeline-date">Webinar 5</div>
    <div class="gf-timeline-title">Il Risk Management finanziario</div>
    <div class="gf-timeline-desc">Identificazione, misurazione, controllo e mitigazione dei rischi finanziari. Strumenti derivati, hedging e politiche di gestione del rischio.</div>
  </div>
</div>

<div style="background:var(--gf-gold-light);border-radius:var(--gf-radius-lg);padding:1.5rem;margin:1.5rem 0;">
  <p style="font-size:.88rem;color:var(--gf-gold-dark);">Le registrazioni dei webinar saranno rese disponibili a breve. <a href="<?php echo home_url('/contatti/'); ?>">Contattaci</a> per ricevere accesso ai materiali.</p>
</div>

</div></div></section>
<?php get_footer(); ?>
