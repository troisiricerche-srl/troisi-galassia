<?php /** Template Name: Video Pillole */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>10 Video Pillole</h1><p>Micro-contenuti formativi su digital transformation, governance e sostenibilità</p></div></div>
<section class="gf-section"><div class="gf-container">

<div class="gf-section-header">
  <h2>Strumenti operativi per manager e imprese</h2>
  <p>10 pillole informative per rafforzare le competenze nello scenario di "ripartenza e resilienza", capitalizzando le esperienze condivise nel network delle imprese.</p>
</div>

<div class="gf-grid gf-grid-2">
<?php
$pillole = [
  ['n'=>1,'title'=>'Come ottenere benefici dai modelli dell\'economia circolare','desc'=>'Modelli di produzione e consumo circolari, estensione del ciclo di vita dei prodotti, riduzione dei rifiuti e vantaggi competitivi.'],
  ['n'=>2,'title'=>'Perché l\'orientamento al valore condiviso sta diventando essenziale','desc'=>'Dal modello di Porter e Kramer alla creazione di valore economico e sociale: shared value e stakeholder management.'],
  ['n'=>3,'title'=>'Perché è necessaria una leadership etica e sostenibile','desc'=>'Principi morali, cultura aziendale positiva, benessere organizzativo e il nuovo paradigma di leadership per il manager resiliente.'],
  ['n'=>4,'title'=>'Cosa ci attende in termini di impatti del climate change','desc'=>'Rischio fisico e di transizione, Green Deal Europeo, Agenda 2030 e strumenti di mitigazione per le imprese.'],
  ['n'=>5,'title'=>'Come possono le competenze trasversali essere utili alla governance finanziaria','desc'=>'Change management, modello 4P, gestione del cambiamento tra razionalità ed emotività, modello di Kotter.'],
  ['n'=>6,'title'=>'Come gestire la Data Governance in contesti di cambiamento','desc'=>'Data architecture, data modeling, data mapping: gestire i dati come asset strategico aziendale.'],
  ['n'=>7,'title'=>'Le evoluzioni in tema di IT Security e Privacy','desc'=>'GDPR, Direttiva NIS, CSIRT, cybersecurity, data breach e le principali minacce informatiche per le imprese.'],
  ['n'=>8,'title'=>'Come gestire la programmazione economica finanziaria','desc'=>'Business plan, analisi di scenario, pianificazione strategica in contesti di incertezza post-pandemici.'],
  ['n'=>9,'title'=>'Come presidiare la gestione degli Economics','desc'=>'Budget finanziario e operativo, controllo di gestione, regolamentazioni EBA e scenario tendenziale vs programmatico.'],
  ['n'=>10,'title'=>'Come gestire il Risk Management finanziario','desc'=>'Identificazione, misurazione, controllo e mitigazione dei rischi: strumenti derivati, hedging e risk-tolerance.'],
];
foreach ($pillole as $p) : ?>
  <div class="gf-video-card">
    <div class="gf-video-thumb">
      <div class="gf-video-play">▶</div>
      <span style="position:absolute;top:.75rem;left:.75rem;font-size:.68rem;font-weight:600;background:var(--gf-gold);color:white;padding:.15rem .6rem;border-radius:20px;">Pillola <?php echo $p['n']; ?></span>
    </div>
    <div class="gf-video-body">
      <h3><?php echo $p['title']; ?></h3>
      <p><?php echo $p['desc']; ?></p>
    </div>
  </div>
<?php endforeach; ?>
</div>

<div style="text-align:center;margin-top:2rem;">
  <p style="font-size:.88rem;color:var(--gf-ink-50);">Le video-pillole sono disponibili gratuitamente. I video saranno caricati a breve.</p>
  <p style="margin-top:1rem;"><a href="<?php echo home_url('/contatti/'); ?>" class="gf-btn gf-btn-primary">Richiedi accesso ai materiali &rarr;</a></p>
</div>

</div></section>
<?php get_footer(); ?>
