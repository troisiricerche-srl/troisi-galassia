<?php get_header(); ?>
<section class="gf-section"><div class="gf-container" style="max-width:600px;text-align:center;">
  <h1 style="font-size:4rem;color:var(--gf-gold);margin-bottom:1rem;">404</h1>
  <h2>Pagina non trovata</h2>
  <p style="color:var(--gf-ink-50);margin:1rem 0 2rem;">La pagina che cerchi non esiste o è stata spostata.</p>
  <a href="<?php echo home_url('/'); ?>" class="gf-btn gf-btn-primary">Torna alla home &rarr;</a>
</div></section>
<?php get_footer(); ?>
