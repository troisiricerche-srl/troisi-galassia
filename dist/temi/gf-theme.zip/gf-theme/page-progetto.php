<?php /** Template Name: Il Progetto */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>Il Progetto</h1><p>Governance finanziaria, Digital Transformation e Sostenibilità ESG per il management resiliente</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;"><div class="gf-content" style="margin-top:-1.5rem;">

<h2>Obiettivi</h2>
<p>Mettere a disposizione delle imprese <strong>modelli e strumenti concreti di intervento</strong> per aiutare la dirigenza a ridisegnare i processi di governance finanziaria integrando le tematiche della Digital Transformation e la Sostenibilità d'impresa nella triplice ottica ESG (Environmental, Social and Governance).</p>

<p>Il progetto ha indagato i <strong>nuovi fabbisogni di competenze dei manager "resilienti"</strong> e ha costruito un modello immediatamente applicabile dalle imprese italiane.</p>

<h2>Il consorzio</h2>
<p>L'iniziativa è stata promossa da <strong>Fondirigenti</strong> — il fondo interprofessionale per la formazione manageriale di Confindustria e Federmanager — e realizzata dal raggruppamento temporaneo di imprese (RTI) composto da:</p>
<div class="gf-grid gf-grid-3" style="margin:1.5rem 0;">
  <div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.25rem;text-align:center;">
    <h3 style="color:var(--gf-navy);font-size:.95rem;">Troisi Ricerche S.r.l.</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-50);">Istituto accreditato MIUR. Referente scientifico e coordinamento indagine.</p>
  </div>
  <div style="background:var(--gf-gold-light);border-radius:var(--gf-radius-lg);padding:1.25rem;text-align:center;">
    <h3 style="color:var(--gf-gold-dark);font-size:.95rem;">Links Management</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-50);">Management & Technology. Piattaforma digitale e video-pillole.</p>
  </div>
  <div style="background:var(--gf-teal-light);border-radius:var(--gf-radius-lg);padding:1.25rem;text-align:center;">
    <h3 style="color:var(--gf-teal);font-size:.95rem;">SCS Consulting</h3>
    <p style="font-size:.82rem;color:var(--gf-ink-50);">Consulenza strategica. Modello di competenze e webinar.</p>
  </div>
</div>

<h2>Il modello di competenze</h2>
<p>Il modello ha preso in esame un set di competenze necessarie al management, definite sulla base di tre ambiti:</p>
<p><strong>Dinamiche di Board</strong> — il driver principale. Le competenze finanziarie che i membri del board devono possedere per amministrare le imprese in modo resiliente e consapevole.</p>
<p><strong>Digital Transformation</strong> — data governance, IT security, strumenti digitali per il CFO. Come la trasformazione digitale ridisegna il ruolo del management finanziario.</p>
<p><strong>Sostenibilità ESG</strong> — integrazione dei criteri Environmental, Social and Governance nei processi di governance finanziaria e nella rendicontazione non finanziaria.</p>

<h2>Le attività realizzate</h2>
<div style="background:var(--gf-ivory);border-radius:var(--gf-radius-lg);padding:1.5rem;margin:1.5rem 0;">
  <p style="font-size:.88rem;margin-bottom:.5rem;">&#x1F4CA; <strong>Indagine nazionale</strong> su oltre 400 imprenditori e manager da circa 340 imprese — <a href="<?php echo home_url('/indagine/'); ?>">risultati &rarr;</a></p>
  <p style="font-size:.88rem;margin-bottom:.5rem;">&#x1F3AC; <strong>10 video-pillole informative</strong> su digital transformation, governance e sostenibilità</p>
  <p style="font-size:.88rem;margin-bottom:.5rem;">&#x1F4F9; <strong>5 webinar</strong> con testimonial d'eccellenza</p>
  <p style="font-size:.88rem;">&#x1F3DB; <strong>Presentazione alla Camera dei Deputati</strong> il 25 marzo 2022 — <a href="<?php echo home_url('/camera-deputati/'); ?>">scopri &rarr;</a></p>
</div>

<h2>Comitato scientifico</h2>
<div class="gf-card" style="margin:1.5rem 0;">
  <div class="gf-founder-card">
    <div class="gf-founder-photo"><img src="<?php echo GF_URI; ?>/img/andrea-troisi.jpg" alt="prof. Andrea Troisi"></div>
    <div>
      <h3 style="margin-bottom:.25rem;">prof. Andrea Troisi</h3>
      <p style="font-size:.85rem;color:var(--gf-gold);margin-bottom:.75rem;font-weight:600;">Referente scientifico RTI — Troisi Ricerche S.r.l.</p>
      <p style="font-size:.88rem;">Fondatore di Troisi Ricerche, istituto accreditato MIUR dal 2006. Specializzato in governance, customer satisfaction e metodologie di ricerca applicate. Ha coordinato l'intera indagine nazionale e la definizione del modello di competenze.</p>
      <div class="gf-founder-links">
        <a href="https://andreatroisi.it" target="_blank" rel="noopener">andreatroisi.it &rarr;</a>
        <a href="https://troisiricerche.net" target="_blank" rel="noopener">troisiricerche.net &rarr;</a>
        <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener">LinkedIn</a>
      </div>
    </div>
  </div>
</div>
<p><strong>prof. Corrado Crocetta</strong> — Professore di Statistica, Dipartimento DIRIUM, Università degli Studi di Bari. Membro del Comitato Scientifico.</p>

</div></div></section>
<?php get_footer(); ?>
