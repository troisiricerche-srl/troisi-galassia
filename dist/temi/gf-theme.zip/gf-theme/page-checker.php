<?php /** Template Name: Checker */ get_header(); ?>

<section class="gf-hero" style="padding:3.5rem 0 3rem;">
  <div class="gf-container">
    <div class="gf-hero-inner" style="max-width:640px;">
      <div class="gf-hero-badge">Assessment gratuito &middot; 2 minuti</div>
      <h1 style="font-size:clamp(1.6rem,4vw,2.4rem);">La tua azienda &egrave; davvero pronta<br>alle sfide finanziarie, ESG e AI?</h1>
      <p class="gf-hero-desc" style="font-size:.95rem;">Scopri in 2 minuti se la tua governance espone l&rsquo;azienda a rischi decisionali, competitivi e di mercato.</p>
    </div>
  </div>
</section>

<section class="gf-section" style="padding-top:0;margin-top:-1rem;">
<div class="gf-container" style="max-width:680px;">

<div id="gf-ck-intro" style="background:var(--gf-white);border-radius:var(--gf-radius-xl);padding:2rem;border:var(--gf-border);margin-bottom:1.5rem;">
  <p style="font-size:.95rem;line-height:1.8;color:var(--gf-ink-80);">La maggior parte delle aziende ritiene di avere sotto controllo la propria governance finanziaria.</p>
  <p style="font-size:.95rem;line-height:1.8;color:var(--gf-ink-80);">Ma oggi le decisioni non dipendono pi&ugrave; solo dai numeri. Le imprese devono affrontare nuove variabili di incertezza:</p>
  <div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1rem 1.25rem;margin:1rem 0;">
    <p style="font-size:.88rem;color:var(--gf-navy);margin-bottom:.3rem;">&#x26A0; Volatilit&agrave; dei mercati e instabilit&agrave; geopolitica</p>
    <p style="font-size:.88rem;color:var(--gf-navy);margin-bottom:.3rem;">&#x26A0; Pressioni ESG da banche, investitori e normativa europea</p>
    <p style="font-size:.88rem;color:var(--gf-navy);">&#x26A0; Crescente impatto dell&rsquo;intelligenza artificiale nei processi decisionali</p>
  </div>
  <p style="font-size:.92rem;line-height:1.8;color:var(--gf-ink-80);"><strong style="color:var(--gf-ink);">In questo contesto, una governance non strutturata espone l&rsquo;azienda a rischi invisibili ma concreti.</strong></p>
  <div style="text-align:center;margin-top:1.5rem;">
    <button id="gf-ck-start" class="gf-btn gf-btn-gold" style="font-size:1rem;padding:.8rem 2rem;">Inizia la valutazione &rarr;</button>
    <p style="font-size:.72rem;color:var(--gf-ink-50);margin-top:.5rem;">12 domande &middot; 2 minuti &middot; Risultato immediato</p>
  </div>
</div>

<div id="gf-ck-app" style="display:none;"></div>

<input type="hidden" id="gf-ck-ajax-url" value="<?php echo admin_url('admin-ajax.php'); ?>" />
<input type="hidden" id="gf-ck-nonce" value="<?php echo wp_create_nonce('gf_checker_nonce'); ?>" />
<input type="hidden" id="gf-ck-privacy-url" value="<?php echo home_url('/privacy-policy/'); ?>" />
<input type="hidden" id="gf-ck-contatti-url" value="<?php echo home_url('/contatti/'); ?>" />

</div></section>

<style>
@keyframes ckspin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
@media print {
  .gf-header,.gf-footer,.gf-hero,.gf-cookie-banner,#gf-ck-intro,.no-print{display:none!important}
  .gf-section{padding:0!important;margin:0!important}
  #gf-ck-app{display:block!important}
  #gf-report-card{border:none!important;box-shadow:none!important;padding:1.5rem!important}
  body{background:white!important;font-size:12pt!important}
  .print-header{display:block!important;text-align:center;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:2px solid #1e3a5f}
  .print-header h2{font-size:16pt;color:#1e3a5f;margin-bottom:.25rem}
  .print-header p{font-size:9pt;color:#666}
  .cta-box-dark{background:#f0f0f0!important;color:#1e3a5f!important}
  .cta-box-dark h3,.cta-box-dark p,.cta-box-dark a{color:#1e3a5f!important}
}
.print-header{display:none}
</style>

<?php get_footer(); ?>
