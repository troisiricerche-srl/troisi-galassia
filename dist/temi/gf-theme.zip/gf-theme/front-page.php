<?php /** Template Name: Homepage */ get_header(); ?>

<!-- ═══ FASE 1 — HERO ═══ -->
<section class="gf-hero">
  <div class="gf-container">
    <div class="gf-hero-inner">
      <div class="gf-hero-badge"><span style="width:6px;height:6px;background:#d4a845;border-radius:50%;"></span> Troisi Ricerche &middot; Advisor strategico per governance, dati e decision making</div>
      <h1>La tua azienda &egrave; davvero pronta<br>alle sfide finanziarie, ESG e AI?</h1>
      <p class="gf-hero-desc">La maggior parte delle aziende prende decisioni finanziarie senza un modello strutturato e senza integrare ESG e intelligenza artificiale.<br><strong>Questo espone l&rsquo;azienda a rischi invisibili ma concreti.</strong></p>
      <div style="display:flex;gap:.75rem;flex-wrap:wrap;margin-top:.5rem;">
        <a href="<?php echo home_url('/checker/'); ?>" class="gf-hero-cta">Valuta la tua governance finanziaria &rarr;</a>
        <a href="<?php echo home_url('/caso-fondirigenti/'); ?>" style="display:inline-flex;align-items:center;gap:.4rem;color:rgba(248,249,252,.5);font-size:.88rem;font-weight:500;padding:.75rem 1.25rem;border:1px solid rgba(248,249,252,.12);border-radius:var(--gf-radius);transition:.2s;">Scopri il modello Fondirigenti &rarr;</a>
      </div>
      <div class="gf-hero-partners">
        Modello validato con
        <div class="gf-hero-partners-logos">
          <span>Fondirigenti</span><span>Confindustria</span><span>Federmanager</span><span>AIDP</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ FASE 2 — IL PROBLEMA ═══ -->
<section class="gf-section">
  <div class="gf-container">
    <div class="gf-section-header">
      <div class="eyebrow">Il problema che molte aziende non vedono</div>
      <h2>Governance frammentata, decisioni a rischio</h2>
    </div>
    <div class="gf-grid gf-grid-4">
      <div class="gf-stat-card">
        <div class="num" style="color:#c0392b;">76%</div>
        <div class="label"><strong style="color:var(--gf-ink);">Decisioni non data-driven</strong><br>Il 76% delle PMI italiane non usa KPI strutturati per le decisioni strategiche</div>
      </div>
      <div class="gf-stat-card">
        <div class="num" style="color:var(--gf-gold);">82%</div>
        <div class="label"><strong style="color:var(--gf-ink);">Governance frammentata</strong><br>L&rsquo;82% usa ancora Excel come strumento principale di analisi finanziaria</div>
      </div>
      <div class="gf-stat-card">
        <div class="num" style="color:var(--gf-teal);">85%</div>
        <div class="label"><strong style="color:var(--gf-ink);">ESG non integrato</strong><br>L&rsquo;85% delle imprese non ha una strategia ESG integrata nella governance</div>
      </div>
      <div class="gf-stat-card">
        <div class="num" style="color:#6b21a8;">88%</div>
        <div class="label"><strong style="color:var(--gf-ink);">AI non utilizzata</strong><br>L&rsquo;88% non ha una strategia per integrare l&rsquo;AI nelle decisioni aziendali</div>
      </div>
    </div>
    <div style="background:rgba(192,57,43,.06);border-left:3px solid #c0392b;border-radius:0 var(--gf-radius-lg) var(--gf-radius-lg) 0;padding:1.25rem 1.5rem;margin-top:2rem;max-width:720px;margin-left:auto;margin-right:auto;">
      <p style="font-size:.95rem;color:var(--gf-ink);line-height:1.7;margin:0;"><strong>Senza una governance strutturata, l&rsquo;azienda rischia di prendere decisioni meno efficaci e perdere competitivit&agrave;.</strong> L&rsquo;accesso a capitale, credito e opportunit&agrave; si riduce progressivamente. Il divario con le imprese pi&ugrave; evolute si amplia ogni trimestre.</p>
    </div>
  </div>
</section>

<!-- ═══ FASE 3 — AUTORITÀ ═══ -->
<section class="gf-section" style="background:var(--gf-white);border-top:var(--gf-border);border-bottom:var(--gf-border);">
  <div class="gf-container">
    <div class="gf-section-header">
      <div class="eyebrow">Un modello validato a livello istituzionale</div>
      <h2>Presentato alla Camera dei Deputati con Fondirigenti</h2>
    </div>
    <div class="gf-grid gf-grid-2" style="max-width:860px;margin:0 auto;gap:2.5rem;">
      <div style="border-radius:var(--gf-radius-lg);overflow:hidden;">
        <img src="<?php echo GF_URI; ?>/img/camera-deputati.jpg" alt="Presentazione Governance Finanziaria alla Camera dei Deputati — 25 marzo 2022" style="width:100%;height:100%;object-fit:cover;">
      </div>
      <div style="display:flex;flex-direction:column;justify-content:center;">
        <p style="font-size:.92rem;line-height:1.8;margin-bottom:.75rem;">Non un modello teorico. Un sistema testato su <strong>oltre 400 manager</strong> da <strong>340 imprese nazionali</strong>, con un&rsquo;indagine CATI+CAWI e uno Steering Committee di 6 professori universitari.</p>
        <p style="font-size:.88rem;line-height:1.7;margin-bottom:.75rem;">
          <strong>Progetto Fondirigenti n. 74/2020</strong><br>
          Promosso da Confindustria e Federmanager<br>
          Comitato scientifico: prof. Corrado Crocetta (UniBa)<br>
          Moderatore: <strong>Fabio Savelli</strong>, Corriere della Sera
        </p>
        <div style="background:var(--gf-gold-light);border-left:3px solid var(--gf-gold);border-radius:0 var(--gf-radius) var(--gf-radius) 0;padding:.75rem 1rem;margin-bottom:1rem;">
          <p style="font-size:.88rem;color:var(--gf-gold-dark);font-weight:600;margin:0;">Oggi questo modello &egrave; applicato da Troisi Ricerche per supportare aziende e manager nella governance finanziaria.</p>
        </div>
        <a href="<?php echo home_url('/caso-fondirigenti/'); ?>" class="gf-btn gf-btn-primary" style="align-self:flex-start;">Scopri il caso completo &rarr;</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══ FASE 4 — COSA FACCIAMO OGGI ═══ -->
<section class="gf-section">
  <div class="gf-container">
    <div class="gf-section-header">
      <div class="eyebrow">Come supportiamo le aziende</div>
      <h2>Il Metodo Troisi applicato alla tua governance</h2>
      <p>Dal modello validato con Fondirigenti a servizi operativi per imprese, CDA e CFO.<br>Rigore scientifico, applicabilit&agrave; immediata, risultati misurabili.</p>
    </div>
    <div class="gf-grid gf-grid-3">
      <div class="gf-card"><div class="gf-card-body">
        <div class="gf-card-icon navy">&#x1F4CA;</div>
        <h3>Assessment governance finanziaria</h3>
        <p>Valutazione delle 10 competenze strategiche del modello Fondirigenti. Gap analysis tra stato attuale e livello target. Piano d&rsquo;azione con priorit&agrave; per ciascuno dei 4 ambiti.</p>
      </div></div>
      <div class="gf-card"><div class="gf-card-body">
        <div class="gf-card-icon gold">&#x1F331;</div>
        <h3>Analisi ESG e risk management</h3>
        <p>ESG readiness, compliance CSRD, rischi climatici, economia circolare. Modelli di risk management finanziario strutturati e difendibili verso banche e investitori.</p>
      </div></div>
      <div class="gf-card"><div class="gf-card-body">
        <div class="gf-card-icon teal">&#x1F3AF;</div>
        <h3>Supporto decisionale e AI</h3>
        <p>Business plan multi-scenario, budget EBA-compliant, data governance, integrazione intelligenza artificiale nei processi decisionali. Formazione manageriale.</p>
      </div></div>
    </div>
    <div style="text-align:center;margin-top:1.5rem;">
      <a href="<?php echo home_url('/servizi/'); ?>" class="gf-btn gf-btn-primary">Tutti i servizi &rarr;</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" rel="noopener" class="gf-btn gf-btn-ghost" style="margin-left:.5rem;">Prenota consulenza gratuita &rarr;</a>
    </div>
  </div>
</section>

<!-- ═══ FASE 5 — CHECKER (CENTRALE) ═══ -->
<section class="gf-section" style="background:linear-gradient(135deg,#0f2440,#1e3a5f);color:#f8f9fc;">
  <div class="gf-container" style="text-align:center;">
    <div class="eyebrow" style="color:var(--gf-gold);">Strumento gratuito &middot; 12 domande &middot; 2 minuti</div>
    <h2 style="color:#f8f9fc;margin-bottom:.75rem;">Valuta la tua governance finanziaria</h2>
    <p style="color:rgba(248,249,252,.5);max-width:560px;margin:0 auto 1.5rem;font-size:.95rem;line-height:1.7;">Governance, risk management, ESG e AI: <strong style="color:rgba(248,249,252,.8);">scopri in 2 minuti il livello di maturit&agrave;</strong> della tua impresa, le aree critiche e il benchmark di mercato.</p>
    <a href="<?php echo home_url('/checker/'); ?>" class="gf-hero-cta" style="font-size:1.1rem;padding:1rem 2.5rem;">Inizia la valutazione &rarr;</a>
    <p style="font-size:.78rem;color:rgba(248,249,252,.3);margin-top:1rem;">Report immediato con profilo di rischio, analisi per area e confronto con il benchmark nazionale.</p>
  </div>
</section>

<!-- ═══ FASE 7 — COSA SUCCEDE SE NON AGISCI ═══ -->
<section class="gf-section">
  <div class="gf-container" style="max-width:860px;">
    <div class="gf-section-header">
      <div class="eyebrow" style="color:#c0392b;">Il rischio concreto</div>
      <h2>Cosa succede senza una governance evoluta</h2>
    </div>
    <div class="gf-grid gf-grid-2" style="gap:1.25rem;">
      <div style="background:rgba(192,57,43,.04);border:1px solid rgba(192,57,43,.1);border-radius:var(--gf-radius-lg);padding:1.25rem;">
        <p style="font-size:.88rem;margin:0;"><strong style="color:#c0392b;">Decisioni meno efficaci</strong><br><span style="color:var(--gf-ink-50);">Senza KPI strutturati e analisi multi-scenario, le decisioni strategiche si basano su intuizione e dati del passato. In un mercato volatile, questo significa errori pi&ugrave; frequenti e costosi.</span></p>
      </div>
      <div style="background:rgba(192,57,43,.04);border:1px solid rgba(192,57,43,.1);border-radius:var(--gf-radius-lg);padding:1.25rem;">
        <p style="font-size:.88rem;margin:0;"><strong style="color:#c0392b;">Perdita di competitivit&agrave;</strong><br><span style="color:var(--gf-ink-50);">Le aziende pi&ugrave; evolute integrano gi&agrave; governance, ESG e AI. Il divario non &egrave; statico: si amplia ogni trimestre. Chi resta fermo perde posizioni in modo irreversibile.</span></p>
      </div>
      <div style="background:rgba(192,57,43,.04);border:1px solid rgba(192,57,43,.1);border-radius:var(--gf-radius-lg);padding:1.25rem;">
        <p style="font-size:.88rem;margin:0;"><strong style="color:#c0392b;">Difficolt&agrave; di accesso al credito</strong><br><span style="color:var(--gf-ink-50);">Le nuove regolamentazioni EBA richiedono budget previsionali realistici basati su flussi di cassa. Senza governance strutturata, le banche riducono il credito o aumentano i tassi.</span></p>
      </div>
      <div style="background:rgba(192,57,43,.04);border:1px solid rgba(192,57,43,.1);border-radius:var(--gf-radius-lg);padding:1.25rem;">
        <p style="font-size:.88rem;margin:0;"><strong style="color:#c0392b;">Inefficienza organizzativa</strong><br><span style="color:var(--gf-ink-50);">Governance frammentata significa informazioni distribuite senza coerenza, processi duplicati, tempi decisionali lunghi e costi nascosti che erodono i margini.</span></p>
      </div>
    </div>
  </div>
</section>

<!-- ═══ FASE 8 — ESG + AI INTEGRATI ═══ -->
<section class="gf-section" style="background:var(--gf-white);border-top:var(--gf-border);border-bottom:var(--gf-border);">
  <div class="gf-container" style="max-width:800px;">
    <div class="gf-section-header">
      <div class="eyebrow">Il nuovo contesto competitivo</div>
      <h2>ESG e AI: le variabili che cambiano tutto</h2>
    </div>
    <p style="font-size:.95rem;line-height:1.8;color:var(--gf-ink-80);margin-bottom:1.5rem;">Oggi le decisioni aziendali sono influenzate da tre forze convergenti che non possono pi&ugrave; essere ignorate:</p>
    <div class="gf-grid gf-grid-3" style="gap:1.25rem;">
      <div style="text-align:center;padding:1.5rem;">
        <div style="font-size:2rem;margin-bottom:.75rem;">&#x1F331;</div>
        <h3 style="font-size:.95rem;margin-bottom:.5rem;">Sostenibilit&agrave; ESG</h3>
        <p style="font-size:.82rem;color:var(--gf-ink-50);">La CSRD estende l&rsquo;obbligo di rendicontazione. Banche e investitori chiedono dati ESG per il credito.</p>
      </div>
      <div style="text-align:center;padding:1.5rem;">
        <div style="font-size:2rem;margin-bottom:.75rem;">&#x1F4CA;</div>
        <h3 style="font-size:.95rem;margin-bottom:.5rem;">Data governance</h3>
        <p style="font-size:.82rem;color:var(--gf-ink-50);">Senza dati strutturati non esiste governance efficace. Il data management &egrave; il prerequisito per ogni decisione.</p>
      </div>
      <div style="text-align:center;padding:1.5rem;">
        <div style="font-size:2rem;margin-bottom:.75rem;">&#x1F916;</div>
        <h3 style="font-size:.95rem;margin-bottom:.5rem;">Intelligenza artificiale</h3>
        <p style="font-size:.82rem;color:var(--gf-ink-50);">L&rsquo;AI cambia la qualit&agrave; delle decisioni. Chi non la integra compete con strumenti del secolo scorso.</p>
      </div>
    </div>
    <div style="background:var(--gf-navy-light);border-radius:var(--gf-radius-lg);padding:1.25rem;margin-top:1.5rem;text-align:center;">
      <p style="font-size:.92rem;color:var(--gf-navy);font-weight:600;margin:0;">Le aziende che non integrano ESG, dati e AI rischiano un divario competitivo crescente e irreversibile.</p>
    </div>
  </div>
</section>

<!-- ═══ BLOG ═══ -->
<section class="gf-section">
  <div class="gf-container">
    <div class="gf-section-header">
      <div class="eyebrow">Approfondimenti</div>
      <h2>Governance, ESG e competenze: cosa sapere</h2>
    </div>
    <?php $recent = new WP_Query(['posts_per_page'=>3,'post_status'=>'publish','post__not_in'=>[1]]);
    if ($recent->have_posts()) : ?>
    <div class="gf-grid gf-grid-3">
      <?php while ($recent->have_posts()) : $recent->the_post();
        $slug = get_post_field('post_name', get_the_ID());
        $chart_map = [
            'governance-finanziaria-aziendale-guida' => 'art1-governance.html',
            'esg-imprese-significato-obblighi-2026' => 'art2-esg.html',
            'intelligenza-artificiale-decision-making-imprese' => 'art3-ai.html',
        ];
        $chart_file = isset($chart_map[$slug]) ? $chart_map[$slug] : '';
      ?>
      <a href="<?php the_permalink(); ?>" class="gf-blog-card" style="display:flex;flex-direction:column;">
        <div class="gf-blog-card-img" style="height:220px;overflow:hidden;background:#f8f9fc;position:relative;">
          <?php if ($chart_file) : ?>
          <iframe src="<?php echo GF_URI . '/charts/' . $chart_file; ?>" style="width:100%;height:100%;border:none;pointer-events:none;" loading="lazy" tabindex="-1"></iframe>
          <?php elseif (has_post_thumbnail()) : ?>
          <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'blog-card'); ?>" alt="<?php the_title_attribute(); ?>" style="width:100%;height:100%;object-fit:cover;">
          <?php else : ?>
          <div style="width:100%;height:100%;background:linear-gradient(135deg,#0f2440,#1e3a5f);display:flex;align-items:center;justify-content:center;color:rgba(248,249,252,.3);font-size:2rem;">&#x1F4CA;</div>
          <?php endif; ?>
        </div>
        <div class="gf-blog-card-body" style="flex:1;display:flex;flex-direction:column;">
          <?php $cats = get_the_category(); if ($cats) : ?><div class="cat"><?php echo esc_html($cats[0]->name); ?></div><?php endif; ?>
          <h3 style="flex:1;"><?php the_title(); ?></h3>
          <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
          <div class="meta"><?php echo get_the_date('j F Y'); ?> &middot; <?php echo ceil(str_word_count(get_the_content()) / 200); ?> min di lettura</div>
        </div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <div style="text-align:center;margin-top:1.5rem;">
      <a href="<?php echo home_url('/blog/'); ?>" class="gf-btn gf-btn-ghost">Tutti gli articoli &rarr;</a>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- ═══ FASE 9 — FAQ ═══ -->
<section class="gf-section" style="background:var(--gf-white);border-top:var(--gf-border);">
  <div class="gf-container" style="max-width:800px;">
    <div class="gf-section-header">
      <div class="eyebrow">Domande frequenti</div>
      <h2>Governance finanziaria, ESG e AI: le risposte</h2>
    </div>
    <?php $faqs = gf_get_faqs(); foreach ($faqs as $faq) : ?>
    <div style="border-bottom:var(--gf-border);padding:1.25rem 0;">
      <h3 style="font-size:1rem;margin-bottom:.4rem;color:var(--gf-ink);"><?php echo esc_html($faq['q']); ?></h3>
      <p style="font-size:.88rem;color:var(--gf-ink-80);line-height:1.7;"><?php echo esc_html($faq['a']); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ═══ FASE 7/12 — CTA FINALE ═══ -->
<section class="gf-section">
  <div class="gf-container">
    <div class="gf-cta-banner">
      <div style="font-size:.78rem;font-weight:600;text-transform:uppercase;letter-spacing:.12em;color:var(--gf-gold);margin-bottom:.75rem;">Il primo passo &egrave; misurare</div>
      <h2 style="margin-bottom:.75rem;">Scopri il livello della tua governance</h2>
      <p style="margin-bottom:1.5rem;max-width:520px;margin-left:auto;margin-right:auto;">Il checker &egrave; gratuito e basato sul modello Fondirigenti validato su 400+ manager.<br>Oppure prenota una consulenza diretta con il prof. Andrea Troisi.</p>
      <div style="display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap;">
        <a href="<?php echo home_url('/checker/'); ?>" class="gf-hero-cta">Fai il checker gratuito &rarr;</a>
        <a href="https://calendly.com/andreatroisi/30min" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:.4rem;color:rgba(248,249,252,.5);font-size:.88rem;font-weight:500;padding:.75rem 1.25rem;border:1px solid rgba(248,249,252,.15);border-radius:var(--gf-radius);transition:.2s;">Prenota su Calendly &rarr;</a>
      </div>
      <p style="font-size:.72rem;color:rgba(248,249,252,.25);margin-top:1.25rem;">Troisi Ricerche S.r.l. &mdash; Advisor strategico per governance, dati e decision making &mdash; Accreditata MIUR dal 2006</p>
    </div>
  </div>
</section>

<?php get_footer(); ?>
