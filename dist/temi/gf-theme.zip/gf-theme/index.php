<?php get_header(); ?>
<section class="gf-section"><div class="gf-container" style="max-width:800px;">
  <div class="gf-content">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
      <p><?php the_excerpt(); ?></p>
    <?php endwhile; else : ?>
      <p>Nessun contenuto trovato.</p>
    <?php endif; ?>
  </div>
</div></section>
<?php get_footer(); ?>
