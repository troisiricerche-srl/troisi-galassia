<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="gf-header">
  <div class="gf-header-inner">
    <a href="<?php echo home_url('/'); ?>" class="gf-logo" title="Governance Finanziaria — Fondirigenti">
      <div class="gf-logo-icon">GF</div>
      <div>
        <div class="gf-logo-text">Governance Finanziaria</div>
        <div class="gf-logo-sub">Governance &amp; ESG &middot; Troisi Ricerche</div>
      </div>
    </a>
    <button class="gf-menu-toggle" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
    <?php wp_nav_menu(['theme_location'=>'primary','container'=>'nav','container_class'=>'gf-nav','menu_class'=>'','items_wrap'=>'%3$s','fallback_cb'=>'gf_fallback_menu']); ?>
  </div>
</header>

<div id="gf-cookie-banner" class="gf-cookie-banner" style="display:none;">
  <div class="gf-cookie-inner">
    <div class="gf-cookie-text">
      <p>Questo sito utilizza cookie tecnici e, con il tuo consenso, analitici. <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" title="Privacy Policy">Privacy Policy</a></p>
    </div>
    <div class="gf-cookie-actions">
      <button id="gf-cookie-accept-all" class="gf-btn gf-btn-primary gf-btn-sm">Accetta</button>
      <button id="gf-cookie-accept-ess" class="gf-btn gf-btn-ghost gf-btn-sm">Solo essenziali</button>
    </div>
  </div>
</div>

<?php
function gf_fallback_menu() {
    echo '<nav class="gf-nav">';
    echo '<a href="'.home_url('/servizi/').'">Servizi</a>';
    echo '<a href="'.home_url('/caso-fondirigenti/').'">Il Caso Fondirigenti</a>';
    echo '<a href="'.home_url('/blog/').'">Blog</a>';
    echo '<a href="'.home_url('/contatti/').'">Contatti</a>';
    echo '<span class="gf-nav-cta"><a href="'.home_url('/checker/').'">Checker gratuito</a></span>';
    echo '</nav>';
}
?>
