<?php /** Template Name: FAQ */ get_header(); ?>
<div class="gf-page-header"><div class="gf-container"><h1>FAQ: Governance Finanziaria e ESG</h1><p>Le risposte della scienza alle domande più frequenti</p></div></div>
<section class="gf-section"><div class="gf-container" style="max-width:800px;">
<?php $faqs = gf_get_faqs(); foreach ($faqs as $faq) : ?>
<div style="border-bottom:var(--gf-border);padding:1.25rem 0;">
  <h3 style="font-size:1.05rem;margin-bottom:.5rem;color:var(--gf-ink);"><?php echo esc_html($faq['q']); ?></h3>
  <p style="font-size:.9rem;color:var(--gf-ink-80);line-height:1.7;"><?php echo esc_html($faq['a']); ?></p>
</div>
<?php endforeach; ?>
<div style="text-align:center;margin-top:2rem;">
  <p style="font-size:.88rem;color:var(--gf-ink-50);margin-bottom:1rem;">Non trovi la risposta che cerchi?</p>
  <a href="<?php echo home_url('/contatti/'); ?>" class="gf-btn gf-btn-primary">Scrivici →</a>
</div>
</div></section>
<?php get_footer(); ?>
