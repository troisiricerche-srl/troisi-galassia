<?php
/**
 * Template Name: La Ricerca
 */
get_header(); ?>
<?php $current_page = 'la-ricerca'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.li{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);font-weight:700;border:1px solid #b3d1ff;padding:4px 12px;border-radius:2px;background:var(--bl);text-decoration:none}
.li::after{content:'→'}
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:4px 12px;border-radius:2px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}

/* Libro hero */
.libro-hero{display:grid;grid-template-columns:200px 1fr;gap:36px;align-items:start}
.libro-cover-lg{border-radius:var(--r);overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.15)}
.libro-cover-lg img{width:100%;display:block}
.libro-badge{display:inline-block;background:var(--bl);color:var(--bd);font-size:9.5px;font-weight:700;padding:3px 10px;border-radius:2px;margin-bottom:10px;text-transform:uppercase;letter-spacing:.06em}
.libro-titolo{font-size:22px;font-weight:700;color:var(--dp);margin-bottom:6px;line-height:1.25}
.libro-autori{font-size:13px;color:var(--g);margin-bottom:16px}
.libro-autori strong{color:var(--t)}
.libro-desc{font-size:13px;color:var(--g);line-height:1.8;margin-bottom:18px}
.libro-meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:20px}
.lmg-item{background:var(--bg);border:0.5px solid var(--bo);border-radius:var(--r);padding:10px 14px}
.lmg-k{font-size:9.5px;text-transform:uppercase;letter-spacing:.06em;color:var(--g);font-weight:700;margin-bottom:2px}
.lmg-v{font-size:13px;font-weight:700;color:var(--dp)}
.libro-btns{display:flex;gap:10px;flex-wrap:wrap}
.btn-acquista{background:var(--blu);color:#fff;padding:10px 22px;border-radius:var(--r);font-size:13px;font-weight:700;text-decoration:none;display:inline-block}
.btn-acquista:hover{background:var(--bd);color:#fff;text-decoration:none}

/* Metodo */
.metodo-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.mc{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:20px;border-top:3px solid var(--blu)}
.mc-num{font-size:28px;font-weight:700;color:var(--bl-);margin-bottom:6px;color:var(--blu);line-height:1}
.mc-t{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:5px}
.mc-d{font-size:12px;color:var(--g);line-height:1.65}

/* Modelli proprietari */
.modelli-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.mod-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:20px;display:flex;gap:16px;align-items:flex-start}
.mod-icon{width:48px;height:48px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0}
.mod-name{font-size:14px;font-weight:700;color:var(--dp);margin-bottom:5px}
.mod-desc{font-size:12px;color:var(--g);line-height:1.65;margin-bottom:10px}
.mod-btns{display:flex;gap:7px;flex-wrap:wrap}

/* Collaborazioni */
.collab-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.cc{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;text-align:center}
.cc-logo{max-height:44px;width:auto;object-fit:contain;margin-bottom:8px;filter:grayscale(15%)}
.cc-name{font-size:12px;font-weight:700;color:var(--dp);margin-bottom:2px}
.cc-desc{font-size:10.5px;color:var(--g);line-height:1.45}

/* Pubblicazioni */
.pub-list{display:flex;flex-direction:column;gap:0}
.pub-item{padding:14px 0;border-bottom:0.5px solid var(--bo);display:flex;gap:14px;align-items:flex-start}
.pub-item:last-child{border:none}
.pub-anno{font-size:11px;font-weight:700;color:var(--blu);min-width:38px;padding-top:2px}
.pub-content{}
.pub-titolo{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:3px;line-height:1.35}
.pub-autori{font-size:11.5px;color:var(--g);margin-bottom:2px}
.pub-rivista{font-size:11px;color:var(--blu);font-weight:600}
@media(max-width:900px){.libro-hero{grid-template-columns:1fr}.metodo-grid{grid-template-columns:1fr 1fr}.modelli-grid{grid-template-columns:1fr}.collab-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.metodo-grid{grid-template-columns:1fr}.collab-grid{grid-template-columns:repeat(2,1fr)}.libro-meta-grid{grid-template-columns:1fr}}
</style>

<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; La ricerca</div>
  <h1>Metodo, modelli e <em>pubblicazioni</em></h1>
  <p>L'approccio scientifico di Troisi Ricerche: modelli statistici proprietari, pubblicazioni accademiche, collaborazioni con università e centri di ricerca.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; La ricerca</div>

<!-- IL LIBRO -->
<div class="sec alt" id="libro">
  <div class="sh"><div class="sl"></div><div class="se">La pubblicazione principale</div></div>
  <div class="libro-hero">
    <div class="libro-cover-lg">
      <img src="<?php echo get_template_directory_uri(); ?>/copertina-libro.jpg" alt="Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione">
    </div>
    <div>
      <div class="libro-badge">Cacucci Editore &middot; Bari</div>
      <div class="libro-titolo">Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione</div>
      <div class="libro-autori"><strong>Andrea Troisi</strong>, Silvia Gravili</div>
      <div class="libro-desc">Il volume presenta un modello statistico integrato per la misurazione e l'analisi della customer satisfaction nelle pubbliche amministrazioni italiane. Il lavoro sviluppa un framework metodologico rigoroso che combina tecniche quantitative avanzate con la specificità del contesto pubblico: dalla progettazione del questionario all'analisi multivariata dei dati, fino alla restituzione dei risultati alle amministrazioni per il miglioramento dei servizi. Un riferimento per ricercatori, statistici, dirigenti pubblici e professionisti della qualità.</div>
      <div class="libro-meta-grid">
        <div class="lmg-item"><div class="lmg-k">ISBN</div><div class="lmg-v">978-88-6611-797-1</div></div>
        <div class="lmg-item"><div class="lmg-k">Editore</div><div class="lmg-v">Cacucci Editore</div></div>
        <div class="lmg-item"><div class="lmg-k">Autori</div><div class="lmg-v">Troisi A., Gravili S.</div></div>
        <div class="lmg-item"><div class="lmg-k">Settore</div><div class="lmg-v">Statistica &middot; PA</div></div>
      </div>
      <div class="libro-btns">
        <a href="https://www.cacuccieditore.it/un-modello-statistico-per-lanalisi-della-customer-satisfaction-nella-pubblica-amministrazione-9788866117971" target="_blank" class="btn-acquista">Acquista su Cacucci Editore ↗</a>
        <a href="<?php echo home_url('/contatti'); ?>" class="li">Richiedi informazioni</a>
      </div>
    </div>
  </div>
</div>

<!-- NUOVO LIBRO: BENESSERE ORGANIZZATIVO -->
<div class="sec" id="libro-benessere">
  <div class="sh"><div class="sl"></div><div class="se">Novità 2026</div></div>
  <div class="libro-hero">
    <div class="libro-cover-lg">
      <?php
      $_cover_bo = get_template_directory() . '/copertina-benessere.jpg';
      $_cover_url = file_exists($_cover_bo) ? get_template_directory_uri() . '/copertina-benessere.jpg' : wp_get_attachment_image_url(271, 'large');
      if ($_cover_url): ?>
        <img src="<?php echo esc_url($_cover_url); ?>" alt="Le organizzazioni che si misurano — Andrea Troisi, Cacucci Editore 2026">
      <?php else: ?>
        <div style="aspect-ratio:2/3;background:linear-gradient(150deg,var(--dp) 0%,var(--blu) 100%);display:flex;flex-direction:column;justify-content:space-between;padding:24px 20px;color:#fff">
          <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;opacity:.7">Cacucci Editore</div>
          <div>
            <div style="font-size:20px;font-weight:700;line-height:1.2;font-family:'Lora',serif">Le organizzazioni che si misurano</div>
            <div style="width:36px;height:3px;background:var(--or);margin:14px 0"></div>
            <div style="font-size:12px;opacity:.85">Andrea Troisi</div>
          </div>
          <div style="font-size:9px;opacity:.55">2026</div>
        </div>
      <?php endif; ?>
    </div>
    <div>
      <div class="libro-badge">Cacucci Editore &middot; Bari &middot; 2026</div>
      <div class="libro-titolo">Le organizzazioni che si misurano</div>
      <div class="libro-autori" style="font-style:italic;color:var(--g);margin-top:-2px;margin-bottom:10px">Il benessere organizzativo dalla compliance alla consapevolezza</div>
      <div class="libro-autori"><strong>Andrea Troisi</strong></div>
      <div class="libro-desc">Il nuovo volume di Andrea Troisi affronta il benessere organizzativo come leva di misurazione e miglioramento delle organizzazioni. Attraverso un percorso in dieci capitoli, il libro accompagna il lettore dalla compliance alla consapevolezza, proponendo principi, indicatori e strumenti per rilevare, interpretare e migliorare la qualità della vita lavorativa, con rigore statistico e applicabilità concreta nelle imprese e nelle pubbliche amministrazioni.</div>
      <div style="background:var(--dp);color:#fff;border-radius:var(--r);padding:10px 14px;font-size:12px;line-height:1.55;margin:4px 0 12px"><strong style="color:var(--or);text-transform:uppercase;letter-spacing:.05em;font-size:10.5px">Presentato al Senato della Repubblica</strong><br>Palazzo Madama, Sala Caduti di Nassirya · 15 giugno 2026 · <a href="<?php echo home_url('/media'); ?>#senato" style="color:#fff;text-decoration:underline">foto e media</a></div>
      <div class="libro-meta-grid">
        <div class="lmg-item"><div class="lmg-k">ISBN</div><div class="lmg-v">979-12-5965-650-6</div></div>
        <div class="lmg-item"><div class="lmg-k">Editore</div><div class="lmg-v">Cacucci Editore</div></div>
        <div class="lmg-item"><div class="lmg-k">Autore</div><div class="lmg-v">Troisi A.</div></div>
        <div class="lmg-item"><div class="lmg-k">Tema</div><div class="lmg-v">Benessere organizzativo</div></div>
      </div>
      <div class="libro-btns">
        <a href="https://www.cacuccieditore.it/le-organizzazioni-che-si-misurano-il-benessere-organizzativo-dalla-compliance-alla-consapevolezza-troisi-9791259656506" target="_blank" class="btn-acquista">Acquista su Cacucci Editore ↗</a>
        <a href="<?php echo home_url('/contatti'); ?>" class="li">Richiedi informazioni</a>
      </div>
    </div>
  </div>
</div>

<!-- IL METODO -->
<div class="sec" id="metodo">
  <div class="sh"><div class="sl"></div><div class="se">Approccio scientifico</div></div>
  <div class="s-t">Il <em>metodo</em> Troisi Ricerche</div>
  <p class="s-d">Un approccio che combina rigore statistico, conoscenza del contesto pubblico e capacità di restituire risultati comprensibili e utili per chi decide.</p>
  <div class="metodo-grid">
    <div class="mc">
      <div class="mc-num">01</div>
      <div class="mc-t">Progettazione dell'indagine</div>
      <div class="mc-d">Definizione degli obiettivi, identificazione del campione ottimale (formula di Cochran), costruzione del questionario secondo le linee guida scientifiche e normative. Ogni indagine parte da un brief metodologico preciso.</div>
    </div>
    <div class="mc">
      <div class="mc-num">02</div>
      <div class="mc-t">Raccolta e validazione dati</div>
      <div class="mc-d">Rilevazione CATI, CAWI o mista tramite TIP Platform. Controlli di qualità sui dati grezzi, gestione dei valori anomali, ponderazione campionaria quando necessaria.</div>
    </div>
    <div class="mc">
      <div class="mc-num">03</div>
      <div class="mc-t">Analisi statistica avanzata</div>
      <div class="mc-d">Analisi univariata e bivariata, analisi della varianza, regressione, cluster analysis, analisi fattoriale. Modelli proprietari: CSI (Customer Satisfaction Index), IWS (Index of Well-being at work), TR-Index.</div>
    </div>
    <div class="mc">
      <div class="mc-num">04</div>
      <div class="mc-t">Benchmarking e confronto</div>
      <div class="mc-d">Confronto con i valori medi nazionali del settore, trend temporali, analisi per segmento di utenza. Database storico di Troisi Ricerche su oltre 500 indagini realizzate dal 2006.</div>
    </div>
    <div class="mc">
      <div class="mc-num">05</div>
      <div class="mc-t">Restituzione e raccomandazioni</div>
      <div class="mc-d">Report esecutivo, presentazione ai decisori, identificazione delle priorità di intervento. Non solo dati: ogni ricerca si conclude con raccomandazioni operative concrete.</div>
    </div>
    <div class="mc">
      <div class="mc-num">06</div>
      <div class="mc-t">Monitoraggio nel tempo</div>
      <div class="mc-d">Impostazione di cicli periodici di rilevazione per misurare l'impatto degli interventi di miglioramento. Dashboard live su TroisiInsight.it per i clienti che scelgono il monitoraggio continuativo.</div>
    </div>
  </div>
</div>

<!-- MODELLI PROPRIETARI -->
<div class="sec alt" id="modelli">
  <div class="sh"><div class="sl"></div><div class="se">Modelli proprietari</div></div>
  <div class="s-t">Gli <em>indici e modelli</em> sviluppati da Troisi Ricerche</div>
  <div class="modelli-grid">
    <div class="mod-card">
      <div class="mod-icon">😊</div>
      <div>
        <div class="mod-name">CSI · Customer Satisfaction Index</div>
        <div class="mod-desc">Modello proprietario per la misurazione della soddisfazione degli utenti nei servizi pubblici. Derivato dal libro (Cacucci, 2014). Applicato in 200+ indagini su trasporti, sanità, uffici pubblici, utilities.</div>
        <div class="mod-btns"><a href="https://customerpa.it" target="_blank" rel="noopener" class="le">CustomerPA.it</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">📐</div>
      <div>
        <div class="mod-name">TR-Index · Indice territoriale</div>
        <div class="mod-desc">Indicatore composito per la misurazione della qualità e performance dei territori italiani. Aggiornato annualmente. Basato su fonti ISTAT, Eurostat e dati istituzionali. Classificazione dei capoluoghi di provincia.</div>
        <div class="mod-btns"><a href="https://t-index.it" target="_blank" rel="noopener" class="le">t-index.it</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">🧠</div>
      <div>
        <div class="mod-name">IWS · Index of Well-being at work</div>
        <div class="mod-desc">Modello per la misurazione del benessere organizzativo nelle pubbliche amministrazioni. Conforme al D.Lgs. 150/2009. Applicato in ERSAF, ESU Padova, AQP, AMIU e molte altre PA.</div>
        <div class="mod-btns"><a href="https://benessereorganizzativo.it" target="_blank" rel="noopener" class="le">BenessereOrg.it</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">🗺️</div>
      <div>
        <div class="mod-name">Mappatura delle Competenze · Skill Mapping Model</div>
        <div class="mod-desc">Framework per la mappatura delle competenze aziendali e della PA. Skill gap analysis con AI, piani formativi Fondimpresa, competency framework EQF-aligned. Alla base del sistema Mappatura delle Competenze.</div>
        <div class="mod-btns"><a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener" class="le">Mappatura delle Competenze</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">📜</div>
      <div>
        <div class="mod-name">Registro delle Competenze · Certification Framework</div>
        <div class="mod-desc">Piattaforma per la certificazione formale delle competenze conforme al D.Lgs. 13/2013. Monitoraggio nel tempo con Indice RC. Integrato con Mappatura delle Competenze.</div>
        <div class="mod-btns"><a href="https://registrodellecompetenze.it" target="_blank" rel="noopener" class="le">Registro delle Competenze</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">💼</div>
      <div>
        <div class="mod-name">GFI · Governance Finanziaria d'Impresa</div>
        <div class="mod-desc">Modello di competenze per la governance finanziaria promosso da Fondirigenti. ESG, decision making, AI applicata alla finanza d'impresa. Con Links Management e SCS Consulting.</div>
        <div class="mod-btns"><a href="https://governancefinanziaria.it" target="_blank" rel="noopener" class="le">GovernanceFin.it</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">📱</div>
      <div>
        <div class="mod-name">BDG · Benessere Digitale Giovani</div>
        <div class="mod-desc">Osservatorio sul benessere digitale dei giovani. Dati scientifici e strumenti gratuiti per genitori, insegnanti e istituzioni. Dipendenza smartphone, tempo schermo, effetti social media.</div>
        <div class="mod-btns"><a href="https://benesseredigitalegiovani.it" target="_blank" rel="noopener" class="le">BDG</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">⚡</div>
      <div>
        <div class="mod-name">TIP · Troisi Intelligence Platform</div>
        <div class="mod-desc">Piattaforma proprietaria per raccogliere, analizzare e attivare dati in tempo reale. Survey avanzate, monitoraggio, live polling, dashboard KPI. Per PA, aziende, eventi e formazione.</div>
        <div class="mod-btns"><a href="https://tiplive.it" target="_blank" rel="noopener" class="le">TIP Platform</a></div>
      </div>
    </div>
    <div class="mod-card">
      <div class="mod-icon">🏛️</div>
      <div>
        <div class="mod-name">DELFI · I dati di tutti i comuni italiani</div>
        <div class="mod-desc">Il portale con i dati ufficiali di tutti i 7.896 comuni italiani: popolazione, economia, redditi, ambiente, scuola, sanità, investimenti pubblici e PNRR, da fonti istituzionali (ISTAT, MEF, ISPRA, Ministero dell'Interno, OpenCoesione, Italia Domani e altre). Come funziona: cerchi un comune e apri la sua scheda, organizzata in 12 sezioni tematiche; puoi confrontare più comuni, consultare classifiche e mappa, e riutilizzare i dati con licenza CC BY 4.0 o tramite API.</div>
        <div class="mod-btns"><a href="https://www.delfiweb.it" target="_blank" rel="noopener" class="le">delfiweb.it</a></div>
      </div>
    </div>
  </div>
</div>

<!-- COLLABORAZIONI UNIVERSITARIE -->
<div class="sec" id="collaborazioni">
  <div class="sh"><div class="sl"></div><div class="se">Collaborazioni accademiche</div></div>
  <div class="s-t">Università e centri di <em>ricerca</em></div>
  <p class="s-d">Troisi Ricerche collabora con istituzioni accademiche e scientifiche per la produzione di ricerca applicata, la co-autorialità di pubblicazioni e la partecipazione a progetti di ricerca.</p>
  <div class="collab-grid">
    <div class="cc">
      <img src="<?php echo get_template_directory_uri(); ?>/loghi-clienti/uniba.jpg" alt="Università di Bari" class="cc-logo" style="background:#fff;padding:4px;border-radius:4px">
      <div class="cc-name">Università degli Studi di Bari</div>
      <div class="cc-desc">Collaborazioni su statistica applicata e ricerche territoriali</div>
    </div>
    <div class="cc">
      <img src="<?php echo get_template_directory_uri(); ?>/loghi-clienti/Unibo.png" alt="Università di Bologna" class="cc-logo" style="background:#fff;padding:4px;border-radius:4px">
      <div class="cc-name">Università di Bologna</div>
      <div class="cc-desc">Ricerche su benessere organizzativo e governance pubblica</div>
    </div>
    <div class="cc">
      <img src="<?php echo get_template_directory_uri(); ?>/logo-sis.png" alt="SIS" class="cc-logo" style="background:#fff;padding:4px;border-radius:4px">
      <div class="cc-name">SIS · Società Italiana di Statistica</div>
      <div class="cc-desc">Ente aderente. Partecipazione ai congressi scientifici nazionali</div>
    </div>
    <div class="cc">
      <img src="<?php echo get_template_directory_uri(); ?>/loghi-clienti/cnr.jpg" alt="CNR" class="cc-logo" style="background:#fff;padding:4px;border-radius:4px">
      <div class="cc-name">CNR · Consiglio Nazionale delle Ricerche</div>
      <div class="cc-desc">Collaborazioni su indagini e metodologie di ricerca</div>
    </div>
  </div>
</div>

<!-- PUBBLICAZIONI -->
<div class="sec alt" id="pubblicazioni">
  <div class="sh"><div class="sl"></div><div class="se">Pubblicazioni e contributi</div></div>
  <div class="s-t">Articoli, saggi e <em>contributi scientifici</em></div>
  <div class="pub-list">
    <div class="pub-item">
      <div class="pub-anno">2026</div>
      <div class="pub-content">
        <div class="pub-titolo">Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Cacucci Editore, Bari &middot; ISBN 979-12-5965-650-6</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2014</div>
      <div class="pub-content">
        <div class="pub-titolo">Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione</div>
        <div class="pub-autori">Troisi A., Gravili S.</div>
        <div class="pub-rivista">Cacucci Editore, Bari &middot; ISBN 978-88-6611-797-1</div>
        <div style="margin-top:6px;font-size:11px;color:var(--vd,#008a5f);font-weight:600">📍 Presentato alla Camera dei Deputati il 29 marzo 2019 — conferenza stampa ufficiale trasmessa in diretta su webtv.camera.it · Selezionato dall'ANAC come modello nazionale di riferimento per la Customer Satisfaction nella PA</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2023</div>
      <div class="pub-content">
        <div class="pub-titolo">Il dibattito pubblico alla prova: esperienze italiane post-DPCM 76/2018</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Contributo a convegno &middot; Forum PA 2023</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2022</div>
      <div class="pub-content">
        <div class="pub-titolo">TR-Index 2022: metodologia e risultati del ranking territoriale italiano</div>
        <div class="pub-autori">Troisi Ricerche</div>
        <div class="pub-rivista">Report annuale &middot; disponibile su t-index.it</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2021</div>
      <div class="pub-content">
        <div class="pub-titolo">Benessere organizzativo nella PA: stato dell'arte e prospettive post-pandemia</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Intervento a convegno &middot; AIDP 2021</div>
      </div>
    </div>

    <div class="pub-item">
      <div class="pub-anno">2025</div>
      <div class="pub-content">
        <div class="pub-titolo">parlIAmone — AI &amp; Compliance</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Domus Libraria Cacucci &middot; Bari &middot; Con Cacucci Editore</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2025</div>
      <div class="pub-content">
        <div class="pub-titolo">CiBari 2025 — Il Cibo della Salute</div>
        <div class="pub-autori">Membro Comitato Tecnico-Scientifico</div>
        <div class="pub-rivista">Piazza del Ferrarese &middot; Bari &middot; 3ª edizione</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2025</div>
      <div class="pub-content">
        <div class="pub-titolo">Forum Pubblici Ufficiali — II Edizione</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Convegno &middot; Bari &middot; 4 Aprile 2025</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2025</div>
      <div class="pub-content">
        <div class="pub-titolo">Fondimpresa — «Nuove Corsie per il Lavoro»</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Corsie Sistine &middot; Santo Spirito in Sassia &middot; Roma</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2025</div>
      <div class="pub-content">
        <div class="pub-titolo">Presentazione «Canone Giusto»</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Palazzo della Città &middot; Comune di Bari</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2024</div>
      <div class="pub-content">
        <div class="pub-titolo">Assoradio — Indagine Radio Puglia</div>
        <div class="pub-autori">Troisi Ricerche</div>
        <div class="pub-rivista">Fiera del Levante &middot; Bari &middot; Ottobre 2024</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2024</div>
      <div class="pub-content">
        <div class="pub-titolo">EDU Exhibition 2ª ed. — «Tra bit e qubit: l'IA entra in classe»</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Relatore al lancio ufficiale &middot; Bari</div>
      </div>
    </div>
    <div class="pub-item">
      <div class="pub-anno">2024</div>
      <div class="pub-content">
        <div class="pub-titolo">Accademia Cittadella Nicolaiana — Giornata della Memoria David Sassoli</div>
        <div class="pub-autori">Troisi A.</div>
        <div class="pub-rivista">Bari &middot; Vice Presidente Accademia</div>
      </div>
    </div>
  </div>
  <p style="margin-top:16px;font-size:12px;color:var(--g)">Per richiedere articoli completi, metodologie o collaborazioni di ricerca: <a href="<?php echo home_url('/contatti'); ?>" style="color:var(--blu);font-weight:700">contattaci</a></p>
</div>

<!-- DAL NETWORK DI TROISI RICERCHE - IN TEMPO REALE -->
<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Dal Network di Troisi Ricerche &middot; in tempo reale</div></div>
    <div class="s-t">Dati e contenuti <em>live dai siti del network</em></div>
    <p class="s-d">Ogni sito del network alimenta questa sezione in tempo reale. I grafici, i dati e gli articoli più recenti, direttamente dai siti dedicati.</p>
    <!-- GRAFICI IN EVIDENZA -->
    <div style="background:var(--dp);border-radius:var(--r);padding:22px;margin-bottom:16px">
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px;text-align:center">
        <div>
          <div style="font-size:32px;font-weight:800;color:var(--or)">370</div>
          <div style="font-size:10px;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.05em">Campione ottimale<br>pop. 10.000 · ±5%</div>
          <a href="<?php echo home_url('/strumenti/calcola-campione/'); ?>" style="font-size:10px;color:var(--blu);margin-top:4px;display:inline-block">Calcolatore PRO →</a>
        </div>
        <div style="border-left:1px solid rgba(255,255,255,.1);border-right:1px solid rgba(255,255,255,.1)">
          <div style="font-size:32px;font-weight:800;color:var(--blu)">7.901</div>
          <div style="font-size:10px;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.05em">Comuni nel ranking<br>TR-Index 2026</div>
          <a href="https://t-index.it" target="_blank" style="font-size:10px;color:var(--blu);margin-top:4px;display:inline-block">TR-Index.it →</a>
        </div>
        <div>
          <div style="font-size:32px;font-weight:800;color:var(--vd,#008a5f)">200+</div>
          <div style="font-size:10px;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.05em">Indagini CS<br>CustomerPA Index</div>
          <a href="https://customerpa.it" target="_blank" style="font-size:10px;color:var(--blu);margin-top:4px;display:inline-block">CustomerPA.it →</a>
        </div>
      </div>
    </div>
    <!-- FEED LIVE DAI SITI -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px">
      <!-- TroisiInsight -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:12px 14px;display:flex;align-items:center;gap:6px">
          <div style="width:7px;height:7px;border-radius:50%;background:#0066cc;flex-shrink:0"></div>
          <span style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.7)">TroisiInsight</span>
          <span style="font-size:7px;font-weight:700;color:#fff;background:var(--blu);padding:1px 5px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:14px">
          <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--g);margin-bottom:6px">Ultimo grafico</div>
          <?php
          $insight = troisi_satellite_feed('https://troisiinsight.it/feed');
          if ($insight && $insight[0]['title'] && strpos(strtolower($insight[0]['title']), 'ciao mondo') === false):
          ?>
          <div style="font-size:12.5px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35"><?php echo esc_html($insight[0]['title']); ?></div>
          <?php else: ?>
          <div style="font-size:12.5px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35">Prezzi carburante e mobilità urbana</div>
          <?php endif; ?>
          <a href="https://troisiinsight.it" target="_blank" rel="noopener" class="le" style="font-size:11px">TroisiInsight.it →</a>
        </div>
      </div>
      <!-- BenessereOrg -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:12px 14px;display:flex;align-items:center;gap:6px">
          <div style="width:7px;height:7px;border-radius:50%;background:#008a5f;flex-shrink:0"></div>
          <span style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.7)">BenessereOrg.</span>
          <span style="font-size:7px;font-weight:700;color:#fff;background:var(--blu);padding:1px 5px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:14px">
          <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--g);margin-bottom:6px">Ultimo dato</div>
          <?php
          $benessere = troisi_satellite_feed('https://benessereorganizzativo.it/feed');
          if ($benessere && $benessere[0]['title'] && strpos(strtolower($benessere[0]['title']), 'ciao mondo') === false):
          ?>
          <div style="font-size:12.5px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35"><?php echo esc_html($benessere[0]['title']); ?></div>
          <?php else: ?>
          <div style="font-size:12.5px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35">Indice Benessere Organizzativo PA 2025</div>
          <?php endif; ?>
          <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener" class="le" style="font-size:11px">BenessereOrg.it →</a>
        </div>
      </div>
      <!-- TR-Index -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:12px 14px;display:flex;align-items:center;gap:6px">
          <div style="width:7px;height:7px;border-radius:50%;background:var(--or);flex-shrink:0"></div>
          <span style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.7)">TR-Index</span>
          <span style="font-size:7px;font-weight:700;color:#fff;background:var(--blu);padding:1px 5px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:14px">
          <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--g);margin-bottom:6px">Ranking 2026</div>
          <div style="font-size:12.5px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35">Ranking territoriale 7.901 comuni italiani</div>
          <a href="https://t-index.it" target="_blank" rel="noopener" class="le" style="font-size:11px">TR-Index.it →</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- STRUMENTI DELLA RICERCA -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Strumenti</div></div>
    <div class="s-t"><em>Strumenti</em> per la ricerca statistica</div>
    <p class="s-d">Tool gratuiti e piattaforme professionali disponibili su questo sito e sui siti dedicati del network.</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px;align-items:flex-start">
        <div style="width:44px;height:44px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">🧮</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px">Calcolatore Campione PRO</div>
          <div style="font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:9px">Formula di Cochran, grafico interattivo, export PDF, confronto scenari. Lo strumento professionale per la dimensione campionaria.</div>
          <a href="<?php echo home_url('/strumenti/calcola-campione/'); ?>" class="li">Apri il tool →</a>
        </div>
      </div>
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px;align-items:flex-start">
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo-tip.png" alt="TIP" style="width:44px;height:auto;flex-shrink:0;border-radius:var(--r)">
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px">TIP — Troisi Intelligence Platform</div>
          <div style="font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:9px">Survey avanzate, live polling, dashboard KPI, report PDF, AI insights. Per PA, aziende, eventi.</div>
          <a href="https://tiplive.it" target="_blank" class="li">Scopri TIP →</a>
        </div>
      </div>
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px;align-items:flex-start">
        <div style="width:44px;height:44px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">📐</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px">TR-Index · Ranking territoriale</div>
          <div style="font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:9px">Indice proprietario per misurare qualità e performance dei 7.901 comuni italiani.</div>
          <a href="https://t-index.it" target="_blank" class="li">TR-Index.it →</a>
        </div>
      </div>
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px;align-items:flex-start">
        <div style="width:44px;height:44px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">🗺️</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px">Mappatura delle Competenze · Mappatura competenze</div>
          <div style="font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:9px">Skill mapping, gap analysis AI, piani formativi Fondimpresa. Per PA e aziende.</div>
          <a href="https://mappaturadellecompetenze.it" target="_blank" class="li">Mappatura delle Competenze →</a>
        </div>
      </div>
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px;align-items:flex-start">
        <div style="width:44px;height:44px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">😊</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px">CustomerPA · Satisfaction Index</div>
          <div style="font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:9px">Misurazione customer satisfaction nei servizi pubblici. Checker gratuito, questionari CAWI/CATI.</div>
          <a href="https://customerpa.it" target="_blank" class="li">CustomerPA.it →</a>
        </div>
      </div>
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px;align-items:flex-start">
        <div style="width:44px;height:44px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">🗣️</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px">Dibattito Pubblico</div>
          <div style="font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:9px">Gestione processi partecipativi grandi opere. Conforme all'art. 40 del D.Lgs. 36/2023 (Allegato I.6). Con TenderCoop e Ti Quadro.</div>
          <a href="https://dibattito-pubblico.it" target="_blank" class="li">Dibattito-Pubblico.it →</a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
