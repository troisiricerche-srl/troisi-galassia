<?php /** Template Name: Strumento — CustomerPA */
get_header(); $current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
</style>
<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1>😊 <em>CustomerPA</em></h1>
  <p>Customer satisfaction per la PA — parte del network Troisi Ricerche.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; CustomerPA</div>
<div class="sec alt"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Cos'è CustomerPA</div></div>
  <div class="s-t">Un progetto del <em>network Troisi Ricerche</em></div>
  <p class="s-d">Piattaforma per la misurazione della soddisfazione degli utenti dei servizi pubblici.</p>
  <p class="s-d">CustomerPA nasce dall'esperienza ventennale di Troisi Ricerche nella ricerca statistica applicata. Ogni strumento del network è progettato per rendere i dati accessibili e utili a chi decide: enti pubblici, imprese, università.</p>
  <div class="cta-box">
    <h3>😊 Visita CustomerPA</h3>
    <p>Accedi al sito dedicato per esplorare tutte le funzionalità e i contenuti di CustomerPA.</p>
    <a href="https://customerpa.it" target="_blank" rel="noopener" class="cta-p">Vai su https://customerpa.it ↗</a>
    <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Contattaci →</a>
  </div>
</div></div>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
