<?php
/**
 * page.php — Router template per Troisi Ricerche
 * Carica il template corretto in base allo slug della pagina
 */
$slug = get_post_field('post_name', get_post());
$t = get_template_directory();

$template_map = [
    'chi-siamo'       => 'page-chi-siamo.php',
    'la-ricerca'      => 'page-la-ricerca.php',
    'strumenti'       => 'page-strumenti.php',
    'servizi'         => 'page-servizi.php',
    'casi-studio'     => 'page-casi-studio.php',
    'case-studio'     => 'page-casi-studio.php',
    'caso-studio-cciaa-padova' => 'page-caso-studio-cciaa-padova.php',
    'cciaa-padova'    => 'page-caso-studio-cciaa-padova.php',
    'media'           => 'page-media.php',
    'territorio'      => 'page-territorio.php',
    'per-il-territorio' => 'page-territorio.php',
    'rassegna-stampa' => 'page-rassegna-stampa.php',
    'notizie'         => 'page-notizie.php',
    'clienti'         => 'page-clienti.php',
    'contatti'        => 'page-contatti.php',
    'contattaci'      => 'page-contatti.php',
    'giochi-statistica' => 'page-giochi-statistica.php',
    // Sottopagine Strumenti
    'calcola-campione'        => 'page-strumento-calcola-campione.php',
    'calcolatore-campione'    => 'page-strumento-calcola-campione.php',
    'tip-platform'            => 'page-strumento-tip-platform.php',
    'dibattito-pubblico'      => 'page-strumento-dibattito-pubblico.php',
    't-index'                 => 'page-strumento-t-index.php',
    'troisiinsight'           => 'page-strumento-troisiinsight.php',
    'benessere-organizzativo' => 'page-strumento-benessere-organizzativo.php',
    'customerpa'              => 'page-strumento-customerpa.php',
    'skillprint'              => 'page-strumento-skillprint.php',
    'voiceinhub'              => 'page-strumento-voiceinhub.php',
    'digitalizzazione-pa'     => 'page-strumento-digitalizzazione-pa.php',
];

if (isset($template_map[$slug])) {
    include($t . '/' . $template_map[$slug]);
    exit;
}

// Fallback generico
get_header(); ?>
<?php $current_page = ''; include(get_template_directory() . '/troisi-nav.php'); ?>
<main style="max-width:860px;margin:60px auto;padding:0 24px;font-family:'Titillium Web',sans-serif">
  <h1 style="font-size:28px;color:#17324d;margin-bottom:16px"><?php the_title(); ?></h1>
  <?php while(have_posts()): the_post(); the_content(); endwhile; ?>
</main>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
