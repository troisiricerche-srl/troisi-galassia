<?php
/**
 * Template Name: Strumento — TIP Platform
 */
get_header();
$current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php');
?>
<style>
.feat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:20px}
.feat{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:20px;border-top:3px solid var(--blu)}
.feat-icon{font-size:28px;margin-bottom:10px}
.feat-t{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:6px}
.feat-d{font-size:12px;color:var(--g);line-height:1.65}
.use-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:20px}
.use-card{background:var(--bg);border:1px solid var(--bo);border-radius:var(--r);padding:18px;display:flex;gap:14px}
.use-icon{font-size:24px;flex-shrink:0}
.use-t{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px}
.use-d{font-size:12px;color:var(--g);line-height:1.6}
.cta-box h3{font-size:22px;font-weight:700;color:#fff;margin-bottom:8px}
.cta-box p{font-size:13.5px;color:rgba(255,255,255,.6);max-width:500px;margin:0 auto 22px;line-height:1.75}
.cta-p{display:inline-flex;align-items:center;gap:8px;background:var(--or);color:#fff;padding:13px 28px;border-radius:var(--r);font-size:14px;font-weight:700;text-decoration:none}
.cta-s{display:inline-flex;align-items:center;gap:8px;color:rgba(255,255,255,.65);padding:13px 24px;border-radius:var(--r);font-size:13px;font-weight:600;border:1.5px solid rgba(255,255,255,.22);text-decoration:none;margin-left:8px}
@media(max-width:900px){.feat-grid{grid-template-columns:1fr 1fr}.use-grid{grid-template-columns:1fr}}
@media(max-width:600px){.feat-grid{grid-template-columns:1fr}}
</style>

<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1><em>TIP Platform</em> — Sondaggi e partecipazione</h1>
  <p>La piattaforma professionale di Troisi Ricerche per sondaggi online, customer satisfaction e processi partecipativi. Configurabile, conforme GDPR, con reportistica automatica.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; TIP Platform</div>

<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Cos'è TIP Platform</div></div>
    <div class="s-t">La piattaforma di Troisi Ricerche per <em>raccogliere dati</em></div>
    <p class="s-d">TIP (Troisi Intelligence Platform) è il sistema proprietario di Troisi Ricerche per la somministrazione di questionari online, la raccolta di dati strutturati e la produzione automatica di report statistici. Usato da enti pubblici, università e imprese in tutta Italia.</p>

    <div style="background:var(--dp);border-radius:var(--r);padding:28px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;margin-bottom:28px;text-align:center">
      <div style="border-right:1px solid rgba(255,255,255,.1);padding-right:20px">
        <div style="font-size:32px;font-weight:700;color:var(--or)">500+</div>
        <div style="font-size:12px;color:rgba(255,255,255,.5);margin-top:3px">Indagini realizzate</div>
      </div>
      <div style="border-right:1px solid rgba(255,255,255,.1);padding-right:20px">
        <div style="font-size:32px;font-weight:700;color:var(--or)">GDPR</div>
        <div style="font-size:12px;color:rgba(255,255,255,.5);margin-top:3px">Conforme al Reg. UE 2016/679</div>
      </div>
      <div>
        <div style="font-size:32px;font-weight:700;color:var(--or)">24/7</div>
        <div style="font-size:12px;color:rgba(255,255,255,.5);margin-top:3px">Raccolta dati continua</div>
      </div>
    </div>

    <div class="feat-grid">
      <div class="feat">
        <div class="feat-icon">📋</div>
        <div class="feat-t">Questionari configurabili</div>
        <div class="feat-d">Domande a risposta multipla, scale Likert, NPS, testo libero, matrici. Layout personalizzabile con il brand del cliente.</div>
      </div>
      <div class="feat">
        <div class="feat-icon">📊</div>
        <div class="feat-t">Report automatici</div>
        <div class="feat-d">Analisi statistica in tempo reale. Grafici, tabelle, indici sintetici. Export in PDF, Excel, CSV. Dashboard interattiva.</div>
      </div>
      <div class="feat">
        <div class="feat-icon">📱</div>
        <div class="feat-t">Multi-canale</div>
        <div class="feat-d">Web, mobile, email, QR code. Funziona su tutti i dispositivi. Interfaccia ottimizzata per la compilazione su smartphone.</div>
      </div>
      <div class="feat">
        <div class="feat-icon">🔐</div>
        <div class="feat-t">Anonimato e GDPR</div>
        <div class="feat-d">Risposte anonime o pseudonimizzate. Gestione del consenso informato. Dati ospitati su server europei certificati.</div>
      </div>
      <div class="feat">
        <div class="feat-icon">🔗</div>
        <div class="feat-t">Integrazioni</div>
        <div class="feat-d">Webhook, API REST, connettori per Google Sheets, SPSS, R. Integrazione con i sistemi informativi dei clienti.</div>
      </div>
      <div class="feat">
        <div class="feat-icon">🤝</div>
        <div class="feat-t">Supporto metodologico</div>
        <div class="feat-d">Non solo la piattaforma: Troisi Ricerche ti affianca nella progettazione del questionario, nella scelta del campione e nell'analisi dei risultati.</div>
      </div>
    </div>
  </div>
</div>

<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Casi d'uso</div></div>
    <div class="s-t">Per chi è pensata <em>TIP Platform</em></div>
    <div class="use-grid">
      <div class="use-card">
        <div class="use-icon">🏛️</div>
        <div>
          <div class="use-t">Pubblica Amministrazione</div>
          <div class="use-d">Customer satisfaction su servizi comunali, indagini sul benessere dei dipendenti, rilevazioni per la rendicontazione PNRR, valutazione dei servizi scolastici.</div>
        </div>
      </div>
      <div class="use-card">
        <div class="use-icon">🚌</div>
        <div>
          <div class="use-t">Trasporto Pubblico</div>
          <div class="use-d">Indagini di customer satisfaction per aziende di TPL, rilevazioni della qualità percepita, conformità alla Carta dei Servizi e agli standard ANAC.</div>
        </div>
      </div>
      <div class="use-card">
        <div class="use-icon">🎓</div>
        <div>
          <div class="use-t">Università e Ricerca</div>
          <div class="use-d">Questionari per ricerche accademiche, rilevazioni di soddisfazione studenti e personale, valutazioni didattiche, survey per tesi di dottorato.</div>
        </div>
      </div>
      <div class="use-card">
        <div class="use-icon">🏢</div>
        <div>
          <div class="use-t">Imprese e Associazioni</div>
          <div class="use-d">NPS aziendale, indagini sul clima organizzativo, mappatura dei fabbisogni formativi, valutazione eventi e convegni, feedback clienti.</div>
        </div>
      </div>
    </div>

    <div class="cta-box">
      <h3>⚡ Prova TIP Platform</h3>
      <p>Accedi direttamente alla piattaforma sul sito dedicato, oppure contattaci per una demo personalizzata o per una proposta su misura per la tua indagine.</p>
      <a href="https://tiplive.it" target="_blank" rel="noopener" class="cta-p">Accedi a TIP Platform ↗</a>
      <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Richiedi una demo →</a>
    </div>
  </div>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
