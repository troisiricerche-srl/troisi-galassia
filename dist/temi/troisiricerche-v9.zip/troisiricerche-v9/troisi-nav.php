<?php
/**
 * troisi-nav.php — Navigazione globale responsive v9
 * Stile Designers Italia: Titillium Web, palette blu istituzionale
 * Mobile-first con hamburger menu
 */
if (!isset($current_page)) $current_page = '';
$_td = get_template_directory_uri();
function troisi_nav_active($slug, $current) {
    return ($slug === $current) ? ' class="act"' : '';
}
?>
<style>
/* ═══════════════════════════════════════
   DESIGN TOKENS — Designers Italia
   ═══════════════════════════════════════ */
:root {
  --blu:#0066CC;--bd:#004D99;--dp:#00264D;
  --bl:#E6F0FF;--bm:#B3D1FF;
  --bg:#F5F7FA;--bo:#D9E2E9;
  --g:#5A6A85;--t:#17324D;
  --or:#E8A020;--vd:#008758;
  --r:4px;--r-lg:8px;
  --shadow:0 2px 8px rgba(23,50,77,.08);
  --shadow-md:0 4px 16px rgba(23,50,77,.1);
  --ease:cubic-bezier(.4,0,.2,1);
  --max-w:1140px;
}

/* ═══════════════════════════════════════
   RESET & BASE
   ═══════════════════════════════════════ */
*,*::before,*::after{box-sizing:border-box}
html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{margin:0;padding:0;font-family:'Titillium Web','Segoe UI',system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--t);line-height:1.7;-webkit-font-smoothing:antialiased}
a{color:var(--blu);text-decoration:none;transition:color .15s var(--ease)}
a:hover{color:var(--bd)}
img{max-width:100%;height:auto;display:block}

/* Wrapper */
.wrap{max-width:var(--max-w);margin:0 auto;padding:0 24px}
@media(max-width:600px){.wrap{padding:0 16px}}

/* Utility links */
.li{display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--blu);font-weight:700;border:1px solid var(--bm);padding:5px 14px;border-radius:var(--r);background:var(--bl);transition:all .15s var(--ease)}
.li::after{content:'→';font-size:10px}
.li:hover{background:var(--blu);color:#fff;border-color:var(--blu)}
.le{display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:5px 14px;border-radius:var(--r);transition:all .15s var(--ease)}
.le::after{content:'↗';font-size:10px;color:#9ca3af}
.le:hover{border-color:var(--blu);color:var(--blu)}

/* ═══════════════════════════════════════
   TOPBAR
   ═══════════════════════════════════════ */
.topbar{background:var(--dp);padding:6px 24px;display:flex;align-items:center;justify-content:space-between;font-size:10.5px}
.topbar-badge{color:rgba(255,255,255,.42);letter-spacing:.04em}
.topbar-links{display:flex;gap:18px}
.topbar-links a{color:rgba(255,255,255,.42);transition:color .15s}
.topbar-links a:hover{color:rgba(255,255,255,.8)}
.topbar-links a.hi{color:rgba(255,255,255,.82);font-weight:700}

/* ═══════════════════════════════════════
   GALASSIA BAR
   ═══════════════════════════════════════ */
.gal-bar{background:var(--bd);display:flex;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch}
.gal-bar::-webkit-scrollbar{display:none}
.gal-bar a{font-size:9.5px;color:rgba(255,255,255,.48);padding:5px 13px;border-right:1px solid rgba(255,255,255,.07);white-space:nowrap;flex-shrink:0;transition:color .15s}
.gal-bar a.cur{color:#fff;font-weight:700}
.gal-bar a:hover{color:rgba(255,255,255,.85)}

/* ═══════════════════════════════════════
   NAVBAR
   ═══════════════════════════════════════ */
.navbar{background:#fff;border-bottom:1px solid var(--bo);padding:0 24px;display:flex;align-items:center;justify-content:space-between;height:64px;position:sticky;top:0;z-index:200;box-shadow:var(--shadow)}
.nb-brand{display:flex;align-items:center;gap:12px;flex-shrink:0}
.nb-logo{height:44px;width:auto;max-width:160px;object-fit:contain}
.nb-text{display:flex;flex-direction:column}
.nb-name{font-size:13.5px;font-weight:700;color:var(--dp);line-height:1.15}
.nb-sub{font-size:9px;color:var(--g);text-transform:uppercase;letter-spacing:.04em}
.nb-nav{display:flex;align-items:center;gap:2px}
.nb-nav a{font-size:11.5px;color:var(--t);padding:6px 9px;font-weight:500;border-bottom:2px solid transparent;transition:color .15s,border-color .15s;white-space:nowrap}
.nb-nav a:hover{color:var(--blu)}
.nb-nav a.act{color:var(--blu);border-bottom-color:var(--blu)}
.nb-cta{background:var(--blu)!important;color:#fff!important;padding:7px 18px!important;border-radius:var(--r)!important;font-weight:700!important;margin-left:6px;border-bottom:none!important;transition:background .15s var(--ease)!important}
.nb-cta:hover{background:var(--bd)!important}

/* ═══════════════════════════════════════
   HAMBURGER & MOBILE MENU
   ═══════════════════════════════════════ */
.nb-ham{display:none;flex-direction:column;justify-content:center;gap:5px;width:40px;height:40px;cursor:pointer;background:none;border:none;padding:8px;border-radius:var(--r);transition:background .15s;flex-shrink:0}
.nb-ham:hover{background:var(--bg)}
.nb-ham span{display:block;width:22px;height:2px;background:var(--t);border-radius:2px;transition:transform .25s ease,opacity .25s ease;transform-origin:center}
.nb-ham.open span:nth-child(1){transform:translateY(7px) rotate(45deg)}
.nb-ham.open span:nth-child(2){opacity:0;transform:scaleX(0)}
.nb-ham.open span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}

.mob-menu{display:none;position:fixed;top:64px;left:0;right:0;bottom:0;background:#fff;z-index:199;overflow-y:auto;padding:8px 0 32px;box-shadow:0 8px 24px rgba(0,0,0,.12)}
.mob-menu.open{display:block}
.mob-menu a{display:flex;align-items:center;font-size:15px;font-weight:500;color:var(--t);padding:13px 24px;border-bottom:1px solid var(--bg);transition:background .1s,color .1s}
.mob-menu a:hover{background:var(--bg);color:var(--blu)}
.mob-menu a.act{color:var(--blu);font-weight:700}
.mob-net-title{font-size:10px!important;font-weight:700!important;text-transform:uppercase;letter-spacing:.08em;color:var(--g)!important;padding:14px 24px 6px!important;background:var(--bg)!important;cursor:default}
.mob-net-title:hover{background:var(--bg)!important;color:var(--g)!important}
.mob-cta-wrap{padding:16px 24px 0}
.mob-cta{display:block!important;background:var(--blu);color:#fff!important;text-align:center;padding:13px!important;border-radius:var(--r)!important;font-weight:700!important;border-bottom:none!important;font-size:14px!important}

/* ═══════════════════════════════════════
   RESPONSIVE BREAKPOINTS
   ═══════════════════════════════════════ */
@media(max-width:1050px){
  .nb-nav{gap:0}
  .nb-nav a{padding:6px 7px;font-size:11px}
}
@media(max-width:900px){
  .nb-nav{display:none}
  .nb-ham{display:flex}
  .topbar-links{display:none}
}
@media(max-width:600px){
  .navbar{padding:0 16px;height:56px}
  .mob-menu{top:56px}
  .nb-logo{height:36px;max-width:130px}
  .nb-name{font-size:12px}
  .nb-sub{display:none}
  .topbar{padding:5px 16px;font-size:9.5px}
  .gal-bar a{font-size:8.5px;padding:4px 10px}
}

/* ═══════════════════════════════════════
   GLOBAL PAGE STYLES (shared across all pages)
   ═══════════════════════════════════════ */

/* Page header */
.ph{background:var(--dp);padding:48px 24px 40px;color:#fff}
.ph-inner{max-width:var(--max-w);margin:0 auto}
.ph .wrap{max-width:var(--max-w)}
.ph-ey{font-size:10px;text-transform:uppercase;letter-spacing:.12em;color:rgba(255,255,255,.38);font-weight:700;margin-bottom:8px;display:flex;align-items:center;gap:10px}
.ph-ey::before{content:'';display:inline-block;width:22px;height:2px;background:var(--blu);flex-shrink:0}
.ph h1{font-size:28px;font-weight:700;color:#fff;margin-bottom:8px;line-height:1.2}
.ph h1 em{color:var(--or);font-style:normal}
.ph p{font-size:14px;color:rgba(255,255,255,.65);max-width:600px;line-height:1.7}
@media(max-width:600px){
  .ph{padding:32px 16px 28px}
  .ph h1{font-size:22px}
  .ph p{font-size:13px}
}

/* Breadcrumb */
.bc{background:#fff;border-bottom:1px solid var(--bo);padding:10px 24px;font-size:11.5px;color:var(--g)}
.bc a{color:var(--g);transition:color .15s}
.bc a:hover{color:var(--blu)}
@media(max-width:600px){.bc{padding:8px 16px;font-size:10.5px}}

/* Section containers */
.sec{padding:40px 24px;max-width:calc(var(--max-w) + 48px);margin-left:auto;margin-right:auto}
.sec.alt{background:#fff}
.sec .wrap{max-width:var(--max-w)}
@media(max-width:600px){.sec{padding:28px 16px}}

/* Section headers */
.sh{display:flex;align-items:center;gap:8px;margin-bottom:20px}
.sl{width:3px;height:18px;background:var(--blu);flex-shrink:0;border-radius:2px}
.st{font-size:18px;font-weight:700;color:var(--t)}
.se{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--g);font-weight:600;margin-bottom:4px}

/* Cards */
.card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:24px;transition:box-shadow .2s var(--ease),border-color .2s var(--ease)}
.card:hover{box-shadow:var(--shadow-md);border-color:var(--bm)}
.card-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px}
@media(max-width:700px){.card-grid{grid-template-columns:1fr}}

/* Badge/tag */
.badge{display:inline-block;font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:3px 10px;border-radius:3px;background:var(--bl);color:var(--blu);border:1px solid var(--bm)}
.badge.green{background:#E8F5E9;color:var(--vd);border-color:#C8E6C9}
.badge.orange{background:#FFF3E0;color:#E65100;border-color:#FFE0B2}
.badge.teal{background:#E0F2F1;color:#00695C;border-color:#B2DFDB}

/* Tables (responsive) */
.rtable{width:100%;border-collapse:collapse;font-size:13px}
.rtable th{background:var(--dp);color:#fff;padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.04em;font-weight:700}
.rtable td{padding:10px 14px;border-bottom:1px solid var(--bo)}
.rtable tr:hover td{background:var(--bl)}
@media(max-width:700px){
  .rtable-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;margin:0 -16px;padding:0 16px}
  .rtable{min-width:600px}
}

/* Body text */
.prose{font-family:'Lora','Georgia',serif;font-size:15px;line-height:1.8;color:var(--t);max-width:720px}
.prose p{margin-bottom:16px}
.prose strong{font-weight:700;color:var(--dp)}
.prose ul{margin:12px 0;padding-left:20px}
.prose li{margin-bottom:6px}

/* CTA Box (used on strumento pages and others) */
.cta-box{background:var(--dp);border-radius:var(--r-lg);padding:32px;text-align:center;margin-top:28px}
.cta-box h3{font-size:20px;font-weight:700;color:#fff;margin-bottom:8px}
.cta-box p{font-size:13px;color:rgba(255,255,255,.6);max-width:480px;margin:0 auto 20px;line-height:1.75}
.cta-p{display:inline-block;background:var(--blu);color:#fff;padding:11px 24px;border-radius:var(--r);font-size:13px;font-weight:700;margin:4px;transition:background .15s var(--ease)}
.cta-p:hover{background:var(--bd);color:#fff}
.cta-s{display:inline-block;color:rgba(255,255,255,.65);padding:11px 24px;border-radius:var(--r);font-size:13px;font-weight:600;border:1.5px solid rgba(255,255,255,.22);margin:4px;transition:all .15s var(--ease)}
.cta-s:hover{border-color:rgba(255,255,255,.5);color:#fff}

/* Section text (used across pages) */
.s-t{font-size:20px;font-weight:700;color:var(--t);margin-bottom:8px}
.s-t em{color:var(--blu);font-style:normal}
.s-d{font-size:13px;color:var(--g);margin-bottom:22px;line-height:1.75;max-width:680px}

/* Footer styles (included from troisi-footer.php) */
.troisi-footer{background:var(--dp);color:rgba(255,255,255,.55);padding:48px 24px 0;font-size:12.5px;line-height:1.7}
.fg{max-width:var(--max-w);margin:0 auto;display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;gap:32px}
.fb-top{display:flex;align-items:center;gap:10px;margin-bottom:14px}
.fb-logo{height:38px;width:auto;opacity:.75;mix-blend-mode:screen}
.fb-name{font-size:14px;font-weight:700;color:#fff}
.fb-sub{font-size:9.5px;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.04em}
.fb-p{margin-bottom:14px}
.fb-legal{font-size:10.5px;color:rgba(255,255,255,.3);margin-bottom:10px}
.fb-sedi{display:flex;flex-direction:column;gap:3px}
.fb-sede{font-size:10px;color:rgba(255,255,255,.28);display:flex;align-items:center;gap:6px}
.fb-sede::before{content:'';display:inline-block;width:5px;height:5px;background:var(--blu);border-radius:50%;flex-shrink:0}
.fc-h4{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.25);margin-bottom:10px}
.fc-ul{list-style:none;padding:0;margin:0}
.fc-ul li{margin-bottom:5px}
.fc-ul a{color:rgba(255,255,255,.5);font-size:12px;transition:color .15s}
.fc-ul a:hover{color:#fff}
.fbot{max-width:var(--max-w);margin:0 auto;border-top:1px solid rgba(255,255,255,.08);margin-top:32px;padding:14px 0;display:flex;justify-content:space-between;align-items:center;font-size:10.5px;color:rgba(255,255,255,.2)}
.fbot a{color:rgba(255,255,255,.25);margin-left:16px;transition:color .15s}
.fbot a:hover{color:rgba(255,255,255,.6)}

@media(max-width:900px){
  .fg{grid-template-columns:1fr 1fr}
  .fg>div:first-child{grid-column:1/-1}
}
@media(max-width:600px){
  .troisi-footer{padding:32px 16px 0}
  .fg{grid-template-columns:1fr;gap:24px}
  .fbot{flex-direction:column;gap:8px;text-align:center;padding:12px 0}
  .fbot a{margin-left:8px}
}
</style>

<!-- ═══════════════════════════════════════
     TOPBAR
     ═══════════════════════════════════════ -->
<div class="topbar">
  <span class="topbar-badge">TROISI RICERCHE — Istituto di Ricerca Statistica · Bari · Roma · Milano</span>
  <div class="topbar-links">
    <a href="https://andreatroisi.it" target="_blank" rel="noopener">andreatroisi.it</a>
    <a href="https://www.osservatoriomezzogiorno.net" target="_blank" rel="noopener">Osservatorio Mezzogiorno</a>
    <a href="<?php echo home_url('/giochi-statistica/'); ?>">Gioca con la statistica</a>
    <a href="<?php echo home_url('/contatti'); ?>" class="hi">Contattaci</a>
  </div>
</div>

<!-- ═══════════════════════════════════════
     GALASSIA BAR
     ═══════════════════════════════════════ -->
<div class="gal-bar">
  <a href="https://troisiricerche.net" class="cur">troisiricerche.net</a>
  <a href="https://t-index.it">TR-Index</a>
  <a href="https://mappaturadellecompetenze.it">Mappatura Competenze</a>
  <a href="https://registrodellecompetenze.it">Registro Competenze</a>
  <a href="https://customerpa.it">CustomerPA</a>
  <a href="https://benessereorganizzativo.it">Benessere Org.</a>
  <a href="https://troisiformazione.it">Formazione</a>
  <a href="https://tiplive.it">TIP</a>
  <a href="https://troisiinsight.it">Insight</a>
  <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
  <a href="https://dibattito-pubblico.it">Dibattito Pubblico</a>
  <a href="https://voiceinhub.it">VoiceInHub</a>
  <a href="https://governancefinanziaria.it">Governance Fin.</a>
  <a href="https://consulenzainternazionalizzazione.it">Internazionalizzazione</a>
  <a href="https://benesseredigitalegiovani.it">Benessere Digitale</a>
  <a href="https://svegliadigitale.it">Sveglia Digitale</a>
</div>

<!-- ═══════════════════════════════════════
     NAVBAR
     ═══════════════════════════════════════ -->
<nav class="navbar" role="navigation">
  <a href="<?php echo home_url(); ?>" class="nb-brand">
    <img src="<?php echo $_td; ?>/logo-troisi-header.png" alt="Troisi Ricerche" class="nb-logo" width="395" height="220">
    <div class="nb-text">
      <span class="nb-name">Troisi Ricerche</span>
      <span class="nb-sub">Istituto di Ricerca Statistica</span>
    </div>
  </a>
  <div class="nb-nav">
    <a href="<?php echo home_url('/chi-siamo'); ?>"<?php echo troisi_nav_active('chi-siamo',$current_page); ?>>Chi siamo</a>
    <a href="<?php echo home_url('/la-ricerca'); ?>"<?php echo troisi_nav_active('la-ricerca',$current_page); ?>>La ricerca</a>
    <a href="<?php echo home_url('/casi-studio'); ?>"<?php echo troisi_nav_active('casi-studio',$current_page); ?>>Casi studio</a>
    <a href="<?php echo home_url('/servizi'); ?>"<?php echo troisi_nav_active('servizi',$current_page); ?>>Servizi</a>
    <a href="<?php echo home_url('/strumenti'); ?>"<?php echo troisi_nav_active('strumenti',$current_page); ?>>Strumenti</a>
    <a href="<?php echo home_url('/clienti'); ?>"<?php echo troisi_nav_active('clienti',$current_page); ?>>Clienti</a>
    <a href="<?php echo home_url('/media'); ?>"<?php echo troisi_nav_active('media',$current_page); ?>>Media</a>
    <a href="<?php echo home_url('/rassegna-stampa'); ?>"<?php echo troisi_nav_active('rassegna-stampa',$current_page); ?>>Stampa</a>
    <a href="<?php echo home_url('/territorio'); ?>"<?php echo troisi_nav_active('territorio',$current_page); ?>>Territorio</a>
    <a href="<?php echo home_url('/notizie'); ?>"<?php echo troisi_nav_active('notizie',$current_page); ?>>Notizie</a>
    <a href="<?php echo home_url('/giochi-statistica/'); ?>"<?php echo troisi_nav_active('giochi',$current_page); ?> style="color:#D95C14;font-weight:700">Giochi</a>
    <a href="<?php echo home_url('/contatti'); ?>" class="nb-cta">Contatti</a>
  </div>
  <button class="nb-ham" onclick="this.classList.toggle('open');document.getElementById('mob-menu').classList.toggle('open');document.body.style.overflow=this.classList.contains('open')?'hidden':'';" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>

<!-- Mobile menu -->
<div class="mob-menu" id="mob-menu">
  <a href="<?php echo home_url(); ?>"<?php echo troisi_nav_active('home',$current_page); ?>>Home</a>
  <a href="<?php echo home_url('/chi-siamo'); ?>"<?php echo troisi_nav_active('chi-siamo',$current_page); ?>>Chi siamo</a>
  <a href="<?php echo home_url('/la-ricerca'); ?>"<?php echo troisi_nav_active('la-ricerca',$current_page); ?>>La ricerca</a>
  <a href="<?php echo home_url('/casi-studio'); ?>"<?php echo troisi_nav_active('casi-studio',$current_page); ?>>Casi studio</a>
  <a href="<?php echo home_url('/servizi'); ?>"<?php echo troisi_nav_active('servizi',$current_page); ?>>Servizi</a>
  <a href="<?php echo home_url('/strumenti'); ?>"<?php echo troisi_nav_active('strumenti',$current_page); ?>>Strumenti</a>
  <a href="<?php echo home_url('/clienti'); ?>"<?php echo troisi_nav_active('clienti',$current_page); ?>>Clienti</a>
  <a href="<?php echo home_url('/territorio'); ?>"<?php echo troisi_nav_active('territorio',$current_page); ?>>Territorio</a>
  <a href="<?php echo home_url('/rassegna-stampa'); ?>"<?php echo troisi_nav_active('rassegna-stampa',$current_page); ?>>Rassegna Stampa</a>
  <a href="<?php echo home_url('/media'); ?>"<?php echo troisi_nav_active('media',$current_page); ?>>Media</a>
  <a href="<?php echo home_url('/notizie'); ?>"<?php echo troisi_nav_active('notizie',$current_page); ?>>Notizie</a>
  <a href="<?php echo home_url('/giochi-statistica/'); ?>"<?php echo troisi_nav_active('giochi',$current_page); ?>>Gioca con la statistica</a>
  <a class="mob-net-title">Il network ▾</a>
  <a href="https://t-index.it" target="_blank">TR-Index</a>
  <a href="https://customerpa.it" target="_blank">CustomerPA</a>
  <a href="https://tiplive.it" target="_blank">TIP Platform</a>
  <a href="https://voiceinhub.it" target="_blank">VoiceInHub</a>
  <a href="https://benessereorganizzativo.it" target="_blank">Benessere Org.</a>
  <a href="https://mappaturadellecompetenze.it" target="_blank">Mappatura Competenze</a>
  <a href="https://svegliadigitale.it" target="_blank">Sveglia Digitale</a>
  <div class="mob-cta-wrap">
    <a href="<?php echo home_url('/contatti'); ?>" class="mob-cta">Contattaci</a>
  </div>
</div>
