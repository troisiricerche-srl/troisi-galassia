<?php
/** 10.3.4 – Claim «Misuriamo ciò che conta. Davvero.» nell'apertura. 10.3.0 – Apertura della home, numeri, ingressi per pubblico, rubrica del martedì. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$h26_temi = tr_home_temi();
$h26_0    = $h26_temi[0];
?>
<div class="h26">
<section class="h26-hero">
  <div class="h26-wrap">
    <div>
      <p class="h26-occhiello"><?php echo esc_html( troisi_opt( 'hero_eyebrow', 'Istituto di Ricerca Statistica · Bari · Roma · Milano' ) ); ?></p>
      <h1>Misuriamo <span class="h26-riga"><span class="h26-pillola" aria-live="polite"><span id="h26-parola">ciò che conta.</span></span> <span class="h26-davvero" id="h26-davvero">Davvero.</span></span></h1>
      <p class="h26-sotto">Dal 2006 trasformiamo dati statistici in conoscenza utile per enti pubblici, imprese e territori: indagini, piattaforme e osservatori che ogni settimana pubblicano analisi su dati ufficiali.</p>
      <div class="h26-bottoni">
        <a class="h26-bp" href="<?php echo esc_url( home_url( '/chi-siamo' ) ); ?>">Scopri chi siamo</a>
        <a class="h26-bs" href="#h26-porte">Cosa facciamo →</a>
      </div>
      <div class="h26-bollini" aria-label="Attività e certificazioni"><span>Ricerca statistica</span><span>Customer satisfaction PA</span><span class="g">TR-Index 2026</span><span>Benessere organizzativo</span><span>Dibattito pubblico</span><span>TÜV ISO 9001:2015</span><span>SIS</span><span>Confindustria</span></div>
    </div>
    <div data-h26="<?php echo esc_attr( wp_json_encode( $h26_temi ) ); ?>">
      <div class="h26-campo"><canvas id="h26-cv" aria-hidden="true"></canvas></div>
      <div class="h26-scheda">
        <div class="h26-prod" id="h26-prod"><?php echo esc_html( $h26_0['m'] ); ?></div>
        <p class="h26-desc" id="h26-desc"><?php echo esc_html( $h26_0['d'] ); ?></p>
        <div class="h26-dato" id="h26-dato"><?php echo esc_html( $h26_0['x'] ); ?></div>
        <a class="h26-vai" id="h26-link" href="<?php echo esc_url( $h26_0['u'] ); ?>" target="_blank" rel="noopener">Vai al sito →</a>
        <div class="h26-pn" id="h26-pn" aria-label="Scegli il tema"></div>
      </div>
    </div>
  </div>
</section>

<section class="h26-numeri" aria-label="Troisi Ricerche in numeri">
  <div class="h26-wrap">
    <div class="h26-num"><b>20+</b><span>anni di attività</span></div>
    <div class="h26-num"><b>500+</b><span>ricerche realizzate</span></div>
    <div class="h26-num"><b>200+</b><span>clienti serviti</span></div>
    <div class="h26-num"><b>20+</b><span>siti del network</span></div>
  </div>
</section>

<section class="h26-sez" id="h26-porte">
  <div class="h26-wrap">
    <h2>Cosa facciamo, per chi</h2>
    <p class="h26-intro">Ogni sito della galassia Troisi Ricerche risponde a una domanda precisa. Partite da chi siete.</p>
    <div class="h26-porte">
      <?php foreach ( tr_home_porte() as $h26_p ) : ?>
      <div class="h26-porta">
        <h3><?php echo esc_html( $h26_p['t'] ); ?></h3>
        <p><?php echo esc_html( $h26_p['d'] ); ?></p>
        <div class="h26-chips">
          <?php foreach ( $h26_p['s'] as $h26_n => $h26_h ) : ?>
          <a href="<?php echo esc_url( 'https://www.' . $h26_h . '/' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $h26_n ); ?></a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="h26-rubrica">
  <div class="h26-wrap">
    <p><strong>Ogni martedì, «Il dato è tratto™».</strong> I numeri della settimana pubblicati dai nostri osservatori, su LinkedIn, Instagram e WhatsApp.</p>
    <div class="h26-bt">
      <a class="h26-wa" href="https://whatsapp.com/channel/0029VbE9Kx9DeONGCBFx5v42" target="_blank" rel="noopener">Segui il canale WhatsApp</a>
      <a class="h26-ig" href="https://www.instagram.com/troisiricerche/" target="_blank" rel="noopener">Instagram</a>
    </div>
  </div>
</section>
</div>
