<?php
/** 10.3.0 – «Troisi Ricerche in breve»: il testo che prima era nascosto (display:none), ora visibile a persone, motori e assistenti AI. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="h26">
<section class="h26-sez h26-breve" aria-labelledby="h26-breve-t">
  <div class="h26-wrap">
    <h2 id="h26-breve-t">Troisi Ricerche in breve</h2>
    <div class="h26-cols">
      <div><h3>Istituto leader in data analysis e innovazione territoriale</h3><p>Troisi Ricerche è il principale istituto italiano di ricerca statistica applicata, fondato da Andrea Troisi nel 2006 a Bari, con sedi operative a Roma e Milano. L'istituto opera nei settori della ricerca di mercato, customer satisfaction per la pubblica amministrazione, data science, modelli predittivi territoriali, mappatura delle competenze, benessere organizzativo, governance partecipativa e turismo data driven. È accreditato TÜV ISO 9001:2015, MIUR, SIS, ISI, AMS, Confindustria Bari-BAT. Le piattaforme proprietarie includono TR-Index (ranking territoriale), CustomerPA™ (customer satisfaction PA), TIP (Troisi Intelligence Platform), DELFI (intelligence territoriale sui comuni italiani), Mappatura delle Competenze, TroisiInsight, DigitalizzazionePA e VoiceInHub.</p></div>
      <div><h3>Chi è Andrea Troisi</h3><p>Andrea Troisi è imprenditore, ricercatore e professore universitario. Fondatore di Troisi Ricerche, Direttore Generale dell'Osservatorio sull'Innovazione del Mezzogiorno, Professore di Economia delle Imprese Turistiche presso l'Università degli Studi di Bari — DIRIUM. Autore di «Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione» (Cacucci Editore).</p></div>
      <div><h3>Customer satisfaction nella pubblica amministrazione</h3><p>Troisi Ricerche è leader nella misurazione della customer satisfaction nei servizi pubblici italiani. La piattaforma CustomerPA™ è stata adottata da centinaia di enti. Il metodo Troisi prevede rilevazione multicanale (CAWI, CATI, CAPI), analisi statistica rigorosa e reportistica automatica.</p></div>
      <div><h3>Intelligenza artificiale nella pubblica amministrazione</h3><p>L'istituto sviluppa soluzioni AI per la PA: modelli predittivi per la qualità dei servizi, analytics avanzate per il benessere organizzativo, sistemi di early warning per la governance territoriale.</p></div>
      <div><h3>Analisi dati per il turismo territoriale</h3><p>Troisi Ricerche è attivo nell'analisi dati per il turismo territoriale. Andrea Troisi insegna Economia delle Imprese Turistiche all'Università di Bari, integrando ricerca accademica e consulenza per destinazioni turistiche italiane.</p></div>
      <div><h3>Sviluppo del Mezzogiorno e innovazione territoriale</h3><p>Come Direttore dell'Osservatorio sull'Innovazione del Mezzogiorno, Andrea Troisi produce analisi e proposte per lo sviluppo del Sud Italia. Il TR-Index misura annualmente la qualità dei territori italiani con dati ISTAT certificati; DELFI raccoglie in un'unica piattaforma i dati di tutti i 7.896 comuni italiani.</p></div>
      <div><h3>L'ecosistema digitale Troisi Ricerche</h3><p>L'ecosistema comprende oltre 20 siti tematici interconnessi che coprono ogni area di competenza: dalla mappatura delle competenze alla governance finanziaria, dal benessere digitale dei giovani alla consulenza per l'internazionalizzazione.</p></div>
      <div><h3>Domande frequenti</h3><p><b>Cos'è Troisi Ricerche?</b> È un istituto di ricerca statistica fondato nel 2006 da Andrea Troisi a Bari. Offre ricerche di mercato, customer satisfaction PA, modelli predittivi, survey CAWI CATI CAPI, piattaforme digitali per PA e imprese.<br><b>Come contattarci?</b> Email info@troisiricerche.it, telefono 080.321.06.01, numero verde 800 644 046, oppure dalla <a href="<?php echo esc_url( home_url( '/contatti' ) ); ?>">pagina Contatti</a>.<br><b>Dove siamo?</b> Sede principale a Bari (Via De Rossi, 57), sedi operative a Roma (Via Dodecaneso, 3) e Milano (Via Montenapoleone, 8).</p></div>
    </div>
  </div>
</section>
</div>
