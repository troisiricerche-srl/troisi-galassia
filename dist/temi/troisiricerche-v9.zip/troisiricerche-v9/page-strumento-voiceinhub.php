<?php /** Template Name: Strumento — VoiceInHub */
get_header(); $current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
</style>
<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1>🎙️ <em>VoiceInHub</em></h1>
  <p>Il podcast di statistica e PA — parte del network Troisi Ricerche.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; VoiceInHub</div>
<div class="sec alt"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Cos'è VoiceInHub</div></div>
  <div class="s-t">Un progetto del <em>network Troisi Ricerche</em></div>
  <p class="s-d">Il podcast di Andrea Troisi su statistica applicata, servizi pubblici e ricerche sociali.</p>
  <p class="s-d">VoiceInHub nasce dall'esperienza ventennale di Troisi Ricerche nella ricerca statistica applicata. Ogni strumento del network è progettato per rendere i dati accessibili e utili a chi decide: enti pubblici, imprese, università.</p>
  <div class="cta-box">
    <h3>🎙️ Visita VoiceInHub</h3>
    <p>Accedi al sito dedicato per esplorare tutte le funzionalità e i contenuti di VoiceInHub.</p>
    <a href="https://voiceinhub.it" target="_blank" rel="noopener" class="cta-p">Vai su https://voiceinhub.it ↗</a>
    <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Contattaci →</a>
  </div>
</div></div>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
