<?php
/**
 * Template Name: Clienti
 */
get_header(); ?>
<?php $current_page = 'clienti'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.filtri{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px}
.fb{font-size:11.5px;font-weight:700;padding:6px 16px;border-radius:2px;border:1px solid var(--bo);background:#fff;color:var(--g);cursor:pointer;transition:all .15s}
.fb.on,.fb:hover{background:var(--blu);color:#fff;border-color:var(--blu)}
.cl-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px}
.cl-item{background:#fff;border:1px solid var(--bo);border-radius:6px;padding:18px 14px 12px;display:flex;flex-direction:column;align-items:center;justify-content:space-between;gap:10px;min-height:150px;transition:box-shadow .18s,transform .18s}
.cl-item:hover{box-shadow:0 6px 22px rgba(0,40,90,.12);transform:translateY(-2px)}
.cl-logo{flex:1;width:100%;display:flex;align-items:center;justify-content:center;min-height:86px}
.cl-item img{max-height:86px;max-width:100%;width:auto;height:auto;object-fit:contain}
.cl-name{font-size:11px;line-height:1.35;color:var(--g);text-align:center;font-weight:600}
.cnt{font-size:12px;color:var(--g);margin-bottom:16px}
#summa .sm-grid,#crossmove .sm-grid,#gl4s .sm-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
#summa .sm-it,#crossmove .sm-it,#gl4s .sm-it{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:14px 12px;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:92px}
#summa .sm-it img,#crossmove .sm-it img,#gl4s .sm-it img{height:72px;width:auto;max-width:100%;object-fit:contain;margin-bottom:8px}
#summa .sm-n,#crossmove .sm-n,#gl4s .sm-n{font-size:11.5px;font-weight:700;color:var(--dp);line-height:1.35}
#summa .sm-r,#crossmove .sm-r,#gl4s .sm-r{font-size:10px;color:var(--g);text-transform:uppercase;letter-spacing:.05em;margin-top:3px}
@media(max-width:900px){#summa .sm-grid,#crossmove .sm-grid,#gl4s .sm-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:1100px){.cl-grid{grid-template-columns:repeat(4,1fr)}}
@media(max-width:820px){.cl-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.cl-grid{grid-template-columns:repeat(2,1fr);gap:10px}.cl-item{min-height:128px;padding:14px 10px 10px}.cl-item img{max-height:66px}.cl-logo{min-height:66px}}
.gl-h{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--blu);margin:0 0 10px}
</style>
<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Clienti</div>
  <h1>I nostri <em>clienti</em></h1>
  <p>200+ organizzazioni che si sono affidate a Troisi Ricerche in vent'anni di attività. Qui una selezione: filtra per settore.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Clienti</div>

<div class="sec alt">
  <div class="filtri">
    <button class="fb on" onclick="filtra('tutti',this)">Tutti</button>
    <button class="fb" onclick="filtra('pa',this)">PA & Istituzioni</button>
    <button class="fb" onclick="filtra('trasporti',this)">Trasporti & Utility</button>
    <button class="fb" onclick="filtra('universita',this)">Università, ricerca e formazione</button>
    <button class="fb" onclick="filtra('cultura',this)">Cultura, media e turismo</button>
    <button class="fb" onclick="filtra('consumatori',this)">Associazioni consumatori</button>
    <button class="fb" onclick="filtra('retail',this)">Imprese e associazioni</button>
    <button class="fb" onclick="filtra('summa',this)">Progetto SUMMA · Interreg</button>
    <button class="fb" onclick="filtra('crossmove',this)">Progetto CROSS-MOVE · Interreg</button>
    <button class="fb" onclick="filtra('gl4s',this)">Progetto GreenLife4Seas · LIFE</button>
  </div>
  <div class="cnt" id="cnt">Visualizzati tutti i clienti</div>
  <div class="cl-grid" id="cl-grid">
<?php
$clienti = troisi_clienti_lista();
foreach ($clienti as $cl): ?>
  <div class="cl-item" data-cat="<?php echo esc_attr($cl['cat']); ?>">
    <div class="cl-logo"><img src="<?php echo esc_url(troisi_cliente_logo_url($cl['file'])); ?>" alt="<?php echo esc_attr($cl['nome']); ?>" loading="lazy"></div>
    <div class="cl-name"><?php echo esc_html($cl['nome']); ?></div>
  </div>
<?php endforeach; ?>
  </div>
</div>

<div class="sec" id="summa">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Progetto SUMMA · Interreg Italia-Croazia</div></div>
    <p style="font-size:13px;color:var(--g);max-width:760px;line-height:1.7;margin-bottom:18px">Il partenariato del progetto SUMMA — Sustainable Multimodal Mobility in Adriatic Coastal and Hinterland Areas, per il quale Troisi Ricerche ha curato lo studio di fattibilità sulla bigliettazione unica intermodale.</p>
    <div class="sm-grid">
<?php
$summa = [
  ['Comune di Caorle','Capofila','comune-di-caorle.png'],
  ['Comune di Pescara','Partner','comune-di-pescara.png'],
  ['Città di Zara','Partner','citta-di-zara.png'],
  ['Regione Spalatino-Dalmata','Partner','regione-spalatino-dalmata.png'],
  ['Città di Parenzo','Partner','citta-di-parenzo.png'],
  ['IRENA — Agenzia Regionale per l\'Energia dell\'Istria','Partner','irena.png'],
  ['Comunità Riviera Friulana','Partner','comunita-riviera-friulana.png'],
  ['ISIG — Istituto di Sociologia Internazionale di Gorizia','Partner','isig.png'],
  ['Autorità Portuale di Spalato','Partner associato',''],
  ['Autorità di Sistema Portuale del Mare Adriatico Centrale','Partner associato',''],
  ['ATVO — Azienda Trasporti Veneto Orientale','Partner associato',''],
  ['Città di Albona','Partner associato',''],
  ['Autorità Portuale di Parenzo','Partner associato',''],
];
foreach($summa as $sp): ?>
      <div class="sm-it">
        <?php if($sp[2]): ?><img src="<?php echo esc_url(troisi_cliente_logo_url($sp[2])); ?>" alt="<?php echo esc_attr($sp[0]); ?>" loading="lazy"><?php endif; ?>
        <div class="sm-n"><?php echo esc_html($sp[0]); ?></div>
        <div class="sm-r"><?php echo esc_html($sp[1]); ?></div>
      </div>
<?php endforeach; ?>
    </div>
    <div style="margin-top:14px;font-size:11px;color:var(--g)">Fonte: <a href="https://www.italy-croatia.eu/web/summa/partners" target="_blank" rel="noopener" style="color:var(--blu)">italy-croatia.eu — SUMMA Partners</a></div>
  </div>
</div>


<div class="sec alt" id="crossmove">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Progetto CROSS-MOVE · Interreg IPA South Adriatic</div></div>
    <div style="display:flex;gap:28px;align-items:center;flex-wrap:wrap;margin-bottom:18px">
      <img src="<?php echo esc_url(get_template_directory_uri() . '/img/crossmove-logo.png'); ?>" alt="Interreg IPA South Adriatic — CROSS-MOVE" loading="lazy" style="width:300px;max-width:100%;height:auto;background:#fff;padding:14px;border-radius:6px;border:1px solid var(--bo)">
      <p style="font-size:13px;color:var(--g);max-width:640px;line-height:1.7;margin:0">CROSS-MOVE — Cross-border sustainable urban mobility efforts in the South-Adriatic area: piani urbani di mobilità sostenibile per i Comuni di piccola e media dimensione tra Italia, Albania e Montenegro (2025–2027). Con CLES curiamo l'analisi dei bisogni di mobilità nei quattro territori del partenariato.</p>
    </div>
    <div class="sm-grid">
<?php
$cm = [
  ['Comune di Mola di Bari','Capofila','comune-di-mola-di-bari.png'],
  ['Comune di Bojano','Partner','comune-di-bojano.png'],
  ['Bashkia Korçë — Comune di Coriza (Albania)','Partner','bashkia-korce.png'],
  ['Komunalno Tuzi (Montenegro)','Partner','komunalno-tuzi-montenegro.png'],
];
foreach ($cm as $sp): ?>
      <div class="sm-it">
        <img src="<?php echo esc_url(troisi_cliente_logo_url($sp[2])); ?>" alt="<?php echo esc_attr($sp[0]); ?>" loading="lazy">
        <div class="sm-n"><?php echo esc_html($sp[0]); ?></div>
        <div class="sm-r"><?php echo esc_html($sp[1]); ?></div>
      </div>
<?php endforeach; ?>
    </div>
    <div style="margin-top:14px;font-size:11px;color:var(--g)">Fonte: <a href="https://crossmove.southadriatic.eu/" target="_blank" rel="noopener" style="color:var(--blu)">crossmove.southadriatic.eu</a></div>
  </div>
</div>


<div class="sec" id="gl4s">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Progetto GreenLife4Seas · Programma LIFE</div></div>
    <div style="display:flex;gap:28px;align-items:center;flex-wrap:wrap;margin-bottom:18px">
      <img src="<?php echo esc_url(get_template_directory_uri() . '/img/gl4s-logo.png'); ?>" alt="GreenLife4Seas — GREen ENgineering solutions: a new LIFE for SEdiments And Shells" loading="lazy" style="width:240px;max-width:100%;height:auto;background:#fff;padding:14px;border-radius:6px;border:1px solid var(--bo)">
      <p style="font-size:13px;color:var(--g);max-width:640px;line-height:1.7;margin:0">GreenLife4Seas — GREen ENgineering solutions: a new LIFE for SEdiments And Shells. Il progetto europeo LIFE guidato dal Politecnico di Bari sul riutilizzo dei sedimenti portuali e dei gusci da acquacoltura nell'economia circolare blu, di cui curiamo la comunicazione integrata.</p>
    </div>
    <div class="gl-h">Partner</div>
    <div class="sm-grid">
<?php
$gl_p = [
  ['Politecnico di Bari','Capofila','politecnico-di-bari.png'],
  ['ISPRA — Istituto Superiore per la Protezione e la Ricerca Ambientale','Partner','ispra.png'],
  ['Autorità di Sistema Portuale del Mar Ligure Orientale','Partner','autorita-di-sistema-portuale-del-mar-ligure-orie.png'],
  ['Vitone Eco','Partner','vitone-eco.png'],
  ['Noesis','Partner','noesis.png'],
  ['SIMEM','Partner','simem.png'],
  ['Piraeus Port Authority','Partner','piraeus-port-authority.png'],
  ['Autorità di Sistema Portuale del Mare Adriatico Meridionale','Partner','autorita-di-sistema-portuale-del-mare-adriatico-.png'],
  ['Consiglio Nazionale delle Ricerche','Partner','cnr.png'],
];
foreach ($gl_p as $sp): ?>
      <div class="sm-it">
        <img src="<?php echo esc_url(troisi_cliente_logo_url($sp[2])); ?>" alt="<?php echo esc_attr($sp[0]); ?>" loading="lazy">
        <div class="sm-n"><?php echo esc_html($sp[0]); ?></div>
        <div class="sm-r"><?php echo esc_html($sp[1]); ?></div>
      </div>
<?php endforeach; ?>
    </div>
    <div class="gl-h" style="margin-top:22px">Contributori in-kind</div>
    <div class="sm-grid">
<?php foreach (troisi_gl4s_inkind() as $ik): ?>
      <div class="sm-it">
        <img src="<?php echo esc_url(troisi_cliente_logo_url($ik['file'])); ?>" alt="<?php echo esc_attr($ik['nome']); ?>" loading="lazy">
        <div class="sm-n"><?php echo esc_html($ik['nome']); ?></div>
      </div>
<?php endforeach; ?>
    </div>
    <div style="margin-top:14px;font-size:11px;color:var(--g)">Fonte: <a href="https://greenlife4seas.poliba.it/#partner" target="_blank" rel="noopener" style="color:var(--blu)">greenlife4seas.poliba.it</a></div>
  </div>
</div>

<script>
(function(){ // ordine casuale a ogni visita
  var g=document.getElementById('cl-grid'); if(!g) return;
  var it=[].slice.call(g.children);
  for(var i=it.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=it[i];it[i]=it[j];it[j]=t;}
  it.forEach(function(e){g.appendChild(e);});
  var c=document.getElementById('cnt'); if(c) c.textContent='Visualizzati tutti i '+it.length+' clienti — l\'ordine cambia a ogni visita';
})();
function filtra(cat,btn){
  document.querySelectorAll('.fb').forEach(b=>b.classList.remove('on'));
  btn.classList.add('on');
  var items=document.querySelectorAll('.cl-item');
  var vis=0;
  items.forEach(function(el){
    if(cat==='tutti'||el.dataset.cat.split(' ').indexOf(cat)>-1){el.style.display='flex';vis++;}
    else{el.style.display='none';}
  });
  document.getElementById('cnt').textContent='Visualizzati '+vis+' clienti'+(cat!=='tutti'?' nel settore selezionato':'');
}
</script>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
