<?php
/**
 * Template Name: Servizi
 */
get_header(); ?>
<?php $current_page = 'servizi'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.li{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);font-weight:700;border:1px solid #b3d1ff;padding:4px 12px;border-radius:2px;background:var(--bl);text-decoration:none}
.li::after{content:'→'}
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:4px 12px;border-radius:2px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}

/* Network intro */
.gal-intro{background:var(--dp);border-radius:var(--r);padding:24px 28px;margin-bottom:28px;display:flex;align-items:center;gap:24px}
.gi-icon{font-size:40px;flex-shrink:0}
.gi-txt h2{font-size:17px;font-weight:700;color:#fff;margin-bottom:5px}
.gi-txt p{font-size:12.5px;color:rgba(255,255,255,.6);line-height:1.7;max-width:600px}

/* Servizio / satellite card */
.sat-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.sat-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:22px;border-left:4px solid var(--blu);transition:box-shadow .15s}
.sat-card:hover{box-shadow:0 4px 16px rgba(0,102,204,.1)}
.sat-card.green{border-left-color:#00a86b}
.sat-card.teal{border-left-color:#008899}
.sat-card.violet{border-left-color:#6c3eb3}
.sat-card.orange{border-left-color:#e8a020}
.sat-card.red{border-left-color:#cc3300}
.sat-card.gray{border-left-color:#5a6a85}
.sat-badge{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:2px 8px;border-radius:2px;border:1px solid var(--bo);background:var(--bg);color:var(--g);display:inline-block;margin-bottom:10px}
.sat-brand{font-size:16px;font-weight:700;color:var(--dp);margin-bottom:3px}
.sat-brand span{color:var(--blu)}
.sat-url{font-size:10px;color:var(--g);margin-bottom:8px;font-family:monospace;letter-spacing:.02em}
.sat-desc{font-size:12.5px;color:var(--g);line-height:1.7;margin-bottom:12px}
.sat-features{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:14px}
.sf{font-size:10px;padding:2px 8px;background:var(--bl);color:var(--bd);border-radius:2px;border:1px solid #b3d1ff}
.sat-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}

/* Categoria label */
.cat-band{background:var(--bg);border:1px solid var(--bo);border-radius:var(--r);padding:10px 16px;margin:24px 0 14px;display:flex;align-items:center;gap:10px}
.cat-band h3{font-size:12.5px;font-weight:700;color:var(--dp);margin:0}
.cat-band span{font-size:11px;color:var(--g)}
.cat-icon{font-size:18px}

/* Perché il network */
.why-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:20px}
.why-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;border-top:3px solid var(--blu)}
.why-icon{font-size:22px;margin-bottom:8px}
.why-title{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:5px}
.why-desc{font-size:12px;color:var(--g);line-height:1.65}

/* note */
.personal-note{background:var(--bg);border:1px dashed var(--bo);border-radius:var(--r);padding:14px 18px;font-size:12px;color:var(--g);display:flex;align-items:flex-start;gap:10px;margin-top:12px}
.personal-note::before{content:'🔧';font-size:16px;flex-shrink:0}

@media(max-width:768px){
  .sat-grid{grid-template-columns:1fr}
  .why-grid{grid-template-columns:1fr}
}
@media(max-width:600px){.sec{padding:28px 16px}}
</style>

<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Servizi e Network</div>
  <h1>Il Network di <em>strumenti e piattaforme</em></h1>
  <p>Troisi Ricerche ha sviluppato nel tempo un network di siti e piattaforme specializzati, ciascuno dedicato a un'area tematica specifica. Ogni sito è raggiungibile dalla sua pagina interna, che approfondisce il servizio prima di rimandare al sito dedicato.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Servizi</div>

<div class="sec">
  <div class="wrap">

    <div class="gal-intro">
      <div class="gi-icon">🌌</div>
      <div class="gi-txt">
        <h2>Network Troisi Ricerche</h2>
        <p>Sedici domini specializzati, una regia scientifica unica. Ogni piattaforma del network condivide il metodo, la qualità e l'identità istituzionale di Troisi Ricerche, con focalizzazione verticale sulla propria area tematica.</p>
      </div>
    </div>

    <!-- RICERCA E ANALISI -->
    <div class="cat-band">
      <span class="cat-icon">📊</span>
      <h3>Ricerca e analisi territoriale</h3>
      <span>Indici, benchmark e modelli statistici per leggere il territorio</span>
    </div>
    <div class="sat-grid">

      <div class="sat-card">
        <span class="sat-badge">Ranking · Indice composito · PA</span>
        <div class="sat-brand"><span>TR</span>-Index</div>
        <div class="sat-url">t-index.it</div>
        <p class="sat-desc">Il ranking delle performance territoriali italiane. TR-Index misura e confronta le performance di comuni, province e regioni attraverso un indice composito multidimensionale. Strumento di benchmarking per amministratori, policy maker e ricercatori.</p>
        <div class="sat-features">
          <span class="sf">Ranking territoriale</span>
          <span class="sf">Comuni e Province</span>
          <span class="sf">Serie storiche</span>
          <span class="sf">Open data</span>
        </div>
        <div class="sat-actions">
          <a href="https://t-index.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri TR-Index →</a>
          <a href="https://t-index.it" target="_blank" rel="noopener" class="le">t-index.it</a>
        </div>
      </div>

      <div class="sat-card green">
        <span class="sat-badge">Dashboard · Open data · Visualizzazione</span>
        <div class="sat-brand"><span>Troisi</span>Insight</div>
        <div class="sat-url">troisiinsight.it</div>
        <p class="sat-desc">Dashboard interattive e visualizzazioni dei dati delle ricerche Troisi. Grafici, infografiche e report automatizzati per rendere accessibili i risultati delle analisi statistiche a un pubblico ampio.</p>
        <div class="sat-features">
          <span class="sf">Dashboard interattive</span>
          <span class="sf">Grafici dinamici</span>
          <span class="sf">Report automatici</span>
        </div>
        <div class="sat-actions">
          <a href="https://troisiinsight.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri TroisiInsight →</a>
          <a href="https://troisiinsight.it" target="_blank" rel="noopener" class="le">troisiinsight.it</a>
        </div>
      </div>

    </div>

    <!-- PUBBLICA AMMINISTRAZIONE -->
    <div class="cat-band">
      <span class="cat-icon">🏛️</span>
      <h3>Pubblica Amministrazione</h3>
      <span>Strumenti per la qualità dei servizi pubblici e il benessere organizzativo</span>
    </div>
    <div class="sat-grid">

      <div class="sat-card teal">
        <span class="sat-badge">Customer Satisfaction · Metodologia · PA</span>
        <div class="sat-brand"><span>Customer</span>PA</div>
        <div class="sat-url">customerpa.it</div>
        <p class="sat-desc">La piattaforma di riferimento per la Customer Satisfaction nella Pubblica Amministrazione italiana. Metodologie validate, strumenti di rilevazione e benchmark di settore per migliorare la qualità percepita dei servizi pubblici. Basato sul modello del libro Cacucci 2017.</p>
        <div class="sat-features">
          <span class="sf">ISO 9001:2015</span>
          <span class="sf">Benchmark PA</span>
          <span class="sf">Questionari validati</span>
          <span class="sf">Modello statistico</span>
        </div>
        <div class="sat-actions">
          <a href="https://customerpa.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri CustomerPA →</a>
          <a href="<?php echo home_url('/la-ricerca'); ?>" class="li">Il modello →</a>
          <a href="https://customerpa.it" target="_blank" rel="noopener" class="le">customerpa.it</a>
        </div>
      </div>

      <div class="sat-card violet">
        <span class="sat-badge">Benessere · Clima organizzativo · PA</span>
        <div class="sat-brand"><span>Benessere</span>Organizzativo</div>
        <div class="sat-url">benessereorganizzativo.it</div>
        <p class="sat-desc">Indagini sul benessere organizzativo e il clima interno nelle organizzazioni pubbliche e private. Strumenti diagnostici per misurare il livello di engagement, motivazione e soddisfazione del personale con metodologia statistica rigorosa.</p>
        <div class="sat-features">
          <span class="sf">D.Lgs. 150/2009</span>
          <span class="sf">Clima organizzativo</span>
          <span class="sf">Employee satisfaction</span>
        </div>
        <div class="sat-actions">
          <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri BenessereOrganizzativo →</a>
          <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener" class="le">benessereorganizzativo.it</a>
        </div>
      </div>

      <div class="sat-card orange">
        <span class="sat-badge">PNRR · Digitalizzazione · PA digitale</span>
        <div class="sat-brand"><span>Digitalizzazione</span>PA</div>
        <div class="sat-url">digitalizzazionepa.it</div>
        <p class="sat-desc">Monitoraggio e analisi della digitalizzazione della Pubblica Amministrazione italiana, con focus sugli interventi PNRR. Ricerche sull'adozione delle tecnologie digitali nei servizi pubblici e sull'impatto percepito da cittadini e dipendenti PA.</p>
        <div class="sat-features">
          <span class="sf">PNRR</span>
          <span class="sf">PA digitale</span>
          <span class="sf">Transizione 4.0</span>
        </div>
        <div class="sat-actions">
          <a href="https://digitalizzazionepa.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri DigitalizzazionePA →</a>
          <a href="https://digitalizzazionepa.it" target="_blank" rel="noopener" class="le">digitalizzazionepa.it</a>
        </div>
      </div>

      <div class="sat-card red">
        <span class="sat-badge">Partecipazione · D.Lgs. 36/2023 · Ascolto</span>
        <div class="sat-brand"><span>Dibattito</span>Pubblico</div>
        <div class="sat-url">dibattito-pubblico.it</div>
        <p class="sat-desc">Strumenti e metodologie per il dibattito pubblico sulle grandi opere e le politiche territoriali. Il framework per la partecipazione civica applicato al dibattito pubblico disciplinato dall'art. 40 del Codice dei contratti pubblici (D.Lgs. 36/2023) e dall'Allegato I.6, obbligatorio per le grandi opere infrastrutturali sopra soglia.</p>
        <div class="sat-features">
          <span class="sf">D.Lgs. 36/2023 · All. I.6</span>
          <span class="sf">Grandi opere</span>
          <span class="sf">Partecipazione civica</span>
        </div>
        <div class="sat-actions">
          <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri Dibattito Pubblico →</a>
          <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" class="le">dibattito-pubblico.it</a>
        </div>
      </div>

    </div>

    <!-- COMPETENZE EQF -->
    <div class="cat-band">
      <span class="cat-icon">🎓</span>
      <h3>Competenze e formazione</h3>
      <span>Mappatura e registrazione delle competenze secondo il Framework EQF</span>
    </div>
    <div class="sat-grid">

      <div class="sat-card">
        <span class="sat-badge">Competenze · EQF · Mappatura</span>
        <div class="sat-brand"><span>Mappatura</span> delle Competenze</div>
        <div class="sat-url">mappaturadellecompetenze.it</div>
        <p class="sat-desc">La piattaforma per la mappatura delle competenze secondo il Framework Europeo delle Qualifiche (EQF). Strumenti diagnostici per rilevare, classificare e valorizzare le competenze individuali e organizzative con metodologia europea.</p>
        <div class="sat-features">
          <span class="sf">EQF Framework</span>
          <span class="sf">Competenze individuali</span>
          <span class="sf">Analisi organizzativa</span>
        </div>
        <div class="sat-actions">
          <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri Mappatura delle Competenze →</a>
          <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener" class="le">mappaturadellecompetenze.it</a>
        </div>
      </div>

      <div class="sat-card green">
        <span class="sat-badge">Registro · Certificazione · EQF</span>
        <div class="sat-brand"><span>Registro</span> delle Competenze</div>
        <div class="sat-url">registrodellecompetenze.it</div>
        <p class="sat-desc">Il registro delle competenze certificate EQF. Complementare a Mappatura delle Competenze, Registro delle Competenze consente di registrare, archiviare e certificare le competenze rilevate, creando un portafoglio professionale strutturato e verificabile.</p>
        <div class="sat-features">
          <span class="sf">Certificazione EQF</span>
          <span class="sf">Portfolio competenze</span>
          <span class="sf">Registro digitale</span>
        </div>
        <div class="sat-actions">
          <a href="https://registrodellecompetenze.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri Registro delle Competenze →</a>
          <a href="https://registrodellecompetenze.it" target="_blank" rel="noopener" class="le">registrodellecompetenze.it</a>
        </div>
      </div>

    </div>

    <!-- PIATTAFORME E MEDIA -->
    <div class="cat-band">
      <span class="cat-icon">🎙️</span>
      <h3>Piattaforme e media</h3>
      <span>Sondaggi partecipati, podcast e contenuti multimediali</span>
    </div>
    <div class="sat-grid">

      <div class="sat-card teal">
        <span class="sat-badge">Sondaggi · Partecipazione · Civic tech</span>
        <div class="sat-brand"><span>TIP</span> Platform</div>
        <div class="sat-url">tiplive.it</div>
        <p class="sat-desc">TIP (Troisi Insight Platform) è la piattaforma per sondaggi partecipati e ricerca online. Strumenti di rilevazione digitale, panel management e analisi dei dati in tempo reale per ricerche quantitative e qualitative.</p>
        <div class="sat-features">
          <span class="sf">Sondaggi online</span>
          <span class="sf">Panel management</span>
          <span class="sf">Real-time analytics</span>
        </div>
        <div class="sat-actions">
          <a href="https://tiplive.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri TIP →</a>
          <a href="https://tiplive.it" target="_blank" rel="noopener" class="le">tiplive.it</a>
        </div>
      </div>

      <div class="sat-card orange">
        <span class="sat-badge">Podcast · Audio · Comunicazione scientifica</span>
        <div class="sat-brand"><span>VoiceIn</span>Hub</div>
        <div class="sat-url">voiceinhub.it</div>
        <p class="sat-desc">L'hub dei podcast Troisi Ricerche. Contenuti audio su statistica, ricerca sociale, governance territoriale e dibattito pubblico. La comunicazione scientifica nella sua forma più accessibile: il podcast.</p>
        <div class="sat-features">
          <span class="sf">Podcast</span>
          <span class="sf">Audio content</span>
          <span class="sf">Comunicazione scientifica</span>
        </div>
        <div class="sat-actions">
          <a href="https://voiceinhub.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri VoiceInHub →</a>
          <a href="<?php echo home_url('/media'); ?>" class="li">Media →</a>
          <a href="https://voiceinhub.it" target="_blank" rel="noopener" class="le">voiceinhub.it</a>
        </div>
      </div>

      <div class="sat-card orange">
        <span class="sat-badge">Formazione finanziata · Fondimpresa · Fondirigenti · WooCommerce</span>
        <div class="sat-brand"><span>Troisi</span>Formazione</div>
        <div class="sat-url">troisiformazione.it</div>
        <p class="sat-desc">L'hub formativo di Troisi Ricerche. Formazione finanziata anche con i Fondi Interprofessionali, mappatura competenze con Mappatura delle Competenze, certificazione con Registro delle Competenze. Catalogo corsi, slide formative e sistema integrato formazione-competenze-certificazione.</p>
        <div class="sat-features">
          <span class="sf">Fondimpresa</span>
          <span class="sf">Fondirigenti</span>
          <span class="sf">Mappatura delle Competenze + Registro delle Competenze</span>
          <span class="sf">E-commerce slide</span>
        </div>
        <div class="sat-actions">
          <a href="https://troisiformazione.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri Troisi Formazione →</a>
          <a href="https://troisiformazione.it" target="_blank" rel="noopener" class="le">troisiformazione.it</a>
        </div>
      </div>

      <div class="sat-card orange">
        <span class="sat-badge">ESG · Governance · Fondirigenti · Camera dei Deputati</span>
        <div class="sat-brand"><span>Governance</span>Finanziaria</div>
        <div class="sat-url">governancefinanziaria.it</div>
        <p class="sat-desc">Archivio istituzionale del progetto Governance Finanziaria promosso da Fondirigenti. Modello di competenze per la governance finanziaria d'impresa, ESG, AI e decision making. Con Links Management e SCS Consulting. Presentato alla Camera dei Deputati.</p>
        <div class="sat-features">
          <span class="sf">Fondirigenti</span>
          <span class="sf">ESG &amp; Governance</span>
          <span class="sf">Camera dei Deputati</span>
          <span class="sf">AI Decision Making</span>
        </div>
        <div class="sat-actions">
          <a href="https://governancefinanziaria.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri Governance Finanziaria →</a>
          <a href="https://governancefinanziaria.it" target="_blank" rel="noopener" class="le">governancefinanziaria.it</a>
        </div>
      </div>

      <div class="sat-card orange">
        <span class="sat-badge">Export · MISE · Invitalia · Voucher · SIMEST</span>
        <div class="sat-brand"><span>Consulenza</span>Internazionalizzazione</div>
        <div class="sat-url">consulenzainternazionalizzazione.it</div>
        <p class="sat-desc">Consulenza strategica per l'internazionalizzazione delle PMI italiane. Voucher MISE/Invitalia, finanziamenti SIMEST, analisi mercati esteri, temporary export management. Troisi Ricerche come fornitore accreditato.</p>
        <div class="sat-features">
          <span class="sf">Voucher MISE</span>
          <span class="sf">SIMEST</span>
          <span class="sf">Export Management</span>
          <span class="sf">Analisi Mercati</span>
        </div>
        <div class="sat-actions">
          <a href="https://consulenzainternazionalizzazione.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri Internazionalizzazione →</a>
          <a href="https://consulenzainternazionalizzazione.it" target="_blank" rel="noopener" class="le">consulenzainternazionalizzazione.it</a>
        </div>
      </div>

      <div class="sat-card orange">
        <span class="sat-badge">Osservatorio · Genitori · Insegnanti · Istituzioni</span>
        <div class="sat-brand"><span>BDG</span> · Benessere Digitale Giovani</div>
        <div class="sat-url">benesseredigitalegiovani.it</div>
        <p class="sat-desc">L'Osservatorio sul Benessere Digitale dei Giovani. Dati scientifici e strumenti gratuiti su dipendenza smartphone, tempo schermo, effetti social media. Checker per genitori, ricerca annuale, programmi per scuole e famiglie.</p>
        <div class="sat-features">
          <span class="sf">Checker genitori</span>
          <span class="sf">Ricerca annuale</span>
          <span class="sf">Programmi scuole</span>
          <span class="sf">Dati scientifici</span>
        </div>
        <div class="sat-actions">
          <a href="https://benesseredigitalegiovani.it" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;background:var(--blu);color:#fff;font-size:11px;font-weight:700;padding:7px 14px;border-radius:var(--r);text-decoration:none">Scopri BDG →</a>
          <a href="https://benesseredigitalegiovani.it" target="_blank" rel="noopener" class="le">benesseredigitalegiovani.it</a>
        </div>
      </div>

    </div>

    <!-- Perché il network -->
    <div style="margin-top:36px">
      <div class="sh"><div class="sl"></div><div class="se">Architettura strategica</div></div>
      <div class="s-t">Perché un <em>network</em> di siti?</div>
      <div class="why-grid">
        <div class="why-card">
          <div class="why-icon">🎯</div>
          <div class="why-title">Focalizzazione verticale</div>
          <p class="why-desc">Ogni sito è ottimizzato per la sua area tematica: SEO verticale, contenuti specifici, audience dedicata. La specializzazione produce maggiore autorevolezza in ogni dominio.</p>
        </div>
        <div class="why-card">
          <div class="why-icon">🔗</div>
          <div class="why-title">Regia scientifica unica</div>
          <p class="why-desc">Tutti i siti del network condividono il metodo Troisi, le certificazioni ISO 9001, l'identità visiva istituzionale. Un network, un metodo.</p>
        </div>
        <div class="why-card">
          <div class="why-icon">📡</div>
          <div class="why-title">Network interconnesso</div>
          <p class="why-desc">I siti del network si alimentano e si citano reciprocamente, creando un network di contenuti scientifici coerente e autoreferenziale — un modello hub-and-spoke per la comunicazione istituzionale.</p>
        </div>
      </div>
    </div>

  </div>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
