<?php
/**
 * Template Name: Territorio
 */
get_header(); ?>
<?php $current_page = 'territorio'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.li{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);font-weight:700;border:1px solid #b3d1ff;padding:4px 12px;border-radius:2px;background:var(--bl);text-decoration:none}
.li::after{content:'→'}
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:4px 12px;border-radius:2px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}

/* Sport cards */
.sport-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px;margin-bottom:8px}
.sport-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden;box-shadow:0 1px 4px rgba(0,38,77,.04)}
.sport-img{width:100%;height:440px;min-height:400px;object-fit:cover;object-position:center;display:block;background:var(--bg)}
.sport-body{padding:18px}
.sport-badge{display:inline-block;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:2px 8px;border-radius:2px;margin-bottom:8px;background:var(--bl);color:var(--bd);border:1px solid #b3d1ff}
.sport-badge.green{background:#e6f5ee;color:#00663a;border-color:#a0d4b8}
.sport-badge.orange{background:#fff3e0;color:#b45309;border-color:#ffd080}
.sport-badge.purple{background:#f0eeff;color:#4c1d95;border-color:#c4b5fd}
.sport-title{font-size:15px;font-weight:700;color:var(--dp);margin-bottom:6px}
.sport-desc{font-size:12.5px;color:var(--g);line-height:1.7;margin-bottom:10px}
.sport-highlight{background:var(--bl);border-left:3px solid var(--blu);padding:8px 12px;border-radius:0 var(--r) var(--r) 0;font-size:12px;color:var(--bd);margin-bottom:10px;line-height:1.55}
.sport-highlight strong{color:var(--dp)}

/* Progetti speciali */
.prog-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:24px;margin-bottom:16px;display:grid;grid-template-columns:1fr 320px;gap:28px;align-items:start}
.prog-card.rev{grid-template-columns:320px 1fr}
.prog-tag{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--vd);border:1px solid #a0d4b8;background:#e6f5ee;padding:2px 9px;border-radius:2px;display:inline-block;margin-bottom:10px}
.prog-title{font-size:17px;font-weight:700;color:var(--dp);margin-bottom:6px}
.prog-sub{font-size:11px;color:var(--g);margin-bottom:12px;letter-spacing:.01em}
.prog-desc{font-size:12.5px;color:var(--g);line-height:1.75;margin-bottom:12px}
.prog-partner{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}
.pp{font-size:10.5px;font-weight:700;padding:3px 10px;border-radius:2px;background:var(--bg);border:1px solid var(--bo);color:var(--t)}
.prog-img{width:100%;height:440px;min-height:400px;object-fit:cover;object-position:center;border-radius:var(--r);display:block;background:var(--bg)}
.prog-img-pair{display:grid;grid-template-columns:1fr 1fr;gap:8px}

/* Convegni / eventi */
.ev-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.ev-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;border-left:3px solid var(--blu)}
.ev-year{font-size:10px;font-weight:700;color:var(--blu);margin-bottom:4px}
.ev-title{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px}
.ev-desc{font-size:12px;color:var(--g);line-height:1.6}

/* Nota video */
.video-note{background:var(--bg);border:1px dashed var(--bo);border-radius:var(--r);padding:14px 18px;font-size:12px;color:var(--g);display:flex;align-items:flex-start;gap:10px}
.video-note::before{content:'🎬';font-size:16px;flex-shrink:0}

/* Intro territory band */
.terr-band{background:var(--dp);color:#fff;padding:20px 24px;display:flex;align-items:center;justify-content:space-between;gap:20px}
.tb-num{text-align:center;min-width:70px}
.tb-val{font-size:28px;font-weight:700;color:var(--or)}
.tb-lab{font-size:9.5px;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:.06em}
.tb-div{width:1px;height:40px;background:rgba(255,255,255,.12)}
.tb-txt{font-size:12.5px;color:rgba(255,255,255,.65);line-height:1.7;flex:1}

@media(max-width:768px){
  .sport-grid{grid-template-columns:1fr}
  .prog-card,.prog-card.rev{grid-template-columns:1fr}
  .ev-grid{grid-template-columns:1fr}
  .terr-band{flex-direction:column;text-align:center}
  .tb-div{display:none}
}
@media(max-width:600px){.sec{padding:28px 16px}}
</style>

<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Territorio</div>
  <h1>Radicati nel <em>territorio</em></h1>
  <p>Troisi Ricerche non è solo ricerca scientifica: è un soggetto attivo nella comunità barese e pugliese. Sponsorizziamo lo sport giovanile, partecipiamo a progetti di ricerca applicata, portiamo la statistica nei convegni e nei media locali.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Territorio</div>

<div class="terr-band">
  <div class="tb-num"><div class="tb-val">4</div><div class="tb-lab">Squadre sportive sponsorizzate</div></div>
  <div class="tb-div"></div>
  <div class="tb-num"><div class="tb-val">2</div><div class="tb-lab">Sedi operative (Bari + Roma)</div></div>
  <div class="tb-div"></div>
  <div class="tb-num"><div class="tb-val">20+</div><div class="tb-lab">Anni di presenza a Bari</div></div>
  <div class="tb-div"></div>
  <div class="tb-txt"><em style="font-size:1.15em;font-style:italic;color:var(--dp);line-height:1.7;display:block">Crediamo che un istituto di ricerca abbia responsabilità verso il proprio territorio. Sosteniamo sport giovanile, ricerca applicata e partecipazione civica.</em></div>
</div>

<!-- SPORT -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Sponsorizzazioni sportive</div></div>
    <div class="s-t">Troisi Ricerche nel <em>mondo dello sport</em></div>
    <p class="s-d">Il logo di Troisi Ricerche sulle divise, sui campi, nei palazzetti. Quattro realtà sportive pugliesi che condividono i nostri valori: impegno, metodo, crescita.</p>

    <div class="sport-grid">

      <!-- Patriots Football Americano -->
      <div class="sport-card">
        <img src="<?php echo get_template_directory_uri(); ?>/foto-patriots.jpg" alt="Patriots Football Americano Bari - Troisi Ricerche sponsor" class="sport-img" style="object-position:center 60%">
        <div class="sport-body">
          <span class="sport-badge orange">Football americano</span>
          <div class="sport-title">Patriots Bari</div>
          <p class="sport-desc">Sponsor ufficiale della squadra di football americano barese. Il logo Troisi Ricerche campeggia sulle divise dei Patriots, portando il brand della ricerca statistica anche sui campi da gioco.</p>
          <div class="sport-highlight"><strong>Nota storica:</strong> Chef Rubio, il celebre personaggio televisivo, ha partecipato come ospite a una partita dei Patriots — un momento di grande visibilità mediatica per la squadra e per i suoi sponsor.</div>
        </div>
      </div>

      <!-- Rollin' Skate Bari -->
      <div class="sport-card">
        <img src="<?php echo get_template_directory_uri(); ?>/foto-rollin-skate.jpg" alt="Rollin' Skate Bari hockey inline - Troisi Ricerche" class="sport-img">
        <div class="sport-body">
          <span class="sport-badge purple">Hockey inline · ASD</span>
          <div class="sport-title">Rollin' Skate Bari</div>
          <p class="sport-desc">L'ASD Rollin' Skate Bari porta Troisi Ricerche sui campi da hockey inline di tutta Italia. Il nostro banner occupa posizione centrale e prominente a bordo campo, e il logo TR è visibile sulle divise dei giocatori.</p>
          <div class="sport-highlight">Visibilità garantita in ogni partita casalinga, con il banner Troisi Ricerche in primo piano nel campo di gioco.</div>
        </div>
      </div>

      <!-- Club Scherma Bari -->
      <div class="sport-card">
        <img src="<?php echo get_template_directory_uri(); ?>/foto-scherma.webp" alt="Club Scherma Bari FIS - atleti nazionali" class="sport-img" style="object-position:center top">
        <div class="sport-body">
          <span class="sport-badge green">Scherma · FIS · Nazionale</span>
          <div class="sport-title">Club Scherma Bari</div>
          <p class="sport-desc">Socio sostenitore del Club Scherma Bari, ASD affiliata alla <strong>Federazione Italiana Scherma (FIS)</strong>. I nostri atleti competono a livello nazionale e internazionale, indossando la maglia della Nazionale italiana.</p>
          <div class="sport-highlight"><strong>Eccellenza pugliese:</strong> Atleti federati FIS che rappresentano l'Italia in competizioni internazionali. La foto del team è stata scattata a Courmayeur Mont Blanc, sede di gara internazionale.</div>
        </div>
      </div>

      <!-- USD Enterprise Giovani Atleti -->
      <div class="sport-card">
        <img src="<?php echo get_template_directory_uri(); ?>/foto-atletica.jpg" alt="USD Enterprise Giovani Atleti - Troisi Ricerche sponsor atletica" class="sport-img">
        <div class="sport-body">
          <span class="sport-badge">Atletica leggera</span>
          <div class="sport-title">USD Enterprise Giovani Atleti</div>
          <p class="sport-desc">Sponsor tecnico dell'USD Enterprise Giovani Atleti, società di atletica leggera pugliese impegnata nella formazione dei giovani talenti. La giacca tecnica blu con il logo di Troisi Ricerche è il segno tangibile del nostro sostegno.</p>
          <div class="sport-highlight">Investire nello sport giovanile significa investire nel futuro del territorio. I giovani atleti pugliesi sono la prossima generazione di eccellenze.</div>
        </div>
      </div>

    </div>

    <!-- Seconda foto Rollin' banner -->
    <div style="margin-top:16px;background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden;display:grid;grid-template-columns:1fr 1.2fr;gap:0;align-items:center">
      <img src="<?php echo get_template_directory_uri(); ?>/foto-rollin-banner.jpg" alt="Banner Troisi Ricerche campo hockey inline" style="width:100%;height:200px;object-fit:cover;display:block">
      <div style="padding:20px 24px">
        <div class="se" style="margin-bottom:8px">Visibilità sul campo</div>
        <div class="s-t" style="font-size:15px">Il banner Troisi Ricerche a bordo campo</div>
        <p style="font-size:12.5px;color:var(--g);line-height:1.7">La presenza Troisi Ricerche nel mondo dell'hockey inline va oltre le divise: un grande banner occupa posizione centrale e privilegiata a bordo campo, visibile in ogni partita e nelle riprese video degli incontri.</p>
      </div>
    </div>
  </div>
</div>

<!-- PROGETTI RICERCA TERRITORIALE -->
<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Ricerca applicata nel territorio</div></div>
    <div class="s-t">Progetti che <em>cambiano il territorio</em></div>
    <p class="s-d">Oltre alla ricerca istituzionale, Troisi Ricerche partecipa attivamente a progetti di ricerca applicata che coinvolgono il territorio pugliese e nazionale.</p>

    <!-- STIMARE -->
    <div class="prog-card">
      <div>
        <span class="prog-tag">Ricerca Interuniversitaria · In corso</span>
        <div class="prog-title">Progetto STIMARE</div>
        <div class="prog-sub">STrategie Innovative per il Monitoraggio e l'Analisi del Rischio Erosione</div>
        <div class="prog-partner">
          <span class="pp">Politecnico di Bari</span>
          <span class="pp">Università di Bologna — DICAM</span>
          <span class="pp">Troisi Ricerche</span>
        </div>
        <p class="prog-desc">STIMARE è un progetto di ricerca interuniversitaria focalizzato sul monitoraggio del rischio di erosione costiera. Troisi Ricerche partecipa come soggetto operativo, portando le proprie competenze metodologiche nell'analisi dei dati e nel coinvolgimento dei portatori di interesse.</p>
        <p class="prog-desc">Il progetto coinvolge il <strong>Dipartimento di Ingegneria Civile, Chimica, Ambientale e dei Materiali (DICAM)</strong> dell'Università di Bologna e il <strong>Politecnico di Bari</strong>, due eccellenze nazionali nella ricerca applicata.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://www.poliba.it/en/ateneo/eventi/il-progetto-stimare" class="le" target="_blank">PoliBa — STIMARE</a>
          <a href="https://dicam.unibo.it/it/ricerca/progetti-di-ricerca/stimare-strategie-innovative-per-il-monitoraggio-e-l-analisi-del-rischio-erosione-1" class="le" target="_blank">UniBO — DICAM</a>
        </div>
      </div>
      <div>
        <div class="prog-img-pair">
          <img src="<?php echo get_template_directory_uri(); ?>/foto-stimare-bari.jpg" alt="Team STIMARE lungomare Bari" class="prog-img">
          <img src="<?php echo get_template_directory_uri(); ?>/foto-stimare-convegno.jpg" alt="Andrea Troisi presenta STIMARE al convegno" class="prog-img">
        </div>
        <p style="font-size:11px;color:var(--g);margin-top:8px;text-align:center">Il team STIMARE al lungomare di Bari · Andrea Troisi presenta i risultati al convegno</p>
      </div>
    </div>

    <!-- MSC Summer Tour -->
    <div class="prog-card" style="border-left:3px solid var(--or)">
      <div>
        <span class="prog-tag" style="background:#fff3e0;color:#b45309;border-color:#ffd080">Caso studio · Committente privato</span>
        <div class="prog-title">MSC Summer Tour — Prima edizione</div>
        <div class="prog-sub">Customer Satisfaction per MSC Crociere · Prima edizione storica del tour</div>
        <div class="prog-partner">
          <span class="pp">MSC Crociere</span>
          <span class="pp">Troisi Ricerche</span>
        </div>
        <p class="prog-desc">Troisi Ricerche ha condotto le indagini di <strong>Customer Satisfaction</strong> per il primo MSC Summer Tour nella storia di MSC Crociere, uno degli operatori crocieristici leader al mondo. Un primato storico: la prima edizione di questo tour estivo — tappa dopo tappa lungo le coste italiane — monitorata con metodo scientifico. Giochi, relax, divertimento e l'emozione di MSC già dalla terraferma: Troisi Ricerche ha misurato la soddisfazione dei partecipanti con il proprio metodo proprietario, raccogliendo dati strutturati in tempo reale su più location nazionali.</p>
        <p class="prog-desc">Il progetto ha richiesto coordinamento di team di intervistatori su molteplici location e analisi statistica dei dati — un esempio di ricerca applicata ad alta intensità operativa per uno dei brand più riconoscibili del settore crocieristico mondiale.</p>
        <!-- Video MSC — click to open -->
        <a href="https://www.youtube.com/watch?v=6ubSZhpvrL4" target="_blank" rel="noopener"
           style="display:flex;align-items:center;gap:14px;background:var(--dp);border-radius:var(--r);padding:14px 18px;text-decoration:none;margin:14px 0">
          <div style="width:48px;height:48px;background:#cc0000;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="white"><polygon points="9.5,7.5 16.5,12 9.5,16.5"/></svg>
          </div>
          <div>
            <div style="font-size:13px;font-weight:700;color:#fff">▶ Guarda il servizio video</div>
            <div style="font-size:11px;color:rgba(255,255,255,.55)">MSC Summer Tour — YouTube · Troisi Ricerche</div>
          </div>
        </a>
      </div>
      <div style="background:var(--dp);border-radius:var(--r);padding:24px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:14px;min-height:200px">
        <img src="<?php echo get_template_directory_uri(); ?>/loghi-clienti/MSC-new.png" alt="MSC Cruises" style="max-width:180px;max-height:90px;object-fit:contain;background:#fff;padding:8px 16px;border-radius:4px">
        <div style="font-size:12px;color:rgba(255,255,255,.65);line-height:1.7">Indagini di Customer Satisfaction<br>per il primo MSC Summer Tour<br>nella storia di MSC Crociere</div>
        <div style="font-size:10px;color:var(--or);font-weight:700;text-transform:uppercase;letter-spacing:.08em;border:1px solid rgba(232,160,32,.4);padding:4px 12px;border-radius:2px">Primato storico — Prima edizione</div>
      </div>
    </div>

  </div>
</div>

<!-- CONVEGNI ED EVENTI -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Presenza istituzionale</div></div>
    <div class="s-t">Troisi Ricerche nei <em>convegni e nei media</em></div>
    <p class="s-d">Andrea Troisi porta la voce della statistica applicata nei principali contesti istituzionali, accademici e mediatici del territorio e del Paese.</p>

    <div class="ev-grid">
      <div class="ev-card">
        <div class="ev-year">2011 — Evento storico</div>
        <div class="ev-title">Qualità della vita in Puglia</div>
        <p class="ev-desc">1.068 interviste face-to-face, metodologia stratificata, errore campionario 3,5%. In prima pagina su EPolis Bari, con copertura su Repubblica, Corriere del Mezzogiorno e Nuovo Quotidiano di Puglia. Committenti: Codacons, Regione Puglia, Min. Sviluppo.</p>
      </div>
      <div class="ev-card">
        <div class="ev-year">Ricorrente</div>
        <div class="ev-title">Fiera del Levante — Bari</div>
        <p class="ev-desc">Presenza come espositore e relatore alla Fiera del Levante di Bari, vetrina internazionale dell'economia meridionale. Un appuntamento annuale con il tessuto imprenditoriale pugliese.</p>
      </div>
      <div class="ev-card">
        <div class="ev-year">Ricorrente</div>
        <div class="ev-title">Forum PA — Roma</div>
        <p class="ev-desc">Partecipazione al Forum della Pubblica Amministrazione a Roma, il principale evento nazionale dedicato all'innovazione nella PA. Troisi Ricerche porta il proprio contributo su customer satisfaction e governance territoriale.</p>
      </div>
      <div class="ev-card">
        <div class="ev-year">Ricorrente</div>
        <div class="ev-title">Congressi SIS</div>
        <p class="ev-desc">Presenza ai convegni della Società Italiana di Statistica (SIS), ente di cui Troisi Ricerche è membro. Un confronto continuo con la comunità scientifica statistica nazionale.</p>
      </div>
      <div class="ev-card">
        <div class="ev-year">Radio · Settimanale</div>
        <div class="ev-title">Il Dato è Tratto — Controradio</div>
        <p class="ev-desc">Andrea Troisi conduce e ha fondato "Il Dato è Tratto" su Controradio Bari: statistica, sondaggi e dati raccontati al grande pubblico radiofonico barese.</p>
      </div>
      <div class="ev-card">
        <div class="ev-year">TV · In corso</div>
        <div class="ev-title">Drive In — Tele Lazio Nord</div>
        <p class="ev-desc">Andrea Troisi è ospite fisso della trasmissione "Drive In" su Tele Lazio Nord. Le puntate sono disponibili sulla <a href="https://www.youtube.com/watch?v=qa3CJBMLXIY&list=PLOoGJz564GrV21MMzOLhiUlpEdW3Xbu8T" target="_blank" style="color:var(--blu)">playlist YouTube ufficiale</a>.</p>
      </div>
    </div>
  </div>
</div>

<!-- CTA -->
<div class="sec alt" style="text-align:center;padding:32px 24px">
  <div class="wrap">
    <div style="background:var(--dp);border-radius:var(--r);padding:32px;color:#fff;max-width:600px;margin:0 auto">
      <div style="font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.38);margin-bottom:10px">Collabora con noi</div>
      <div style="font-size:20px;font-weight:700;color:#fff;margin-bottom:8px">Vuoi sostenere la ricerca statistica nel territorio?</div>
      <p style="font-size:13px;color:rgba(255,255,255,.6);line-height:1.7;margin-bottom:18px">Sponsorizzazioni, partnership istituzionali, progetti di ricerca applicata: siamo aperti a collaborazioni con enti, associazioni e imprese che condividono i nostri valori.</p>
      <a href="<?php echo home_url('/contatti'); ?>" style="background:var(--or);color:#fff;padding:10px 24px;border-radius:var(--r);font-size:13px;font-weight:700;text-decoration:none;display:inline-block">Contattaci</a>
    </div>
  </div>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
