<?php
/**
 * Template Name: Strumento — TR-Index
 */
get_header();
$current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php');
?>
<style>
.dim-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin:16px 0}
.dim{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;border-left:4px solid var(--blu)}
.dim-n{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--blu);margin-bottom:6px}
.dim-t{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:4px}
.dim-d{font-size:12px;color:var(--g);line-height:1.6}
.source-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}
.source{background:var(--bg);border:0.5px solid var(--bo);border-radius:var(--r);padding:12px;text-align:center;font-size:11.5px;font-weight:600;color:var(--dp)}
.media-cite{background:#fff;border-left:4px solid var(--or);padding:16px 20px;margin:12px 0;border-radius:0 var(--r) var(--r) 0}
.cite-testata{font-size:11px;font-weight:700;color:var(--or);text-transform:uppercase;margin-bottom:4px}
.cite-text{font-size:13px;color:var(--t);line-height:1.65}
.cta-p{display:inline-block;background:var(--or);color:#fff;padding:11px 24px;border-radius:var(--r);font-size:13px;font-weight:700;text-decoration:none;margin:4px}
@media(max-width:600px){.dim-grid{grid-template-columns:1fr}.source-grid{grid-template-columns:1fr 1fr}}
</style>

<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1>TR-Index — <em>Ranking territoriale</em></h1>
  <p>L'indice proprietario di Troisi Ricerche per misurare la qualità della vita, i servizi pubblici e la performance dei territori italiani. Aggiornato annualmente con dati ISTAT e fonti istituzionali.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; TR-Index</div>

<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Cos'è il TR-Index</div></div>
    <div class="s-t">Un indice multidimensionale per <em>valutare i territori</em></div>
    <p class="s-d">Il TR-Index (Troisi Index) è un indice composito che misura la qualità dei servizi pubblici e la performance dei territori italiani su base provinciale e regionale. Nasce da oltre vent'anni di ricerca applicata di Troisi Ricerche ed è costruito su dati ISTAT, Ministeri, Banca d'Italia e altre fonti istituzionali certificate.</p>

    <div style="background:var(--dp);border-radius:var(--r);padding:24px;display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;text-align:center">
      <div><div style="font-size:28px;font-weight:700;color:var(--or)">110</div><div style="font-size:11px;color:rgba(255,255,255,.5);margin-top:3px">Province monitorate</div></div>
      <div><div style="font-size:28px;font-weight:700;color:var(--or)">30+</div><div style="font-size:11px;color:rgba(255,255,255,.5);margin-top:3px">Indicatori per dimensione</div></div>
      <div><div style="font-size:28px;font-weight:700;color:var(--or)">5</div><div style="font-size:11px;color:rgba(255,255,255,.5);margin-top:3px">Dimensioni tematiche</div></div>
      <div><div style="font-size:28px;font-weight:700;color:var(--or)">2026</div><div style="font-size:11px;color:rgba(255,255,255,.5);margin-top:3px">Ultimo aggiornamento</div></div>
    </div>

    <div class="sh"><div class="sl"></div><div class="se">Le dimensioni del TR-Index</div></div>
    <div class="dim-grid">
      <div class="dim">
        <div class="dim-n">Dimensione 1</div>
        <div class="dim-t">Servizi pubblici locali</div>
        <div class="dim-d">Qualità dei servizi municipali, raccolta rifiuti, trasporto pubblico locale, verde urbano. Fonte: ISTAT e carte dei servizi comunali.</div>
      </div>
      <div class="dim">
        <div class="dim-n">Dimensione 2</div>
        <div class="dim-t">Sanità e benessere</div>
        <div class="dim-d">Tempi di attesa, indici di ospedalizzazione, medici per abitante, prevenzione. Fonte: Ministero della Salute, AGENAS.</div>
      </div>
      <div class="dim">
        <div class="dim-n">Dimensione 3</div>
        <div class="dim-t">Istruzione e cultura</div>
        <div class="dim-d">Dispersione scolastica, titoli di studio, biblioteche, musei, offerta universitaria. Fonte: MIUR, ISTAT.</div>
      </div>
      <div class="dim">
        <div class="dim-n">Dimensione 4</div>
        <div class="dim-t">Economia e lavoro</div>
        <div class="dim-d">Tasso di occupazione, PIL pro capite, imprese attive, esportazioni, innovazione. Fonte: ISTAT, Banca d'Italia.</div>
      </div>
      <div class="dim">
        <div class="dim-n">Dimensione 5</div>
        <div class="dim-t">Ambiente e mobilità</div>
        <div class="dim-d">Qualità dell'aria, infrastrutture, mobilità sostenibile, rischio idrogeologico, energia rinnovabile. Fonte: ISPRA, TERNA.</div>
      </div>
    </div>

    <div class="sh" style="margin-top:24px"><div class="sl"></div><div class="se">Fonti dati</div></div>
    <div class="source-grid">
      <div class="source">ISTAT</div><div class="source">Ministero Salute</div><div class="source">Banca d'Italia</div><div class="source">MIUR</div>
      <div class="source">ISPRA</div><div class="source">AGENAS</div><div class="source">Openpolis</div><div class="source">OpenCoesione</div>
    </div>
  </div>
</div>

<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Media e citazioni</div></div>
    <div class="s-t">Il TR-Index sui <em>media nazionali</em></div>
    <div class="media-cite">
      <div class="cite-testata">Corriere del Mezzogiorno</div>
      <div class="cite-text">«Il TR-Index di Troisi Ricerche posiziona Bari nella fascia media nazionale per qualità dei servizi pubblici, con punteggi sopra la media nelle dimensioni Cultura e Istruzione.»</div>
    </div>
    <div class="media-cite">
      <div class="cite-testata">Strade & Autostrade</div>
      <div class="cite-text">«Secondo il TR-Index 2025, le province del Nord-Est si confermano in cima alla classifica della mobilità sostenibile, mentre il Mezzogiorno recupera terreno nel settore sanitario.»</div>
    </div>

    <div class="cta-box">
      <h3>📐 Consulta il TR-Index completo</h3>
      <p>Sul sito dedicato t-index.it trovi il ranking aggiornato per tutte le province italiane, la metodologia completa e i dataset scaricabili.</p>
      <a href="https://t-index.it" target="_blank" rel="noopener" class="cta-p">Vai su t-index.it ↗</a>
      <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Usa il TR-Index per il tuo territorio →</a>
    </div>
  </div>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
