<?php
/**
 * Template Name: Media
 */
get_header(); ?>
<?php $current_page = 'media'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:4px 12px;border-radius:2px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}

/* Numeri band */
.media-nums{background:var(--dp);display:grid;grid-template-columns:repeat(4,1fr)}
.mn{text-align:center;padding:20px 16px;border-right:1px solid rgba(255,255,255,.08)}
.mn:last-child{border-right:none}
.mn-v{font-size:26px;font-weight:700;color:var(--or);line-height:1}
.mn-l{font-size:10px;color:rgba(255,255,255,.42);text-transform:uppercase;letter-spacing:.04em;margin-top:4px;line-height:1.4}

/* Flagship */
.flagship{background:var(--dp);border-radius:var(--r);padding:28px;margin-bottom:24px}
.fg-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.35);margin-bottom:18px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.1)}
.fg-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.fg-card{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:var(--r);padding:16px;border-top:3px solid var(--or)}
.fg-testata{font-size:16px;font-weight:700;color:var(--or);margin-bottom:3px}
.fg-data{font-size:10.5px;color:rgba(255,255,255,.35);margin-bottom:8px}
.fg-titolo{font-size:12.5px;color:#fff;line-height:1.45;margin-bottom:8px;font-weight:600}
.fg-desc{font-size:11.5px;color:rgba(255,255,255,.52);line-height:1.6}

/* TV / Cards */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.mc{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:22px}
.mc-type{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:9px;display:inline-block;padding:3px 10px;border-radius:2px}
.t-radio{background:#e6f5f0;color:#006644}
.t-tv{background:#e6f0ff;color:#004d99}
.t-web{background:#f0e6ff;color:#5e30a0}
.mc-t{font-size:15px;font-weight:700;color:var(--dp);margin-bottom:8px;line-height:1.3}
.mc-d{font-size:13px;color:var(--g);line-height:1.75;margin-bottom:14px}

/* Video embed */
.video-embed{background:var(--dp);border-radius:var(--r);padding:13px 15px;display:flex;gap:12px;align-items:center;margin-bottom:9px;text-decoration:none}
.video-embed:hover{background:var(--bd)}
.vp{width:32px;height:32px;background:var(--blu);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.vp-i{width:0;height:0;border-top:5px solid transparent;border-bottom:5px solid transparent;border-left:9px solid #fff;margin-left:2px}
.vt{font-size:11.5px;color:rgba(255,255,255,.65);line-height:1.4}
.vt strong{display:block;font-size:12px;color:#fff;margin-bottom:1px}

/* Stampa locale */
.stampa-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.sc{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:14px;border-left:3px solid var(--blu)}
.sc-testata{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--blu);margin-bottom:3px}
.sc-data{font-size:10px;color:var(--g);margin-bottom:5px}
.sc-titolo{font-size:12.5px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:4px}
.sc-desc{font-size:11.5px;color:var(--g);line-height:1.55}

/* Camera Deputati */
.camera-box{background:var(--dp);border-radius:var(--r);padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px}
.cb-item{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:var(--r);padding:16px}
.cb-anno{font-size:10px;font-weight:700;color:var(--or);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px}
.cb-title{font-size:13px;font-weight:700;color:#fff;margin-bottom:6px;line-height:1.35}
.cb-desc{font-size:12px;color:rgba(255,255,255,.58);line-height:1.6;margin-bottom:10px}

/* Convegni */
.conv-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.conv-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;border-top:3px solid var(--vd)}
.conv-data{font-size:10px;font-weight:700;color:var(--vd);margin-bottom:4px;text-transform:uppercase;letter-spacing:.05em}
.conv-title{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35}
.conv-desc{font-size:12px;color:var(--g);line-height:1.6}

@media(max-width:768px){
  .fg-grid,.two-col,.stampa-grid,.camera-box,.conv-grid{grid-template-columns:1fr}
  .media-nums{grid-template-columns:1fr 1fr}
}
@media(max-width:600px){.sec{padding:28px 16px}}

/* Timeline cronologica */
.tl-year{display:grid;grid-template-columns:110px 1fr;gap:24px;padding:26px 0;border-top:1px solid var(--bo)}
.tl-year:first-child{border-top:none;padding-top:6px}
.tl-y{font-size:34px;font-weight:700;color:var(--dp);line-height:1;position:sticky;top:90px;align-self:start}
.tl-y small{display:block;font-size:10px;font-weight:700;color:var(--g);text-transform:uppercase;letter-spacing:.08em;margin-top:6px}
.tl-items{display:flex;flex-direction:column;gap:14px}
.ti{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px 20px;border-left:4px solid var(--blu)}
.ti.k-stampa{border-left-color:var(--or)}
.ti.k-tv{border-left-color:#9333ea}
.ti.k-radio{border-left-color:#0f9d6b}
.ti.k-ist{border-left-color:#cc0000}
.ti.k-conv{border-left-color:var(--vd)}
.ti-top{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-bottom:6px}
.ti-data{font-size:11px;font-weight:700;color:var(--dp)}
.ti-k{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:2px 8px;border-radius:2px;background:var(--bg);color:var(--g);border:1px solid var(--bo)}
.ti-testata{font-size:11px;font-weight:700;color:var(--blu);text-transform:uppercase;letter-spacing:.05em}
.ti-t{font-size:15px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:6px}
.ti-d{font-size:13px;color:var(--g);line-height:1.7}
.ti-img{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin-top:12px}
.ti-img figure{margin:0}
.ti-img img{width:100%;height:120px;object-fit:cover;border-radius:3px;display:block}
.ti-img figcaption{font-size:10px;color:var(--g);margin-top:4px;line-height:1.4}
.ti-links{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.tl-filtri{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}
.tl-filtri button{font-size:11.5px;font-weight:700;padding:6px 14px;border-radius:2px;border:1px solid var(--bo);background:#fff;color:var(--g);cursor:pointer}
.tl-filtri button.on,.tl-filtri button:hover{background:var(--blu);color:#fff;border-color:var(--blu)}
@media(max-width:768px){.tl-year{grid-template-columns:1fr;gap:10px}.tl-y{position:static;font-size:26px}}
</style>

<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Media</div>
  <h1>Radio, televisione, stampa e <em>convegni istituzionali</em></h1>
  <p>Da La Capitale al Senato della Repubblica, dalla Camera dei Deputati al Sole 24 Ore e alla RAI: tutte le uscite di Troisi Ricerche nei media e nei tavoli istituzionali, dalla più recente.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Media</div>

<div class="media-nums">
  <div class="mn"><div class="mn-v">3</div><div class="mn-l">Testate nazionali (Sole 24 Ore · Repubblica · Corriere)</div></div>
  <div class="mn"><div class="mn-v">3×</div><div class="mn-l">Parlamento: Senato (2026) · Camera dei Deputati (2019 · 2022)</div></div>
  <div class="mn"><div class="mn-v">RAI</div><div class="mn-l">Servizio speciale TG3 Puglia</div></div>
  <div class="mn"><div class="mn-v">2026</div><div class="mn-l">Roma che Dice con La Capitale</div></div>
</div>

<?php
$T = get_template_directory_uri();
$sen = troisi_senato_2026();
$rc = get_category_by_slug('roma-che-dice');
$uscite = [
  ['y'=>2026,'data'=>'Agosto – ottobre 2026','k'=>'stampa','tipo'=>'Stampa online','testata'=>'La Capitale','t'=>'«Roma, che dici?» — L\'Osservatorio sull\'opinione dei romani',
   'd'=>'La Capitale avvia con Troisi Ricerche un osservatorio permanente: sondaggi mensili su mille residenti del Comune di Roma. Il primo report è dedicato ai social network e ai minori, il secondo al rapporto dei romani con l\'intelligenza artificiale.',
   'links'=>[['https://www.lacapitale.it/articolo/sondaggio-romani-lintelligenza-artificiale-troisi-ricerche','I romani e l\'intelligenza artificiale (3 ottobre)'],['https://www.lacapitale.it/articolo/social-minori-sondaggio-roma-divieto-under-15','Social vietati agli under 15 (10 agosto)'],['https://www.lacapitale.it/articolo/divieto-social-minori-sondaggio-roma-che-dici','Parte il primo sondaggio (3 agosto)']],
   'rubrica'=>true],
  ['y'=>2026,'data'=>$sen['data'],'k'=>'ist','tipo'=>'Istituzioni · Senato TV','testata'=>'Senato della Repubblica','t'=>'Presentazione del libro «Le organizzazioni che si misurano»',
   'd'=>$sen['testo'],'luogo'=>$sen['luogo'],
   'img'=>array_map(function($f){return [troisi_remote_asset($f['src']),$f['cap']];}, $sen['foto']),
   'links'=>array_merge(array_map(function($l){return [$l['href'],$l['label']];}, $sen['link']),[['https://www.cacuccieditore.it/le-organizzazioni-che-si-misurano-il-benessere-organizzativo-dalla-compliance-alla-consapevolezza-troisi-9791259656506','Il libro su Cacucci Editore']])],
  ['y'=>2025,'data'=>'17 ottobre 2025','k'=>'stampa','tipo'=>'Stampa locale','testata'=>'Gazzetta del Mezzogiorno · Quotidiano di Bari','t'=>'CiBari 2025 — «Nel buon cibo il segreto della salute»',
   'd'=>'Andrea Troisi sulla Gazzetta: «Abbiamo coinvolto un campione di mille persone per capire quanto si conosca davvero la sindrome metabolica, in forte crescita ma ancora poco compresa».'],
  ['y'=>2023,'data'=>'21 settembre 2023','k'=>'conv','tipo'=>'Convegno · Video','testata'=>'AIQUAV Annual Conference · Bari','t'=>'Food Policy and Well-Being — con Pina Picierno (VP Parlamento Europeo)',
   'd'=>'Sessione della AIQUAV Annual Conference 2023 con la Vicepresidente del Parlamento Europeo Pina Picierno, l\'assessora Paola Romano (Comune di Bari) e la prof.ssa Filomena Corbo (UniBa). Modera Danilo Giannese (RAI). Sala Toscanini, Hotel Excelsior, Bari.',
   'img'=>[[$T.'/img/cibari/aiquav2023_locandina_pina_picierno_VP_parlamento_europeo_andrea_troisi.png','Locandina AIQUAV 2023']],
   'links'=>[['https://youtu.be/zB1iZVjzK5k','▶ Guarda il video']]],
  ['y'=>2023,'data'=>'25 luglio 2023','k'=>'radio','tipo'=>'Radio','testata'=>'Radio Canale100','t'=>'«Guarda che Estate» — Statistica e ricerche di mercato alla Summer House',
   'd'=>'Andrea Troisi ospite, con Brixhilda Lleshi di Troisi Ricerche, della Summer House di Radio Canale100 al Riva Beach di Giovinazzo, nella puntata condotta da Roberto de Marinis: statistica, big data, mappatura delle competenze e ricerche di mercato.',
   'links'=>[['https://www.andreatroisi.it/sul-palco/radio-canale100-2023/','Approfondisci']]],
  ['y'=>2023,'data'=>'17 maggio 2023','k'=>'tv','tipo'=>'Televisione','testata'=>'Rai 3 · TGR Puglia','t'=>'«La Puglia che va» — Centri di ricerca, per guidare le imprese nel business',
   'd'=>'Servizio del TG regionale girato nella sede di Bari di Troisi Ricerche: il giornalista Salvatore Catapano intervista Andrea Troisi sulla storia e sui progetti dell\'istituto.',
   'links'=>[['https://www.rainews.it/tgr/puglia/video/2023/05/centri-di-ricerca-imprese-business-troisi-bari-puglia-che-va-22e2cb36-95fd-46a4-a8d5-8d7c452d5be6.html','▶ Guarda il servizio su RaiNews']]],
  ['y'=>2022,'data'=>'19 ottobre 2022','k'=>'conv','tipo'=>'Convegno','testata'=>'Fiera del Levante · Bari','t'=>'Food Policy di Bari — stili di vita e comportamenti alimentari',
   'd'=>'Seminario con la Scuola Superiore Sant\'Anna di Pisa e la prof.ssa Filomena Corbo (UniBa). Progetto AGRICULTURA — PON Legalità.',
   'links'=>[['https://www.comune.bari.it/-/cosa-mangiano-i-baresi-il-comune-di-bari-nell-ambito-della-food-policy-indaga-i-consumi-e-i-comportamenti-alimentari-in-citta','Comune di Bari']]],
  ['y'=>2022,'data'=>'27 marzo 2022 · pag. 33','k'=>'stampa','tipo'=>'Stampa nazionale','testata'=>'Corriere della Sera','t'=>'«Attacchi informatici e formazione dei manager»',
   'd'=>'Articolo di Fabio Savelli, che due giorni prima aveva moderato l\'evento Fondirigenti alla Camera. Citata l\'indagine su 340 imprenditori e manager.'],
  ['y'=>2022,'data'=>'25 marzo 2022','k'=>'ist','tipo'=>'Istituzioni · WebTV','testata'=>'Camera dei Deputati','t'=>'Modello di competenze per la Governance Finanziaria — Fondirigenti',
   'd'=>'Evento Fondirigenti (Confindustria e Federmanager): Andrea Troisi presenta il modello di competenze. Modera Fabio Savelli (Corriere della Sera). Con Giovani Imprenditori Confindustria, AIDP, Federmanager e cinque università. In diretta su webtv.camera.it.',
   'img'=>[[$T.'/img/camera/fondirigenti_camera_25mar2022_relatori_al_banco.jpeg','Sala della Camera dei Deputati, 25 marzo 2022'],[$T.'/img/camera/fondirigenti_camera_25mar2022_foto_gruppo_6_persone.jpeg','I relatori dell\'evento']],
   'links'=>[['https://www.youtube.com/watch?v=-gykCKwqLxw','▶ YouTube'],['https://www.radioradicale.it/scheda/663951/competenze-per-la-governance-finanziaria','Radio Radicale'],['https://dirigentindustria.it/formazione/imprese-da-fondirigenti-un-modello-di-competenze-per-la-governance-finanziaria.html','Dirigenti Industria'],['https://www.fondirigenti.it/modello-di-competenze-per-la-governance-finanziaria','Fondirigenti.it']]],
  ['y'=>2021,'data'=>'15 novembre 2021','k'=>'stampa','tipo'=>'Stampa nazionale','testata'=>'la Repubblica','t'=>'«I dati: analizzarli e interpretarli per prendere le decisioni»',
   'd'=>'Speciale Aziende — Eccellenze Lazio. Descrizione dei servizi: customer satisfaction nella PA, Mappatura delle Competenze, TR-Index, internazionalizzazione.',
   'links'=>[['https://roma.repubblica.it/dossier-adv/eccellenze-lazio/2021/11/15/news/troisi_ricerche_i_dati_analizzarli_e_interpretarli_per_prendere_le_decisioni-326423272/','Leggi su Repubblica']]],
  ['y'=>2021,'data'=>'12 novembre 2021','k'=>'stampa','tipo'=>'Stampa nazionale','testata'=>'Il Sole 24 Ore','t'=>'«Ricerche di mercato con mission sviluppo»',
   'd'=>'Troisi Ricerche scelta tra i casi di eccellenza dell\'inserto «Sud». Andrea Troisi: «Offriamo un servizio strategico che combina il rigore della statistica con la versatilità delle scienze sociali».'],
  ['y'=>2021,'data'=>'12 gennaio 2021','k'=>'conv','tipo'=>'Convegno online','testata'=>'Interreg CENTRAL EUROPE','t'=>'Chain Reactions — La filiera biomedicale in Veneto',
   'd'=>'Andrea Troisi presenta l\'analisi sull\'incidenza economica del settore biomedicale veneto. Con CCIAA di Padova e Galileo Visionary District.'],
  ['y'=>2020,'data'=>'2020','k'=>'stampa','tipo'=>'Rivista di settore','testata'=>'«Muoversi bene»','t'=>'Ascoltare la città fa crescere il servizio — Trieste Trasporti',
   'd'=>'Il 98,1% dei triestini promuove il servizio di trasporto pubblico. Andrea Troisi: «Ci ha permesso di sviluppare un innovativo modello per la customer satisfaction nei servizi pubblici, presentato alla Camera dei Deputati».'],
  ['y'=>2020,'data'=>'14 gennaio 2020 · prima pagina','k'=>'stampa','tipo'=>'Stampa locale','testata'=>'La Gazzetta del Mezzogiorno','t'=>'Il commercio è a un bivio — «Pronti alla nuova sfida»',
   'd'=>'Indagine DUC Bari per Confcommercio, in prima pagina e alle pagine II–III, con i risultati dell\'indagine di Troisi Ricerche.'],
  ['y'=>2020,'data'=>'12 gennaio 2020 · pag. 7','k'=>'stampa','tipo'=>'Stampa locale','testata'=>'la Repubblica Bari','t'=>'Shopping, i clienti vogliono orario continuato ed eventi',
   'd'=>'Sondaggio Confcommercio Bari: voto 7 al Murattiano, il 63% raggiunge il centro in auto, il 51% chiede più parcheggi.'],
  ['y'=>2020,'data'=>'Gennaio 2020','k'=>'tv','tipo'=>'Televisione','testata'=>'TRM TV · Bari','t'=>'«I consumatori chiedono più servizi e meno caos»',
   'd'=>'Servizio sull\'indagine sul commercio barese per Confcommercio Bari-BAT, con intervista ad Andrea Troisi alla presentazione dei risultati.',
   'links'=>[['https://www.youtube.com/watch?v=c4TU22nFTJQ','▶ Video TRM']]],
  ['y'=>2019,'data'=>'29 marzo 2019','k'=>'ist','tipo'=>'Istituzioni · WebTV','testata'=>'Camera dei Deputati','t'=>'Presentazione del libro sulla Customer Satisfaction nella P.A.',
   'd'=>'Conferenza stampa: Andrea Troisi presenta il volume Cacucci Editore «Un modello statistico per l\'analisi della Customer Satisfaction nella Pubblica Amministrazione». Trasmessa su webtv.camera.it.',
   'img'=>[[$T.'/img/camera/andrea_al_banco_camera_deputati_2019.jpg','Camera dei Deputati, 29 marzo 2019'],[$T.'/img/camera/webtv_camera_screenshot_29mar2019_libro_cacucci.jpg','La diretta su webtv.camera.it']],
   'links'=>[['https://webtv.camera.it/evento/14114','Video su webtv.camera.it']]],
  ['y'=>2018,'data'=>'10–12 novembre 2018','k'=>'stampa','tipo'=>'Stampa locale','testata'=>'Il Gazzettino · Il Mattino di Padova','t'=>'Le imprese a lezione di innovazione / Casa, meccanica e ICT: un\'unica filiera',
   'd'=>'Mappatura dinamica delle imprese per la CCIAA di Padova: il Gazzettino dedica l\'intera pagina X, il Mattino di Padova cita Andrea Troisi tra i relatori.'],
  ['y'=>2018,'data'=>'29 settembre 2018','k'=>'stampa','tipo'=>'Stampa locale','testata'=>'La Gazzetta del Mezzogiorno · la Repubblica','t'=>'E la mensa scolastica diventa bio e sostenibile',
   'd'=>'Customer satisfaction delle mense scolastiche di Bari: conferenza stampa a Palazzo di Città. Repubblica: «A testare il servizio sarà l\'istituto di ricerche Troisi».'],
  ['y'=>2016,'data'=>'18 febbraio 2016','k'=>'conv','tipo'=>'Convegno','testata'=>'Camera di Commercio di Bari','t'=>'Doing Business negli Emirati Arabi Uniti',
   'd'=>'Andrea Troisi presenta la «Presentazione introduttiva Paese». Con S.E. Massimo Rustico (Farnesina), il Presidente della CCIAA di Bari, l\'Assessore della Regione Puglia, il Presidente della Fiera del Levante e il Presidente dell\'Ordine degli Avvocati di Bari.',
   'links'=>[[$T.'/img/pdf/eau_locandina_convegno_cciaa_bari_18feb2016.pdf','📄 Locandina PDF']]],
];
$anni = [];
foreach ($uscite as $u) $anni[$u['y']][] = $u;
krsort($anni);
?>
<!-- USCITE IN ORDINE CRONOLOGICO -->
<div class="sec alt" id="uscite">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Tutte le uscite, dalla più recente</div></div>
    <div class="tl-filtri">
      <button class="on" data-f="tutti">Tutte</button>
      <button data-f="stampa">Stampa</button>
      <button data-f="tv">TV</button>
      <button data-f="radio">Radio</button>
      <button data-f="ist">Istituzioni</button>
      <button data-f="conv">Convegni</button>
    </div>
    <div class="tl">
<?php foreach ($anni as $y => $lista): ?>
      <div class="tl-year">
        <div class="tl-y"><?php echo (int) $y; ?><small><?php echo count($lista) === 1 ? '1 uscita' : count($lista) . ' uscite'; ?></small></div>
        <div class="tl-items">
<?php foreach ($lista as $u): ?>
          <article class="ti k-<?php echo esc_attr($u['k']); ?>" data-k="<?php echo esc_attr($u['k']); ?>">
            <div class="ti-top"><span class="ti-data"><?php echo esc_html($u['data']); ?></span><span class="ti-k"><?php echo esc_html($u['tipo']); ?></span><span class="ti-testata"><?php echo esc_html($u['testata']); ?></span></div>
            <div class="ti-t"><?php echo esc_html($u['t']); ?></div>
            <?php if (!empty($u['luogo'])): ?><div class="ti-d" style="font-weight:600;margin-bottom:4px"><?php echo esc_html($u['luogo']); ?></div><?php endif; ?>
            <div class="ti-d"><?php echo esc_html($u['d']); ?></div>
            <?php if (!empty($u['img'])): ?>
            <div class="ti-img">
              <?php foreach ($u['img'] as $im): ?><figure><img src="<?php echo esc_url($im[0]); ?>" alt="<?php echo esc_attr($im[1]); ?>" loading="lazy"><figcaption><?php echo esc_html($im[1]); ?></figcaption></figure><?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php if (!empty($u['links']) || !empty($u['rubrica'])): ?>
            <div class="ti-links">
              <?php if (!empty($u['rubrica']) && $rc): ?><a href="<?php echo esc_url(get_category_link($rc)); ?>" class="le" style="color:var(--blu);border-color:#b3d1ff;background:var(--bl)">La rubrica Roma che Dice</a><?php endif; ?>
              <?php foreach ((array) ($u['links'] ?? []) as $l): ?><a href="<?php echo esc_url($l[0]); ?>" target="_blank" rel="noopener" class="le"><?php echo esc_html($l[1]); ?></a><?php endforeach; ?>
            </div>
            <?php endif; ?>
          </article>
<?php endforeach; ?>
        </div>
      </div>
<?php endforeach; ?>
    </div>
  </div>
</div>

<!-- APPUNTAMENTI FISSI -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Appuntamenti fissi e canali</div></div>
    <div class="two-col">
      <div class="mc">
        <span class="mc-type t-tv">Tele Lazio Nord · Roma</span>
        <div class="mc-t">«Drive In» — Ospite fisso</div>
        <div class="mc-d">Andrea Troisi è ospite fisso di «Drive In» su Tele Lazio Nord: dati, sondaggi e ricerche di attualità commentati in diretta.</div>
        <a href="https://www.youtube.com/watch?v=qa3CJBMLXIY&list=PLOoGJz564GrV21MMzOLhiUlpEdW3Xbu8T" target="_blank" rel="noopener" class="video-embed"><div class="vp"><div class="vp-i"></div></div><div class="vt"><strong>Drive In — Playlist completa</strong>Tutte le puntate su YouTube</div></a>
      </div>
      <div class="mc">
        <span class="mc-type t-radio">Radio · Controradio Bari</span>
        <div class="mc-t">«Il Dato è Tratto» — Fondatore e conduttore</div>
        <div class="mc-d">Statistica, sondaggi e ricerche raccontati al pubblico radiofonico: un appuntamento settimanale per rendere i dati accessibili e utili per tutti.</div>
      </div>
      <div class="mc">
        <span class="mc-type t-web">Podcast · VoiceInHub</span>
        <div class="mc-t">VoiceInHub — Il podcast di Troisi Ricerche</div>
        <div class="mc-d">Episodi su customer satisfaction, governance pubblica, benessere organizzativo e ricerca statistica applicata.</div>
        <a href="https://voiceinhub.it" target="_blank" rel="noopener" class="le">voiceinhub.it</a>
      </div>
      <div class="mc">
        <span class="mc-type t-web">YouTube · @Troisiricerche</span>
        <div class="mc-t">Canale YouTube ufficiale</div>
        <div class="mc-d">Convegni, interventi istituzionali, puntate di Drive In e approfondimenti sulla ricerca statistica applicata.</div>
        <a href="https://www.youtube.com/@Troisiricerche" target="_blank" rel="noopener" class="video-embed"><div class="vp"><div class="vp-i"></div></div><div class="vt"><strong>@Troisiricerche</strong>Tutti i video di Troisi Ricerche</div></a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.tl-filtri button').forEach(function(b){
  b.addEventListener('click',function(){
    document.querySelectorAll('.tl-filtri button').forEach(function(x){x.classList.remove('on')});
    b.classList.add('on');var f=b.dataset.f;
    document.querySelectorAll('.tl-year').forEach(function(y){
      var vis=0;y.querySelectorAll('.ti').forEach(function(t){var ok=f==='tutti'||t.dataset.k===f;t.style.display=ok?'':'none';if(ok)vis++;});
      y.style.display=vis?'':'none';
    });
  });
});
</script>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
