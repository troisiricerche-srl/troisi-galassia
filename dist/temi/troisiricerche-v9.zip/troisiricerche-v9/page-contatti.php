<?php get_header(); $current_page='contatti'; include(get_template_directory().'/troisi-nav.php'); ?>
<style>
.cont-grid{display:grid;grid-template-columns:1fr 1fr;gap:28px;align-items:start}
.cont-info{display:flex;flex-direction:column;gap:16px}
.ci{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;display:flex;gap:16px;align-items:flex-start;transition:box-shadow .2s var(--ease)}
.ci:hover{box-shadow:var(--shadow)}
.ci-icon{width:40px;height:40px;background:var(--bl);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.ci-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--g);margin-bottom:4px}
.ci-val{font-size:14px;font-weight:700;color:var(--dp)}.ci-val a{color:var(--dp)}.ci-val a:hover{color:var(--blu)}
.ci-sub{font-size:11.5px;color:var(--g);margin-top:2px;line-height:1.5}
.sedi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:20px}
.sede{background:var(--dp);border-radius:var(--r-lg);padding:20px}
.sede-city{font-size:16px;font-weight:700;color:#fff;margin-bottom:3px}
.sede-role{font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.4);margin-bottom:10px}
.sede-info{font-size:12px;color:rgba(255,255,255,.6);line-height:1.7}
.calendly-wrap{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);overflow:hidden}
.cal-header{background:var(--dp);padding:16px 20px}
.cal-header h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:3px}
.cal-header p{font-size:12px;color:rgba(255,255,255,.6);margin:0}
.cta-box{background:var(--dp);border-radius:var(--r-lg);padding:32px;text-align:center;margin-top:28px}
.cta-box h3{font-size:20px;font-weight:700;color:#fff;margin-bottom:8px}
.cta-box p{font-size:13px;color:rgba(255,255,255,.6);max-width:480px;margin:0 auto 20px;line-height:1.75}
.cta-btn{display:inline-block;background:var(--or);color:#fff;padding:13px 32px;border-radius:var(--r);font-size:14px;font-weight:700;transition:background .15s}
.cta-btn:hover{background:#cc8800;color:#fff}
@media(max-width:900px){.cont-grid{grid-template-columns:1fr}.sedi-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.sedi-grid{grid-template-columns:1fr}}
</style>

<div class="ph"><div class="wrap">
  <div class="ph-ey">Troisi Ricerche &middot; Contatti</div>
  <h1>Parliamo del tuo <em>prossimo progetto</em></h1>
  <p>Hai una ricerca da realizzare, un dato da misurare o uno strumento da adottare? Contattaci per una consulenza senza impegno. Siamo a Bari, Roma e Milano.</p>
</div></div>
<div class="bc"><div class="wrap"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Contatti</div></div>

<div class="sec alt"><div class="wrap"><div class="cont-grid">
  <div class="cont-info">
    <div class="sh"><div class="sl"></div><div class="se">Come contattarci</div></div>
    <div class="ci"><div class="ci-icon">📧</div><div><div class="ci-label">Email</div><div class="ci-val"><a href="mailto:<?php echo esc_attr(troisi_opt("email","info@troisiricerche.it")); ?>"><?php echo esc_html(troisi_opt("email","info@troisiricerche.it")); ?></a></div><div class="ci-sub">Risposta entro 24 ore lavorative</div></div></div>
    <div class="ci"><div class="ci-icon">📞</div><div><div class="ci-label">Telefono</div><div class="ci-val"><a href="tel:+390803210601">+39 080.321.06.01</a></div><div class="ci-sub">Lun–Ven 9:00–18:00</div></div></div>
    <div class="ci"><div class="ci-icon">🆓</div><div><div class="ci-label">Numero verde gratuito</div><div class="ci-val"><a href="tel:800644046">800 644 046</a></div><div class="ci-sub">Gratuito da fisso e mobile</div></div></div>
    <div class="ci"><div class="ci-icon">💼</div><div><div class="ci-label">LinkedIn</div><div class="ci-val"><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener">Troisi Ricerche</a></div><div class="ci-sub">Seguici per aggiornamenti e news</div></div></div>
    <div class="ci"><div class="ci-icon">📺</div><div><div class="ci-label">YouTube</div><div class="ci-val"><a href="https://www.youtube.com/@Troisiricerche" target="_blank" rel="noopener">@Troisiricerche</a></div><div class="ci-sub">Interventi, convegni e Drive In</div></div></div>
    <div style="background:var(--bg);border:1px solid var(--bo);border-radius:var(--r-lg);padding:16px;font-size:11.5px;color:var(--g);line-height:1.7">
      <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--dp);margin-bottom:6px">Dati societari</div>
      Troisi Ricerche S.r.l. Unipersonale<br>P.IVA 07216100722 &middot; REA BA-541094<br>Sede legale: Via De Rossi, 57 — 70122 Bari (BA)
    </div>
  </div>
  <div>
    <div class="sh"><div class="sl"></div><div class="se">Prenota una call gratuita</div></div>
    <div class="calendly-wrap">
      <div class="cal-header"><h3>📅 Fissa un appuntamento con Andrea Troisi</h3><p>30 minuti · Gratuito · Video call o telefono</p></div>
      <div class="calendly-inline-widget" data-url="<?php echo esc_url(troisi_opt("calendly_url","https://calendly.com/andreatroisi/30min")); ?>?hide_gdpr_banner=1&primary_color=0066cc" style="min-width:280px;height:630px"></div>
      <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
    </div>
  </div>
</div></div></div>

<div class="sec"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Le nostre sedi</div></div>
  <div class="sedi-grid">
    <div class="sede"><div class="sede-city">🏛️ Bari</div><div class="sede-role">Sede principale · Direzione scientifica</div><div class="sede-info">Via De Rossi, 57<br>70122 Bari (BA)<br>+39 080.321.06.01</div></div>
    <div class="sede"><div class="sede-city">🏟️ Roma</div><div class="sede-role">Sede operativa · PA nazionale</div><div class="sede-info">Via Dodecaneso, 3<br>00144 Roma (RM)<br>Ministeri · Forum PA · ANAC</div></div>
    <div class="sede"><div class="sede-city">🏙️ Milano</div><div class="sede-role">Sede operativa · Imprese</div><div class="sede-info">Via Montenapoleone, 8<br>20121 Milano (MI)<br>Confindustria · Fondi interprofessionali</div></div>
  </div>
  <div class="cta-box">
    <h3>Preferisci scrivere una mail?</h3>
    <p>Descrivi il tuo progetto in poche righe. Ti rispondo entro 24 ore con una proposta metodologica iniziale e un preventivo indicativo — senza impegno.</p>
    <a href="mailto:info@troisiricerche.it?subject=Richiesta%20di%20collaborazione%20—%20Troisi%20Ricerche" class="cta-btn">✉️ Scrivi a info@troisiricerche.it</a>
  </div>
</div></div>
<?php include(get_template_directory().'/troisi-footer.php'); ?>
