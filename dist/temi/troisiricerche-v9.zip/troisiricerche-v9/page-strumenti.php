<?php
/**
 * Template Name: Strumenti
 */
get_header(); ?>
<?php $current_page = 'strumenti'; include(get_template_directory() . '/troisi-nav.php'); ?>

<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

<style>
/* ── VARIABILI ── */
:root{
  --navy:#17324D;--navy-dark:#0d1f30;--navy-mid:#1e3f5c;
  --red:#8B1A1A;--orange:#E8630A;--orange-light:#f5861a;
  --grey:#f4f6f9;--grey-mid:#e2e8f0;--grey-dark:#64748b;
  --text:#1a2332;--white:#ffffff;
  --shadow:0 4px 24px rgba(23,50,77,.10);--shadow-lg:0 12px 48px rgba(23,50,77,.16);
  --r:12px;--r-lg:20px;
  /* compat vecchio tema */
  --blu:#0066cc;--dp:#00264d;--bl:#e6f0ff;--bg:#f5f6fa;--bo:#d9e0ed;--g:#5a6a85;--t:#1a1a2e;--or:#e8a020;--r4:4px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Sora',sans-serif;background:var(--white);color:var(--text);overflow-x:hidden}

/* ── HERO ── */
.sc-hero{background:linear-gradient(135deg,var(--navy-dark) 0%,var(--navy) 60%,#1a4a6e 100%);padding:56px 32px 44px;position:relative;overflow:hidden}
.sc-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 80% 50%,rgba(232,99,10,.12),transparent 60%);pointer-events:none}
.sc-hero::after{content:'';position:absolute;bottom:-2px;left:0;right:0;height:40px;background:linear-gradient(to bottom,transparent,var(--white));pointer-events:none}
.sc-hero-inner{max-width:920px;margin:0 auto;position:relative;z-index:1}
.sc-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.85);font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;padding:5px 14px;border-radius:100px;margin-bottom:14px}
.sc-hero h1{font-family:'DM Serif Display',serif;font-size:clamp(26px,4vw,42px);color:#fff;line-height:1.15;margin-bottom:10px;font-weight:400}
.sc-hero h1 em{color:var(--orange);font-style:italic}
.sc-hero p{font-size:15px;color:rgba(255,255,255,.65);max-width:560px;line-height:1.7;font-weight:300}
.sc-bc{background:#fff;border-bottom:1px solid var(--grey-mid);padding:10px 32px;font-size:11.5px;color:var(--grey-dark)}
.sc-bc a{color:var(--grey-dark);text-decoration:none}

/* ── CALCOLATORE PRO ── */
.sc-calc-wrap{max-width:1060px;margin:0 auto;padding:40px 32px 8px}
.sc-calc-card{background:#fff;border-radius:var(--r-lg);box-shadow:var(--shadow-lg);border:1px solid var(--grey-mid);overflow:hidden}
.sc-calc-hdr{background:linear-gradient(135deg,var(--navy),var(--navy-mid));padding:18px 28px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px}
.sc-calc-title{font-size:15px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px}
.sc-calc-badge{font-size:10px;background:rgba(255,255,255,.15);color:rgba(255,255,255,.9);padding:2px 10px;border-radius:100px;border:1px solid rgba(255,255,255,.2)}
.sc-tabs{display:flex;gap:2px;padding:14px 28px 0;background:var(--grey)}
.sc-tab{padding:9px 18px;border:none;background:transparent;font-family:'Sora',sans-serif;font-size:12px;font-weight:600;color:var(--grey-dark);cursor:pointer;border-radius:8px 8px 0 0;transition:all .2s;border-bottom:3px solid transparent;white-space:nowrap}
.sc-tab.active{background:#fff;color:var(--navy);border-bottom-color:var(--orange)}
.sc-tab-content{display:none}.sc-tab-content.active{display:block}
.sc-body{padding:24px 28px;background:#fff}
.sc-grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}
.sc-field{margin-bottom:16px}
.sc-field label{display:block;font-size:11px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}
.sc-field label span{font-weight:400;color:var(--grey-dark);text-transform:none;letter-spacing:0;font-size:11px;display:block;margin-top:1px}
.sc-field input,.sc-field select{width:100%;padding:10px 13px;border:1.5px solid var(--grey-mid);border-radius:var(--r);font-family:'Sora',sans-serif;font-size:14px;color:var(--text);background:var(--grey);transition:border-color .2s,box-shadow .2s;-moz-appearance:none;-webkit-appearance:none}
.sc-field input:focus,.sc-field select:focus{outline:none;border-color:var(--orange);box-shadow:0 0 0 3px rgba(232,99,10,.1);background:#fff}
.sc-go-btn{width:100%;padding:12px;background:var(--orange);color:#fff;border:none;border-radius:var(--r);font-family:'Sora',sans-serif;font-size:14px;font-weight:700;cursor:pointer;transition:all .2s;box-shadow:0 4px 16px rgba(232,99,10,.35);margin-top:4px}
.sc-go-btn:hover{background:var(--orange-light);transform:translateY(-1px)}
/* Strat */
.sc-strat-row{display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:6px;align-items:end;margin-bottom:6px}
.sc-strat-row input{padding:9px 10px;font-size:12.5px}
.sc-mode{display:flex;gap:6px;margin-bottom:12px}
.sc-mode-btn{padding:5px 13px;border:1.5px solid var(--grey-mid);border-radius:100px;font-family:'Sora',sans-serif;font-size:12px;font-weight:600;color:var(--grey-dark);background:#fff;cursor:pointer;transition:all .15s}
.sc-mode-btn.active{border-color:var(--orange);color:var(--orange);background:rgba(232,99,10,.06)}
.sc-btn-add{padding:8px 13px;background:var(--navy);color:#fff;border:none;border-radius:var(--r);cursor:pointer;font-size:12px;font-weight:600;font-family:'Sora',sans-serif;width:100%;margin-top:5px}
.sc-btn-del{padding:8px 10px;background:#fee2e2;color:var(--red);border:none;border-radius:8px;cursor:pointer;font-size:13px;transition:all .2s}
.sc-btn-del:hover{background:var(--red);color:#fff}
/* Risultati */
.sc-result{background:linear-gradient(135deg,var(--navy-dark),var(--navy));border-radius:var(--r-lg);padding:22px;display:flex;flex-direction:column;gap:14px;min-height:340px}
.sc-result-main{text-align:center}
.sc-result-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.5);margin-bottom:3px}
.sc-result-n{font-size:64px;font-weight:800;color:var(--orange);line-height:1;font-family:'DM Serif Display',serif}
.sc-result-unit{font-size:12px;color:rgba(255,255,255,.6);margin-top:2px}
.sc-meta{display:grid;grid-template-columns:1fr 1fr;gap:7px}
.sc-meta-box{background:rgba(255,255,255,.08);border-radius:9px;padding:10px;text-align:center;border:1px solid rgba(255,255,255,.1)}
.sc-meta-val{font-size:17px;font-weight:700;color:#fff}
.sc-meta-key{font-size:10px;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:.05em;margin-top:1px}
.sc-table{width:100%;border-collapse:collapse;font-size:12px}
.sc-table th{background:rgba(255,255,255,.1);color:rgba(255,255,255,.7);padding:6px 9px;text-align:center;font-size:10px;text-transform:uppercase;letter-spacing:.04em}
.sc-table td{padding:6px 9px;text-align:center;color:rgba(255,255,255,.85);border-bottom:1px solid rgba(255,255,255,.06)}
.sc-table tr.hi td{color:var(--orange);font-weight:700;background:rgba(232,99,10,.1)}
.sc-chart-wrap{}
.sc-chart-label{font-size:10px;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.06em;margin-bottom:7px}
.sc-bar-row{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.sc-bar-lbl{font-size:11px;color:rgba(255,255,255,.6);width:28px;text-align:right;flex-shrink:0}
.sc-bar-track{flex:1;height:19px;background:rgba(255,255,255,.08);border-radius:3px;overflow:hidden}
.sc-bar-fill{height:100%;border-radius:3px;transition:width .8s cubic-bezier(.4,0,.2,1);display:flex;align-items:center;padding-left:8px}
.sc-bar-val{font-size:11px;font-weight:700;color:#fff;white-space:nowrap}
.sc-interp{background:rgba(255,255,255,.06);border-radius:9px;padding:11px 13px;border-left:3px solid var(--orange)}
.sc-interp-txt{font-size:12px;color:rgba(255,255,255,.75);line-height:1.7}
.sc-pdf-btn{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;padding:9px;background:rgba(255,255,255,.1);border:1.5px solid rgba(255,255,255,.25);color:#fff;border-radius:var(--r);cursor:pointer;font-family:'Sora',sans-serif;font-size:12px;font-weight:600;transition:all .2s}
.sc-pdf-btn:hover{background:rgba(255,255,255,.18)}
.sc-placeholder{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:10px;padding:30px 16px}
.sc-placeholder-icon{font-size:40px;opacity:.3}
.sc-placeholder-txt{font-size:13px;color:rgba(255,255,255,.4);line-height:1.6}

/* ── ACCORDION ── */
.sc-edu{max-width:1060px;margin:0 auto;padding:28px 32px 8px}
.sc-edu-title{font-family:'DM Serif Display',serif;font-size:22px;font-weight:400;color:var(--navy);margin-bottom:14px}
.sc-acc{border:1.5px solid var(--grey-mid);border-radius:var(--r);margin-bottom:7px;overflow:hidden}
.sc-acc-hdr{display:flex;align-items:center;justify-content:space-between;padding:13px 17px;cursor:pointer;background:#fff;font-size:13.5px;font-weight:600;color:var(--navy);transition:background .15s;gap:10px}
.sc-acc-hdr:hover{background:var(--grey)}
.sc-acc-icon{font-size:11px;color:var(--orange);transition:transform .25s;flex-shrink:0}
.sc-acc.open .sc-acc-icon{transform:rotate(180deg)}
.sc-acc-body{display:none;padding:0 17px 15px;font-size:13px;color:#4a5568;line-height:1.8}
.sc-acc-body strong{color:var(--navy)}
.sc-acc.open .sc-acc-body{display:block}

/* ── ALTRI STRUMENTI ── */
.tools-section{max-width:1060px;margin:0 auto;padding:32px 32px 48px}
.tools-section-title{font-family:'DM Serif Display',serif;font-size:22px;font-weight:400;color:var(--navy);margin-bottom:6px}
.tools-section-sub{font-size:13px;color:var(--grey-dark);margin-bottom:22px}
.tools-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.tool{background:#fff;border:1.5px solid var(--grey-mid);border-radius:var(--r);padding:20px;display:flex;gap:15px;align-items:flex-start;transition:box-shadow .2s}
.tool:hover{box-shadow:var(--shadow)}
.tool-icon{width:44px;height:44px;background:var(--grey);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.tool-name{font-size:13.5px;font-weight:700;color:var(--navy);margin-bottom:4px}
.tool-desc{font-size:12px;color:var(--grey-dark);line-height:1.65;margin-bottom:10px}
.tool-btns{display:flex;gap:7px;flex-wrap:wrap}
.li{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--orange);font-weight:700;border:1px solid rgba(232,99,10,.3);padding:4px 12px;border-radius:4px;background:rgba(232,99,10,.05);text-decoration:none}
.li::after{content:'→'}
.li:hover{background:rgba(232,99,10,.12)}
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--grey-dark);font-weight:600;border:1px solid var(--grey-mid);padding:4px 12px;border-radius:4px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}
.le:hover{border-color:var(--grey-dark)}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  .sc-hero{padding:44px 18px 36px}
  .sc-calc-wrap,.sc-edu,.tools-section{padding-left:18px;padding-right:18px}
  .sc-body{padding:18px}
  .sc-grid{grid-template-columns:1fr}
  .tools-grid{grid-template-columns:1fr}
  .sc-tabs{padding:12px 16px 0;overflow-x:auto}
  .sc-strat-row{grid-template-columns:1fr 1fr}
  .sc-strat-row input:first-child{grid-column:1/-1}
}
@media(max-width:600px){.sec{padding:28px 16px}}
</style>

<!-- HERO -->
<section class="sc-hero">
  <div class="sc-hero-inner">
    <div class="sc-badge">Troisi Ricerche · Strumenti</div>
    <h1>Strumenti <em>online</em> di Troisi Ricerche</h1>
    <p>Tool gratuiti e piattaforme professionali per la ricerca statistica, i sondaggi e la governance partecipativa.</p>
  </div>
</section>
<div class="sc-bc"><a href="<?php echo home_url('/'); ?>">Home</a> › Strumenti</div>

<!-- SEO SECTION -->
<section style="max-width:1060px;margin:0 auto;padding:40px 32px 0">
  <h2 style="font-family:'DM Serif Display',serif;font-size:clamp(22px,3vw,30px);color:var(--navy);margin-bottom:6px;font-weight:400">Calcolo Campione Statistico: numerosità campionaria per aziende e Pubblica Amministrazione</h2>
  <p style="font-size:15px;color:var(--grey-dark);margin-bottom:20px">Calcola rapidamente la dimensione del campione per survey, ricerche di mercato e analisi dati con il metodo Troisi Ricerche</p>
  <p style="font-size:14px;color:#4a5568;line-height:1.8;margin-bottom:20px">
    Il <strong>calcolo della numerosità campionaria</strong> è uno degli elementi più importanti nella progettazione di una ricerca statistica.
    Il <strong>calcolatore sviluppato da Troisi Ricerche</strong> consente di determinare in modo semplice, veloce e scientificamente corretto
    il numero di interviste necessarie per ottenere risultati affidabili. Questo <strong>sample size calculator</strong> è utilizzato in
    <strong>ricerche di mercato</strong>, <strong>customer satisfaction</strong> aziendale, indagini nella <strong>Pubblica Amministrazione</strong>,
    studi territoriali e survey accademiche.
  </p>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
    <div style="background:var(--grey);border-radius:var(--r);padding:16px 18px;border-left:3px solid var(--orange)">
      <h3 style="font-size:11px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px">Un campione corretto garantisce</h3>
      <ul style="list-style:none;font-size:13px;color:var(--grey-dark)">
        <li style="padding:2px 0 2px 14px;position:relative">→ Rappresentatività statistica dei dati</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Affidabilità scientifica dei risultati</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Riduzione del <strong>margine di errore</strong></li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Ottimizzazione dei costi di ricerca</li>
      </ul>
    </div>
    <div style="background:var(--grey);border-radius:var(--r);padding:16px 18px;border-left:3px solid var(--orange)">
      <h3 style="font-size:11px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px">Metodi supportati</h3>
      <ul style="list-style:none;font-size:13px;color:var(--grey-dark)">
        <li style="padding:2px 0 2px 14px;position:relative">→ Formula di Cochran (standard internazionale)</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Correzione per <strong>sample size finite population</strong></li>
        <li style="padding:2px 0 2px 14px;position:relative">→ <strong>Campionamento stratificato</strong> proporzionale</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Allocazione ottimale di Neyman</li>
      </ul>
    </div>
    <div style="background:var(--grey);border-radius:var(--r);padding:16px 18px;border-left:3px solid var(--orange)">
      <h3 style="font-size:11px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px">Utilizzato da</h3>
      <ul style="list-style:none;font-size:13px;color:var(--grey-dark)">
        <li style="padding:2px 0 2px 14px;position:relative">→ Aziende (dipendenti, clienti, utenti)</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Enti pubblici e Pubblica Amministrazione</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Università e centri di ricerca</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Consulenti e analisti di dati</li>
      </ul>
    </div>
    <div style="background:var(--grey);border-radius:var(--r);padding:16px 18px;border-left:3px solid var(--orange)">
      <h3 style="font-size:11px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px">Il tool fornisce</h3>
      <ul style="list-style:none;font-size:13px;color:var(--grey-dark)">
        <li style="padding:2px 0 2px 14px;position:relative">→ Dimensione ottimale del campione</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Margine di errore effettivo</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ <strong>Livello di confidenza</strong> configurabile</li>
        <li style="padding:2px 0 2px 14px;position:relative">→ Confronto tra scenari e PDF report</li>
      </ul>
    </div>
  </div>
  <p style="font-size:13.5px;color:#4a5568;line-height:1.8;margin-bottom:8px">
    Troisi Ricerche è specializzata in <strong>ricerche di mercato in Italia</strong> (<em>market research methodology Italy</em>),
    <strong>survey metodologia</strong>, analisi dei dati e progettazione di indagini statistiche. Il calcolatore si basa sulla
    <strong>formula di Cochran</strong> con correzione per popolazioni finite — il riferimento metodologico standard per determinare il
    <em>statistical sample size calculator Italy</em>, rispondere a <em>how many interviews needed survey</em> e gestire il
    <em>stratified sampling tool</em> in qualsiasi tipo di ricerca.
  </p>
</section>

<!-- CALCOLATORE PRO -->
<div class="sc-calc-wrap" id="calcolatore">
  <div class="sc-calc-card">
    <div class="sc-calc-hdr">
      <div class="sc-calc-title"><span>🧮</span> CALCOLA IL CAMPIONE STATISTICO</div>
      <div class="sc-calc-badge">v2.0 · Metodo Cochran</div>
    </div>
    <div class="sc-tabs">
      <button class="sc-tab active" onclick="scTab('prop',this)">📊 Per proporzione</button>
      <button class="sc-tab" onclick="scTab('media',this)">📈 Per media</button>
      <button class="sc-tab" onclick="scTab('strat',this)">🏙️ Stratificato</button>
    </div>
    <div class="sc-body">

      <!-- TAB 1 PROPORZIONE -->
      <div id="sc-prop" class="sc-tab-content active">
        <div class="sc-grid">
          <div>
            <div class="sc-field"><label>Universo / Popolazione (N) <span>Numero totale di dipendenti, clienti, cittadini o unità</span></label><input type="number" id="p-N" value="10000" min="1"></div>
            <div class="sc-field"><label>Margine di errore (%) <span>Quanto puoi tollerare che i risultati si discostino dal valore reale</span></label><input type="number" id="p-e" value="5" min="0.1" max="30" step="0.5"></div>
            <div class="sc-field"><label>Livello di confidenza <span>Probabilità che il vero valore cada nell'intervallo stimato</span></label><select id="p-z"><option value="1.645">90% — Stima orientativa</option><option value="1.96" selected>95% — Standard (raccomandato)</option><option value="2.576">99% — Alta precisione</option></select></div>
            <div class="sc-field"><label>Proporzione attesa (p%) <span>Se incerto, usa 50% — massimizza il campione necessario</span></label><input type="number" id="p-p" value="50" min="1" max="99"></div>
            <button class="sc-go-btn" onclick="scCalcProp()">Calcola campione →</button>
          </div>
          <div id="sc-res-prop"><div class="sc-result"><div class="sc-placeholder"><div class="sc-placeholder-icon">📐</div><div class="sc-placeholder-txt">Inserisci i parametri<br>e clicca <strong style="color:rgba(255,255,255,.65)">Calcola campione</strong></div></div></div></div>
        </div>
      </div>

      <!-- TAB 2 MEDIA -->
      <div id="sc-media" class="sc-tab-content">
        <div class="sc-grid">
          <div>
            <div class="sc-field"><label>Universo / Popolazione (N)</label><input type="number" id="m-N" value="10000" min="1"></div>
            <div class="sc-field"><label>Deviazione standard (σ) <span>Variabilità del fenomeno misurato</span></label><input type="number" id="m-sigma" value="15" min="0.1" step="0.5"></div>
            <div class="sc-field"><label>Margine di errore (ε) — unità assolute <span>Es. ±2 punti su scala 0-100</span></label><input type="number" id="m-e" value="3" min="0.1" step="0.5"></div>
            <div class="sc-field"><label>Livello di confidenza</label><select id="m-z"><option value="1.645">90%</option><option value="1.96" selected>95% — Standard</option><option value="2.576">99%</option></select></div>
            <button class="sc-go-btn" onclick="scCalcMedia()">Calcola campione →</button>
          </div>
          <div id="sc-res-media"><div class="sc-result"><div class="sc-placeholder"><div class="sc-placeholder-icon">📏</div><div class="sc-placeholder-txt">Inserisci i parametri<br>e clicca <strong style="color:rgba(255,255,255,.65)">Calcola campione</strong></div></div></div></div>
        </div>
      </div>

      <!-- TAB 3 STRATIFICATO -->
      <div id="sc-strat" class="sc-tab-content">
        <div class="sc-grid">
          <div>
            <div class="sc-field"><label>Metodo di allocazione</label><div class="sc-mode"><button class="sc-mode-btn active" id="sm-prop" onclick="scStratMode('prop')">Proporzionale</button><button class="sc-mode-btn" id="sm-ney" onclick="scStratMode('neyman')">Ottimale (Neyman)</button></div></div>
            <div class="sc-field"><label>Margine di errore globale (%)</label><input type="number" id="s-e" value="5" min="0.5" max="30" step="0.5"></div>
            <div class="sc-field"><label>Livello di confidenza</label><select id="s-z"><option value="1.645">90%</option><option value="1.96" selected>95%</option><option value="2.576">99%</option></select></div>
            <div class="sc-field"><label>Strati <span>Aggiungi ogni gruppo/segmento della popolazione</span></label>
              <div id="sc-strat-rows">
                <div class="sc-strat-row"><input type="text" placeholder="Nome strato" value="Nord"><input type="number" placeholder="N strato" value="3000"><input type="number" placeholder="σ" value="15"><button class="sc-btn-del" onclick="scDelStrat(this)">✕</button></div>
                <div class="sc-strat-row"><input type="text" placeholder="Nome strato" value="Centro"><input type="number" placeholder="N strato" value="2000"><input type="number" placeholder="σ" value="12"><button class="sc-btn-del" onclick="scDelStrat(this)">✕</button></div>
                <div class="sc-strat-row"><input type="text" placeholder="Nome strato" value="Sud"><input type="number" placeholder="N strato" value="5000"><input type="number" placeholder="σ" value="18"><button class="sc-btn-del" onclick="scDelStrat(this)">✕</button></div>
              </div>
              <button class="sc-btn-add" onclick="scAddStrat()">+ Aggiungi strato</button>
            </div>
            <button class="sc-go-btn" onclick="scCalcStrat()">Calcola campione stratificato →</button>
          </div>
          <div id="sc-res-strat"><div class="sc-result"><div class="sc-placeholder"><div class="sc-placeholder-icon">🏙️</div><div class="sc-placeholder-txt">Definisci gli strati<br>e clicca <strong style="color:rgba(255,255,255,.65)">Calcola</strong></div></div></div></div>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- ACCORDION METODOLOGICO -->
<section class="sc-edu">
  <h2 class="sc-edu-title">📚 Guida metodologica</h2>
  <div class="sc-acc" onclick="scToggleAcc(this)"><div class="sc-acc-hdr">Cos'è il margine di errore statistico? <span class="sc-acc-icon">▼</span></div><div class="sc-acc-body">Il <strong>margine di errore</strong> rappresenta la massima differenza accettabile tra il valore stimato nel campione e il valore reale nella popolazione. Nelle ricerche di mercato professionali il <strong>5% è lo standard accettato</strong>. Per sondaggi di alta precisione si usa il 3%.</div></div>
  <div class="sc-acc" onclick="scToggleAcc(this)"><div class="sc-acc-hdr">Come funziona la formula di Cochran? <span class="sc-acc-icon">▼</span></div><div class="sc-acc-body">La <strong>formula di Cochran (1977)</strong> è il metodo standard: <strong>n₀ = (z² × p × q) / e²</strong>. Per popolazioni finite si applica la correzione: <strong>n = n₀ / (1 + n₀/N)</strong>. Il 50% come proporzione p massimizza la dimensione del campione ed è usato quando non si hanno informazioni preliminari.</div></div>
  <div class="sc-acc" onclick="scToggleAcc(this)"><div class="sc-acc-hdr">Qual è la differenza tra campione teorico e campione effettivo? <span class="sc-acc-icon">▼</span></div><div class="sc-acc-body">Il campione calcolato è il <strong>campione teorico minimo</strong>. Nella pratica occorre considerare il <strong>tasso di risposta</strong>: se il 70% risponde, dividi il teorico per 0.70 (es. 383 / 0.70 = 547 contatti). Troisi Ricerche raccomanda di aggiungere un <strong>margine del 15-25%</strong>.</div></div>
</section>

<!-- ALTRI STRUMENTI -->
<div class="tools-section">
  <div class="tools-section-title">Le <em style="color:var(--orange);font-style:italic">piattaforme</em> di Troisi Ricerche</div>
  <p class="tools-section-sub">Piattaforme professionali per ricerca, sondaggi e governance partecipativa</p>
  <div class="tools-grid">
    <div class="tool">
      <div class="tool-icon">⚡</div>
      <div>
        <div class="tool-name">TIP Platform · Sondaggi e partecipazione</div>
        <div class="tool-desc">Piattaforma professionale per sondaggi, indagini di customer satisfaction e processi partecipativi. Multi-progetto, conforme GDPR, reportistica automatica.</div>
        <div class="tool-btns"><a href="https://tiplive.it" target="_blank" rel="noopener" class="le">Accedi a TIP Platform</a></div>
      </div>
    </div>
    <div class="tool">
      <div class="tool-icon">🗣️</div>
      <div>
        <div class="tool-name">Troisi Ricerche · Dibattito Pubblico</div>
        <div class="tool-desc">Piattaforma per il dibattito pubblico nelle grandi opere infrastrutturali. Conforme all'art. 40 del D.Lgs. 36/2023 (Allegato I.6). Sviluppata con TenderCoop e Ti Quadro.</div>
        <div class="tool-btns"><a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" class="le">Vai al sito dedicato</a></div>
      </div>
    </div>
    <div class="tool">
      <div class="tool-icon">📐</div>
      <div>
        <div class="tool-name">TR-Index · Ranking territoriale</div>
        <div class="tool-desc">Indice proprietario per misurare qualità e performance dei territori italiani. Aggiornato annualmente con dati ISTAT e fonti istituzionali.</div>
        <div class="tool-btns"><a href="https://t-index.it" target="_blank" rel="noopener" class="le">t-index.it</a></div>
      </div>
    </div>
    <div class="tool">
      <div class="tool-icon">😊</div>
      <div>
        <div class="tool-name">CustomerPA · Customer Satisfaction PA</div>
        <div class="tool-desc">Strumenti e metodologie per la misurazione della customer satisfaction nei servizi pubblici. Conforme alle linee guida AGID e ai decreti sulla trasparenza.</div>
        <div class="tool-btns"><a href="https://customerpa.it" target="_blank" rel="noopener" class="le">customerpa.it</a></div>
      </div>
    </div>
    <div class="tool" id="delfi">
      <div class="tool-icon">🏛️</div>
      <div>
        <div class="tool-name">DELFI · I dati di tutti i comuni italiani</div>
        <div class="tool-desc">Il portale con i dati ufficiali di tutti i 7.896 comuni italiani: popolazione, economia, redditi, ambiente, scuola, sanità, investimenti pubblici e PNRR, da fonti istituzionali (ISTAT, MEF, ISPRA, Ministero dell'Interno, OpenCoesione, Italia Domani e altre).<br><strong>Come funziona:</strong> cerchi un comune e apri la sua scheda, organizzata in 12 sezioni tematiche; puoi confrontare più comuni, consultare classifiche e mappa, e riutilizzare i dati con licenza CC BY 4.0 o tramite API.</div>
        <div class="tool-btns"><a href="https://www.delfiweb.it" target="_blank" rel="noopener" class="le">Apri DELFI</a></div>
      </div>
    </div>
    <div class="tool">
      <div class="tool-icon">📊</div>
      <div>
        <div class="tool-name">Ricerche di mercato · La guida</div>
        <div class="tool-desc">Che cosa sono le ricerche di mercato, come si progettano, come si calcola il campione: una guida con i casi reali di Troisi Ricerche.</div>
        <div class="tool-btns"><a href="https://www.ricerchedimercato.eu" target="_blank" rel="noopener" class="le">ricerchedimercato.eu</a></div>
      </div>
    </div>
    <div class="tool">
      <div class="tool-icon">💬</div>
      <div>
        <div class="tool-name">Ricerche qualitative · La guida</div>
        <div class="tool-desc">Focus group, interviste in profondità, mystery client: quando servono e come si conducono, con i casi reali di Troisi Ricerche.</div>
        <div class="tool-btns"><a href="https://www.ricerchequalitative.it" target="_blank" rel="noopener" class="le">ricerchequalitative.it</a></div>
      </div>
    </div>
  </div>
</div>

<script>
var scLastResult = null, scStratMode = 'prop';
function scTab(tab,btn){document.querySelectorAll('.sc-tab-content').forEach(function(t){t.classList.remove('active')});document.querySelectorAll('.sc-tab').forEach(function(b){b.classList.remove('active')});document.getElementById('sc-'+tab).classList.add('active');btn.classList.add('active');}
function scToggleAcc(el){el.classList.toggle('open');}
function scStratMode(m){scStratMode=m;document.getElementById('sm-prop').classList.toggle('active',m==='prop');document.getElementById('sm-ney').classList.toggle('active',m==='neyman');}
function scAddStrat(){var r=document.createElement('div');r.className='sc-strat-row';r.innerHTML='<input type="text" placeholder="Nome strato"><input type="number" placeholder="N strato" value="1000"><input type="number" placeholder="σ" value="15"><button class="sc-btn-del" onclick="scDelStrat(this)">✕</button>';document.getElementById('sc-strat-rows').appendChild(r);}
function scDelStrat(b){if(document.querySelectorAll('.sc-strat-row').length>1)b.closest('.sc-strat-row').remove();}
function scCochran(z,p,q,e,N){var n0=(z*z*p*q)/(e*e);return Math.ceil(n0/(1+(n0-1)/N));}
function scTable(N,z,p,q,curE,label){var es=[2,3,4,5,7,10],rows='';es.forEach(function(ep){var n=scCochran(z,p,q,ep/100,N);var hi=Math.abs(ep-curE*100)<0.1;rows+='<tr class="'+(hi?'hi':'')+'"><td>±'+ep+'%</td><td><strong>'+n.toLocaleString('it-IT')+'</strong></td><td>'+((n/N)*100).toFixed(1)+'%</td></tr>';});return '<table class="sc-table"><thead><tr><th>Margine</th><th>'+label+'</th><th>% universo</th></tr></thead><tbody>'+rows+'</tbody></table>';}
function scChart(N,z,p,q){var es=[3,4,5,7,10],ns=es.map(function(e){return scCochran(z,p,q,e/100,N);}),mx=Math.max.apply(null,ns),html='<div class="sc-chart-wrap"><div class="sc-chart-label">Campione per margine errore</div>';es.forEach(function(e,i){html+='<div class="sc-bar-row"><div class="sc-bar-lbl">±'+e+'%</div><div class="sc-bar-track"><div class="sc-bar-fill" style="width:'+(ns[i]/mx*100).toFixed(1)+'%;background:'+(i===2?'var(--orange)':'rgba(255,255,255,.28)')+'"><span class="sc-bar-val">'+ns[i].toLocaleString('it-IT')+'</span></div></div></div>';});return html+'</div>';}
function scInterp(N,n,e,conf,method){var cl=conf===1.96?'95%':conf===2.576?'99%':'90%';return '<div class="sc-interp"><div class="sc-interp-txt">Con un universo di <strong style="color:#fff">'+N.toLocaleString('it-IT')+' unità</strong> e margine <strong style="color:#fff">±'+(e*100).toFixed(1)+'%</strong>, il campione necessario è <strong style="color:var(--orange)">'+n.toLocaleString('it-IT')+' osservazioni</strong>. Affidabilità: <strong style="color:#fff">'+cl+'</strong>. '+method+'</div></div>';}
function scBuild(n,meta,table,chart,interp,params){scLastResult={n:n,meta:meta,params:params};var html='<div class="sc-result"><div class="sc-result-main"><div class="sc-result-label">Campione necessario</div><div class="sc-result-n">'+n.toLocaleString('it-IT')+'</div><div class="sc-result-unit">interviste / osservazioni</div></div><div class="sc-meta">';meta.forEach(function(m){html+='<div class="sc-meta-box"><div class="sc-meta-val">'+m.v+'</div><div class="sc-meta-key">'+m.k+'</div></div>';});html+='</div>'+chart+table+interp+'<button class="sc-pdf-btn" onclick="scPDF()"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/></svg> Scarica PDF Report</button></div>';return html;}
function scCalcProp(){var N=parseInt(document.getElementById('p-N').value)||10000,e=parseFloat(document.getElementById('p-e').value)/100||.05,z=parseFloat(document.getElementById('p-z').value)||1.96,p=parseFloat(document.getElementById('p-p').value)/100||.5,q=1-p,cl=z===1.96?'95%':z===2.576?'99%':'90%',n=scCochran(z,p,q,e,N);document.getElementById('sc-res-prop').innerHTML=scBuild(n,[{v:cl,k:'Confidenza'},{v:'±'+(e*100).toFixed(1)+'%',k:'Margine errore'},{v:((n/N)*100).toFixed(1)+'%',k:'Del totale'},{v:(p*100).toFixed(0)+'%',k:'Proporzione p'}],scTable(N,z,p,q,e,'Campione'),scChart(N,z,p,q),scInterp(N,n,e,z,'Formula Cochran, correzione popolazione finita.'),{N:N,e:e,z:z,p:p,type:'Proporzione',cl:cl});}
function scCalcMedia(){var N=parseInt(document.getElementById('m-N').value)||10000,sigma=parseFloat(document.getElementById('m-sigma').value)||15,e=parseFloat(document.getElementById('m-e').value)||3,z=parseFloat(document.getElementById('m-z').value)||1.96,cl=z===1.96?'95%':z===2.576?'99%':'90%',n0=(z*z*sigma*sigma)/(e*e),n=Math.ceil(n0/(1+(n0-1)/N));document.getElementById('sc-res-media').innerHTML=scBuild(n,[{v:cl,k:'Confidenza'},{v:'±'+e,k:'Margine assoluto'},{v:sigma,k:'Dev. std. σ'},{v:((n/N)*100).toFixed(1)+'%',k:'Del totale'}],'','',scInterp(N,n,e/100,z,'Calcolato per media con σ='+sigma+' e margine ±'+e+'.'),{N:N,e:e,z:z,sigma:sigma,type:'Media',cl:cl});}
function scCalcStrat(){var rows=document.querySelectorAll('.sc-strat-row'),e=parseFloat(document.getElementById('s-e').value)/100||.05,z=parseFloat(document.getElementById('s-z').value)||1.96,cl=z===1.96?'95%':z===2.576?'99%':'90%',strati=[];rows.forEach(function(r){var inp=r.querySelectorAll('input');var nh=parseInt(inp[1].value)||0;if(nh>0)strati.push({n:inp[0].value||'Strato',N:nh,s:parseFloat(inp[2].value)||15});});if(!strati.length)return;var N=strati.reduce(function(a,s){return a+s.N;},0),tot=scCochran(z,.5,.5,e,N),alloc;if(scStratMode==='prop'){alloc=strati.map(function(s){return{...s,nh:Math.max(1,Math.round(tot*s.N/N))};});}else{var den=strati.reduce(function(a,s){return a+s.N*s.s;},0);alloc=strati.map(function(s){return{...s,nh:Math.max(1,Math.round(tot*(s.N*s.s)/den))};});}var nEff=alloc.reduce(function(a,s){return a+s.nh;},0),mx=Math.max.apply(null,alloc.map(function(a){return a.nh;}));var tbl='<table class="sc-table"><thead><tr><th style="text-align:left">Strato</th><th>N</th><th>Campione</th><th>%</th></tr></thead><tbody>';alloc.forEach(function(s){tbl+='<tr><td style="text-align:left;padding-left:10px">'+s.n+'</td><td>'+s.N.toLocaleString('it-IT')+'</td><td><strong style="color:var(--orange)">'+s.nh+'</strong></td><td>'+((s.nh/nEff)*100).toFixed(1)+'%</td></tr>';});tbl+='</tbody></table>';var ch='<div class="sc-chart-wrap"><div class="sc-chart-label">Distribuzione per strato</div>';alloc.forEach(function(s){ch+='<div class="sc-bar-row"><div class="sc-bar-lbl" style="width:46px;font-size:10px">'+s.n.substring(0,5)+'</div><div class="sc-bar-track"><div class="sc-bar-fill" style="width:'+(s.nh/mx*100).toFixed(1)+'%;background:var(--orange)"><span class="sc-bar-val">'+s.nh+'</span></div></div></div>';});ch+='</div>';var itp='<div class="sc-interp"><div class="sc-interp-txt">Con <strong style="color:#fff">'+strati.length+' strati</strong> per universo <strong style="color:#fff">'+N.toLocaleString('it-IT')+' unità</strong>, campione: <strong style="color:var(--orange)">'+nEff+' interviste</strong>. Allocazione <strong style="color:#fff">'+(scStratMode==='prop'?'proporzionale':'ottimale Neyman')+'</strong>.</div></div>';document.getElementById('sc-res-strat').innerHTML=scBuild(nEff,[{v:cl,k:'Confidenza'},{v:'±'+(e*100).toFixed(1)+'%',k:'Margine'},{v:strati.length,k:'N. strati'},{v:N.toLocaleString('it-IT'),k:'Universo tot.'}],tbl,ch,itp,{N:N,e:e,z:z,strati:strati,type:'Stratificato',cl:cl});}
function scPDF(){if(!window.jspdf)return alert('jsPDF non disponibile');var {jsPDF}=window.jspdf,doc=new jsPDF({unit:'mm',format:'a4'}),W=210,H=297,navy=[23,50,77],orange=[232,99,10];doc.setFillColor(...navy);doc.rect(0,0,W,40,'F');doc.setFillColor(...orange);doc.rect(0,38,W,3,'F');doc.setFont('helvetica','bold');doc.setFontSize(18);doc.setTextColor(255,255,255);doc.text('TROISI RICERCHE',20,17);doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(200,215,230);doc.text('Istituto di Ricerca Statistica · www.troisiricerche.net',20,25);doc.setFont('helvetica','bold');doc.setFontSize(13);doc.setTextColor(255,255,255);doc.text('Report Calcolo Campione Statistico',20,34);var now=new Date();doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(180,200,220);doc.text('Generato il '+now.toLocaleDateString('it-IT')+' ore '+now.toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'}),W-20,17,{align:'right'});if(!scLastResult){doc.save('troisi-campione.pdf');return;}var {n,meta,params}=scLastResult,y=52;doc.setFillColor(244,246,249);doc.roundedRect(15,y,W-30,8,1,1,'F');doc.setFillColor(...navy);doc.roundedRect(15,y,4,8,1,1,'F');doc.setFont('helvetica','bold');doc.setFontSize(9);doc.setTextColor(...navy);doc.text('1. PARAMETRI',23,y+5.5);y+=11;doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(60,70,85);['Metodo: '+params.type,'Universo (N): '+(params.N?params.N.toLocaleString('it-IT'):'—'),'Margine errore: ±'+(params.e?(params.e*100).toFixed(1):'—')+'%','Livello confidenza: '+(params.cl||'95%')].forEach(function(l){doc.text(l,20,y);y+=5.5;});y+=4;doc.setFillColor(...navy);doc.roundedRect(15,y,W-30,30,2,2,'F');doc.setFont('helvetica','bold');doc.setFontSize(9);doc.setTextColor(180,200,220);doc.text('NUMEROSITÀ CAMPIONARIA',W/2,y+9,{align:'center'});doc.setFontSize(36);doc.setTextColor(...orange);doc.text(n.toLocaleString('it-IT'),W/2,y+22,{align:'center'});doc.setFontSize(9);doc.setTextColor(180,200,220);doc.text('interviste necessarie',W/2,y+28,{align:'center'});y+=36;doc.setFillColor(244,246,249);doc.roundedRect(15,y,W-30,8,1,1,'F');doc.setFillColor(...orange);doc.roundedRect(15,y,4,8,1,1,'F');doc.setFont('helvetica','bold');doc.setFontSize(9);doc.setTextColor(...orange);doc.text('2. INTERPRETAZIONE',23,y+5.5);y+=11;doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(60,70,85);doc.text('Con un universo di '+(params.N?params.N.toLocaleString('it-IT'):'N')+' unità e margine ±'+(params.e?(params.e*100).toFixed(1):'—')+'%,',20,y);y+=5.5;doc.text('il campione necessario è pari a '+n.toLocaleString('it-IT')+' osservazioni.',20,y);y+=5.5;doc.text('Garantisce affidabilità del '+(params.cl||'95%')+'.',20,y);y+=9;doc.setFillColor(244,246,249);doc.roundedRect(15,y,W-30,8,1,1,'F');doc.setFillColor(...navy);doc.roundedRect(15,y,4,8,1,1,'F');doc.setFont('helvetica','bold');doc.setFontSize(9);doc.setTextColor(...navy);doc.text('3. NOTA METODOLOGICA',23,y+5.5);y+=11;doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(60,70,85);['Formula di Cochran (1977): n = (z² × p × q) / e² → correzione: n / (1 + n/N)','Standard internazionale per ricerche di mercato e customer satisfaction.'].forEach(function(l){doc.text(l,20,y);y+=5.5;});doc.setFillColor(...navy);doc.rect(0,H-18,W,18,'F');doc.setFillColor(...orange);doc.rect(0,H-20,W,2,'F');doc.setFont('helvetica','bold');doc.setFontSize(8);doc.setTextColor(255,255,255);doc.text('Troisi Ricerche',20,H-10);doc.setFont('helvetica','normal');doc.setTextColor(180,200,220);doc.text('www.troisiricerche.net · Ricerche di mercato, analisi dati e customer satisfaction',20,H-5);doc.save('troisi-report-campione.pdf');}
</script>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
