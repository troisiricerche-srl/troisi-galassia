<?php
/**
 * Template Name: Casi Studio
 */
get_header(); ?>
<?php $current_page = 'casi-studio'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.sec{padding:36px 0}.sec-pad{padding:36px 24px}
.sec.alt{background:#fff}
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:4px 12px;border-radius:2px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}
.li{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);font-weight:700;border:1px solid #b3d1ff;padding:4px 12px;border-radius:2px;background:var(--bl);text-decoration:none}
.li::after{content:'→'}

/* Filtri categoria */
.filtri{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px}
.filtro{font-size:11px;font-weight:700;padding:5px 14px;border-radius:2px;border:1.5px solid var(--bo);color:var(--g);cursor:pointer;text-decoration:none;background:#fff}
.filtro.att,.filtro:hover{border-color:var(--blu);color:var(--blu);background:var(--bl)}
.filtro-eu{border-color:#003399;color:#003399;background:#f0f4ff}
.filtro-eu:hover,.filtro-eu.att{background:#003399;color:#fff}

/* Griglia progetti */
.progetti-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}

/* Card progetto */
.pc{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden;display:flex;flex-direction:column}
.pc-top{padding:20px 20px 0}
.pc-badges{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.pc-badge{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:2px 8px;border-radius:2px}
.b-pa{background:#e6f0ff;color:#004d99;border:1px solid #b3d1ff}
.b-eu{background:#e8f0ff;color:#003399;border:1px solid #99b3ff}
.b-priv{background:#fff3e0;color:#b45309;border:1px solid #ffd080}
.b-tpl{background:#e6f5f0;color:#006644;border:1px solid #99ccbb}
.b-cult{background:#f5e6ff;color:#6600cc;border:1px solid #cc99ff}
.b-sal{background:#e6fff0;color:#006633;border:1px solid #99eebb}
.b-com{background:#fff8e6;color:#996600;border:1px solid #ffdd80}
.b-corso{background:#fff0e6;color:#cc4400;border:1px solid #ffbb99}

.pc-anno{font-size:10px;font-weight:700;color:var(--g);margin-bottom:6px}
.pc-title{font-size:15px;font-weight:700;color:var(--dp);margin-bottom:6px;line-height:1.3}
.pc-committente{font-size:11px;color:var(--g);margin-bottom:10px;padding:5px 0;border-bottom:1px solid var(--bg)}
.pc-committente strong{color:var(--t)}
.pc-desc{font-size:12.5px;color:var(--g);line-height:1.7;padding:0 20px;flex:1}
.pc-numeri{display:flex;gap:0;margin:12px 0 0;background:var(--bg);border-top:1px solid var(--bo)}
.pc-n{flex:1;text-align:center;padding:10px 8px;border-right:1px solid var(--bo)}
.pc-n:last-child{border-right:none}
.pc-nv{font-size:18px;font-weight:700;color:var(--dp);line-height:1}
.pc-nl{font-size:9.5px;color:var(--g);line-height:1.3;margin-top:2px}
.pc-footer{padding:14px 20px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;border-top:1px solid var(--bo)}
.pc-media{font-size:10px;color:var(--g);display:flex;align-items:center;gap:4px;flex-wrap:wrap}
.pc-media-item{background:var(--bg);padding:2px 7px;border-radius:2px;border:1px solid var(--bo);font-size:9.5px;font-weight:600}

/* Card grande (featured) */
.pc.featured{border-left:4px solid var(--or)}
.pc.eu{border-left:4px solid #003399}
.pc.parlamento{border-left:4px solid #cc0000}

/* Stats band */
.stats-band{background:var(--dp);padding:24px;display:grid;grid-template-columns:repeat(5,1fr);gap:0;margin-bottom:0}
.sb{text-align:center;padding:0 12px;border-right:1px solid rgba(255,255,255,.1)}
.sb:last-child{border-right:none}
.sbv{font-size:24px;font-weight:700;color:var(--or);line-height:1}
.sbl{font-size:9.5px;color:rgba(255,255,255,.42);text-transform:uppercase;letter-spacing:.04em;margin-top:3px;line-height:1.4}

/* Sezione scale */
.scala-map{background:var(--dp);border-radius:var(--r);padding:22px;margin-bottom:28px}
.sm-title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.35);margin-bottom:16px}
.sm-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.sm-item{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:var(--r);padding:12px;text-align:center}
.sm-icon{font-size:20px;margin-bottom:5px}
.sm-label{font-size:11px;font-weight:700;color:#fff;margin-bottom:3px}
.sm-sub{font-size:10.5px;color:rgba(255,255,255,.42);line-height:1.4}

@media(max-width:768px){
  .progetti-grid{grid-template-columns:1fr}
  .stats-band{grid-template-columns:1fr 1fr}
  .sm-grid{grid-template-columns:1fr 1fr}
}
@media(max-width:600px){.sec{padding:28px 16px}}
</style>

<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Casi Studio e Progetti</div>
  <h1>Vent'anni di ricerca sul campo, <em>progetto dopo progetto</em></h1>
  <p>Da Bari a Spalato, dal Parlamento italiano al Parlamento Europeo, dalla Camera di Commercio di Padova ai Ministeri della Repubblica: una selezione dei progetti che hanno definito il metodo Troisi Ricerche.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Casi Studio</div>

<div class="stats-band">
  <div class="sb"><div class="sbv">223</div><div class="sbl">Progetti documentati</div></div>
  <div class="sb"><div class="sbv">2011</div><div class="sbl">Anno primo grande progetto</div></div>
  <div class="sb"><div class="sbv">EU</div><div class="sbl">Programmi europei attivi</div></div>
  <div class="sb"><div class="sbv">9</div><div class="sbl">Regioni italiane coperte</div></div>
  <div class="sb"><div class="sbv">2026</div><div class="sbl">Progetti in corso fino a</div></div>
</div>

<div class="sec-pad alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">La scala dei progetti</div></div>
    <div class="scala-map">
      <div class="sm-title">Troisi Ricerche opera a tutte le scale — locale, nazionale, europea, transnazionale</div>
      <div class="sm-grid">
        <div class="sm-item"><div class="sm-icon">🏙️</div><div class="sm-label">Locale / Comunale</div><div class="sm-sub">Bari · Bisceglie · Pescara · Padova</div></div>
        <div class="sm-item"><div class="sm-icon">🇮🇹</div><div class="sm-label">Nazionale</div><div class="sm-sub">Camera Deputati · MiC · Fondirigenti</div></div>
        <div class="sm-item"><div class="sm-icon">🇪🇺</div><div class="sm-label">Europeo</div><div class="sm-sub">Erasmus+ · Interreg · LIFE · PON</div></div>
        <div class="sm-item"><div class="sm-icon">🌊</div><div class="sm-label">Transnazionale</div><div class="sm-sub">Italia–Croazia · Adriatico–Mediterraneo</div></div>
      </div>
    </div>

    <!-- GRIGLIA PROGETTI -->
    <div class="sh"><div class="sl"></div><div class="se">I progetti, dal più recente</div></div>
    <div class="progetti-grid">
      <!-- ROMA CHE DICE -->
      <div class="pc featured">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Sondaggi · Opinione pubblica</span><span class="pc-badge b-priv">Media</span></div>
          <div class="pc-anno">Dal 2026 · Roma · In corso</div>
          <div class="pc-title">Roma che Dice — Osservatorio permanente sull'opinione dei romani</div>
          <div class="pc-committente">Progetto editoriale di <strong>La Capitale</strong> · supporto metodologico Troisi Ricerche</div>
        </div>
        <div class="pc-desc">Sondaggi mensili CAWI su mille residenti maggiorenni del Comune di Roma, con campione per quote di genere, età e area di residenza e risultati ponderati sui dati ISTAT. Il primo report (agosto 2026) è stato dedicato ai social network e ai minori; il secondo, partito a ottobre 2026, al rapporto dei romani con l'intelligenza artificiale.</div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">1.000</div><div class="pc-nl">Residenti per rilevazione</div></div>
          <div class="pc-n"><div class="pc-nv">CAWI</div><div class="pc-nl">Panel accreditati</div></div>
          <div class="pc-n"><div class="pc-nv">Mensile</div><div class="pc-nl">Cadenza</div></div>
        </div>
        <div class="pc-footer">
          <a href="<?php $rc = get_category_by_slug('roma-che-dice'); echo $rc ? esc_url(get_category_link($rc)) : esc_url(home_url('/notizie')); ?>" class="li">La rubrica</a>
          <a href="https://www.lacapitale.it/articolo/social-minori-sondaggio-roma-divieto-under-15" target="_blank" rel="noopener" class="le">La Capitale</a>
        </div>
      </div>

      <!-- CROSS-MOVE INTERREG -->
      <div class="pc eu">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-eu">Interreg IPA South Adriatic · In corso</span><span class="pc-badge b-tpl">Mobilità sostenibile</span></div>
          <div class="pc-anno">2025–2027 · Italia · Albania · Montenegro · In corso</div>
          <div class="pc-title">CROSS-MOVE — Cross-border sustainable urban mobility in the South-Adriatic area</div>
          <div class="pc-committente">Capofila: <strong>Comune di Mola di Bari</strong> · Partner: Comune di Bojano · Comune di Korçë (AL) · Komunalno Tuzi (ME) · con CLES srl</div>
        </div>
        <div class="pc-desc">Il progetto sviluppa e aggiorna i Piani Urbani di Mobilità Sostenibile (PUMS) di Comuni di piccola e media dimensione e studia la fattibilità di un futuro piano transfrontaliero. Curiamo l'analisi dei bisogni di mobilità: un questionario comune, armonizzato e tradotto in italiano, albanese, montenegrino e inglese, somministrato nei quattro territori con piani di campionamento per quote costruiti sui dati censuari ufficiali, per una lettura statistica congiunta dei risultati.</div>
        <div style="padding:12px 20px 4px"><img src="<?php echo get_template_directory_uri(); ?>/img/crossmove-logo.png" alt="Interreg IPA South Adriatic — CROSS-MOVE" loading="lazy" style="width:100%;max-width:340px;height:auto;display:block"></div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">4</div><div class="pc-nl">Comuni in 3 Paesi</div></div>
          <div class="pc-n"><div class="pc-nv">4</div><div class="pc-nl">Lingue del questionario</div></div>
          <div class="pc-n"><div class="pc-nv">2027</div><div class="pc-nl">Conclusione</div></div>
        </div>
        <div class="pc-footer">
          <a href="https://crossmove.southadriatic.eu/" target="_blank" rel="noopener" class="le">Sito ufficiale CROSS-MOVE</a>
          <a href="<?php echo home_url('/clienti'); ?>#crossmove" class="li">I partner</a>
        </div>
      </div>

      <!-- 14. GREENLIFE4SEAS -->
      <div class="pc eu">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-eu">LIFE EU · In corso</span><span class="pc-badge" style="background:#e6f5e6;color:#006600;border:1px solid #99cc99">Blue Economy</span></div>
          <div class="pc-anno">2024–2026 · In corso</div>
          <div class="pc-title">GreenLife4Seas — Comunicazione integrata di progetto</div>
          <div class="pc-committente">Lead Partner: <strong>Politecnico di Bari</strong> · Consorzio: ISPRA · CNR · AdSP Adriatico Meridionale · Porto del Pireo · Vitone Eco · SIMEM · Noesis</div>
        </div>
        <div class="pc-desc">Troisi Ricerche è responsabile della comunicazione istituzionale del progetto LIFE europeo GreenLife4Seas: ha creato l'identità visiva coordinata, il sito web greenlife4seas.poliba.it, i layout delle presentazioni e gestisce i rapporti con i media. Il progetto affronta il riutilizzo di 200 milioni di m³/anno di sedimenti portuali e 490.000 t/anno di gusci da acquacoltura come materie prime per l'economia circolare blu.</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:12px 0">
          <img src="<?php echo get_template_directory_uri(); ?>/img/gl4s/gl4s-visita-monitoraggio-bari-2026-gruppo.jpg" alt="GreenLife4Seas — visita di monitoraggio, Bari, febbraio 2026" loading="lazy" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/gl4s/gl4s-visita-monitoraggio-bari-2026-sala.jpg" alt="GreenLife4Seas — sessione di lavoro della visita di monitoraggio, Bari 2026" loading="lazy" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/gl4s/gl4s-2025-convegno.jpg" alt="GreenLife4Seas — convegno 2025" loading="lazy" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div style="font-size:10.5px;color:var(--g);margin:-4px 0 10px;padding:0 20px">Foto: greenlife4seas.poliba.it</div>
        <div style="padding:2px 20px 12px;display:flex;align-items:center;gap:14px;flex-wrap:wrap"><img src="<?php echo get_template_directory_uri(); ?>/img/gl4s-logo.png" alt="GreenLife4Seas" loading="lazy" style="height:64px;width:auto"><a href="<?php echo home_url('/clienti'); ?>#gl4s" class="li">Partner e contributori</a></div>
        <div class="pc-footer">
          <a href="https://greenlife4seas.poliba.it" target="_blank" class="le">greenlife4seas.poliba.it</a>
          <div class="pc-media"><span class="pc-media-item">Ecomondo 2025</span><span class="pc-media-item">Smart Bay La Spezia 2025</span><span class="pc-media-item">Monitoring Visit Feb 2026</span></div>
        </div>
      </div>

      <!-- 15. SUMMA INTERREG -->
      <div class="pc eu">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-eu">Interreg Italy-Croatia · In corso</span><span class="pc-badge b-tpl">Mobilità sostenibile</span></div>
          <div class="pc-anno">2025–2026 · Transnazionale · In corso</div>
          <div class="pc-title">SUMMA — Sustainable Multimodal Mobility in Adriatic Coastal and Hinterland Areas</div>
          <div class="pc-committente">Capofila: <strong>Comune di Caorle</strong> · Partner: Comune di Pescara · Città di Zara · Regione Spalatino-Dalmata · Città di Parenzo · IRENA (Istria) · Comunità Riviera Friulana · ISIG Gorizia · con CLES srl</div>
        </div>
        <div class="pc-desc">Studio di fattibilità per la bigliettazione unica intermodale ("One Ticket") nell'area adriatica Italia-Croazia. Analisi su tre assi: fattibilità tecnologica (piattaforma MaaS), finanziaria (modello di business, ripartizione ricavi) e giuridica (armonizzazione tariffe transfrontaliere). Meeting Pescara (febbraio 2025) + Mid-Term Conference Spalato (maggio 2025). Budget totale progetto: €2,6 milioni. Co-finanziamento UE: 80%.</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/summa/spalato_mag2025_foto_gruppo_lungomare_adriatico.jpeg" alt="SUMMA — foto gruppo lungomare Spalato maggio 2025" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/summa/pescara_feb2025_foto_gruppo_banner_interreg_sindaco.jpeg" alt="SUMMA Pescara — foto gruppo banner Interreg con fascia Sindaco" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/summa/spalato_mag2025_panel_andrea_papillon_nero.jpg" alt="SUMMA — Andrea Troisi al microfono con papillon nero Spalato" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">€2,6M</div><div class="pc-nl">Budget totale</div></div>
          <div class="pc-n"><div class="pc-nv">80%</div><div class="pc-nl">Co-finanziamento UE</div></div>
          <div class="pc-n"><div class="pc-nv">2026</div><div class="pc-nl">Conclusione</div></div>
        </div>
        <div class="pc-footer">
          <a href="https://www.italy-croatia.eu/web/summa" target="_blank" class="le">Sito ufficiale SUMMA</a>
          <a href="<?php echo home_url('/clienti'); ?>#summa" class="li">I partner</a>
          <a href="https://www.cleseconomia.com/intermodalita-e-bigliettazione-unica-il-progetto-summa-a-pescara/" target="_blank" class="le">CLES — Il progetto</a>
        </div>
      </div>

      <!-- tpl-fvg-2025 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Trasporto pubblico</span></div>
          <div class="pc-anno">Marzo 2025 · Friuli Venezia Giulia</div>
          <div class="pc-title">TPL FVG — La domanda potenziale di trasporto pubblico</div>
          <div class="pc-committente">Friuli Venezia Giulia · marzo 2025 · Pordenone, Udine, Gorizia, Trieste</div>
        </div>
        <div class="pc-desc">Dal 12 marzo 2025 Troisi Ricerche ha attraversato il Friuli Venezia Giulia per un nuovo progetto di ricerca: l&#x27;analisi della domanda potenziale dei trasporti pubblici locali a Pordenone, Udine, Gorizia e Trieste, per conto di TPL FVG.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-8-2.webp" alt="TPL FVG — La domanda potenziale di trasporto pubblico" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/tpl-fvg-2025/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- 12. CIBARI -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-sal">Salute</span><span class="pc-badge b-pa">UniBa · Ricorrente</span></div>
          <div class="pc-anno">2023 · 2024 · 2025 — Tre edizioni</div>
          <div class="pc-title">CiBari — Il Cibo della Salute (3 edizioni)</div>
          <div class="pc-committente">Committente: <strong>Centro Interdipartimentale "Cibo in Salute" — Università degli Studi di Bari Aldo Moro</strong> · con Regione Puglia e Comune di Bari</div>
        </div>
        <div class="pc-desc">Partnership pluriennale con il festival universitario sul cibo e la salute. Nella 2ª edizione (2024) Troisi Ricerche presenta i dati sulla ricerca statistica all'interno della sala affrescata di UniBa. Nella 3ª edizione (2025) conduce la prima <strong>survey nazionale sulla sindrome metabolica</strong> su 1.000 intervistati, presentata il 21 ottobre 2025 con il prof. Antonio Moschetta. Il logo TR compare nelle slide ufficiali dell'evento.</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/cibari/cibari2024_FOTO_PROFESSIONALE_platea_centinaia_giovani.jpg" alt="CiBari 2024 — platea centinaia giovani (foto professionale)" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/cibari/cibari2024_FOTO_PROFESSIONALE_andrea_microfono_platea.jpg" alt="CiBari 2024 — Andrea Troisi al microfono (foto professionale)" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/cibari/aiquav2023_locandina_pina_picierno_VP_parlamento_europeo_andrea_troisi.png" alt="AIQUAV 2023 — locandina con Pina Picierno VP PE e Andrea Troisi" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">3</div><div class="pc-nl">Edizioni</div></div>
          <div class="pc-n"><div class="pc-nv">1.000</div><div class="pc-nl">Intervistati (2025)</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Gazzetta del Mezzogiorno</span><span class="pc-media-item">Quotidiano di Bari</span><span class="pc-media-item">TV</span></div>
        </div>
      </div>

      <!-- 13. FENAPRO -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-priv">Privato · Beauty</span><span class="pc-badge b-pa">Mappatura delle Competenze</span></div>
          <div class="pc-anno">9 aprile 2024</div>
          <div class="pc-title">Mappatura Fabbisogni Formativi nelle Profumerie — FENAPRO</div>
          <div class="pc-committente">Committente: <strong>FENAPRO — Federazione Nazionale Profumieri</strong></div>
        </div>
        <div class="pc-desc">Survey nazionale sulla mappatura dei fabbisogni formativi all'interno delle profumerie italiane. I risultati vengono presentati in conferenza stampa (Zoom + diretta social) il 9 aprile 2024 da Andrea Troisi (CEO Troisi Ricerche) insieme al Presidente FENAPRO Michelangelo Liuni e al Segretario Generale Mario Verduci. I dati servono a progettare i nuovi corsi di Beauty Coach e gli strumenti di Formazione Finanziata tramite Fondi Interprofessionali.</div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Conferenza stampa online</span><span class="pc-media-item">Diretta YouTube · LinkedIn · Facebook</span></div>
        </div>
      </div>

      <!-- 11. FOOD POLICY BARI -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-sal">Alimentazione</span><span class="pc-badge b-eu">PON Legalità</span><span class="pc-badge b-pa">Comune di Bari</span></div>
          <div class="pc-anno">2022</div>
          <div class="pc-title">Food Policy della Città di Bari — Indagine sui comportamenti alimentari</div>
          <div class="pc-committente">Committente: <strong>Comune di Bari</strong> · Progetto AGRICULTURA — Città Metropolitana Bari, CIHEAM, PON Legalità 2014-2020</div>
        </div>
        <div class="pc-desc">Indagine campionaria sui consumi alimentari nei 9 quartieri di Bari. Primo lavoro statistico alla base della redazione del Piano di azione locale sul cibo (Food Policy) di Bari, che valse alla città l'Oscar della Salute. Presentazione alla Fiera del Levante il 19 ottobre 2022 con la Scuola Superiore Sant'Anna di Pisa e la prof. Filomena Corbo (UniBa). Il progetto si estende all'AIQUAV Conference 2023 con la VP Parlamento Europeo Pina Picierno.</div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">1.090</div><div class="pc-nl">Residenti intervistati</div></div>
          <div class="pc-n"><div class="pc-nv">9</div><div class="pc-nl">Aree geografiche</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Comune di Bari — Comunicato ufficiale</span><span class="pc-media-item">Fiera del Levante</span></div>
          <a href="https://www.comune.bari.it/-/cosa-mangiano-i-baresi-il-comune-di-bari-nell-ambito-della-food-policy-indaga-i-consumi-e-i-comportamenti-alimentari-in-citta" target="_blank" class="le">Comune di Bari</a>
        </div>
      </div>

      <!-- 10. FONDIRIGENTI -->
      <div class="pc parlamento">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge" style="background:#ffe6e6;color:#cc0000;border:1px solid #ffaaaa">Camera dei Deputati</span><span class="pc-badge b-priv">Confindustria · Federmanager</span></div>
          <div class="pc-anno">2021–2022 · Roma + Milano</div>
          <div class="pc-title">Modelli Manageriali Post-Covid + Governance Finanziaria — Fondirigenti</div>
          <div class="pc-committente">Committente: <strong>Fondirigenti</strong> (promosso da Confindustria + Federmanager) · con Links M&T e SCS Consulting</div>
        </div>
        <div class="pc-desc"><strong>Fase 1 (2021):</strong> Indagine sulle competenze manageriali post-Covid su 340 imprenditori e manager di medie imprese di Milano, Monza-Brianza e Lodi. <strong>Fase 2 (2022):</strong> Modello di competenze per la Governance Finanziaria presentato alla Camera dei Deputati il 25 marzo 2022, moderato da Fabio Savelli (Corriere della Sera), trasmesso su webtv.camera.it. Seguirà tre giorni dopo un articolo sul Corriere della Sera.</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/camera/fondirigenti_camera_25mar2022_relatori_al_banco.jpeg" alt="Sala Camera dei Deputati 25 marzo 2022 — Andrea Troisi in collegamento" style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/camera/fondirigenti_camera_25mar2022_foto_gruppo_6_persone.jpeg" alt="Foto gruppo Camera Deputati — relatori Fondirigenti 2022" style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">340</div><div class="pc-nl">Manager e imprenditori</div></div>
          <div class="pc-n"><div class="pc-nv">25/3/22</div><div class="pc-nl">Camera dei Deputati</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Corriere della Sera</span><span class="pc-media-item">webtv.camera.it</span><span class="pc-media-item">FD Magazine</span></div>
          <a href="https://www.fondirigenti.it/modello-di-competenze-per-la-governance-finanziaria" target="_blank" class="le">Fondirigenti</a>
        </div>
      </div>

      <!-- 9. COMPETENZE PATRIMONIO CULTURALE -->
      <div class="pc eu">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-eu">Erasmus+ · EU</span><span class="pc-badge b-cult">Patrimonio Culturale</span><span class="pc-badge b-pa">MiC</span></div>
          <div class="pc-anno">2021 · Roma · Online</div>
          <div class="pc-title">Competenze per il Patrimonio Culturale — Fondazione Scuola Beni Culturali</div>
          <div class="pc-committente">Committente: <strong>Fondazione Scuola dei Beni e delle Attività Culturali</strong> (vigilata MiC) · in partnership con CLES srl · Progetto CHARTER Erasmus+</div>
        </div>
        <div class="pc-desc">Indagine statistica nazionale presso 916 luoghi della cultura italiani. Troisi Ricerche realizza le rilevazioni con tecnica C.A.P.I.–C.A.T.I. su 5 tipologie: Musei, Aree archeologiche, Complessi monumentali, Biblioteche, Archivi. Focus su 6 ruoli direttivi EQF 6–8. I risultati alimentano il progetto europeo CHARTER per una strategia europea per le professioni del patrimonio culturale. Gruppo di ricerca TR: Andrea Troisi (responsabile), Silvia Gravili, Margherita Console, Carlo Cusatelli, Luca Tisselli.</div>
        <div style="padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/patrimonio/meeting_online_18feb2021_slide_916_luoghi_cultura.jpg" alt="Meeting online 18 febbraio 2021 — slide 916 organizzazioni culturali" style="width:100%;max-height:160px;object-fit:cover;border-radius:3px;display:block">
          <div style="font-size:10.5px;color:var(--g);margin-top:5px">Meeting Adobe Connect 18/02/2021 · slide «Composizione del campione» — 916 organizzazioni culturali italiane</div>
        </div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">916</div><div class="pc-nl">Luoghi della cultura</div></div>
          <div class="pc-n"><div class="pc-nv">512</div><div class="pc-nl">Musei</div></div>
          <div class="pc-n"><div class="pc-nv">EQF</div><div class="pc-nl">Livelli 6–8</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Presentazione online 18/02/2021</span><span class="pc-media-item">Pubblicazione Fondazione SBAC</span></div>
        </div>
      </div>

      <!-- 3. CS SVT VICENZA -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-tpl">TPL</span><span class="pc-badge b-pa">Customer Satisfaction</span></div>
          <div class="pc-anno">Dal 2019 · Gare a evidenza pubblica</div>
          <div class="pc-title">Customer Satisfaction SVT Vicenza</div>
          <div class="pc-committente">Committente: <strong>SVT — Società Vicentina Trasporti</strong></div>
        </div>
        <div class="pc-desc">Indagine online sulla soddisfazione degli utenti del trasporto pubblico di Vicenza, Bassano del Grappa, Recoaro e Valdagno. 5 questionari distinti per tipologia di servizio (extraurbano + rete urbana). Parametri: sicurezza passeggeri, affidabilità, comfort a bordo, informazioni, cortesia del personale.</div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Il Giornale di Vicenza</span></div>
          <a href="https://www.svt.vi.it" target="_blank" class="le">svt.vi.it</a>
          <a href="https://www.andreatroisi.it/sul-campo/svt-vicenza-2019-2025/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- comune-genova-2019 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Scuola &amp; Servizi</span></div>
          <div class="pc-anno">2019–2021 · Genova</div>
          <div class="pc-title">Comune di Genova — La customer satisfaction nelle scuole</div>
          <div class="pc-committente">Genova · dall&#x27;aprile 2019 · Percorso triennale</div>
        </div>
        <div class="pc-desc">L&#x27;8 aprile 2019 Troisi Ricerche ha avviato con il Comune di Genova un percorso lungo tre anni, dedicato al monitoraggio della customer satisfaction nelle scuole della città.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-75-5.webp" alt="Comune di Genova — La customer satisfaction nelle scuole" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/comune-genova-2019/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- stimare-2019 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Ambiente &amp; Coste</span></div>
          <div class="pc-anno">2019–2021 · Bari</div>
          <div class="pc-title">STIMARE — Il rischio di erosione costiera</div>
          <div class="pc-committente">Ministero dell&#x27;Ambiente · Politecnico di Bari · Università di Bologna · 2019–2021</div>
        </div>
        <div class="pc-desc">Nel giugno 2019 Troisi Ricerche ha vinto la gara nazionale per lavorare a STIMARE – Strategie Innovative per il Monitoraggio e l&#x27;Analisi del Rischio Erosione, il progetto finanziato dal Ministero dell&#x27;Ambiente e della Tutela del Territorio e del Mare con l&#x27;Università di Bologna e il Politecnico di Bari, per definire le strategie ottimali di intervento e gestione delle coste, mitigare il rischio di erosione e valorizzare il territorio.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-78-5.webp" alt="STIMARE — Il rischio di erosione costiera" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/stimare-2019/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- indagini-energia-2019 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Energia &amp; Mercati</span></div>
          <div class="pc-anno">Aprile–Maggio 2019 · Sicilia · Sardegna</div>
          <div class="pc-title">Energit e Onda Più — Indagini di mercato nel settore dell&#x27;energia</div>
          <div class="pc-committente">Sicilia · Sardegna · primavera 2019</div>
        </div>
        <div class="pc-desc">Nella primavera 2019 Troisi Ricerche ha realizzato due indagini di mercato nel settore dell&#x27;energia: a fine aprile tre giornate in Sicilia per Onda Più, fornitore di luce e gas; all&#x27;inizio di maggio due giornate in Sardegna per Energit, fornitore di energia elettrica.</div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/indagini-energia-2019/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- 6. DUC BARI + BISCEGLIE -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-com">Commercio</span><span class="pc-badge b-pa">DUC</span></div>
          <div class="pc-anno">2019–2020</div>
          <div class="pc-title">DUC Bari + DUC Bisceglie — Distretti Urbani del Commercio</div>
          <div class="pc-committente">Committente: <strong>Confcommercio Bari-Bat</strong> · DUC di Bisceglie · Regione Puglia — PON</div>
        </div>
        <div class="pc-desc">Doppia indagine sui Distretti Urbani del Commercio di Bari e Bisceglie: analisi dell'offerta commerciale percepita da clienti e commercianti. Per Bari: 935 residenti + 365 fuori città face-to-face + focus group durante la settimana di San Nicola. Sede di Bisceglie: Politeama Italia, 28 ottobre 2019. Ricercatrice: Silvia Gravili. Focus group in sede Confcommercio BAT.</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/duc-bari/gazzetta_PRIMA_PAGINA_14gen2020.jpg" alt="Gazzetta Prima Pagina 14 gennaio 2020 — DUC Bari" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/duc-bisceglie/andrea_troisi_al_microfono_blazer_scuro.jpg" alt="Andrea Troisi al microfono — Politeama Italia Bisceglie" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/duc-bisceglie/politeama_italia_platea_gremita.jpg" alt="Politeama Italia platea gremita — DUC Bisceglie 2019" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">1.300</div><div class="pc-nl">Interviste Bari</div></div>
          <div class="pc-n"><div class="pc-nv">11</div><div class="pc-nl">Focus group commercianti</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Gazzetta del Mezzogiorno</span><span class="pc-media-item">la Repubblica</span><span class="pc-media-item">TRM TV</span><span class="pc-media-item">YouTube</span></div>
          <a href="https://www.youtube.com/watch?v=c4TU22nFTJQ" target="_blank" class="le">Video TRM</a>
        </div>
      </div>

      <!-- 7. MAPPATURA COMPETENZE PORTO -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Mappatura delle Competenze</span><span class="pc-badge b-pa">PA — MIT</span></div>
          <div class="pc-anno">~2019</div>
          <div class="pc-title">Mappatura delle Competenze — Autorità Portuale del Mare Adriatico Meridionale</div>
          <div class="pc-committente">Committente: <strong>AdSP Mare Adriatico Meridionale</strong> (Bari, Brindisi, Manfredonia, Barletta, Monopoli) — ente vigilato dal MIT</div>
        </div>
        <div class="pc-desc">Applicazione della piattaforma Mappatura delle Competenze per la mappatura delle competenze del personale dell'Autorità Portuale. Presentazione formale dei risultati nella sede storica dell'ente, con circa 30 dirigenti e funzionari presenti. Uno dei primi casi reali applicativi di Mappatura delle Competenze su un ente pubblico statale di primo piano.</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/porto/slide_titolo_TROISI_RICERCHE_per_autorita_portuale.jpg" alt="Slide TROISI RICERCHE per Autorità Portuale Bari" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/porto/sala_30_dirigenti_portuali.jpg" alt="Sala Autorità Portuale Bari — 30 dirigenti" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div class="pc-footer">
          <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener" target="_blank" class="le">Mappatura delle Competenze</a>
        </div>
      </div>

      <!-- 5. MAPPATURA DINAMICA CCIAA PADOVA -->
      <div class="pc eu">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-eu">Interreg EU</span><span class="pc-badge b-priv">Imprese</span></div>
          <div class="pc-anno">2018–2021</div>
          <div class="pc-title">Mappatura Dinamica delle Imprese — CCIAA Padova · Padova Innovation Hub</div>
          <div class="pc-committente">Committente: <strong>Camera di Commercio di Padova</strong> · budget €500.000 · esteso a progetto EU Chain Reactions (Interreg CENTRAL EUROPE)</div>
        </div>
        <div class="pc-desc">Ricerca quantitativa su tre filiere strategiche del territorio padovano: Casa/efficienza energetica, Informatica/ICT, Meccanica di precisione. Obiettivo: ricostruire struttura, dinamiche relazionali, potenzialità competitive e difficoltà del sistema imprenditoriale locale. 60 interviste previste per filiera → 80 realizzate (+60% rispetto al target). Il progetto si evolve nel 2021 nel workshop europeo Chain Reactions sulla filiera biomedicale del Veneto.</div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">244</div><div class="pc-nl">Imprese coinvolte</div></div>
          <div class="pc-n"><div class="pc-nv">60</div><div class="pc-nl">Domande per impresa</div></div>
          <div class="pc-n"><div class="pc-nv">14.700</div><div class="pc-nl">Dati disponibili</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Il Gazzettino</span><span class="pc-media-item">Il Mattino di Padova</span></div>
          <a href="<?php echo home_url('/casi-studio/cciaa-padova'); ?>" class="li">Scheda completa</a>
        </div>
      </div>

      <!-- 4. CS MENSE SCOLASTICHE BARI -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Customer Satisfaction</span><span class="pc-badge b-sal">Educazione alimentare</span></div>
          <div class="pc-anno">2018</div>
          <div class="pc-title">Customer Satisfaction Mense Scolastiche — Comune di Bari / Ladisa</div>
          <div class="pc-committente">Committente: <strong>Comune di Bari</strong> · con Ladisa Srl (vincitrice bando triennale)</div>
        </div>
        <div class="pc-desc">Troisi Ricerche è l'istituto terzo indipendente incaricato di testare la qualità del nuovo servizio di ristorazione scolastica biologica del Comune di Bari. La conferenza stampa si tiene a Palazzo di Città con copertura TV (RAI e TRM). La Repubblica scrive: «A testare il servizio sarà l'istituto di ricerche Troisi, che realizzerà un'indagine con oltre 4mila interviste e focus group con genitori, docenti e alunni».</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/mense/conferenza_comune_bari_tavolo_6_relatori_report_TR.jpg" alt="Conferenza stampa Comune Bari — mense scolastiche 2018" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/mense/gazzetta_mezzogiorno_29set2018_mense_bio.jpeg" alt="Gazzetta del Mezzogiorno 29 settembre 2018 — mense bio" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/mense/repubblica_bari_29set2018_mense_ecosostenibile.jpeg" alt="la Repubblica Bari 29 settembre 2018 — mense ecosostenibili" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">4.000+</div><div class="pc-nl">Interviste previste</div></div>
          <div class="pc-n"><div class="pc-nv">5.300</div><div class="pc-nl">Bambini nel servizio</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Gazzetta del Mezzogiorno</span><span class="pc-media-item">la Repubblica Bari</span><span class="pc-media-item">TV</span></div>
          <a href="https://www.andreatroisi.it/sul-campo/ladisa-refezione-bari-2018/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- locus-festival-2018 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Internazionalizzazione</span></div>
          <div class="pc-anno">Febbraio 2018 · Puglia</div>
          <div class="pc-title">Locus Festival — Promuovere il festival nel mondo</div>
          <div class="pc-committente">Bass Culture · febbraio 2018 · Temporary Export Manager</div>
        </div>
        <div class="pc-desc">Nel febbraio 2018 Bass Culture, che organizza il Locus Festival, ha scelto Troisi Ricerche come propria società TEM – Temporary Export Manager – per curare i processi di internazionalizzazione e promuovere il festival nel mondo.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-119-1.webp" alt="Locus Festival — Promuovere il festival nel mondo" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/locus-festival-2018/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- grandapulia-2018 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Retail &amp; Customer satisfaction</span></div>
          <div class="pc-anno">Febbraio 2018 · Foggia</div>
          <div class="pc-title">GrandApulia — La customer satisfaction nel centro commerciale</div>
          <div class="pc-committente">Foggia · febbraio 2018 · Interviste face to face</div>
        </div>
        <div class="pc-desc">Il 19 febbraio 2018 Troisi Ricerche ha avviato la rilevazione di customer satisfaction nel centro commerciale più grande della Puglia, GrandApulia, con interviste face to face ai visitatori, proseguite fino al 25 febbraio.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-123-5.webp" alt="GrandApulia — La customer satisfaction nel centro commerciale" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/grandapulia-2018/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- lum-2017 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Università &amp; Formazione</span></div>
          <div class="pc-anno">2017 · Casamassima</div>
          <div class="pc-title">LUM — La collaborazione con la School of Management</div>
          <div class="pc-committente">LUM Jean Monnet · dal marzo 2017 · Master MASDACS</div>
        </div>
        <div class="pc-desc">Il 29 marzo 2017 Troisi Ricerche ha avviato la collaborazione con la School of Management della LUM – Libera Università Mediterranea Jean Monnet: un percorso per sviluppare programmi comuni di formazione e definire nuovi modelli statistici per la Pubblica Amministrazione, la sanità, la finanza, le assicurazioni, il turismo e i big data.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-146-0.webp" alt="LUM — La collaborazione con la School of Management" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/lum-2017/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- eupolis-lombardia-2017 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Opinione pubblica</span></div>
          <div class="pc-anno">Febbraio 2017 · Milano</div>
          <div class="pc-title">Éupolis Lombardia — I cittadini e la Regione</div>
          <div class="pc-committente">Regione Lombardia · febbraio 2017 · Gara vinta</div>
        </div>
        <div class="pc-desc">Nel 2017, dopo una gara vinta, Troisi Ricerche ha condotto per Éupolis Lombardia, l&#x27;Istituto superiore per la ricerca, la statistica e la formazione della Regione, un&#x27;indagine sui cittadini lombardi: come percepiscono la propria condizione socio-economica, quali aspettative hanno per il futuro, come valutano l&#x27;operato della Regione.</div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/eupolis-lombardia-2017/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- 2. CS TRIESTE TRASPORTI -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-tpl">TPL</span><span class="pc-badge b-pa">Customer Satisfaction</span></div>
          <div class="pc-anno">~2016–2020 — Pluriennale</div>
          <div class="pc-title">Customer Satisfaction Trieste Trasporti</div>
          <div class="pc-committente">Committente: <strong>Trieste Trasporti Srl</strong> · in collaborazione con Gap srl</div>
        </div>
        <div class="pc-desc">Quattro anni consecutivi di indagini di customer satisfaction per il servizio di trasporto pubblico di Trieste. L'indagine ha permesso di sviluppare un innovativo modello per la misurazione della soddisfazione nei servizi pubblici — modello alla base del libro Cacucci (2019) presentato alla Camera dei Deputati. Trieste è la quarta città italiana per numero di viaggi per abitante.</div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">1.605</div><div class="pc-nl">Residenti intervistati</div></div>
          <div class="pc-n"><div class="pc-nv">98,1%</div><div class="pc-nl">Valutazione positiva</div></div>
          <div class="pc-n"><div class="pc-nv">4</div><div class="pc-nl">Anni consecutivi</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Rivista "muoversi bene"</span><span class="pc-media-item">Libro Cacucci 2019</span></div>
          <a href="https://www.andreatroisi.it/sul-campo/trieste-trasporti-2016-2018/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- ministero-lavoro-2016 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Lavoro &amp; Politiche sociali</span></div>
          <div class="pc-anno">2016–2018 · Roma</div>
          <div class="pc-title">Ministero del Lavoro — Due anni al fianco del Ministero</div>
          <div class="pc-committente">Roma · dal maggio 2016</div>
        </div>
        <div class="pc-desc">Il 6 maggio 2016 Troisi Ricerche ha iniziato un incarico lungo due anni al fianco del Ministero del Lavoro e delle Politiche Sociali: «prospettive diverse, medesimo impegno».</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-194-0.webp" alt="Ministero del Lavoro — Due anni al fianco del Ministero" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/ministero-lavoro-2016/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- federalberghi-puglia-2016 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Turismo</span></div>
          <div class="pc-anno">Marzo 2016 · Puglia</div>
          <div class="pc-title">Federalberghi Puglia — Gli hotel nelle recensioni online</div>
          <div class="pc-committente">Puglia · marzo 2016 · Booking.com, TripAdvisor, Expedia</div>
        </div>
        <div class="pc-desc">Il 29 marzo 2016 Troisi Ricerche ha avviato per Federalberghi Puglia un&#x27;analisi della customer satisfaction degli hotel pugliesi a partire dalle recensioni su Booking.com, TripAdvisor ed Expedia: conoscere è il primo passo per l&#x27;innovazione e per la qualità dell&#x27;esperienza degli ospiti.</div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/federalberghi-puglia-2016/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- 8. DOING BUSINESS EAU -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-priv">Internazionalizzazione</span><span class="pc-badge b-pa">Istituzionale</span></div>
          <div class="pc-anno">18 febbraio 2016 · Bari</div>
          <div class="pc-title">Doing Business negli Emirati Arabi Uniti (EAU) — Camera di Commercio Bari</div>
          <div class="pc-committente">Organizzatori: <strong>Studio Legale Di Francia · Associazione Italia-Dubai · CCIAA Bari</strong></div>
        </div>
        <div class="pc-desc">Convegno istituzionale sulla presenza economica italiana negli EAU. Andrea Troisi presenta la "Presentazione Introduttiva Paese" sugli EAU. Relatori di primo piano: S.E. Massimo Rustico (Ministro Plenipotenziario, Farnesina), Presidente CCIAA Bari, Assessore Regione Puglia, Presidente Fiera del Levante, Presidente Ordine Avvocati di Bari. Incontri singoli con i partecipanti al termine.</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 0 12px">
          <img src="<?php echo get_template_directory_uri(); ?>/img/eau/CHIAVE_andrea_slide_PRESENTAZIONE_INTRODUTTIVA_PAESE.jpg" alt="Andrea Troisi — slide Presentazione Introduttiva Paese EAU — FOTO CHIAVE" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/eau/sala_cciaa_piena_logo_camera_commercio.jpg" alt="Sala CCIAA Bari piena — convegno EAU 2016" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
          <img src="<?php echo get_template_directory_uri(); ?>/img/eau/foto_gruppo_finale.jpg" alt="Foto di gruppo finale — convegno EAU CCIAA Bari 2016" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div style="padding:0 0 12px">
          <a href="<?php echo get_template_directory_uri(); ?>/img/pdf/eau_locandina_convegno_cciaa_bari_18feb2016.pdf" target="_blank" style="font-size:11px;font-weight:700;color:var(--blu);border:1px solid var(--bm);padding:4px 10px;border-radius:var(--r);background:var(--bl)">📄 Locandina convegno PDF</a>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">Camera di Commercio Bari</span></div>
        </div>
      </div>

      <!-- provincia-brindisi-2013 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Formazione &amp; Imprese</span></div>
          <div class="pc-anno">Maggio 2013 · Brindisi</div>
          <div class="pc-title">Provincia di Brindisi — Le imprese valutano la formazione</div>
          <div class="pc-committente">Brindisi · maggio 2013 · 147 interviste alle aziende · con Nomisma</div>
        </div>
        <div class="pc-desc">Nel maggio 2013 Troisi Ricerche ha vinto una nuova gara della Provincia di Brindisi: 147 interviste alle aziende del territorio per misurare la customer satisfaction sull&#x27;attività formativa erogata con gli avvisi provinciali. Con questa seconda collaborazione si è rafforzata la partnership con Nomisma.</div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/provincia-brindisi-2013/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- arti-puglia-2013 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Lavoro &amp; Competenze</span></div>
          <div class="pc-anno">Marzo 2013 · Bari</div>
          <div class="pc-title">ARTI Puglia — Le competenze richieste da 6.000 imprese</div>
          <div class="pc-committente">Puglia · marzo 2013 · Mappatura regionale delle competenze</div>
        </div>
        <div class="pc-desc">Nel marzo 2013 ARTI Puglia ha avviato un&#x27;analisi su seimila imprese pugliesi per realizzare la mappatura regionale delle nuove competenze richieste dal mercato del lavoro. Troisi Ricerche ha organizzato i focus group internazionali del progetto.</div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/arti-puglia-2013/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- epolis-trasporto-bari-2012 -->
      <div class="pc">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Trasporto pubblico</span></div>
          <div class="pc-anno">Gennaio 2012 · Bari</div>
          <div class="pc-title">Epolis Bari — L&#x27;inchiesta sul trasporto pubblico</div>
          <div class="pc-committente">Bari · gennaio 2012 · Quattro puntate</div>
        </div>
        <div class="pc-desc">Nel gennaio 2012 il quotidiano Epolis Bari ha pubblicato, in quattro puntate, l&#x27;inchiesta sul servizio di trasporto pubblico locale condotta da Troisi Ricerche: come i baresi giudicano autobus, frequenze, puntualità e pulizia, chi usa il servizio e che cosa chiede.</div>
        <div style="padding:0 0 12px"><img src="<?php echo get_template_directory_uri(); ?>/img/progetti/fb-505-0.webp" alt="Epolis Bari — L&#x27;inchiesta sul trasporto pubblico" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:3px;display:block"></div>
        <div class="pc-footer">
          <a href="https://www.andreatroisi.it/sul-campo/epolis-trasporto-bari-2012/" target="_blank" rel="noopener" class="le">Approfondisci</a>
        </div>
      </div>

      <!-- 1. QUALITÀ DELLA VITA IN PUGLIA 2011 -->
      <div class="pc featured">
        <div class="pc-top">
          <div class="pc-badges"><span class="pc-badge b-pa">Ricerca sociale</span><span class="pc-badge b-com">Consumatori</span></div>
          <div class="pc-anno">2011 — Evento storico</div>
          <div class="pc-title">Qualità della vita in Puglia</div>
          <div class="pc-committente">Committenti: <strong>Codacons · Confconsumatori · Movimento Consumatori · Unione Consumatori + Regione Puglia + Min. Sviluppo</strong></div>
        </div>
        <div class="pc-desc">Indagine campionaria face-to-face sulla qualità della vita nella regione Puglia. Metodologia stratificata, errore campionario 3,5%. Risultato principale: il 74,1% dei pugliesi si dichiara soddisfatto della propria qualità della vita. La ricerca ottiene copertura in prima pagina su EPolis Bari, oltre che su la Repubblica, Corriere del Mezzogiorno e Nuovo Quotidiano di Puglia.</div>
        <div class="pc-numeri">
          <div class="pc-n"><div class="pc-nv">1.068</div><div class="pc-nl">Interviste face-to-face</div></div>
          <div class="pc-n"><div class="pc-nv">3,5%</div><div class="pc-nl">Errore campionario</div></div>
          <div class="pc-n"><div class="pc-nv">74,1%</div><div class="pc-nl">Soddisfazione qualità vita</div></div>
        </div>
        <div class="pc-footer">
          <div class="pc-media"><span class="pc-media-item">EPolis Bari — Prima pagina</span><span class="pc-media-item">la Repubblica</span><span class="pc-media-item">Corriere del Mezzogiorno</span></div>
        </div>
      </div>

    </div><!-- /progetti-grid -->

    <!-- CTA -->
    <div style="background:var(--dp);border-radius:var(--r);padding:28px;text-align:center;margin-top:32px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.35);margin-bottom:8px">Hai un progetto di ricerca?</div>
      <div style="font-size:20px;font-weight:700;color:#fff;margin-bottom:8px">Parliamo del tuo prossimo progetto</div>
      <p style="font-size:13px;color:rgba(255,255,255,.55);max-width:500px;margin:0 auto 18px">Ogni progetto di Troisi Ricerche nasce da un ascolto attento delle esigenze del cliente. Contattaci per una consulenza senza impegno.</p>
      <a href="<?php echo home_url('/contatti'); ?>" style="background:var(--or);color:#fff;padding:10px 28px;border-radius:var(--r);font-size:13px;font-weight:700;text-decoration:none;display:inline-block">Contattaci →</a>
    </div>

  </div><!-- /wrap -->
</div>


<?php include(get_template_directory() . '/troisi-footer.php'); ?>
