# ISTRUZIONI — Pagine WordPress da creare nel DB
## Da eseguire su: https://www.troisiricerche.net/wp-admin/

Queste pagine devono esistere nel DB WordPress con lo slug esatto indicato.
Il tema le troverà automaticamente tramite il router in `page.php`.

---

## Pagine da creare (WP Admin → Pagine → Aggiungi nuova)

| Titolo pagina     | Slug (URL)      | Stato    |
|-------------------|-----------------|----------|
| Strumenti         | strumenti       | Pubblica |
| Servizi           | servizi         | Pubblica |
| La Ricerca        | la-ricerca      | Pubblica |
| Casi Studio       | casi-studio     | Pubblica |
| Media             | media           | Pubblica |
| Contatti          | contatti        | Pubblica |

**Nota:** Il contenuto della pagina può essere vuoto — il router PHP carica automaticamente
il template corretto in base allo slug. Non inserire nulla nel body della pagina.

---

## Come farlo via WP Admin (metodo manuale)

1. Vai su https://www.troisiricerche.net/wp-admin/post-new.php?post_type=page
2. Inserisci il Titolo (es. "Strumenti")
3. Nel pannello destro "Permalink", assicurati che lo slug sia esattamente quello indicato sopra
4. Stato: Pubblica
5. Salva
6. Ripeti per tutte le 6 pagine

---

## Alternativa via REST API (dalla console del browser, in WP Admin)

```javascript
// Esegui dalla console del browser mentre sei loggato come admin su wp-admin
const pages = [
  {title:'Strumenti', slug:'strumenti'},
  {title:'Servizi', slug:'servizi'},
  {title:'La Ricerca', slug:'la-ricerca'},
  {title:'Casi Studio', slug:'casi-studio'},
  {title:'Media', slug:'media'},
  {title:'Contatti', slug:'contatti'}
];

for (const p of pages) {
  fetch('/wp-json/wp/v2/pages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': wpApiSettings.nonce
    },
    body: JSON.stringify({title: p.title, slug: p.slug, status: 'publish'})
  }).then(r => r.json()).then(d => console.log('✅ Creata:', d.slug, '→ ID:', d.id));
}
```

---

## Pagine già esistenti nel DB (non toccare)

- `territorio` [ID: 16] ✅
- `rassegna-stampa` [ID: 175] ✅
- `case-studio` [ID: 173] ✅ (il router gestisce anche questo slug)
- `chi-siamo` [ID: 13] ✅
- `notizie` [ID: 18] ✅
- `clienti` [ID: 19] ✅
- `contattaci` [ID: 20] ✅ (il router gestisce anche questo slug)

## Sottopagine Strumenti (da creare come figlie della pagina Strumenti)

Vai su WP Admin → Pagine → Aggiungi nuova per ognuna:

| Titolo | Slug | Parent |
|--------|------|--------|
| Calcola il Campione | calcola-campione | Strumenti |
| TIP Platform | tip-platform | Strumenti |
| Dibattito Pubblico | dibattito-pubblico | Strumenti |
| T-Index® | t-index | Strumenti |
| TroisiInsight | troisiinsight | Strumenti |
| Benessere Organizzativo | benessere-organizzativo | Strumenti |
| CustomerPA | customerpa | Strumenti |
| Skillprint™ | skillprint | Strumenti |
| VoiceInHub | voiceinhub | Strumenti |
| DigitalizzazionePA | digitalizzazione-pa | Strumenti |

**Importante:** il router (page.php) riconosce automaticamente lo slug e carica il template corretto.
