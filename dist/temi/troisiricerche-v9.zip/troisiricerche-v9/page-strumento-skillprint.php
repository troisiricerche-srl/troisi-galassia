<?php /** Template Name: Strumento — Mappatura delle Competenze */
get_header(); $current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
</style>
<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1>🗺️ <em>Mappatura delle Competenze</em></h1>
  <p>Mappatura delle competenze — parte del network Troisi Ricerche.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; Mappatura delle Competenze</div>
<div class="sec alt"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Cos'è Mappatura delle Competenze</div></div>
  <div class="s-t">Un progetto del <em>network Troisi Ricerche</em></div>
  <p class="s-d">Sistema proprietario per la mappatura e la valutazione delle competenze nelle organizzazioni.</p>
  <p class="s-d">Mappatura delle Competenze nasce dall'esperienza ventennale di Troisi Ricerche nella ricerca statistica applicata. Ogni strumento del network è progettato per rendere i dati accessibili e utili a chi decide: enti pubblici, imprese, università.</p>
  <div class="cta-box">
    <h3>🗺️ Visita Mappatura delle Competenze</h3>
    <p>Accedi al sito dedicato per esplorare tutte le funzionalità e i contenuti di Mappatura delle Competenze.</p>
    <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener" class="cta-p">Vai su https://mappaturadellecompetenze.it ↗</a>
    <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Contattaci →</a>
  </div>
</div></div>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
