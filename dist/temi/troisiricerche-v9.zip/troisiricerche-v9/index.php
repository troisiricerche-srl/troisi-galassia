<?php
/**
 * index.php — Fallback template
 * WordPress usa front-page.php per la homepage.
 * Questo file gestisce la visualizzazione del blog/archivio.
 */
get_header();
$current_page = 'notizie';
include(get_template_directory() . '/troisi-nav.php');
$_td = get_template_directory_uri();
?>
<style>
.blog-wrap{max-width:var(--max-w);margin:0 auto;padding:40px 24px}
.blog-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px}
.blog-card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);overflow:hidden;transition:box-shadow .2s var(--ease)}
.blog-card:hover{box-shadow:var(--shadow-md)}
.blog-card-body{padding:20px}
.blog-card-cat{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--blu);margin-bottom:6px}
.blog-card-title{font-size:16px;font-weight:700;color:var(--dp);line-height:1.3;margin-bottom:8px}
.blog-card-title a{color:inherit;text-decoration:none}
.blog-card-title a:hover{color:var(--blu)}
.blog-card-date{font-size:11px;color:var(--g);margin-bottom:8px}
.blog-card-excerpt{font-size:13px;color:var(--g);line-height:1.7;margin-bottom:12px}
.blog-card-link{font-size:12px;font-weight:700;color:var(--blu)}
.blog-pagination{display:flex;justify-content:center;gap:8px;margin-top:32px}
.blog-pagination a,.blog-pagination span{display:inline-block;padding:8px 14px;border:1px solid var(--bo);border-radius:var(--r);font-size:12px;font-weight:600;color:var(--t)}
.blog-pagination .current{background:var(--blu);color:#fff;border-color:var(--blu)}
@media(max-width:600px){.blog-wrap{padding:28px 16px}.blog-grid{grid-template-columns:1fr}}
</style>

<div class="ph">
  <div class="wrap">
    <?php if ( is_category() ) : $tr_cat = get_queried_object(); $tr_rubrica = ( 'roma-che-dice' === $tr_cat->slug ); ?>
    <div class="ph-ey">Troisi Ricerche &middot; <?php echo $tr_rubrica ? 'Rubrica' : 'Notizie'; ?></div>
    <h1><?php echo esc_html( $tr_cat->name ); ?></h1>
    <?php if ( $tr_cat->description ) : ?><p><?php echo esc_html( $tr_cat->description ); ?></p><?php endif; ?>
    <?php if ( $tr_rubrica ) : ?><p style="margin-top:14px"><a href="https://www.lacapitale.it/" target="_blank" rel="noopener" style="color:#F5A623;font-weight:700;text-decoration:none">Leggi i sondaggi su La Capitale &rarr;</a></p><?php endif; ?>
    <?php else : ?>
    <div class="ph-ey">Troisi Ricerche &middot; Blog</div>
    <h1>Notizie e <em>aggiornamenti</em></h1>
    <p>Ricerche pubblicate, aggiornamenti dal network, presenza sui media, eventi.</p>
    <?php endif; ?>
  </div>
</div>

<div class="blog-wrap">
  <?php if(have_posts()): ?>
  <div class="blog-grid">
    <?php while(have_posts()): the_post();
      $cats = get_the_category();
      $cat_name = $cats ? $cats[0]->name : 'Notizie';
    ?>
    <article class="blog-card">
      <?php if(has_post_thumbnail()): ?>
        <img src="<?php echo get_the_post_thumbnail_url(null,'medium_large'); ?>" alt="<?php the_title_attribute(); ?>" style="width:100%;height:180px;object-fit:cover">
      <?php endif; ?>
      <div class="blog-card-body">
        <div class="blog-card-cat"><?php echo esc_html($cat_name); ?></div>
        <div class="blog-card-date"><?php echo get_the_date('d/m/Y'); ?></div>
        <h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <div class="blog-card-excerpt"><?php echo wp_trim_words(get_the_excerpt(),25); ?></div>
        <a href="<?php the_permalink(); ?>" class="blog-card-link">Leggi l'articolo →</a>
      </div>
    </article>
    <?php endwhile; ?>
  </div>
  <div class="blog-pagination">
    <?php
    echo paginate_links([
      'prev_text' => '← Precedente',
      'next_text' => 'Successiva →',
    ]);
    ?>
  </div>
  <?php else: ?>
  <p style="text-align:center;color:var(--g);padding:60px 0">Nessun articolo ancora pubblicato.</p>
  <?php endif; ?>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
