<?php
/**
 * Template Name: Strumento — Dibattito Pubblico
 */
get_header();
$current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php');
?>
<style>
.law-box{background:#fff4e6;border:2px solid #e8a020;border-radius:var(--r);padding:20px;margin-bottom:24px}
.law-title{font-size:12px;font-weight:700;color:var(--or);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.law-text{font-size:13px;color:var(--t);line-height:1.75}
.step-list{display:flex;flex-direction:column;gap:0;margin-top:16px}
.step{display:flex;gap:16px;padding:18px 0;border-bottom:1px solid var(--bo)}
.step:last-child{border:none}
.step-n{width:36px;height:36px;background:var(--dp);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;flex-shrink:0;margin-top:2px}
.step-t{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:4px}
.step-d{font-size:12.5px;color:var(--g);line-height:1.65}
.partner-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px}
.partner{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;text-align:center}
.partner-name{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:4px}
.partner-desc{font-size:11.5px;color:var(--g);line-height:1.5}
@media(max-width:600px){.partner-grid{grid-template-columns:1fr}}
</style>

<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1>Dibattito Pubblico — <em>D.Lgs. 36/2023</em></h1>
  <p>Troisi Ricerche gestisce i processi di dibattito pubblico nelle grandi opere infrastrutturali, secondo l'art. 40 del Codice dei contratti pubblici (D.Lgs. 36/2023) e l'Allegato I.6, che disciplinano il confronto con cittadini e portatori di interesse sulle opere.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; Dibattito Pubblico</div>

<div class="sec alt">
  <div class="wrap">
    <div class="law-box">
      <div class="law-title">⚖️ Riferimento normativo — art. 40 e Allegato I.6 del D.Lgs. 36/2023</div>
      <div class="law-text">Il Codice dei contratti pubblici (D.Lgs. 36/2023) disciplina il dibattito pubblico all'art. 40: la stazione appaltante o l'ente concedente può indirlo e l'<strong>Allegato I.6</strong> individua le grandi opere per cui è <strong>obbligatorio</strong>. Il dibattito si apre con la pubblicazione di una relazione sul progetto dell'opera e sulle alternative, dura al massimo 120 giorni e si chiude con una relazione conclusiva del responsabile del dibattito pubblico, che sintetizza proposte e osservazioni. L'Allegato I.6 riprende i contenuti del precedente DPCM 76/2018.</div>
    </div>

    <div class="sh"><div class="sl"></div><div class="se">Cosa facciamo</div></div>
    <div class="s-t">Troisi Ricerche come <em>soggetto terzo indipendente</em></div>
    <p class="s-d">La nostra esperienza nella ricerca sociale ci rende il partner ideale per gestire i processi di dibattito pubblico: dalla raccolta delle istanze dei cittadini alla sintesi dei risultati, con piena conformità normativa e massima trasparenza.</p>

    <div class="step-list">
      <div class="step">
        <div class="step-n">1</div>
        <div><div class="step-t">Analisi del contesto e mappa degli stakeholder</div><div class="step-d">Identificazione dei soggetti interessati (enti pubblici, associazioni, residenti, imprese) e analisi del contesto socio-territoriale dell'opera.</div></div>
      </div>
      <div class="step">
        <div class="step-n">2</div>
        <div><div class="step-t">Progettazione del percorso partecipativo</div><div class="step-d">Definizione del calendario, dei formati (assemblee pubbliche, focus group, sondaggi, piattaforma digitale) e degli strumenti di comunicazione.</div></div>
      </div>
      <div class="step">
        <div class="step-n">3</div>
        <div><div class="step-t">Conduzione del dibattito</div><div class="step-d">Moderazione professionale degli incontri pubblici, gestione della piattaforma digitale di raccolta osservazioni, supporto al Coordinatore nominato.</div></div>
      </div>
      <div class="step">
        <div class="step-n">4</div>
        <div><div class="step-t">Analisi statistica delle osservazioni</div><div class="step-d">Categorizzazione, analisi di frequenza e sintesi delle istanze pervenute. Report quantitativo e qualitativo per il responsabile del dibattito pubblico e il proponente.</div></div>
      </div>
      <div class="step">
        <div class="step-n">5</div>
        <div><div class="step-t">Rendicontazione e archivio</div><div class="step-d">Produzione del dossier finale del dibattito pubblico, a supporto della relazione conclusiva prevista dall'art. 40 del D.Lgs. 36/2023.</div></div>
      </div>
    </div>
  </div>
</div>

<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Partner di progetto</div></div>
    <div class="s-t">Lavoriamo in <em>rete</em> con i migliori</div>
    <p class="s-d">Per i processi di dibattito pubblico, Troisi Ricerche opera in partenariato con soggetti specializzati nelle diverse componenti del processo.</p>
    <div class="partner-grid">
      <div class="partner">
        <div class="partner-name">TenderCoop</div>
        <div class="partner-desc">Cooperativa specializzata in partecipazione, facilitazione e processi deliberativi</div>
      </div>
      <div class="partner">
        <div class="partner-name">Ti Quadro</div>
        <div class="partner-desc">Piattaforma tecnologica per la gestione digitale dei processi partecipativi online</div>
      </div>
      <div class="partner">
        <div class="partner-name">Troisi Ricerche</div>
        <div class="partner-desc">Ricerca statistica, analisi dei dati, campionamento e reportistica scientifica</div>
      </div>
    </div>

    <div class="cta-box">
      <h3>Hai un'opera soggetta a dibattito pubblico?</h3>
      <p>Contattaci per una consulenza preventiva gratuita. Valutiamo insieme se la tua opera rientra nelle soglie dell'Allegato I.6 del D.Lgs. 36/2023 e come strutturare il percorso partecipativo.</p>
      <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" class="cta-p">Visita dibattito-pubblico.it ↗</a>
      <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Richiedi consulenza →</a>
    </div>
  </div>
</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
