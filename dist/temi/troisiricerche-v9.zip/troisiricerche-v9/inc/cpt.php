<?php
/**
 * inc/cpt.php — Custom Post Types per Troisi Ricerche v9
 * Gestione contenuti da wp-admin senza plugin esterni
 */

// ═══════════════════════════════════════
// CPT: TEAM MEMBERS
// ═══════════════════════════════════════
function troisi_cpt_team() {
    register_post_type('troisi_team', [
        'labels' => [
            'name' => '👥 Team',
            'singular_name' => 'Membro Team',
            'add_new' => 'Aggiungi membro',
            'add_new_item' => 'Aggiungi membro del team',
            'edit_item' => 'Modifica membro',
            'all_items' => 'Tutti i membri',
            'search_items' => 'Cerca membri',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'troisi-settings',
        'supports' => ['title'],
        'menu_icon' => 'dashicons-groups',
    ]);

    register_taxonomy('team_status', 'troisi_team', [
        'labels' => ['name' => 'Stato', 'singular_name' => 'Stato'],
        'hierarchical' => true,
        'show_admin_column' => true,
    ]);
}

function troisi_team_metaboxes() {
    add_meta_box('troisi_team_meta', 'Dettagli Membro', 'troisi_team_meta_html', 'troisi_team', 'normal', 'high');
}

function troisi_team_meta_html($post) {
    wp_nonce_field('troisi_team_save', 'troisi_team_nonce');
    $ruolo = get_post_meta($post->ID, '_troisi_ruolo', true);
    $bio = get_post_meta($post->ID, '_troisi_bio', true);
    $icona = get_post_meta($post->ID, '_troisi_icona', true) ?: '👤';
    $attivo = get_post_meta($post->ID, '_troisi_attivo', true);
    $ordine = get_post_meta($post->ID, '_troisi_ordine', true) ?: 0;
    ?>
    <table class="form-table">
        <tr><th><label>Icona emoji</label></th><td><input type="text" name="troisi_icona" value="<?php echo esc_attr($icona); ?>" style="width:60px"> <span class="description">Es: 📐 🌐 📊 🎓 🔬 💼</span></td></tr>
        <tr><th><label>Ruolo</label></th><td><input type="text" name="troisi_ruolo" value="<?php echo esc_attr($ruolo); ?>" class="large-text" placeholder="Es: Responsabile Statistico"></td></tr>
        <tr><th><label>Bio</label></th><td><textarea name="troisi_bio" rows="4" class="large-text"><?php echo esc_textarea($bio); ?></textarea></td></tr>
        <tr><th><label>Attivo nel team attuale?</label></th><td><label><input type="checkbox" name="troisi_attivo" value="1" <?php checked($attivo, '1'); ?>> Sì, è nel team attuale (altrimenti compare tra i collaboratori storici)</label></td></tr>
        <tr><th><label>Ordine visualizzazione</label></th><td><input type="number" name="troisi_ordine" value="<?php echo esc_attr($ordine); ?>" style="width:80px"> <span class="description">Più basso = prima</span></td></tr>
    </table>
    <?php
}

function troisi_team_save($post_id) {
    if (!isset($_POST['troisi_team_nonce']) || !wp_verify_nonce($_POST['troisi_team_nonce'], 'troisi_team_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    foreach (['troisi_icona' => '_troisi_icona', 'troisi_ruolo' => '_troisi_ruolo', 'troisi_bio' => '_troisi_bio', 'troisi_ordine' => '_troisi_ordine'] as $field => $meta) {
        if (isset($_POST[$field])) update_post_meta($post_id, $meta, sanitize_text_field($_POST[$field]));
    }
    update_post_meta($post_id, '_troisi_attivo', isset($_POST['troisi_attivo']) ? '1' : '0');
}

// ═══════════════════════════════════════
// CPT: CLIENTI
// ═══════════════════════════════════════
function troisi_cpt_clienti() {
    register_post_type('troisi_cliente', [
        'labels' => [
            'name' => '🏢 Clienti',
            'singular_name' => 'Cliente',
            'add_new' => 'Aggiungi cliente',
            'add_new_item' => 'Aggiungi cliente',
            'edit_item' => 'Modifica cliente',
            'all_items' => 'Tutti i clienti',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'troisi-settings',
        'supports' => ['title', 'thumbnail'],
        'menu_icon' => 'dashicons-building',
    ]);

    register_taxonomy('cliente_cat', 'troisi_cliente', [
        'labels' => ['name' => 'Settore', 'singular_name' => 'Settore'],
        'hierarchical' => true,
        'show_admin_column' => true,
    ]);
}

function troisi_clienti_metaboxes() {
    add_meta_box('troisi_cliente_meta', 'Dettagli Cliente', 'troisi_cliente_meta_html', 'troisi_cliente', 'normal', 'high');
}

function troisi_cliente_meta_html($post) {
    wp_nonce_field('troisi_cliente_save', 'troisi_cliente_nonce');
    $file = get_post_meta($post->ID, '_troisi_logo_file', true);
    $cat = get_post_meta($post->ID, '_troisi_cat', true);
    $hp = get_post_meta($post->ID, '_troisi_in_homepage', true);
    $ordine = get_post_meta($post->ID, '_troisi_ordine', true) ?: 50;
    ?>
    <table class="form-table">
        <tr><th><label>File logo</label></th><td><input type="text" name="troisi_logo_file" value="<?php echo esc_attr($file); ?>" class="large-text" placeholder="Nome file nella cartella loghi-clienti/ (es: cnr.jpg)"> <span class="description">Oppure usa l'Immagine in evidenza qui a destra</span></td></tr>
        <tr><th><label>Categoria</label></th><td>
            <select name="troisi_cat">
                <option value="pa" <?php selected($cat,'pa'); ?>>PA & Istituzioni</option>
                <option value="trasporti" <?php selected($cat,'trasporti'); ?>>Trasporti & Utility</option>
                <option value="universita" <?php selected($cat,'universita'); ?>>Università & Ricerca</option>
                <option value="cultura" <?php selected($cat,'cultura'); ?>>Cultura & Turismo</option>
                <option value="consumatori" <?php selected($cat,'consumatori'); ?>>Associazioni consumatori</option>
                <option value="imprese" <?php selected($cat,'imprese'); ?>>Imprese & Consulting</option>
            </select>
        </td></tr>
        <tr><th><label>Mostra in homepage?</label></th><td><label><input type="checkbox" name="troisi_in_homepage" value="1" <?php checked($hp, '1'); ?>> Sì, nella strip clienti della homepage</label></td></tr>
        <tr><th><label>Ordine</label></th><td><input type="number" name="troisi_ordine" value="<?php echo esc_attr($ordine); ?>" style="width:80px"></td></tr>
    </table>
    <?php
}

function troisi_cliente_save($post_id) {
    if (!isset($_POST['troisi_cliente_nonce']) || !wp_verify_nonce($_POST['troisi_cliente_nonce'], 'troisi_cliente_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    update_post_meta($post_id, '_troisi_logo_file', sanitize_text_field($_POST['troisi_logo_file'] ?? ''));
    update_post_meta($post_id, '_troisi_cat', sanitize_text_field($_POST['troisi_cat'] ?? 'pa'));
    update_post_meta($post_id, '_troisi_in_homepage', isset($_POST['troisi_in_homepage']) ? '1' : '0');
    update_post_meta($post_id, '_troisi_ordine', intval($_POST['troisi_ordine'] ?? 50));
}

// ═══════════════════════════════════════
// CPT: CERTIFICAZIONI
// ═══════════════════════════════════════
function troisi_cpt_cert() {
    register_post_type('troisi_cert', [
        'labels' => [
            'name' => '🏅 Certificazioni',
            'singular_name' => 'Certificazione',
            'add_new' => 'Aggiungi certificazione',
            'all_items' => 'Tutte le certificazioni',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'troisi-settings',
        'supports' => ['title', 'thumbnail'],
    ]);
}

function troisi_cert_metaboxes() {
    add_meta_box('troisi_cert_meta', 'Dettagli Certificazione', 'troisi_cert_meta_html', 'troisi_cert', 'normal', 'high');
}

function troisi_cert_meta_html($post) {
    wp_nonce_field('troisi_cert_save', 'troisi_cert_nonce');
    $desc = get_post_meta($post->ID, '_troisi_cert_desc', true);
    $logo_path = get_post_meta($post->ID, '_troisi_cert_logo', true);
    $ordine = get_post_meta($post->ID, '_troisi_ordine', true) ?: 0;
    ?>
    <table class="form-table">
        <tr><th><label>Percorso logo</label></th><td><input type="text" name="troisi_cert_logo" value="<?php echo esc_attr($logo_path); ?>" class="large-text" placeholder="Es: img/loghi/tuv.jpeg"> <span class="description">Relativo alla cartella del tema, oppure usa Immagine in evidenza</span></td></tr>
        <tr><th><label>Descrizione breve</label></th><td><input type="text" name="troisi_cert_desc" value="<?php echo esc_attr($desc); ?>" class="large-text" placeholder="Es: Sistema di gestione qualità certificato"></td></tr>
        <tr><th><label>Ordine</label></th><td><input type="number" name="troisi_ordine" value="<?php echo esc_attr($ordine); ?>" style="width:80px"></td></tr>
    </table>
    <?php
}

function troisi_cert_save($post_id) {
    if (!isset($_POST['troisi_cert_nonce']) || !wp_verify_nonce($_POST['troisi_cert_nonce'], 'troisi_cert_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    update_post_meta($post_id, '_troisi_cert_desc', sanitize_text_field($_POST['troisi_cert_desc'] ?? ''));
    update_post_meta($post_id, '_troisi_cert_logo', sanitize_text_field($_POST['troisi_cert_logo'] ?? ''));
    update_post_meta($post_id, '_troisi_ordine', intval($_POST['troisi_ordine'] ?? 0));
}

// ═══════════════════════════════════════
// CPT: SEDI
// ═══════════════════════════════════════
function troisi_cpt_sedi() {
    register_post_type('troisi_sede', [
        'labels' => [
            'name' => '📍 Sedi',
            'singular_name' => 'Sede',
            'add_new' => 'Aggiungi sede',
            'all_items' => 'Tutte le sedi',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'troisi-settings',
        'supports' => ['title'],
    ]);
}

function troisi_sedi_metaboxes() {
    add_meta_box('troisi_sede_meta', 'Dettagli Sede', 'troisi_sede_meta_html', 'troisi_sede', 'normal', 'high');
}

function troisi_sede_meta_html($post) {
    wp_nonce_field('troisi_sede_save', 'troisi_sede_nonce');
    $ruolo = get_post_meta($post->ID, '_troisi_sede_ruolo', true);
    $info = get_post_meta($post->ID, '_troisi_sede_info', true);
    $icona = get_post_meta($post->ID, '_troisi_sede_icona', true) ?: '🏛️';
    $ordine = get_post_meta($post->ID, '_troisi_ordine', true) ?: 0;
    ?>
    <table class="form-table">
        <tr><th><label>Icona</label></th><td><input type="text" name="troisi_sede_icona" value="<?php echo esc_attr($icona); ?>" style="width:60px"></td></tr>
        <tr><th><label>Ruolo</label></th><td><input type="text" name="troisi_sede_ruolo" value="<?php echo esc_attr($ruolo); ?>" class="large-text" placeholder="Es: Sede principale · Direzione scientifica"></td></tr>
        <tr><th><label>Informazioni</label></th><td><textarea name="troisi_sede_info" rows="4" class="large-text" placeholder="Indirizzo, telefono, note..."><?php echo esc_textarea($info); ?></textarea><span class="description">Puoi usare &lt;br&gt; per andare a capo</span></td></tr>
        <tr><th><label>Ordine</label></th><td><input type="number" name="troisi_ordine" value="<?php echo esc_attr($ordine); ?>" style="width:80px"></td></tr>
    </table>
    <?php
}

function troisi_sede_save($post_id) {
    if (!isset($_POST['troisi_sede_nonce']) || !wp_verify_nonce($_POST['troisi_sede_nonce'], 'troisi_sede_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    update_post_meta($post_id, '_troisi_sede_ruolo', sanitize_text_field($_POST['troisi_sede_ruolo'] ?? ''));
    update_post_meta($post_id, '_troisi_sede_info', wp_kses_post($_POST['troisi_sede_info'] ?? ''));
    update_post_meta($post_id, '_troisi_sede_icona', sanitize_text_field($_POST['troisi_sede_icona'] ?? '🏛️'));
    update_post_meta($post_id, '_troisi_ordine', intval($_POST['troisi_ordine'] ?? 0));
}

// ═══════════════════════════════════════
// CPT: TIMELINE (storia aziendale)
// ═══════════════════════════════════════
function troisi_cpt_timeline() {
    register_post_type('troisi_timeline', [
        'labels' => [
            'name' => '📅 Timeline',
            'singular_name' => 'Milestone',
            'add_new' => 'Aggiungi milestone',
            'all_items' => 'Tutte le milestone',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'troisi-settings',
        'supports' => ['title'],
    ]);
}

function troisi_timeline_metaboxes() {
    add_meta_box('troisi_tl_meta', 'Dettagli Milestone', 'troisi_tl_meta_html', 'troisi_timeline', 'normal', 'high');
}

function troisi_tl_meta_html($post) {
    wp_nonce_field('troisi_tl_save', 'troisi_tl_nonce');
    $anno = get_post_meta($post->ID, '_troisi_anno', true);
    $desc = get_post_meta($post->ID, '_troisi_tl_desc', true);
    $evidenza = get_post_meta($post->ID, '_troisi_tl_evidenza', true);
    ?>
    <table class="form-table">
        <tr><th><label>Anno</label></th><td><input type="text" name="troisi_anno" value="<?php echo esc_attr($anno); ?>" style="width:80px" placeholder="2006"></td></tr>
        <tr><th><label>Descrizione</label></th><td><textarea name="troisi_tl_desc" rows="3" class="large-text"><?php echo esc_textarea($desc); ?></textarea></td></tr>
        <tr><th><label>In evidenza (colore oro)?</label></th><td><label><input type="checkbox" name="troisi_tl_evidenza" value="1" <?php checked($evidenza, '1'); ?>> Sì (per la milestone attuale)</label></td></tr>
    </table>
    <?php
}

function troisi_tl_save($post_id) {
    if (!isset($_POST['troisi_tl_nonce']) || !wp_verify_nonce($_POST['troisi_tl_nonce'], 'troisi_tl_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    update_post_meta($post_id, '_troisi_anno', sanitize_text_field($_POST['troisi_anno'] ?? ''));
    update_post_meta($post_id, '_troisi_tl_desc', sanitize_textarea_field($_POST['troisi_tl_desc'] ?? ''));
    update_post_meta($post_id, '_troisi_tl_evidenza', isset($_POST['troisi_tl_evidenza']) ? '1' : '0');
}

// ═══════════════════════════════════════
// CPT: STRUMENTI / SITI NETWORK
// ═══════════════════════════════════════
function troisi_cpt_strumenti() {
    register_post_type('troisi_strumento', [
        'labels' => [
            'name' => '🔧 Strumenti Network',
            'singular_name' => 'Strumento',
            'add_new' => 'Aggiungi strumento',
            'all_items' => 'Tutti gli strumenti',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'troisi-settings',
        'supports' => ['title', 'editor'],
    ]);
}

function troisi_strumenti_metaboxes() {
    add_meta_box('troisi_str_meta', 'Dettagli Strumento', 'troisi_str_meta_html', 'troisi_strumento', 'normal', 'high');
}

function troisi_str_meta_html($post) {
    wp_nonce_field('troisi_str_save', 'troisi_str_nonce');
    $icona = get_post_meta($post->ID, '_troisi_str_icona', true) ?: '🔧';
    $url_ext = get_post_meta($post->ID, '_troisi_str_url', true);
    $url_int = get_post_meta($post->ID, '_troisi_str_url_int', true);
    $desc_breve = get_post_meta($post->ID, '_troisi_str_desc', true);
    $in_galassia = get_post_meta($post->ID, '_troisi_str_galassia', true);
    $in_homepage = get_post_meta($post->ID, '_troisi_str_homepage', true);
    $ordine = get_post_meta($post->ID, '_troisi_ordine', true) ?: 0;
    ?>
    <table class="form-table">
        <tr><th><label>Icona emoji</label></th><td><input type="text" name="troisi_str_icona" value="<?php echo esc_attr($icona); ?>" style="width:60px"></td></tr>
        <tr><th><label>Descrizione breve</label></th><td><input type="text" name="troisi_str_desc" value="<?php echo esc_attr($desc_breve); ?>" class="large-text" placeholder="Max 1-2 righe per le card"></td></tr>
        <tr><th><label>URL sito esterno</label></th><td><input type="url" name="troisi_str_url" value="<?php echo esc_attr($url_ext); ?>" class="large-text" placeholder="https://t-index.it"></td></tr>
        <tr><th><label>Pagina interna</label></th><td><input type="text" name="troisi_str_url_int" value="<?php echo esc_attr($url_int); ?>" class="large-text" placeholder="/strumenti/t-index"></td></tr>
        <tr><th><label>Mostra nella Galassia?</label></th><td><label><input type="checkbox" name="troisi_str_galassia" value="1" <?php checked($in_galassia, '1'); ?>> Sì</label></td></tr>
        <tr><th><label>Mostra in homepage strumenti?</label></th><td><label><input type="checkbox" name="troisi_str_homepage" value="1" <?php checked($in_homepage, '1'); ?>> Sì</label></td></tr>
        <tr><th><label>Ordine</label></th><td><input type="number" name="troisi_ordine" value="<?php echo esc_attr($ordine); ?>" style="width:80px"></td></tr>
    </table>
    <?php
}

function troisi_str_save($post_id) {
    if (!isset($_POST['troisi_str_nonce']) || !wp_verify_nonce($_POST['troisi_str_nonce'], 'troisi_str_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    $fields = ['troisi_str_icona'=>'_troisi_str_icona','troisi_str_desc'=>'_troisi_str_desc','troisi_str_url'=>'_troisi_str_url','troisi_str_url_int'=>'_troisi_str_url_int','troisi_ordine'=>'_troisi_ordine'];
    foreach ($fields as $f => $m) {
        if (isset($_POST[$f])) update_post_meta($post_id, $m, sanitize_text_field($_POST[$f]));
    }
    update_post_meta($post_id, '_troisi_str_galassia', isset($_POST['troisi_str_galassia']) ? '1' : '0');
    update_post_meta($post_id, '_troisi_str_homepage', isset($_POST['troisi_str_homepage']) ? '1' : '0');
}

// ═══════════════════════════════════════
// REGISTRA TUTTO
// ═══════════════════════════════════════
add_action('init', 'troisi_cpt_team');
add_action('init', 'troisi_cpt_clienti');
add_action('init', 'troisi_cpt_cert');
add_action('init', 'troisi_cpt_sedi');
add_action('init', 'troisi_cpt_timeline');
add_action('init', 'troisi_cpt_strumenti');

add_action('add_meta_boxes', 'troisi_team_metaboxes');
add_action('add_meta_boxes', 'troisi_clienti_metaboxes');
add_action('add_meta_boxes', 'troisi_cert_metaboxes');
add_action('add_meta_boxes', 'troisi_sedi_metaboxes');
add_action('add_meta_boxes', 'troisi_timeline_metaboxes');
add_action('add_meta_boxes', 'troisi_strumenti_metaboxes');

add_action('save_post_troisi_team', 'troisi_team_save');
add_action('save_post_troisi_cliente', 'troisi_cliente_save');
add_action('save_post_troisi_cert', 'troisi_cert_save');
add_action('save_post_troisi_sede', 'troisi_sede_save');
add_action('save_post_troisi_timeline', 'troisi_tl_save');
add_action('save_post_troisi_strumento', 'troisi_str_save');

// ═══════════════════════════════════════
// HELPER: Recupera dati CPT
// ═══════════════════════════════════════
function troisi_get_team($attivo = true) {
    return get_posts([
        'post_type' => 'troisi_team',
        'posts_per_page' => -1,
        'meta_key' => '_troisi_ordine',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
        'meta_query' => $attivo ? [['key'=>'_troisi_attivo','value'=>'1']] : [['key'=>'_troisi_attivo','value'=>'0']],
    ]);
}

function troisi_get_clienti($cat = '', $homepage_only = false) {
    $meta_query = [];
    if ($cat) $meta_query[] = ['key'=>'_troisi_cat','value'=>$cat];
    if ($homepage_only) $meta_query[] = ['key'=>'_troisi_in_homepage','value'=>'1'];
    return get_posts([
        'post_type' => 'troisi_cliente',
        'posts_per_page' => -1,
        'meta_key' => '_troisi_ordine',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
        'meta_query' => $meta_query ?: '',
    ]);
}

function troisi_get_certificazioni() {
    return get_posts([
        'post_type' => 'troisi_cert',
        'posts_per_page' => -1,
        'meta_key' => '_troisi_ordine',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
    ]);
}

function troisi_get_sedi() {
    return get_posts([
        'post_type' => 'troisi_sede',
        'posts_per_page' => -1,
        'meta_key' => '_troisi_ordine',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
    ]);
}

function troisi_get_timeline() {
    return get_posts([
        'post_type' => 'troisi_timeline',
        'posts_per_page' => -1,
        'meta_key' => '_troisi_anno',
        'orderby' => 'meta_value',
        'order' => 'ASC',
    ]);
}

function troisi_get_strumenti_galassia() {
    return get_posts([
        'post_type' => 'troisi_strumento',
        'posts_per_page' => -1,
        'meta_key' => '_troisi_ordine',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
        'meta_query' => [['key'=>'_troisi_str_galassia','value'=>'1']],
    ]);
}
