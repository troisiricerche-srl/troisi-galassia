<?php
/**
 * 10.3.6 – Pop-up del video istituzionale in apertura della home (lancio del 26/10/2026).
 * Il video è nella Libreria media: si cerca l'allegato il cui file inizia con
 * «Troisi-Ricerche-video-istituzionale-orizzontale» (e la copertina «...-copertina»).
 * Se il video non c'è, il pop-up non compare. Si apre una volta per visitatore,
 * parte senza audio; si chiude con la X, con Esc o cliccando fuori.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function troisi_popup_allegato( $prefisso, $mime ) {
    $q = get_posts( array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => $mime,
        'posts_per_page' => 20,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ) );
    foreach ( $q as $id ) {
        $f = basename( (string) get_attached_file( $id ) );
        if ( 0 === stripos( $f, $prefisso ) ) {
            return wp_get_attachment_url( $id );
        }
    }
    return '';
}

function troisi_popup_video_dati() {
    $d = get_transient( 'troisi_popup_video_v1' );
    if ( is_array( $d ) ) { return $d; }
    $d = array(
        'video'  => troisi_popup_allegato( 'Troisi-Ricerche-video-istituzionale-orizzontale', 'video' ),
        'poster' => troisi_popup_allegato( 'Troisi-Ricerche-video-istituzionale-copertina', 'image' ),
    );
    set_transient( 'troisi_popup_video_v1', $d, $d['video'] ? 12 * HOUR_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
    return $d;
}

// Quando si carica o si cancella un file, la ricerca si rifà subito.
add_action( 'add_attachment', function () { delete_transient( 'troisi_popup_video_v1' ); } );
add_action( 'delete_attachment', function () { delete_transient( 'troisi_popup_video_v1' ); } );

add_action( 'wp_footer', function () {
    if ( ! is_front_page() ) { return; }
    $d = troisi_popup_video_dati();
    if ( empty( $d['video'] ) ) { return; }
    ?>
<div id="tr-vpop" class="tr-vpop" role="dialog" aria-modal="true" aria-label="Video: Troisi Ricerche, misuriamo ciò che conta" hidden>
  <div class="tr-vpop__box">
    <button type="button" class="tr-vpop__x" aria-label="Chiudi il video">&times;</button>
    <video class="tr-vpop__v" controls muted playsinline preload="none"<?php echo $d['poster'] ? ' poster="' . esc_url( $d['poster'] ) . '"' : ''; ?>>
      <source src="<?php echo esc_url( $d['video'] ); ?>" type="video/mp4">
    </video>
    <div class="tr-vpop__bar">
      <span>Misuriamo ciò che conta. <b>Davvero.</b></span>
      <button type="button" class="tr-vpop__audio">🔊 Attiva l'audio</button>
    </div>
  </div>
</div>
<style>
html body .tr-vpop{position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(10,22,38,.78);opacity:0;transition:opacity .25s}
html body .tr-vpop[hidden]{display:none}
html body .tr-vpop.is-on{opacity:1}
html body .tr-vpop__box{position:relative;width:min(960px,100%);background:#0f2540;border-radius:14px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.45)}
html body .tr-vpop__v{display:block;width:100%;aspect-ratio:16/9;height:auto;background:#0f2540}
html body .tr-vpop__x{position:absolute;top:8px;right:8px;z-index:2;width:40px;height:40px;border:0;border-radius:50%;background:rgba(0,0,0,.55);color:#fff;font-size:26px;line-height:40px;cursor:pointer;padding:0}
html body .tr-vpop__x:hover,html body .tr-vpop__x:focus-visible{background:#E8630A;outline:none}
html body .tr-vpop__bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;padding:12px 16px;color:#fff;font-size:16px}
html body .tr-vpop__bar b{color:#E8630A}
html body .tr-vpop__audio{border:0;border-radius:999px;background:#E8630A;color:#fff;font-weight:700;font-size:15px;padding:8px 16px;cursor:pointer}
html body .tr-vpop__audio[hidden]{display:none}
html body.tr-vpop-aperto{overflow:hidden}
</style>
<script>
(function(){
  var K='tr_video_istituzionale_visto';
  var p=document.getElementById('tr-vpop'); if(!p) return;
  var forza=/[?&]video=1/.test(location.search);
  try{ if(!forza && localStorage.getItem(K)) return; }catch(e){}
  var v=p.querySelector('video'), a=p.querySelector('.tr-vpop__audio'), x=p.querySelector('.tr-vpop__x'), prima=null;
  function segna(){ try{ localStorage.setItem(K, String(Date.now())); }catch(e){} }
  function chiudi(){
    if(p.hidden) return;
    try{ v.pause(); }catch(e){}
    p.classList.remove('is-on'); document.body.classList.remove('tr-vpop-aperto');
    setTimeout(function(){ p.hidden=true; }, 250);
    document.removeEventListener('keydown', tasto);
    if(prima && prima.focus) prima.focus();
  }
  function tasto(e){ if(e.key==='Escape'){ chiudi(); } }
  function apri(){
    prima=document.activeElement; p.hidden=false; segna();
    document.body.classList.add('tr-vpop-aperto');
    requestAnimationFrame(function(){ p.classList.add('is-on'); });
    v.muted=true; var pr=v.play(); if(pr && pr.catch) pr.catch(function(){});
    x.focus(); document.addEventListener('keydown', tasto);
  }
  x.addEventListener('click', chiudi);
  p.addEventListener('click', function(e){ if(e.target===p) chiudi(); });
  a.addEventListener('click', function(){ v.muted=false; v.volume=1; if(v.paused){ v.play(); } a.hidden=true; });
  v.addEventListener('volumechange', function(){ a.hidden=!v.muted; });
  v.addEventListener('ended', function(){ setTimeout(chiudi, 1500); });
  setTimeout(apri, 1200);
})();
</script>
    <?php
}, 50 );
