<?php
/**
 * inc/options.php — Pagina Opzioni Tema Troisi Ricerche
 * Gestisce: Hero, Numeri chiave, Bio Andrea, Dati societari, Calendly URL
 */

// ═══════════════════════════════════════
// MENU ADMIN
// ═══════════════════════════════════════
function troisi_admin_menu() {
    add_menu_page(
        'Troisi Ricerche',
        '⚙️ Troisi Ricerche',
        'manage_options',
        'troisi-settings',
        'troisi_settings_page',
        'dashicons-chart-area',
        3
    );
    add_submenu_page('troisi-settings', 'Impostazioni Tema', '⚙️ Impostazioni', 'manage_options', 'troisi-settings', 'troisi_settings_page');
    add_submenu_page('troisi-settings', 'Importa dati iniziali', '📦 Importa dati', 'manage_options', 'troisi-import', 'troisi_import_page');
}
add_action('admin_menu', 'troisi_admin_menu');

// ═══════════════════════════════════════
// REGISTRA SETTINGS
// ═══════════════════════════════════════
function troisi_register_settings() {
    // Hero
    register_setting('troisi_options', 'troisi_hero_eyebrow');
    register_setting('troisi_options', 'troisi_hero_title');
    register_setting('troisi_options', 'troisi_hero_subtitle');
    register_setting('troisi_options', 'troisi_hero_tags');

    // Numeri chiave
    register_setting('troisi_options', 'troisi_num_anni');
    register_setting('troisi_options', 'troisi_num_ricerche');
    register_setting('troisi_options', 'troisi_num_clienti');
    register_setting('troisi_options', 'troisi_num_siti');

    // Bio Andrea
    register_setting('troisi_options', 'troisi_andrea_nome');
    register_setting('troisi_options', 'troisi_andrea_ruolo');
    register_setting('troisi_options', 'troisi_andrea_bio');

    // Dati societari
    register_setting('troisi_options', 'troisi_ragione_sociale');
    register_setting('troisi_options', 'troisi_piva');
    register_setting('troisi_options', 'troisi_rea');
    register_setting('troisi_options', 'troisi_sede_legale');
    register_setting('troisi_options', 'troisi_email');
    register_setting('troisi_options', 'troisi_telefono');
    register_setting('troisi_options', 'troisi_numero_verde');
    register_setting('troisi_options', 'troisi_linkedin');
    register_setting('troisi_options', 'troisi_youtube');
    register_setting('troisi_options', 'troisi_calendly_url');
}
add_action('admin_init', 'troisi_register_settings');

// ═══════════════════════════════════════
// PAGINA SETTINGS
// ═══════════════════════════════════════
function troisi_settings_page() {
    ?>
    <div class="wrap">
        <h1>⚙️ Troisi Ricerche — Impostazioni Tema</h1>
        <p>Modifica i contenuti del sito direttamente da qui. Ogni modifica sarà visibile immediatamente sul sito.</p>

        <form method="post" action="options.php">
            <?php settings_fields('troisi_options'); ?>

            <h2 class="title">🏠 Hero Homepage</h2>
            <table class="form-table">
                <tr><th>Eyebrow</th><td><input type="text" name="troisi_hero_eyebrow" value="<?php echo esc_attr(get_option('troisi_hero_eyebrow', 'Istituto di Ricerca Statistica · Bari · Roma · Milano')); ?>" class="large-text"></td></tr>
                <tr><th>Titolo (HTML)</th><td><textarea name="troisi_hero_title" rows="3" class="large-text"><?php echo esc_textarea(get_option('troisi_hero_title', 'Dati, analisi e modelli<br>per la <em>governance pubblica</em><br>e i servizi ai cittadini')); ?></textarea><p class="description">Puoi usare &lt;br&gt; e &lt;em&gt; per formattare</p></td></tr>
                <tr><th>Sottotitolo</th><td><textarea name="troisi_hero_subtitle" rows="3" class="large-text"><?php echo esc_textarea(get_option('troisi_hero_subtitle', 'Dal 2006 Troisi Ricerche trasforma dati statistici in <strong>conoscenza utile</strong> per enti pubblici, imprese e territori.')); ?></textarea></td></tr>
                <tr><th>Tags (uno per riga)</th><td><textarea name="troisi_hero_tags" rows="4" class="large-text"><?php echo esc_textarea(get_option('troisi_hero_tags', "Ricerca statistica\nCustomer satisfaction PA\nTR-Index 2026\nBenessere organizzativo\nTÜV ISO 9001\nDibattito pubblico")); ?></textarea></td></tr>
            </table>

            <h2 class="title">📊 Numeri Chiave</h2>
            <table class="form-table">
                <tr><th>Anni di attività</th><td><input type="text" name="troisi_num_anni" value="<?php echo esc_attr(get_option('troisi_num_anni', '20+')); ?>" style="width:100px"></td></tr>
                <tr><th>Ricerche realizzate</th><td><input type="text" name="troisi_num_ricerche" value="<?php echo esc_attr(get_option('troisi_num_ricerche', '500+')); ?>" style="width:100px"></td></tr>
                <tr><th>Clienti serviti</th><td><input type="text" name="troisi_num_clienti" value="<?php echo esc_attr(get_option('troisi_num_clienti', '200+')); ?>" style="width:100px"></td></tr>
                <tr><th>Siti del network</th><td><input type="text" name="troisi_num_siti" value="<?php echo esc_attr(get_option('troisi_num_siti', '16')); ?>" style="width:100px"></td></tr>
            </table>

            <h2 class="title">👤 Bio Andrea Troisi</h2>
            <table class="form-table">
                <tr><th>Nome</th><td><input type="text" name="troisi_andrea_nome" value="<?php echo esc_attr(get_option('troisi_andrea_nome', 'Andrea Troisi')); ?>" class="large-text"></td></tr>
                <tr><th>Ruolo</th><td><input type="text" name="troisi_andrea_ruolo" value="<?php echo esc_attr(get_option('troisi_andrea_ruolo', 'Fondatore e Direttore scientifico · Troisi Ricerche · Bari')); ?>" class="large-text"></td></tr>
                <tr><th>Bio</th><td><textarea name="troisi_andrea_bio" rows="6" class="large-text"><?php echo esc_textarea(get_option('troisi_andrea_bio', 'Statistico, ricercatore e autore. Specializzato in customer satisfaction, benessere organizzativo e governance territoriale. Dal 2006 guida Troisi Ricerche con un approccio che coniuga rigore scientifico e concretezza applicativa.')); ?></textarea></td></tr>
            </table>

            <h2 class="title">🏢 Dati Societari e Contatti</h2>
            <table class="form-table">
                <tr><th>Ragione sociale</th><td><input type="text" name="troisi_ragione_sociale" value="<?php echo esc_attr(get_option('troisi_ragione_sociale', 'Troisi Ricerche S.r.l. Unipersonale')); ?>" class="large-text"></td></tr>
                <tr><th>P.IVA</th><td><input type="text" name="troisi_piva" value="<?php echo esc_attr(get_option('troisi_piva', '07216100722')); ?>" style="width:200px"></td></tr>
                <tr><th>REA</th><td><input type="text" name="troisi_rea" value="<?php echo esc_attr(get_option('troisi_rea', 'BA-541094')); ?>" style="width:200px"></td></tr>
                <tr><th>Sede legale</th><td><input type="text" name="troisi_sede_legale" value="<?php echo esc_attr(get_option('troisi_sede_legale', 'Via De Rossi, 57 — 70122 Bari (BA)')); ?>" class="large-text"></td></tr>
                <tr><th>Email</th><td><input type="email" name="troisi_email" value="<?php echo esc_attr(get_option('troisi_email', 'info@troisiricerche.it')); ?>" class="large-text"></td></tr>
                <tr><th>Telefono</th><td><input type="text" name="troisi_telefono" value="<?php echo esc_attr(get_option('troisi_telefono', '+39 080.321.06.01')); ?>" style="width:200px"></td></tr>
                <tr><th>Numero verde</th><td><input type="text" name="troisi_numero_verde" value="<?php echo esc_attr(get_option('troisi_numero_verde', '800 644 046')); ?>" style="width:200px"></td></tr>
                <tr><th>LinkedIn URL</th><td><input type="url" name="troisi_linkedin" value="<?php echo esc_attr(get_option('troisi_linkedin', 'https://www.linkedin.com/company/troisi-ricerche')); ?>" class="large-text"></td></tr>
                <tr><th>YouTube URL</th><td><input type="url" name="troisi_youtube" value="<?php echo esc_attr(get_option('troisi_youtube', 'https://www.youtube.com/@Troisiricerche')); ?>" class="large-text"></td></tr>
                <tr><th>Calendly URL</th><td><input type="url" name="troisi_calendly_url" value="<?php echo esc_attr(get_option('troisi_calendly_url', 'https://calendly.com/andreatroisi/30min')); ?>" class="large-text"></td></tr>
            </table>

            <?php submit_button('💾 Salva tutte le impostazioni'); ?>
        </form>
    </div>
    <?php
}

// ═══════════════════════════════════════
// HELPER: Recupera opzione con fallback
// ═══════════════════════════════════════
function troisi_opt($key, $default = '') {
    return get_option('troisi_' . $key, $default);
}
