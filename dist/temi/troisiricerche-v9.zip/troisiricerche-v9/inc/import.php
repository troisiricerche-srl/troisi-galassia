<?php
/**
 * inc/import.php — Importa dati iniziali nei CPT
 * Eseguito una sola volta da wp-admin → Troisi Ricerche → Importa dati
 */

function troisi_import_page() {
    if (isset($_POST['troisi_do_import']) && check_admin_referer('troisi_import_action')) {
        troisi_run_import();
        echo '<div class="notice notice-success"><p>✅ <strong>Importazione completata!</strong> Tutti i dati sono stati importati nei Custom Post Types. Ora puoi gestirli da questo menu.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>📦 Importa Dati Iniziali</h1>
        <p>Questo strumento importa <strong>una sola volta</strong> tutti i dati hardcoded (team, clienti, certificazioni, sedi, timeline, strumenti) nei Custom Post Types.</p>
        <p>Dopo l'importazione potrai gestire tutto da <strong>⚙️ Troisi Ricerche</strong> nel menu admin.</p>

        <?php
        $already = get_option('troisi_imported', false);
        if ($already): ?>
            <div class="notice notice-warning"><p>⚠️ I dati sono già stati importati il <?php echo esc_html($already); ?>. Se importi di nuovo, i dati verranno duplicati.</p></div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('troisi_import_action'); ?>
            <p><button type="submit" name="troisi_do_import" class="button button-primary button-hero">📦 Importa tutti i dati</button></p>
        </form>

        <h3>Cosa viene importato:</h3>
        <ul style="list-style:disc;padding-left:20px">
            <li>👥 <strong>Team</strong>: 6 membri attivi + 62 collaboratori storici</li>
            <li>🏢 <strong>Clienti</strong>: ~130 clienti con logo e categoria</li>
            <li>🏅 <strong>Certificazioni</strong>: 8 certificazioni/appartenenze</li>
            <li>📍 <strong>Sedi</strong>: 3 sedi (Bari, Roma, Milano)</li>
            <li>📅 <strong>Timeline</strong>: 6 milestone storia aziendale</li>
            <li>🔧 <strong>Strumenti</strong>: 17 siti della Galassia</li>
        </ul>
    </div>
    <?php
}

function troisi_run_import() {
    // ═══ TEAM ATTIVO ═══
    $team = [
        ['nome'=>'Carlo Cusatelli','icona'=>'📐','ruolo'=>'Responsabile Statistico','bio'=>'Ricercatore confermato di Statistica all\'Università di Bari, ricercatore senior FSE e Tecnologo ISTAT. Autore di numerose pubblicazioni di statistica multivariata.','ordine'=>1],
        ['nome'=>'Davide Manganelli','icona'=>'🌐','ruolo'=>'Business Development','bio'=>'Strategic Expansion Consultant con esperienza internazionale. Guida la crescita e lo sviluppo di nuovi mercati.','ordine'=>2],
        ['nome'=>'Brixhilda Lleshi, PhD','icona'=>'📊','ruolo'=>'Project Manager & Data Analyst','bio'=>'Ingegnere Civile specializzata in analisi dati. Coordina i progetti complessi garantendo qualità, tempi e risultati misurabili.','ordine'=>3],
        ['nome'=>'Elena Caramia','icona'=>'🎓','ruolo'=>'Formazione & Coaching','bio'=>'Coach Professionista MCI, Practitioner e Technician in PNL. Formatrice, Orientatrice, Esperta in gestione delle risorse umane e formazione continua.','ordine'=>4],
        ['nome'=>'Debora Cazzetta, PhD','icona'=>'🔬','ruolo'=>'Ricercatore','bio'=>'Data analyst, specialista in semiotica e linguistica, con esperienza ultra-decennale nella qualitative marketing research. Dottore di ricerca.','ordine'=>5],
        ['nome'=>'Stefania Fanelli','icona'=>'💼','ruolo'=>'Account & Administrative Management','bio'=>'Marketing Solutions, PR events. Strong problem solving, diplomacy and team builder skills. Specializzazione in Relazioni Internazionali.','ordine'=>6],
    ];
    foreach ($team as $m) {
        $pid = wp_insert_post(['post_title'=>$m['nome'],'post_type'=>'troisi_team','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_icona', $m['icona']);
        update_post_meta($pid, '_troisi_ruolo', $m['ruolo']);
        update_post_meta($pid, '_troisi_bio', $m['bio']);
        update_post_meta($pid, '_troisi_attivo', '1');
        update_post_meta($pid, '_troisi_ordine', $m['ordine']);
    }

    // ═══ COLLABORATORI STORICI ═══
    $storici = ['Silvia Gravili','Giuseppe Raffaele','Barbara Di Bari','Margherita Console','Gemma Di Poppa','Adriana Fanelli','Fabiana Ferrante','Massimiliano Gaeta','Leonardo Lovecchio','Rossella Vantaggio','Monica Fabiano','Andrea Fistetto','Domenico Ficco','Enza Moscaritolo','Luca Tisselli','Marco Mancarella','Davide Catizone','Raffaele Nitti','Francesco Gismondi','Maria Teresa Digennaro','Stefano Iacovino','Rossella Sgaramella','Eva Cossa','Andrea Picciuolo','Niccolò Accettura','Mattia Caputo','Valentina Battista','Alessia Forciniti','Valeria Elisabetta Volponi','Botelho Rosli de Jesus','Carmela Piccolo','Debora Bettinardi','Denis Damiani','Elide Paoletti','Elisabetta Battista','Felicia Risci','Franca Vigolo','Roberto Leone','Silvia Bettinardi','Giuseppe Remine','Ivan Remine','Paolo Inno','Paolo Binetti','Giacomo Carreras','Alessandro Cafagno','Daniele Leuzzi','Giuseppe Rubino','Andrea Belcredi','Daniele Cavallo','Elena Ciliberti','Salvatore Alì','Saverio De Bellis','Simone Bottalico','Vera Ciliberti','Diana Sanna','Ornella La Tegola','Mariateresa Caldarola','Andrea Venturelli','Nicola D\'Elia','Manuela Mirizzi','Francesca Traldi'];
    foreach ($storici as $i => $nome) {
        $pid = wp_insert_post(['post_title'=>$nome,'post_type'=>'troisi_team','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_attivo', '0');
        update_post_meta($pid, '_troisi_ordine', $i + 10);
        update_post_meta($pid, '_troisi_icona', '👤');
        update_post_meta($pid, '_troisi_ruolo', '');
        update_post_meta($pid, '_troisi_bio', '');
    }

    // ═══ CLIENTI ═══
    $clienti = [
        ['nome'=>'Presidenza Consiglio','file'=>'Presidenza_Consiglio.jpg','cat'=>'pa','hp'=>1],
        ['nome'=>'Ministero Interno','file'=>'ministero Interno.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Ministero Lavoro','file'=>'ministero_lavoro_politiche_sociali.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'MIMIT','file'=>'ministero_sviluppo_economico.jpg','cat'=>'pa','hp'=>1],
        ['nome'=>'Ministero Infrastrutture','file'=>'ministro-infrastrutture-e-trasporti.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Regione Puglia','file'=>'Regione-Puglia.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Regione Lombardia','file'=>'RegioneLombardia.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Regione Toscana','file'=>'Regione Toscana.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Regione Liguria','file'=>'regione liguria.jpg','cat'=>'pa','hp'=>1],
        ['nome'=>'Regione Molise','file'=>'regione molise.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Comune di Bari','file'=>'Comune Bari.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Comune di Genova','file'=>'Comune di Genova.png','cat'=>'pa','hp'=>0],
        ['nome'=>'Puglia Sviluppo','file'=>'PugliaSviluppo.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'ARTI Puglia','file'=>'arti puglia.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Corecom','file'=>'Corecom.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'ISFOL','file'=>'Isfol.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'AQP','file'=>'AqP.png','cat'=>'trasporti','hp'=>0],
        ['nome'=>'Aeroporti di Puglia','file'=>'Aeroporti di Puglia.png','cat'=>'trasporti','hp'=>0],
        ['nome'=>'Autorità Portuale Bari','file'=>'Autorita Portuale Bari.jpg','cat'=>'trasporti','hp'=>1],
        ['nome'=>'Lamezia Aeroporto','file'=>'Lamezia_Aeroporto.jpeg','cat'=>'trasporti','hp'=>0],
        ['nome'=>'Trieste Trasporti','file'=>'Trieste Trasporti.jpg','cat'=>'trasporti','hp'=>0],
        ['nome'=>'SVT Vicenza','file'=>'SVT Vicenza.png','cat'=>'trasporti','hp'=>0],
        ['nome'=>'AMIU Bari','file'=>'amiu-bari.jpg','cat'=>'trasporti','hp'=>0],
        ['nome'=>'AMTAB','file'=>'amtab.jpg','cat'=>'trasporti','hp'=>0],
        ['nome'=>'MSC Crociere','file'=>'MSC.jpg','cat'=>'trasporti','hp'=>1],
        ['nome'=>'Energit','file'=>'Energit.jpg','cat'=>'trasporti','hp'=>0],
        ['nome'=>'UniBa','file'=>'uniba.jpg','cat'=>'universita','hp'=>1],
        ['nome'=>'UniBO','file'=>'Unibo.png','cat'=>'universita','hp'=>1],
        ['nome'=>'Politecnico di Bari','file'=>'politecnico-di-bari.jpg','cat'=>'universita','hp'=>0],
        ['nome'=>'UniSalento','file'=>'unisalento.jpg','cat'=>'universita','hp'=>0],
        ['nome'=>'Uni Basilicata','file'=>'università basilicata.jpg','cat'=>'universita','hp'=>0],
        ['nome'=>'CNR','file'=>'cnr.jpg','cat'=>'universita','hp'=>1],
        ['nome'=>'Confindustria Puglia','file'=>'confindustria puglia.jpg','cat'=>'imprese','hp'=>1],
        ['nome'=>'Federalberghi','file'=>'Federalberghi.jpg','cat'=>'cultura','hp'=>1],
        ['nome'=>'Ipercoop','file'=>'ipercoop.jpg','cat'=>'imprese','hp'=>1],
        ['nome'=>'Fiera del Levante','file'=>'fiera-del-levante-bari.jpg','cat'=>'cultura','hp'=>1],
        ['nome'=>'Ladisa','file'=>'ladisa.jpg','cat'=>'imprese','hp'=>0],
        ['nome'=>'UNESCO','file'=>'UNESCO.jpg','cat'=>'cultura','hp'=>0],
        ['nome'=>'Codacons','file'=>'codacons.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Cittadinanzattiva','file'=>'cittadinanza_attiva.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Adiconsum','file'=>'adiconsum.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Federconsumatori','file'=>'federconsumatori.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Confconsumatori','file'=>'confconsumatori.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Lega Consumatori','file'=>'lega_consumatori.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'ADOC Puglia','file'=>'adoc_puglia.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Adusbef','file'=>'adusbef.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Movimento Consumatori','file'=>'movimento_consumatori.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'Movimento Difesa Cittadino','file'=>'movimento_difesa_cittadino.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'UNC','file'=>'unione_nazionale_consumatori.jpg','cat'=>'consumatori','hp'=>0],
        ['nome'=>'CCIAA Padova','file'=>'Camera commercio padova.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'ESU Padova','file'=>'ESU Padova.png','cat'=>'universita','hp'=>0],
        ['nome'=>'Eupolis','file'=>'Eupolis.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'ERSAF','file'=>'Ersaf.jpg','cat'=>'pa','hp'=>0],
        ['nome'=>'Locus Festival','file'=>'Locus Festival 2018.jpg','cat'=>'cultura','hp'=>0],
        ['nome'=>'Oropan','file'=>'oropan.jpg','cat'=>'imprese','hp'=>0],
        ['nome'=>'Primadonna','file'=>'Primadonna.jpg','cat'=>'imprese','hp'=>0],
        ['nome'=>'Pescaria','file'=>'Pescaria.png','cat'=>'imprese','hp'=>0],
    ];
    foreach ($clienti as $i => $c) {
        $pid = wp_insert_post(['post_title'=>$c['nome'],'post_type'=>'troisi_cliente','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_logo_file', $c['file']);
        update_post_meta($pid, '_troisi_cat', $c['cat']);
        update_post_meta($pid, '_troisi_in_homepage', $c['hp'] ? '1' : '0');
        update_post_meta($pid, '_troisi_ordine', $i);
    }

    // ═══ CERTIFICAZIONI ═══
    $certs = [
        ['nome'=>'TÜV ISO 9001:2015','logo'=>'img/loghi/tuv.jpeg','desc'=>'Sistema di gestione qualità certificato'],
        ['nome'=>'SIS · Società Italiana di Statistica','logo'=>'img/loghi/sis.png','desc'=>'Ente aderente alla società scientifica'],
        ['nome'=>'Confindustria Bari e BAT','logo'=>'img/loghi/confindustria.jpg','desc'=>'Associato Confindustria'],
        ['nome'=>'ISI · International Statistical Institute','logo'=>'img/loghi/isi.png','desc'=>'Membro ISI'],
        ['nome'=>'AMS · American Mathematical Society','logo'=>'img/loghi/ams_logo.jpg','desc'=>'Membro AMS'],
        ['nome'=>'Google Advanced Data Analytics','logo'=>'img/loghi/google-analytics.jpg','desc'=>'Certificazione Google'],
        ['nome'=>'HubSpot Academy','logo'=>'img/loghi/hubspot.png','desc'=>'Certificazione HubSpot'],
        ['nome'=>'MIUR · Ente Accreditato','logo'=>'img/loghi/miur.png','desc'=>'Formazione accreditata MIUR'],
    ];
    foreach ($certs as $i => $c) {
        $pid = wp_insert_post(['post_title'=>$c['nome'],'post_type'=>'troisi_cert','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_cert_logo', $c['logo']);
        update_post_meta($pid, '_troisi_cert_desc', $c['desc']);
        update_post_meta($pid, '_troisi_ordine', $i);
    }

    // ═══ SEDI ═══
    $sedi = [
        ['nome'=>'Bari','icona'=>'🏛️','ruolo'=>'Sede principale · Direzione scientifica','info'=>'Via De Rossi, 57<br>70122 Bari (BA)<br>+39 080.321.06.01'],
        ['nome'=>'Roma','icona'=>'🏟️','ruolo'=>'Sede operativa · PA nazionale','info'=>'Via Dodecaneso, 3<br>00144 Roma (RM)<br>Ministeri · Forum PA · ANAC'],
        ['nome'=>'Milano','icona'=>'🏙️','ruolo'=>'Sede operativa · Imprese','info'=>'Via Montenapoleone, 8<br>20121 Milano (MI)<br>Confindustria · Fondi interprofessionali'],
    ];
    foreach ($sedi as $i => $s) {
        $pid = wp_insert_post(['post_title'=>$s['nome'],'post_type'=>'troisi_sede','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_sede_icona', $s['icona']);
        update_post_meta($pid, '_troisi_sede_ruolo', $s['ruolo']);
        update_post_meta($pid, '_troisi_sede_info', $s['info']);
        update_post_meta($pid, '_troisi_ordine', $i);
    }

    // ═══ TIMELINE ═══
    $tl = [
        ['anno'=>'2006','titolo'=>'Fondazione di Troisi Ricerche','desc'=>'Andrea Troisi fonda l\'istituto a Bari. Prime ricerche sulla customer satisfaction nelle pubbliche amministrazioni pugliesi.','ev'=>0],
        ['anno'=>'2010','titolo'=>'Espansione nazionale e certificazione ISO','desc'=>'Apertura sede operativa a Roma. Prima certificazione TÜV ISO 9001. Avvio delle collaborazioni con ministeri e regioni.','ev'=>0],
        ['anno'=>'2014','titolo'=>'Pubblicazione del libro e modello proprietario','desc'=>'"La Customer Satisfaction nei servizi pubblici" (Cacucci Editore). Formalizzazione del modello statistico integrato.','ev'=>0],
        ['anno'=>'2018','titolo'=>'Lancio del TR-Index e del network','desc'=>'Nasce il TR-Index — indice proprietario per la misurazione delle performance territoriali. Avvio dell\'ecosistema satellite.','ev'=>0],
        ['anno'=>'2021','titolo'=>'Troisi Ricerche e dibattito pubblico','desc'=>'Lancio della piattaforma con TenderCoop e Ti Quadro. Troisi Ricerche entra nel mondo della governance infrastrutturale.','ev'=>0],
        ['anno'=>'2026','titolo'=>'Oggi: +200 clienti, network completo','desc'=>'Un ecosistema maturo con strumenti per ogni area della governance pubblica.','ev'=>1],
    ];
    foreach ($tl as $t) {
        $pid = wp_insert_post(['post_title'=>$t['titolo'],'post_type'=>'troisi_timeline','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_anno', $t['anno']);
        update_post_meta($pid, '_troisi_tl_desc', $t['desc']);
        update_post_meta($pid, '_troisi_tl_evidenza', $t['ev'] ? '1' : '0');
    }

    // ═══ STRUMENTI / GALASSIA ═══
    $strumenti = [
        ['nome'=>'Troisi Ricerche','icona'=>'🏛️','desc'=>'Hub · sei qui','url'=>'https://troisiricerche.net','url_int'=>'/','gal'=>1,'hp'=>0,'ord'=>0],
        ['nome'=>'Andrea Troisi','icona'=>'👤','desc'=>'Sito personale','url'=>'https://andreatroisi.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>1],
        ['nome'=>'TR-Index','icona'=>'📐','desc'=>'Ranking territori','url'=>'https://t-index.it','url_int'=>'/strumenti/t-index','gal'=>1,'hp'=>1,'ord'=>2],
        ['nome'=>'Mappatura Competenze','icona'=>'🗺️','desc'=>'Mappatura competenze','url'=>'https://mappaturadellecompetenze.it','url_int'=>'/strumenti/skillprint','gal'=>1,'hp'=>0,'ord'=>3],
        ['nome'=>'Registro Competenze','icona'=>'📜','desc'=>'Registro EQF','url'=>'https://registrodellecompetenze.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>4],
        ['nome'=>'CustomerPA','icona'=>'😊','desc'=>'CS servizi pubblici','url'=>'https://customerpa.it','url_int'=>'/strumenti/customerpa','gal'=>1,'hp'=>0,'ord'=>5],
        ['nome'=>'BenessereOrg.','icona'=>'🧠','desc'=>'Clima PA','url'=>'https://benessereorganizzativo.it','url_int'=>'/strumenti/benessere-organizzativo','gal'=>1,'hp'=>0,'ord'=>6],
        ['nome'=>'Formazione','icona'=>'📚','desc'=>'Hub formativo','url'=>'https://troisiformazione.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>7],
        ['nome'=>'TIP Platform','icona'=>'⚡','desc'=>'Survey e polling','url'=>'https://tiplive.it','url_int'=>'/strumenti/tip-platform','gal'=>1,'hp'=>1,'ord'=>8],
        ['nome'=>'TroisiInsight','icona'=>'📊','desc'=>'Grafici e dati','url'=>'https://troisiinsight.it','url_int'=>'/strumenti/troisiinsight','gal'=>1,'hp'=>0,'ord'=>9],
        ['nome'=>'DigitalizzazionePA','icona'=>'💻','desc'=>'PA digitale','url'=>'https://www.digitalizzazionenellapa.it','url_int'=>'/strumenti/digitalizzazione-pa','gal'=>1,'hp'=>0,'ord'=>10],
        ['nome'=>'Dibattito Pubblico','icona'=>'🏗️','desc'=>'Infrastrutture','url'=>'https://dibattito-pubblico.it','url_int'=>'/strumenti/dibattito-pubblico','gal'=>1,'hp'=>1,'ord'=>11],
        ['nome'=>'VoiceInHub','icona'=>'🎙️','desc'=>'Podcast','url'=>'https://voiceinhub.it','url_int'=>'/strumenti/voiceinhub','gal'=>1,'hp'=>0,'ord'=>12],
        ['nome'=>'Governance Fin.','icona'=>'💼','desc'=>'ESG e governance','url'=>'https://governancefinanziaria.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>13],
        ['nome'=>'Internazionaliz.','icona'=>'🌍','desc'=>'Export e mercati','url'=>'https://consulenzainternazionalizzazione.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>14],
        ['nome'=>'BDG','icona'=>'📱','desc'=>'Benessere digitale','url'=>'https://benesseredigitalegiovani.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>15],
        ['nome'=>'Sveglia Digitale','icona'=>'⏰','desc'=>'Consapevolezza','url'=>'https://svegliadigitale.it','url_int'=>'','gal'=>1,'hp'=>0,'ord'=>16],
    ];
    foreach ($strumenti as $s) {
        $pid = wp_insert_post(['post_title'=>$s['nome'],'post_type'=>'troisi_strumento','post_status'=>'publish']);
        update_post_meta($pid, '_troisi_str_icona', $s['icona']);
        update_post_meta($pid, '_troisi_str_desc', $s['desc']);
        update_post_meta($pid, '_troisi_str_url', $s['url']);
        update_post_meta($pid, '_troisi_str_url_int', $s['url_int']);
        update_post_meta($pid, '_troisi_str_galassia', $s['gal'] ? '1' : '0');
        update_post_meta($pid, '_troisi_str_homepage', $s['hp'] ? '1' : '0');
        update_post_meta($pid, '_troisi_ordine', $s['ord']);
    }

    update_option('troisi_imported', date('d/m/Y H:i'));
}
