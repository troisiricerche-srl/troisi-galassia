<?php
/**
 * 10.3.0 – Apertura della home: «Misuriamo [parola che cambia]» con il numero a puntini.
 * Per gli osservatori il numero è l'ultimo dato pubblicato (letto dal sito d'origine, aggiornato ogni 6 ore
 * in background); per i prodotti senza dato settimanale i puntini compongono la sigla.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** I temi dell'apertura. h = sito da cui leggere l'ultimo dato (vuoto = prodotto con sigla fissa). */
function tr_home_temi_base() {
	return array(
		array( 'p' => 'la soddisfazione dei cittadini', 'n' => 'CPA', 'm' => 'CustomerPA™', 'd' => 'Indagini di customer satisfaction per le pubbliche amministrazioni, dal questionario al report.', 'x' => 'customerpa.it', 'u' => 'https://www.customerpa.it/', 'h' => '' ),
		array( 'p' => 'il benessere organizzativo', 'n' => '47,3%', 'm' => 'Benessere organizzativo', 'd' => 'Benessere organizzativo, stress lavoro-correlato e rischio psicosociale nelle organizzazioni.', 'x' => '47,3% dei lavoratori delle grandi unità produttive è esposto a rischi psicosociali', 'u' => 'https://www.benessereorganizzativo.it/rischi-psicosociali-dimensione-azienda-settore/', 'h' => 'benessereorganizzativo.it' ),
		array( 'p' => 'le competenze', 'n' => '8,2%', 'm' => 'Mappatura delle Competenze', 'd' => 'Mappatura e Registro delle Competenze: cosa sanno fare le persone, misurato e certificabile.', 'x' => '8,2% dei giovani 18-24 anni ha lasciato precocemente gli studi', 'u' => 'https://www.mappaturadellecompetenze.it/2026/10/11/abbandoni-precoci-istruzione-italia-2025/', 'h' => 'mappaturadellecompetenze.it' ),
		array( 'p' => 'i dati in tempo reale', 'n' => 'TIP', 'm' => 'TIP · Troisi Intelligence Platform', 'd' => 'La nostra piattaforma: i risultati delle indagini consultabili in tempo reale.', 'x' => 'tiplive.it', 'u' => 'https://www.tiplive.it/', 'h' => '' ),
		array( 'p' => "l'economia", 'n' => '6,2%', 'm' => 'TroisiInsight', 'd' => "Ogni lunedì un'analisi sui grandi temi dell'economia italiana e internazionale.", 'x' => '6,2% la disoccupazione in Italia ad agosto 2026', 'u' => 'https://www.troisiinsight.it/2026/10/12/disoccupazione-agosto-2026-italia-6-2-per-cento/', 'h' => 'troisiinsight.it' ),
		array( 'p' => 'i territori', 'n' => 'TR', 'm' => 'TR-Index', 'd' => 'La classifica dei territori italiani costruita su indicatori statistici.', 'x' => 't-index.it', 'u' => 'https://www.t-index.it/', 'h' => '' ),
		array( 'p' => 'i comuni italiani', 'n' => '7.896', 'm' => 'DELFI · intelligence territoriale', 'd' => 'La piattaforma con i dati di tutti i comuni italiani: amministratori, fondi europei, rischio idrogeologico, imprese, servizi.', 'x' => '7.896 comuni italiani, tutti, in un solo posto', 'u' => 'https://www.delfiweb.it/', 'h' => '' ),
		array( 'p' => 'la PA digitale', 'n' => '1,6%', 'm' => 'Digitalizzazione nella PA', 'd' => 'Osservatorio sulla trasformazione digitale delle pubbliche amministrazioni.', 'x' => '1,6% dei titoli terziari italiani è in ICT, contro il 5,0% UE', 'u' => 'https://www.digitalizzazionenellapa.it/2026/10/08/laureati-ict-titoli-terziari-italia-europa/', 'h' => 'digitalizzazionenellapa.it' ),
		array( 'p' => 'i giovani', 'n' => '24,4%', 'm' => 'Benessere digitale giovani', 'd' => 'Osservatorio sul benessere digitale dei giovani, ogni sabato su dati ufficiali.', 'x' => '24,4% dei quindicenni italiani è sotto la soglia minima in lettura (PISA 2025)', 'u' => 'https://www.benesseredigitalegiovani.it/pisa-2025-in-lettura-e-sotto-la-soglia-minima-il-244-dei-quindicenni-italiani-contro-il-313-in-ue/', 'h' => 'benesseredigitalegiovani.it' ),
		array( 'p' => 'il dibattito pubblico', 'n' => '0,19%', 'm' => 'Dibattito pubblico', 'd' => 'Osservatorio sul dibattito pubblico nelle grandi opere e sulle scelte di spesa.', 'x' => "0,19% del PIL in investimenti pubblici per l'ambiente, sopra lo 0,16% UE", 'u' => 'https://www.dibattito-pubblico.it/2026/10/09/investimenti-pubblici-protezione-ambiente-italia/', 'h' => 'dibattito-pubblico.it' ),
	);
}

/** Primo numero «da copertina» nel titolo: prima le percentuali, poi gli altri numeri (anni esclusi). */
function tr_home_numero( $t ) {
	if ( preg_match( '/([+\-−]?\d{1,3}(?:,\d+)?)\s+per\s?cento/iu', $t, $m ) ) {
		return str_replace( '-', '−', $m[1] ) . '%';
	}
	if ( preg_match( '/[+\-−]?\d{1,3}(?:[.,]\d+)?\s?%/u', $t, $m ) ) {
		return str_replace( array( ' %', '-' ), array( '%', '−' ), $m[0] );
	}
	if ( preg_match_all( '/[+\-−]?\d{1,3}(?:\.\d{3})+|[+\-−]?\d+(?:,\d+)?/u', $t, $mm ) ) {
		foreach ( $mm[0] as $n ) {
			$p = ltrim( $n, '+-−' );
			if ( preg_match( '/^(19|20)\d\d$/', $p ) || '0' === $p ) {
				continue;
			}
			return str_replace( '-', '−', $n );
		}
	}
	return '';
}

/** Legge l'ultimo articolo con un numero nel titolo da ogni osservatorio. Gira in background (evento singolo). */
function tr_home_temi_aggiorna() {
	$temi = tr_home_temi_base();
	foreach ( $temi as $i => $t ) {
		if ( ! $t['h'] ) {
			continue;
		}
		$url = add_query_arg( array( 'rest_route' => '/wp/v2/posts', 'per_page' => 8, '_fields' => 'title,link' ), 'https://www.' . $t['h'] . '/' );
		$r   = wp_remote_get( $url, array( 'timeout' => 10 ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			continue;
		}
		foreach ( (array) json_decode( wp_remote_retrieve_body( $r ), true ) as $p ) {
			if ( empty( $p['title']['rendered'] ) || empty( $p['link'] ) ) {
				continue;
			}
			$titolo = trim( html_entity_decode( wp_strip_all_tags( $p['title']['rendered'] ), ENT_QUOTES, 'UTF-8' ) );
			$n      = tr_home_numero( $titolo );
			if ( '' === $n ) {
				continue;
			}
			$temi[ $i ]['n'] = $n;
			$temi[ $i ]['x'] = $titolo;
			$temi[ $i ]['u'] = esc_url_raw( $p['link'] );
			break;
		}
	}
	set_transient( 'tr_home_temi', $temi, 6 * HOUR_IN_SECONDS );
}
add_action( 'tr_home_temi_aggiorna', 'tr_home_temi_aggiorna' );

/** I temi da mostrare: quelli aggiornati se ci sono, altrimenti i valori di base (e si chiede un aggiornamento). */
function tr_home_temi() {
	$t = get_transient( 'tr_home_temi' );
	if ( is_array( $t ) && $t ) {
		return $t;
	}
	if ( ! wp_next_scheduled( 'tr_home_temi_aggiorna' ) ) {
		wp_schedule_single_event( time() + 5, 'tr_home_temi_aggiorna' );
	}
	return tr_home_temi_base();
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! is_front_page() ) {
		return;
	}
	$d = get_template_directory();
	$u = get_template_directory_uri();
	wp_enqueue_style( 'tr-home-2026', $u . '/assets/home-2026.css', array( 'troisi-skin' ), filemtime( $d . '/assets/home-2026.css' ) );
	wp_enqueue_script( 'tr-home-2026', $u . '/assets/home-2026.js', array(), filemtime( $d . '/assets/home-2026.js' ), true );
}, 30 );

/** I siti della galassia per pubblico, con il loro indirizzo. */
function tr_home_porte() {
	return array(
		array(
			't' => 'Per la pubblica amministrazione',
			'd' => 'Soddisfazione dei cittadini, benessere organizzativo e rischio psicosociale, competenze del personale, servizi digitali, dati sui comuni.',
			's' => array( 'CustomerPA™' => 'customerpa.it', 'DELFI' => 'delfiweb.it', 'Benessere organizzativo' => 'benessereorganizzativo.it', 'Mappatura delle Competenze' => 'mappaturadellecompetenze.it', 'Digitalizzazione nella PA' => 'digitalizzazionenellapa.it', 'Dibattito pubblico' => 'dibattito-pubblico.it' ),
		),
		array(
			't' => 'Per le imprese',
			'd' => "Ricerche di mercato e qualitative, competenze certificabili, export e finanza d'impresa, risultati in tempo reale.",
			's' => array( 'Ricerche di mercato' => 'ricerchedimercato.eu', 'Ricerche qualitative' => 'ricerchequalitative.it', 'Registro delle Competenze' => 'registrodellecompetenze.it', 'Internazionalizzazione' => 'consulenzainternazionalizzazione.it', 'Governance finanziaria' => 'governancefinanziaria.it', 'TIP' => 'tiplive.it' ),
		),
		array(
			't' => 'Per istituzioni e territori',
			'd' => 'Dati su tutti i comuni, classifiche territoriali, osservatori su economia, giovani e Mezzogiorno, la rubrica settimanale dei numeri che contano.',
			's' => array( 'DELFI' => 'delfiweb.it', 'TR-Index' => 't-index.it', 'TroisiInsight' => 'troisiinsight.it', 'Benessere digitale giovani' => 'benesseredigitalegiovani.it', 'Osservatorio Mezzogiorno' => 'osservatoriomezzogiorno.net', 'Il dato è tratto™' => 'ildatoetratto.it' ),
		),
	);
}
