<?php get_header(); ?>
<?php $current_page = 'home'; include(get_template_directory().'/troisi-nav.php'); ?>
<?php $_td = get_template_directory_uri(); ?>

<style>
/* ═══════════════════════════════════════
   HOMEPAGE — HERO
   ═══════════════════════════════════════ */
.hero{background:var(--dp);color:#fff;padding:52px 24px 44px}
.hero-in{max-width:var(--max-w);margin:0 auto;display:grid;grid-template-columns:1fr 300px;gap:36px;align-items:center}
.h-ey{font-size:10px;text-transform:uppercase;letter-spacing:.12em;color:rgba(255,255,255,.38);font-weight:700;margin-bottom:12px;display:flex;align-items:center;gap:10px}
.h-ey::before{content:'';display:inline-block;width:22px;height:2px;background:var(--blu);flex-shrink:0}
.hero h1{font-size:28px;font-weight:700;line-height:1.15;margin-bottom:12px}
.hero h1 em{color:var(--or);font-style:normal}
.hero p{font-size:13.5px;color:rgba(255,255,255,.68);line-height:1.8;margin-bottom:20px;max-width:520px}
.hero p strong{color:#fff}
.h-btns{display:flex;gap:9px;margin-bottom:20px;flex-wrap:wrap}
.bp{background:var(--blu);color:#fff;padding:10px 20px;border-radius:var(--r);font-size:12.5px;font-weight:700;display:inline-block;transition:background .15s var(--ease)}
.bp:hover{background:var(--bl);color:var(--dp)}
.bs{color:#fff;padding:10px 20px;border-radius:var(--r);font-size:12.5px;font-weight:600;border:1.5px solid rgba(255,255,255,.25);display:inline-block;transition:all .15s var(--ease)}
.bs:hover{border-color:#fff;color:#fff}
.h-tags{display:flex;gap:5px;flex-wrap:wrap}
.ht{font-size:10px;padding:3px 9px;border-radius:2px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.11);color:rgba(255,255,255,.65)}
.ht.g{background:rgba(232,160,32,.11);border-color:rgba(232,160,32,.22);color:var(--or)}

/* Hero numeri box */
.hn{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:var(--r);padding:20px}
.hn-t{font-size:9px;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.27);font-weight:700;margin-bottom:12px}
.hn-g{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.hn-s{border-left:2px solid var(--blu);padding-left:9px}
.hn-v{font-size:22px;font-weight:700;color:#fff;line-height:1}
.hn-l{font-size:9.5px;color:rgba(255,255,255,.42);margin-top:2px;line-height:1.3}
.hn-div{height:1px;background:rgba(255,255,255,.07);margin:12px 0}
.hn-cs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px}
.hn-c{font-size:8.5px;font-weight:700;padding:2px 7px;border-radius:2px;background:rgba(255,255,255,.06);color:rgba(255,255,255,.46);border:1px solid rgba(255,255,255,.09)}
.hn-sedi{display:flex;flex-direction:column;gap:3px}
.hn-sede{font-size:9.5px;color:rgba(255,255,255,.35);display:flex;align-items:center;gap:6px}
.hn-sede::before{content:'';display:inline-block;width:5px;height:5px;background:var(--blu);border-radius:50%;flex-shrink:0}

@media(max-width:900px){
  .hero-in{grid-template-columns:1fr;gap:24px}
  .hn{max-width:400px}
}
@media(max-width:600px){
  .hero{padding:36px 16px 32px}
  .hero h1{font-size:22px}
  .hero p{font-size:12.5px}
  .hn-g{gap:8px}
  .hn-v{font-size:18px}
}

/* ═══════════════════════════════════════
   CHI SIAMO anteprima
   ═══════════════════════════════════════ */
.s-t{font-size:20px;font-weight:700;color:var(--t);margin-bottom:8px}
.s-t em{color:var(--blu);font-style:normal}
.s-d{font-size:13.5px;color:var(--g);line-height:1.7;margin-bottom:20px;max-width:640px}
.andrea-box{display:flex;gap:20px;align-items:flex-start;background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;margin-bottom:20px}
.andrea-foto{width:100px;height:100px;border-radius:50%;object-fit:cover;flex-shrink:0;border:3px solid var(--bl)}
.andrea-name{font-size:15px;font-weight:700;color:var(--dp);margin-bottom:2px}
.andrea-role{font-size:11px;color:var(--blu);font-weight:600;margin-bottom:8px}
.andrea-bio{font-size:12.5px;color:var(--g);line-height:1.7}
.andrea-bio em{font-style:italic;color:var(--t)}

.cs-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.cs-card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;transition:box-shadow .2s var(--ease)}
.cs-card:hover{box-shadow:var(--shadow-md)}
.cs-icon{font-size:24px;margin-bottom:8px}
.cs-title{font-size:14px;font-weight:700;color:var(--dp);margin-bottom:6px}
.cs-desc{font-size:12.5px;color:var(--g);line-height:1.6;margin-bottom:12px}

@media(max-width:900px){.cs-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){
  .andrea-box{flex-direction:column;align-items:center;text-align:center}
  .andrea-foto{width:80px;height:80px}
  .cs-grid{grid-template-columns:1fr}
  .s-t{font-size:18px}
}

/* ═══════════════════════════════════════
   NOTIZIE
   ═══════════════════════════════════════ */
.news-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.nc{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);overflow:hidden;transition:box-shadow .2s var(--ease)}
.nc:hover{box-shadow:var(--shadow-md)}
.nc-bar{padding:8px 16px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}
.cat-r{background:#E8F0FE;color:var(--blu)}
.cat-g{background:#E8F5E9;color:var(--vd)}
.cat-m{background:#FFF3E0;color:#E65100}
.cat-d{background:#F3E5F5;color:#7B1FA2}
.cat-e{background:#ECEFF1;color:#455A64}
.nc-b{padding:16px}
.nc-data{font-size:10px;color:var(--g);margin-bottom:6px}
.nc-title{font-size:14px;font-weight:700;color:var(--dp);line-height:1.3;margin-bottom:8px}
.nc-desc{font-size:12.5px;color:var(--g);line-height:1.6;margin-bottom:10px}
.nc-link{font-size:11.5px;font-weight:700;color:var(--blu)}

@media(max-width:900px){.news-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.news-grid{grid-template-columns:1fr}}

/* ═══════════════════════════════════════
   FEED GALASSIA
   ═══════════════════════════════════════ */
.bk-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.bk-card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;display:flex;flex-direction:column;gap:14px}
.bk-top{display:flex;gap:18px;align-items:flex-start}
.bk-cov{width:120px;flex-shrink:0;border-radius:var(--r);box-shadow:var(--shadow-md)}
.bk-badge{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--or);margin-bottom:6px}
.bk-info h3{font-size:17px;font-weight:700;color:var(--dp);line-height:1.3;margin:0 0 4px}
.bk-sub{font-size:13px;font-style:italic;color:var(--g);margin-bottom:8px}
.bk-info p{font-size:12.5px;color:var(--g);line-height:1.6;margin:0 0 8px}
.bk-meta{font-size:11px;color:var(--g)}
.bk-parl{background:var(--dp);border-radius:var(--r);padding:14px;color:#fff}
.bk-parl-h{display:flex;justify-content:space-between;gap:10px;font-size:11px;font-weight:700;color:var(--or);text-transform:uppercase;letter-spacing:.05em}
.bk-parl-ist{color:#fff}
.bk-parl-l{font-size:11.5px;color:rgba(255,255,255,.6);margin:3px 0 10px}
.bk-ph{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.bk-ph2{grid-template-columns:repeat(2,1fr)}
.bk-ph figure{margin:0}
.bk-ph img{width:100%;height:110px;object-fit:cover;border-radius:3px;display:block}
.bk-parl-t{font-size:12px;color:rgba(255,255,255,.72);line-height:1.6;margin:10px 0 0}
@media(max-width:900px){.bk-grid{grid-template-columns:1fr}}
@media(max-width:600px){.bk-top{flex-direction:column;align-items:center;text-align:center}.bk-ph{grid-template-columns:1fr 1fr}}
.net-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
.net-card{display:flex;flex-direction:column;background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);overflow:hidden;color:inherit;transition:box-shadow .2s var(--ease),transform .2s var(--ease)}
.net-card:hover{box-shadow:var(--shadow-md);transform:translateY(-2px);color:inherit}
.net-first{grid-column:span 2;grid-row:span 2}
.net-first .net-img{aspect-ratio:16/9}
.net-img{aspect-ratio:3/2;overflow:hidden;background:var(--bl)}
.net-img img{width:100%;height:100%;object-fit:cover}
html body .net-img.net-svg{background:#fff;border-bottom:3px solid var(--bl);padding:10px 12px;display:flex;align-items:center;justify-content:center}
html body .net-img.net-svg svg{width:100%;height:100%;display:block}
.net-b{padding:14px 16px 16px;display:flex;flex-direction:column;gap:6px;flex:1}
.net-src{display:flex;align-items:center;gap:6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--dp)}
.net-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.net-date{margin-left:auto;font-weight:500;text-transform:none;letter-spacing:0;color:var(--g)}
.net-tit{font-size:14px;font-weight:700;color:var(--dp);line-height:1.3}
.net-first .net-tit{font-size:20px}
.net-txt{font-size:13px;color:var(--g);line-height:1.6}
.net-go{margin-top:auto;font-size:11px;font-weight:700;color:var(--blu)}
@media(max-width:1000px){.net-grid{grid-template-columns:repeat(2,1fr)}.net-first{grid-row:auto}}
@media(max-width:600px){.net-grid{grid-template-columns:1fr}.net-first{grid-column:auto}.net-first .net-img{aspect-ratio:3/2}}
.feed-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.fc-card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);overflow:hidden;transition:box-shadow .2s var(--ease)}
.fc-card:hover{box-shadow:var(--shadow-md)}
.fc-h{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid var(--bo);background:var(--bg)}
.fc-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.fc-src{font-size:12px;font-weight:700;color:var(--dp);flex:1}
.fc-live{font-size:8px;font-weight:800;letter-spacing:.1em;padding:2px 6px;border-radius:2px;background:rgba(0,135,88,.1);color:var(--vd);border:1px solid rgba(0,135,88,.2)}
.fc-b{padding:16px}
.fc-lbl{font-size:9.5px;text-transform:uppercase;letter-spacing:.06em;color:var(--g);font-weight:600;margin-bottom:4px}
.fc-tit{font-size:14px;font-weight:700;color:var(--dp);margin-bottom:6px;line-height:1.3}
.fc-txt{font-size:12.5px;color:var(--g);line-height:1.6;margin-bottom:10px}
.fc-links{display:flex;gap:8px;flex-wrap:wrap}

.fc-vbox{display:flex;gap:12px;align-items:center;background:var(--bg);padding:10px 16px;border-top:1px solid var(--bo)}
.fvp{width:44px;height:44px;background:var(--dp);border-radius:var(--r);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.fvp-i{width:0;height:0;border-left:12px solid #fff;border-top:7px solid transparent;border-bottom:7px solid transparent;margin-left:3px}
.fvt{font-size:11.5px;color:var(--g);line-height:1.4}
.fvt strong{display:block;color:var(--dp);font-size:12px;margin-bottom:2px}

@media(max-width:900px){.feed-grid{grid-template-columns:1fr}}

/* ═══════════════════════════════════════
   STRUMENTI
   ═══════════════════════════════════════ */
.tools-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.tool{display:flex;gap:14px;align-items:flex-start;background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;transition:box-shadow .2s var(--ease)}
.tool:hover{box-shadow:var(--shadow-md)}
.tool-icon{font-size:28px;flex-shrink:0;margin-top:2px}
.tool-name{font-size:14px;font-weight:700;color:var(--dp);margin-bottom:4px}
.tool-desc{font-size:12.5px;color:var(--g);line-height:1.6;margin-bottom:10px}
.tool-btns{display:flex;gap:8px;flex-wrap:wrap}

@media(max-width:900px){.tools-grid{grid-template-columns:1fr}}
@media(max-width:600px){
  .tool{flex-direction:column}
}

/* ═══════════════════════════════════════
   NUMERI CHIAVE
   ═══════════════════════════════════════ */
.num-grid{max-width:var(--max-w);margin:0 auto;display:grid;grid-template-columns:repeat(4,1fr);gap:20px;text-align:center}
.nc2{padding:8px}
.nv{font-size:36px;font-weight:900;color:var(--blu);line-height:1;margin-bottom:4px}
.nl{font-size:12px;color:var(--g);line-height:1.5}

@media(max-width:700px){.num-grid{grid-template-columns:repeat(2,1fr);gap:16px}}
@media(max-width:400px){.nv{font-size:28px}}

/* ═══════════════════════════════════════
   GALASSIA grid
   ═══════════════════════════════════════ */
.gal-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}
.gc{display:flex;flex-direction:column;align-items:center;text-align:center;padding:16px 10px;background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);transition:all .2s var(--ease)}
.gc:hover{border-color:var(--blu);box-shadow:var(--shadow-md);transform:translateY(-2px)}
.gc.hub{background:var(--bl);border-color:var(--bm)}
.gc-i{font-size:22px;margin-bottom:6px}
.gc-n{font-size:11px;font-weight:700;color:var(--dp);line-height:1.2;margin-bottom:2px}
.gc-d{font-size:9.5px;color:var(--g)}

@media(max-width:600px){.gal-grid{grid-template-columns:repeat(3,1fr);gap:8px}.gc{padding:12px 6px}.gc-n{font-size:10px}}

/* ═══════════════════════════════════════
   CLIENTI strip
   ═══════════════════════════════════════ */
.cl-marquee{position:relative;overflow:hidden;margin:6px 0 18px;padding:6px 0;-webkit-mask-image:linear-gradient(90deg,transparent,#000 6%,#000 94%,transparent);mask-image:linear-gradient(90deg,transparent,#000 6%,#000 94%,transparent)}
.cl-track{display:flex;gap:18px;width:max-content;animation:clscroll var(--cl-dur,240s) linear infinite}
.cl-marquee:hover .cl-track,.cl-marquee:focus-within .cl-track{animation-play-state:paused}
.cl{flex:0 0 auto;width:190px;height:112px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid var(--bo);border-radius:6px;padding:14px 18px;transition:box-shadow .15s}
.cl:hover{box-shadow:var(--shadow)}
.cl img{max-width:100%;max-height:78px;width:auto;height:auto;object-fit:contain}
@keyframes clscroll{from{transform:translateX(0)}to{transform:translateX(-50%)}}
@media(max-width:600px){.cl{width:150px;height:92px;padding:10px 12px}.cl img{max-height:62px}}
@media(prefers-reduced-motion:reduce){.cl-track{animation:none}.cl-marquee{overflow-x:auto}}

/* ═══════════════════════════════════════
   MEDIA grid
   ═══════════════════════════════════════ */
.media-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.mc{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;transition:box-shadow .2s var(--ease)}
.mc:hover{box-shadow:var(--shadow-md)}
.mc-type{display:inline-block;font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:3px 10px;border-radius:3px;margin-bottom:10px}
.t-radio{background:#E8F0FE;color:var(--blu)}
.t-tv{background:#F3E5F5;color:#7B1FA2}
.t-stampa{background:#FFF3E0;color:#E65100}
.t-web{background:#FCE4EC;color:#C62828}
.mc-t{font-size:14px;font-weight:700;color:var(--dp);margin-bottom:6px}
.mc-d{font-size:12.5px;color:var(--g);line-height:1.6;margin-bottom:10px}
.mc-items{display:flex;flex-direction:column;gap:4px}
.mc-item{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--t)}
.mc-b{width:5px;height:5px;background:var(--blu);border-radius:50%;flex-shrink:0}

@media(max-width:700px){.media-grid{grid-template-columns:1fr}}

/* ═══════════════════════════════════════
   TERRITORIO + LIBRO
   ═══════════════════════════════════════ */
.tl-grid{display:grid;grid-template-columns:1fr 1fr;gap:28px}
.ter-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.terc{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);overflow:hidden}
.ter-h{padding:14px}
.ter-h img{width:100%;height:140px;object-fit:cover;border-radius:var(--r);margin-bottom:10px}
.ter-h h3{font-size:14px;font-weight:700;color:var(--dp);margin-bottom:4px}
.ter-h p{font-size:12px;color:var(--g);line-height:1.6}
.sport-badge{display:inline-block;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;border-radius:2px;background:rgba(0,135,88,.1);color:var(--vd);border:1px solid rgba(0,135,88,.2);margin-top:6px}
.ter-body{padding:0 14px 14px}
.ter-i{display:flex;align-items:center;gap:8px;font-size:11.5px;color:var(--t);margin-bottom:4px}
.ter-b{width:4px;height:4px;background:var(--blu);border-radius:50%;flex-shrink:0}

.libro-box{display:flex;gap:20px;align-items:flex-start}
.libro-cov{flex-shrink:0;width:160px}
.libro-cov img{width:100%;border-radius:var(--r);box-shadow:var(--shadow-md)}
.libro-cov .lc-t{font-size:11px;font-weight:700;color:var(--dp);line-height:1.3}
.libro-cov .lc-s{font-size:9.5px;color:var(--g);margin-top:4px}
.libro-cov .lc-b{font-size:9px;color:var(--g);margin-top:8px}
.libro-info h3{font-size:15px;font-weight:700;color:var(--dp);line-height:1.3;margin-bottom:8px}
.libro-info p{font-size:12.5px;color:var(--g);line-height:1.6;margin-bottom:12px}
.lm{display:flex;flex-direction:column;gap:4px;margin-bottom:12px}
.lm-r{font-size:11.5px;color:var(--t);display:flex;gap:8px}
.lm-k{font-weight:700;color:var(--dp);min-width:60px;flex-shrink:0}
.libro-btns{display:flex;gap:8px;flex-wrap:wrap}
.btn-lp{display:inline-block;background:var(--dp);color:#fff;padding:8px 16px;border-radius:var(--r);font-size:11.5px;font-weight:700;transition:background .15s var(--ease)}
.btn-lp:hover{background:var(--blu);color:#fff}

@media(max-width:900px){
  .tl-grid{grid-template-columns:1fr}
  .ter-grid{grid-template-columns:1fr 1fr}
}
@media(max-width:600px){
  .ter-grid{grid-template-columns:1fr}
  .libro-box{flex-direction:column;align-items:center;text-align:center}
  .libro-cov{width:130px}
  .lm-r{flex-direction:column;gap:2px}
  .libro-btns{justify-content:center}
}

/* ═══════════════════════════════════════
   CERTIFICAZIONI
   ═══════════════════════════════════════ */
.cert-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.certc{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:16px;text-align:center;transition:box-shadow .2s var(--ease)}
.certc:hover{box-shadow:var(--shadow-md)}
.cert-logo-img{height:44px;width:auto;max-width:100%;object-fit:contain;margin:0 auto 10px;display:block}
.cert-n{font-size:11.5px;font-weight:700;color:var(--dp);margin-bottom:3px;line-height:1.3}
.cert-d{font-size:10.5px;color:var(--g);line-height:1.4}

@media(max-width:900px){.cert-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.cert-grid{grid-template-columns:repeat(2,1fr);gap:10px}.certc{padding:12px}}

/* ═══════════════════════════════════════
   SEO BLOCK (hidden)
   ═══════════════════════════════════════ */
.seo-block{background:var(--bg);padding:40px 24px;font-family:'Lora',serif;font-size:14px;color:var(--g);line-height:1.8}
.seo-block h2{font-family:'Titillium Web',sans-serif;font-size:20px;color:var(--dp);margin-bottom:16px}
.seo-block h3{font-family:'Titillium Web',sans-serif;font-size:16px;color:var(--t);margin:20px 0 8px}
.seo-block p{margin-bottom:12px;max-width:780px}
</style>

<?php
/* ═══════════════════════════════════════
   CLIENTI IMPORTANTI — lista per la strip homepage
   ═══════════════════════════════════════ */
// Clienti homepage — tutti i loghi dell'elenco unico (inc/clienti-dati.php), in barra scorrevole
$clienti_importanti = troisi_clienti_lista();
?>

<!-- ═══════════════════════════════════════
     HERO
     ═══════════════════════════════════════ -->
<div class="hero">
  <div class="hero-in">
    <div>
      <div class="h-ey"><?php echo wp_kses_post(troisi_opt("hero_eyebrow","Istituto di Ricerca Statistica · Bari · Roma · Milano")); ?></div>
      <h1><?php echo wp_kses_post(troisi_opt("hero_title","Dati, analisi e modelli<br>per la <em>governance pubblica</em><br>e i servizi ai cittadini")); ?></h1>
      <p>Dal 2006 Troisi Ricerche trasforma dati statistici in <strong>conoscenza utile</strong> per enti pubblici, imprese e territori. Customer satisfaction, benessere organizzativo, TR-Index, dibattito pubblico, mappatura delle competenze.</p>
      <div class="h-btns">
        <a href="<?php echo home_url('/chi-siamo'); ?>" class="bp">Scopri chi siamo</a>
        <a href="<?php echo home_url('/servizi'); ?>" class="bs">Il network →</a>
      </div>
      <div class="h-tags">
        <span class="ht">Ricerca statistica</span>
        <span class="ht">Customer satisfaction PA</span>
        <span class="ht g">TR-Index 2026</span>
        <span class="ht">Benessere organizzativo</span>
        <span class="ht">TÜV ISO 9001</span>
        <span class="ht">Dibattito pubblico</span>
      </div>
    </div>
    <div class="hn">
      <div class="hn-t">Troisi Ricerche in numeri</div>
      <div class="hn-g">
        <div class="hn-s"><div class="hn-v">20+</div><div class="hn-l">anni di attività</div></div>
        <div class="hn-s"><div class="hn-v">500+</div><div class="hn-l">ricerche realizzate</div></div>
        <div class="hn-s"><div class="hn-v">200+</div><div class="hn-l">clienti serviti</div></div>
        <div class="hn-s"><div class="hn-v">16</div><div class="hn-l">siti del network</div></div>
      </div>
      <div class="hn-div"></div>
      <div class="hn-cs">
        <span class="hn-c">TÜV ISO 9001:2015</span>
        <span class="hn-c">SIS</span>
        <span class="hn-c">Confindustria</span>
      </div>
      <div class="hn-sedi">
        <div class="hn-sede">Bari &middot; sede principale</div>
        <div class="hn-sede">Roma &middot; sede operativa</div>
        <div class="hn-sede">Milano &middot; sede operativa</div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     GIOCA CON LA STATISTICA (10.1.1)
     ═══════════════════════════════════════ -->
<style>
html body .tr-play{background:linear-gradient(120deg,#00264d 0%,#003366 55%,#004D8C 100%);color:#fff;padding:44px var(--tr-gutter,2rem);position:relative;overflow:hidden}
html body .tr-play:after{content:'';position:absolute;right:-60px;top:-90px;width:320px;height:320px;border-radius:50%;background:radial-gradient(circle,rgba(245,166,35,.30),transparent 65%)}
html body .tr-play-in{position:relative;z-index:1;display:flex;gap:32px;align-items:center;justify-content:space-between;flex-wrap:wrap}
html body .tr-play-k{font-size:12px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#F5A623}
html body .tr-play h2{color:#fff;font-size:clamp(24px,3vw,34px);line-height:1.15;margin:8px 0 10px;font-weight:800}
html body .tr-play h2 em{font-style:normal;color:#F5A623}
html body .tr-play p{color:rgba(255,255,255,.82);font-size:16px;line-height:1.6;margin:0;max-width:620px}
html body .tr-play-chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:16px}
html body .tr-play-chips a{color:#fff;text-decoration:none;border:1px solid rgba(255,255,255,.3);border-radius:999px;padding:7px 14px;font-size:13.5px;font-weight:600}
html body .tr-play-chips a:hover{background:#F5A623;color:#003366;border-color:#F5A623}
html body .tr-play-cta{display:inline-block;background:#F5A623;color:#003366!important;font-weight:800;font-size:16px;text-decoration:none;padding:15px 26px;border-radius:8px;white-space:nowrap}
html body .tr-play-cta:hover{background:#ffb84a}
</style>
<section class="tr-play" aria-label="Gioca con la statistica">
  <div class="tr-play-in">
    <div>
      <div class="tr-play-k">Novità · Gioca con la statistica</div>
      <h2>I numeri non mentono. <em>L'intuito sì.</em></h2>
      <p>Quattro giochi per mettere alla prova il tuo senso dei numeri, con i dati dei nostri osservatori. Un minuto per giocare, un'idea che resta.</p>
      <div class="tr-play-chips">
        <a href="<?php echo esc_url(home_url('/giochi-statistica/#indovina-il-dato')); ?>">Indovina il dato</a>
        <a href="<?php echo esc_url(home_url('/giochi-statistica/#sondaggio-perfetto')); ?>">Il sondaggio perfetto</a>
        <a href="<?php echo esc_url(home_url('/giochi-statistica/#paradosso-compleanno')); ?>">Il paradosso del compleanno</a>
        <a href="<?php echo esc_url(home_url('/giochi-statistica/#tre-porte')); ?>">Le tre porte</a>
      </div>
    </div>
    <a class="tr-play-cta" href="<?php echo esc_url(home_url('/giochi-statistica/')); ?>">Inizia a giocare →</a>
  </div>
</section>

<!-- ═══════════════════════════════════════
     CHI SIAMO — anteprima
     ═══════════════════════════════════════ -->
<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Chi siamo</div></div>
    <div class="s-t">L'istituto, il fondatore, <em>il metodo</em></div>
    <p class="s-d">Troisi Ricerche è un istituto di ricerca statistica fondato da Andrea Troisi nel 2006. Vent'anni di lavoro sul campo, metodo scientifico rigoroso, presenza nazionale.</p>
    <div class="andrea-box">
      <img src="<?php echo $_td; ?>/foto-andrea.jpg" alt="Andrea Troisi" class="andrea-foto">
      <div>
        <div class="andrea-name">Andrea Troisi</div>
        <div class="andrea-role">Fondatore e Direttore scientifico &middot; Troisi Ricerche</div>
        <div class="andrea-bio">Statistico, ricercatore e consulente per enti pubblici e imprese. Fondatore di Troisi Ricerche nel 2006 e di un ecosistema di 16 piattaforme per la governance pubblica. Esperto di customer satisfaction, benessere organizzativo, dibattito pubblico e mappatura delle competenze. Autore del volume <em>«Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione»</em> (Cacucci Editore). Ospite fisso di «Drive In» su Tele Lazio Nord e conduttore de «Il Dato è Tratto» su Controradio Bari. Membro SIS, ISI e AMS. Associato Confindustria Bari-BAT. Professore di Economia delle Imprese Turistiche presso l'Università di Bari — Dipartimento DiRIUM.</div>
      </div>
    </div>
    <div class="cs-grid">
      <div class="cs-card">
        <div class="cs-icon">🎯</div>
        <div class="cs-title">La mission</div>
        <div class="cs-desc">Trasformare i dati in conoscenza utile per chi decide. Metodo scientifico, rigore statistico, linguaggio accessibile per PA e imprese.</div>
        <a href="<?php echo home_url('/chi-siamo'); ?>" class="li">Chi siamo</a>
      </div>
      <div class="cs-card">
        <div class="cs-icon">👥</div>
        <div class="cs-title">Il team e i collaboratori</div>
        <div class="cs-desc">Un network di oltre 70 professionisti — statistici, ricercatori, esperti di governance, analisti — in tutta Italia. Con un grazie a tutti loro.</div>
        <a href="<?php echo home_url('/chi-siamo'); ?>#collaboratori" class="li">Team e collaboratori</a>
      </div>
      <div class="cs-card">
        <div class="cs-icon">🏛️</div>
        <div class="cs-title">Storia e sedi</div>
        <div class="cs-desc">Dal 2006 a Bari, poi Roma e Milano. Vent'anni di ricerche, pubblicazioni, convegni e presenza istituzionale nazionale.</div>
        <a href="<?php echo home_url('/chi-siamo'); ?>#storia" class="li">La nostra storia</a>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     NOTIZIE
     ═══════════════════════════════════════ -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Notizie e aggiornamenti</div></div>
    <div class="s-t">Le ultime <em>notizie</em> da Troisi Ricerche</div>
    <p class="s-d">Ricerche pubblicate, aggiornamenti dal network, presenza sui media, eventi.</p>
    <?php
    $news = get_posts(['numberposts'=>3,'post_type'=>'post']);
    if($news):
    ?>
    <div class="news-grid">
    <?php foreach($news as $post): setup_postdata($post);
      $cats = get_the_category();
      $cat_name = $cats ? $cats[0]->name : 'Notizie';
      $cat_css = 'cat-g';
      if(stripos($cat_name,'ricerca')!==false) $cat_css='cat-r';
      elseif(stripos($cat_name,'media')!==false||stripos($cat_name,'stampa')!==false) $cat_css='cat-m';
      elseif(stripos($cat_name,'dato')!==false) $cat_css='cat-d';
      elseif(stripos($cat_name,'event')!==false) $cat_css='cat-e';
    ?>
      <div class="nc">
        <div class="nc-bar <?php echo $cat_css; ?>"><?php echo esc_html($cat_name); ?></div>
        <div class="nc-b">
          <div class="nc-data"><?php echo get_the_date('d/m/Y'); ?></div>
          <div class="nc-title"><?php the_title(); ?></div>
          <div class="nc-desc"><?php echo wp_trim_words(get_the_excerpt(),18); ?></div>
          <a href="<?php the_permalink(); ?>" class="nc-link">Leggi l'articolo →</a>
        </div>
      </div>
    <?php endforeach; wp_reset_postdata(); ?>
    </div>
    <?php else: ?>
    <div class="news-grid">
      <div class="nc"><div class="nc-bar cat-r">Ricerca</div><div class="nc-b"><div class="nc-data">Prossimamente</div><div class="nc-title">Nuova indagine sulla qualità percepita del TPL nelle città metropolitane italiane</div><div class="nc-desc">I risultati della rilevazione 2025 su 8 città.</div><a href="<?php echo home_url('/notizie'); ?>" class="nc-link">Vai alle notizie →</a></div></div>
      <div class="nc"><div class="nc-bar cat-g">Dal network</div><div class="nc-b"><div class="nc-data">Prossimamente</div><div class="nc-title">TroisiInsight pubblica il nuovo dashboard benessere organizzativo PA 2024</div><div class="nc-desc">Grafico interattivo con i dati INAPP aggiornati.</div><a href="<?php echo home_url('/notizie'); ?>" class="nc-link">Vai alle notizie →</a></div></div>
      <div class="nc"><div class="nc-bar cat-m">Media</div><div class="nc-b"><div class="nc-data">Prossimamente</div><div class="nc-title">Andrea Troisi a Forum PA 2026 · Customer satisfaction e PA digitale</div><div class="nc-desc">Intervento su misurazione della soddisfazione nei servizi digitali.</div><a href="<?php echo home_url('/notizie'); ?>" class="nc-link">Vai alle notizie →</a></div></div>
    </div>
    <?php endif; ?>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;flex-wrap:wrap;gap:8px">
      <span style="font-size:11.5px;color:var(--g)">Categorie: Ricerche &middot; Dal network &middot; Media &middot; Il dato del mese &middot; Eventi</span>
      <a href="<?php echo home_url('/notizie'); ?>" class="li">Tutte le notizie</a>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     DAL NETWORK · ultimi articoli dei siti satellite (REST/RSS, cache 1 ora)
     ═══════════════════════════════════════ -->
<?php $tr_net = troisi_network_all(1); ?>
<div class="sec alt" id="dal-network">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Dal network &middot; nuove analisi ogni giorno</div></div>
    <div class="s-t">Gli ultimi articoli dai <em>siti del network</em></div>
    <p class="s-d">Sette siti pubblicano un'analisi a settimana e due siti ogni due settimane, sempre su dati ufficiali (Eurostat, ISTAT e altre fonti pubbliche). Qui compare in automatico l'ultima uscita di ciascuno.</p>
    <?php if ($tr_net): ?>
    <div class="net-grid">
      <?php foreach ($tr_net as $i => $it): ?>
      <a class="net-card<?php echo $i === 0 ? ' net-first' : ''; ?>" href="<?php echo esc_url($it['link']); ?>" target="_blank" rel="noopener">
        <?php $tr_svg = (!$it['img'] && !empty($it['svg'])) ? $it['svg'] : ''; ?>
        <div class="net-img<?php echo $tr_svg ? ' net-svg' : ''; ?>"<?php if (!$it['img'] && !$tr_svg) echo ' style="background:' . esc_attr($it['colore']) . '"'; ?>>
          <?php if ($it['img']): ?><img src="<?php echo esc_url($it['img']); ?>" alt="<?php echo esc_attr($it['title']); ?>" loading="lazy"><?php elseif ($tr_svg): echo $tr_svg; endif; ?>
        </div>
        <div class="net-b">
          <div class="net-src"><span class="net-dot" style="background:<?php echo esc_attr($it['colore']); ?>"></span><?php echo esc_html($it['site_name']); ?><span class="net-date"><?php echo esc_html($it['date']); ?></span></div>
          <div class="net-tit"><?php echo esc_html($it['title']); ?></div>
          <?php if ($i === 0 && $it['desc']): ?><div class="net-txt"><?php echo esc_html($it['desc']); ?></div><?php endif; ?>
          <span class="net-go">Leggi l'analisi ↗</span>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p class="s-d">Gli aggiornamenti dei siti del network non sono momentaneamente disponibili.</p>
    <?php endif; ?>
    <div style="margin-top:16px;display:flex;justify-content:flex-end"><a href="<?php echo home_url('/notizie'); ?>" class="li">Tutte le notizie dal network</a></div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     STRUMENTI
     ═══════════════════════════════════════ -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Strumenti</div></div>
    <div class="s-t"><em>Strumenti</em> online di Troisi Ricerche</div>
    <p class="s-d">Tool gratuiti e piattaforme professionali, disponibili su questo sito o tramite i siti dedicati del network.</p>
    <div class="tools-grid">
      <!-- Mini calcolatore -->
      <div class="tool" style="flex-direction:column;gap:0">
        <div style="display:flex;gap:12px;align-items:flex-start;margin-bottom:14px">
          <div class="tool-icon">🧮</div>
          <div>
            <div class="tool-name">Calcola il Campione <span style="font-size:10px;font-weight:600;background:rgba(232,99,10,.1);color:#E8630A;border:1px solid rgba(232,99,10,.25);padding:2px 8px;border-radius:100px;margin-left:6px;vertical-align:middle">PRO</span></div>
            <div class="tool-desc">Quante interviste ti servono? Inserisci i parametri e ottieni subito il campione ottimale con la formula di Cochran.</div>
          </div>
        </div>
        <div style="background:var(--bg);border-radius:6px;padding:14px;border:1px solid var(--bo)">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
            <div>
              <label style="display:block;font-size:10px;font-weight:700;color:var(--dp);text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px">Popolazione (N)</label>
              <input type="number" id="hp-N" value="10000" min="1" style="width:100%;padding:7px 10px;border:1px solid var(--bo);border-radius:4px;font-size:13px;font-family:inherit;background:#fff">
            </div>
            <div>
              <label style="display:block;font-size:10px;font-weight:700;color:var(--dp);text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px">Margine errore (%)</label>
              <select id="hp-e" style="width:100%;padding:7px 10px;border:1px solid var(--bo);border-radius:4px;font-size:13px;font-family:inherit;background:#fff">
                <option value="0.03">3%</option>
                <option value="0.05" selected>5%</option>
                <option value="0.07">7%</option>
                <option value="0.10">10%</option>
              </select>
            </div>
          </div>
          <button onclick="hpCalc()" style="width:100%;padding:9px;background:#E8630A;color:#fff;border:none;border-radius:4px;font-size:12.5px;font-weight:700;cursor:pointer;font-family:inherit;margin-bottom:8px;transition:background .15s">Calcola campione →</button>
          <div id="hp-result" style="display:none;background:var(--dp);border-radius:4px;padding:10px;text-align:center">
            <div id="hp-num" style="font-size:36px;font-weight:800;color:#E8630A;line-height:1"></div>
            <div style="font-size:10px;color:rgba(255,255,255,.55);margin-bottom:6px">interviste necessarie (confidenza 95%)</div>
            <a href="<?php echo home_url('/strumenti'); ?>#calcolatore" style="display:inline-flex;align-items:center;gap:5px;font-size:11px;color:rgba(255,255,255,.75);border:1px solid rgba(255,255,255,.25);padding:4px 12px;border-radius:4px">Analisi completa con grafico e PDF →</a>
          </div>
        </div>
      </div>
      <!-- TIP -->
      <div class="tool">
        <img src="<?php echo $_td; ?>/img/logo-tip.png" alt="TIP" style="height:48px;width:auto;flex-shrink:0">
        <div>
          <div class="tool-name">TIP — Troisi Intelligence Platform</div>
          <div class="tool-desc">La piattaforma proprietaria per raccogliere, analizzare e attivare dati in tempo reale. Survey, live polling, dashboard KPI, report PDF, insight AI. Conforme GDPR.</div>
          <div class="tool-btns">
            <a href="https://tiplive.it" target="_blank" rel="noopener" class="li">Scopri TIP →</a>
            <a href="https://tip-troisi.lovable.app/" target="_blank" rel="noopener" class="le">Accedi alla piattaforma</a>
          </div>
        </div>
      </div>
      <!-- Dibattito Pubblico -->
      <div class="tool">
        <div class="tool-icon">🗣️</div>
        <div>
          <div class="tool-name">Dibattito Pubblico</div>
          <div class="tool-desc">Piattaforma per la gestione del dibattito pubblico nelle grandi opere. Conforme all'art. 40 del D.Lgs. 36/2023 (Allegato I.6). Con TenderCoop e Ti Quadro.</div>
          <div class="tool-btns">
            <a href="<?php echo home_url('/strumenti/dibattito-pubblico'); ?>" class="li">Scopri Dibattito Pubblico</a>
            <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" class="le">dibattito-pubblico.it</a>
          </div>
        </div>
      </div>
      <!-- TR-Index -->
      <div class="tool">
        <div class="tool-icon">📐</div>
        <div>
          <div class="tool-name">TR-Index · Ranking territoriale</div>
          <div class="tool-desc">L'indice proprietario per misurare qualità e performance dei territori italiani. Aggiornato annualmente con dati ISTAT.</div>
          <div class="tool-btns">
            <a href="<?php echo home_url('/strumenti/t-index'); ?>" class="li">Cos'è il TR-Index</a>
            <a href="https://t-index.it" target="_blank" rel="noopener" class="le">t-index.it</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     NUMERI CHIAVE
     ═══════════════════════════════════════ -->
<div class="sec alt">
  <div class="num-grid">
    <div class="nc2"><div class="nv"><?php echo esc_html(troisi_opt("num_anni","20+")); ?></div><div class="nl">anni di ricerca statistica applicata in Italia</div></div>
    <div class="nc2"><div class="nv"><?php echo esc_html(troisi_opt("num_ricerche","500+")); ?></div><div class="nl">ricerche, indagini e analisi realizzate</div></div>
    <div class="nc2"><div class="nv"><?php echo esc_html(troisi_opt("num_clienti","200+")); ?></div><div class="nl">clienti tra PA, università e imprese</div></div>
    <div class="nc2"><div class="nv"><?php echo esc_html(troisi_opt("num_siti","16")); ?></div><div class="nl">siti del network Troisi Ricerche</div></div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     GALASSIA
     ═══════════════════════════════════════ -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Il network</div></div>
    <div class="s-t">Un ecosistema di <em>strumenti e metodologie</em></div>
    <p class="s-d">Ogni sito specializzato nasce da una ricerca specifica. Tutti tornano qui, a troisiricerche.net, come hub centrale.</p>
    <div class="gal-grid">
      <?php
      $gal_posts = troisi_get_strumenti_galassia();
      if ($gal_posts):
        foreach ($gal_posts as $gp):
          $icona = get_post_meta($gp->ID, '_troisi_str_icona', true) ?: '🔧';
          $desc = get_post_meta($gp->ID, '_troisi_str_desc', true);
          $url = get_post_meta($gp->ID, '_troisi_str_url', true);
          $is_hub = ($url === 'https://troisiricerche.net' || $url === home_url('/'));
      ?>
        <a href="<?php echo esc_url($url); ?>" <?php echo $is_hub ? '' : 'target="_blank"'; ?> class="gc<?php echo $is_hub ? ' hub' : ''; ?>">
          <span class="gc-i"><?php echo $icona; ?></span>
          <div class="gc-n"><?php echo esc_html($gp->post_title); ?></div>
          <div class="gc-d"><?php echo esc_html($desc); ?></div>
        </a>
      <?php endforeach; else: ?>
        <a href="<?php echo home_url('/'); ?>" class="gc hub"><span class="gc-i">🏛️</span><div class="gc-n">Troisi Ricerche</div><div class="gc-d">Hub · sei qui</div></a>
        <a href="https://t-index.it" target="_blank" class="gc"><span class="gc-i">📐</span><div class="gc-n">TR-Index</div><div class="gc-d">Ranking territori</div></a>
        <a href="https://customerpa.it" target="_blank" class="gc"><span class="gc-i">😊</span><div class="gc-n">CustomerPA</div><div class="gc-d">CS servizi pubblici</div></a>
        <a href="https://www.delfiweb.it" target="_blank" class="gc"><span class="gc-i">🏛️</span><div class="gc-n">DELFI</div><div class="gc-d">Dati di tutti i comuni</div></a>
      <?php endif; ?>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;flex-wrap:wrap;gap:8px">
      <span style="font-size:11.5px;color:var(--g)">Ogni sito del network ha una pagina interna di approfondimento.</span>
      <a href="<?php echo home_url('/servizi'); ?>" class="li">Esplora tutti i servizi</a>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     CLIENTI
     ═══════════════════════════════════════ -->
<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">I nostri clienti</div></div>
    <div class="s-t">200+ organizzazioni si sono <em>affidate</em> a noi</div>
    <p class="s-d">Ministeri, Regioni, Comuni, Università, aziende di trasporto, associazioni di categoria e imprese.</p>
    <div class="cl-marquee" aria-label="Loghi dei clienti">
      <div class="cl-track" id="cl-track">
      <?php foreach ($clienti_importanti as $cl): ?>
        <div class="cl" title="<?php echo esc_attr($cl['nome']); ?>"><img src="<?php echo esc_url(troisi_cliente_logo_url($cl['file'])); ?>" alt="<?php echo esc_attr($cl['nome']); ?>" loading="lazy"></div>
      <?php endforeach; ?>
      </div>
    </div>
    <script>
    (function(){ // ordine casuale a ogni visita + duplicazione per lo scorrimento continuo
      var t=document.getElementById('cl-track'); if(!t) return;
      var it=[].slice.call(t.children);
      for(var i=it.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var x=it[i];it[i]=it[j];it[j]=x;}
      it.forEach(function(e){t.appendChild(e);});
      it.forEach(function(e){var c=e.cloneNode(true);c.setAttribute('aria-hidden','true');var im=c.querySelector('img');if(im)im.alt='';t.appendChild(c);});
      t.style.setProperty('--cl-dur',Math.round(it.length*2.6)+'s');
    })();
    </script>
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
      <span style="font-size:11.5px;color:var(--g)">Passa con il mouse sulla barra per fermarla · tutti i clienti nella pagina dedicata, filtrabili per settore</span>
      <a href="<?php echo home_url('/clienti'); ?>" class="li">Tutti i clienti</a>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     MEDIA
     ═══════════════════════════════════════ -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Media &middot; Presenza pubblica</div></div>
    <div class="s-t">Radio, televisione, <em>stampa</em> e web</div>
    <p class="s-d">La voce di Troisi Ricerche sui media nazionali e locali.</p>
    <div class="media-grid">
      <div class="mc">
        <span class="mc-type t-radio">Radio</span>
        <div class="mc-t">«Il Dato è Tratto» &middot; Controradio</div>
        <div class="mc-d">Programma radiofonico ideato e condotto da Andrea Troisi. Analisi statistiche, indagini e dati sulla qualità della vita pubblica in Italia.</div>
        <div class="mc-items">
          <div class="mc-item"><div class="mc-b"></div>Stagioni regolari su Controradio</div>
          <div class="mc-item"><div class="mc-b"></div>Focus su PA, servizi pubblici, welfare</div>
        </div>
        <div style="margin-top:12px"><a href="<?php echo home_url('/media'); ?>" class="li">Vai alla pagina Media</a></div>
      </div>
      <div class="mc">
        <span class="mc-type t-tv">Televisione</span>
        <div class="mc-t">«Drive In» &middot; Tele Lazio Nord</div>
        <div class="mc-d">Andrea Troisi ospite fisso del programma televisivo. Commenti e analisi su dati e sondaggi di attualità.</div>
        <div class="fc-vbox" style="margin:10px 0 0;border-radius:4px">
          <div class="fvp"><div class="fvp-i"></div></div>
          <a href="https://www.youtube.com/watch?v=qa3CJBMLXIY&list=PLOoGJz564GrV21MMzOLhiUlpEdW3Xbu8T&index=17" target="_blank" style="text-decoration:none">
            <div class="fvt"><strong>Drive In &middot; Tele Lazio Nord</strong>Guarda su YouTube &middot; @Troisiricerche</div>
          </a>
        </div>
      </div>
      <div class="mc">
        <span class="mc-type t-stampa">Rassegna stampa</span>
        <div class="mc-t">Citazioni e interviste</div>
        <div class="mc-items">
          <div class="mc-item"><div class="mc-b"></div>Il Sole 24 Ore &middot; customer satisfaction</div>
          <div class="mc-item"><div class="mc-b"></div>la Repubblica &middot; qualità servizi PA</div>
          <div class="mc-item"><div class="mc-b"></div>TGR Puglia &middot; indagini territoriali</div>
          <div class="mc-item"><div class="mc-b"></div>Strade &amp; Autostrade &middot; dibattito pubblico</div>
          <div class="mc-item"><div class="mc-b"></div>Corriere del Mezzogiorno &middot; TR-Index</div>
        </div>
        <div style="margin-top:12px"><a href="<?php echo home_url('/rassegna-stampa'); ?>" class="li">Tutta la rassegna stampa</a></div>
      </div>
      <div class="mc">
        <span class="mc-type t-web">YouTube</span>
        <div class="mc-t">Canale @Troisiricerche</div>
        <div class="mc-d">Video, interventi a convegni, puntate di Drive In e approfondimenti.</div>
        <div class="mc-items">
          <div class="mc-item"><div class="mc-b"></div>Puntate Drive In &middot; Tele Lazio Nord</div>
          <div class="mc-item"><div class="mc-b"></div>Interventi a convegni e seminari</div>
        </div>
        <div style="margin-top:12px"><a href="https://www.youtube.com/@Troisiricerche" target="_blank" class="le">Vai al canale YouTube</a></div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     LIBRI E PARLAMENTO
     ═══════════════════════════════════════ -->
<?php $sen = troisi_senato_2026(); ?>
<div class="sec" id="libri">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">I libri &middot; presentati in Parlamento</div></div>
    <div class="s-t">Dal Senato alla Camera: <em>i nostri modelli</em> sul benessere e sulla qualità dei servizi</div>
    <div class="bk-grid">

      <div class="bk-card">
        <div class="bk-top">
          <img class="bk-cov" src="<?php echo esc_url(troisi_copertina_benessere()); ?>" alt="Le organizzazioni che si misurano — Andrea Troisi, Cacucci Editore 2026">
          <div class="bk-info">
            <div class="bk-badge">Novità 2026 &middot; Cacucci Editore</div>
            <h3>Le organizzazioni che si misurano</h3>
            <div class="bk-sub">Il benessere organizzativo dalla compliance alla consapevolezza</div>
            <p>Il nuovo volume di Andrea Troisi affronta il benessere organizzativo come leva di misurazione e miglioramento delle organizzazioni: principi, indicatori e strumenti per rilevare, interpretare e migliorare la qualità della vita lavorativa nelle imprese e nelle pubbliche amministrazioni.</p>
            <div class="bk-meta">Andrea Troisi &middot; Cacucci Editore, Bari &middot; ISBN 979-12-5965-650-6</div>
          </div>
        </div>
        <div class="bk-parl">
          <div class="bk-parl-h"><span class="bk-parl-ist">Senato della Repubblica</span><span><?php echo esc_html($sen['data']); ?></span></div>
          <div class="bk-parl-l">Palazzo Madama &middot; Sala Caduti di Nassirya &middot; Roma</div>
          <div class="bk-ph">
            <?php foreach (array_slice($sen['foto'], 0, 3) as $f): ?>
            <figure><img src="<?php echo esc_url(troisi_remote_asset($f['src'])); ?>" alt="<?php echo esc_attr($f['cap']); ?>" loading="lazy"></figure>
            <?php endforeach; ?>
          </div>
          <p class="bk-parl-t">Con il volume Andrea Troisi ha presentato l'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate, da lui promosso, con l'IBO Score e l'Oscar del Benessere Organizzativo.</p>
        </div>
        <div class="libro-btns">
          <a href="https://www.cacuccieditore.it/le-organizzazioni-che-si-misurano-il-benessere-organizzativo-dalla-compliance-alla-consapevolezza-troisi-9791259656506" target="_blank" rel="noopener" class="btn-lp">Acquista su Cacucci ↗</a>
          <a href="<?php echo esc_url($sen['link'][0]['href']); ?>" target="_blank" rel="noopener" class="le">Lo Speciale</a>
          <a href="<?php echo home_url('/media'); ?>#senato" class="li">Foto e media</a>
        </div>
      </div>

      <div class="bk-card">
        <div class="bk-top">
          <?php if (file_exists(get_template_directory() . '/copertina-libro.jpg')): ?>
          <img class="bk-cov" src="<?php echo $_td; ?>/copertina-libro.jpg" alt="Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione — Cacucci Editore">
          <?php endif; ?>
          <div class="bk-info">
            <div class="bk-badge">Cacucci Editore</div>
            <h3>Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione</h3>
            <p>Il modello teorico e applicativo per la misurazione della qualità percepita nei servizi pubblici, sviluppato da Troisi Ricerche.</p>
            <div class="bk-meta">Cacucci Editore, Bari &middot; ISBN 978-88-6611-797-1</div>
          </div>
        </div>
        <div class="bk-parl">
          <div class="bk-parl-h"><span class="bk-parl-ist">Camera dei Deputati</span><span>29 marzo 2019</span></div>
          <div class="bk-parl-l">Conferenza stampa ufficiale &middot; trasmessa in diretta su webtv.camera.it</div>
          <div class="bk-ph bk-ph2">
            <figure><img src="<?php echo $_td; ?>/img/camera/andrea_al_banco_camera_deputati_2019.jpg" alt="Andrea Troisi alla Camera dei Deputati, 29 marzo 2019" loading="lazy"></figure>
            <figure><img src="<?php echo $_td; ?>/img/camera/webtv_camera_screenshot_29mar2019_libro_cacucci.jpg" alt="La presentazione del libro su webtv.camera.it, 29 marzo 2019" loading="lazy"></figure>
          </div>
          <p class="bk-parl-t">Presentazione del volume e del modello statistico per misurare la soddisfazione dei cittadini e la qualità dei servizi pubblici; la registrazione è nell'archivio della WebTV della Camera.</p>
        </div>
        <div class="libro-btns">
          <a href="https://www.cacuccieditore.it/un-modello-statistico-per-lanalisi-della-customer-satisfaction-nella-pubblica-amministrazione-9788866117971" target="_blank" rel="noopener" class="btn-lp">Acquista su Cacucci ↗</a>
          <a href="https://webtv.camera.it/evento/14114" target="_blank" rel="noopener" class="le">Video su webtv.camera.it</a>
          <a href="<?php echo home_url('/media'); ?>#camera" class="li">Foto e media</a>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     TERRITORIO + LIBRO
     ═══════════════════════════════════════ -->
<div class="sec alt">
  <div class="wrap">
    <div>
      <div>
        <div class="sh"><div class="sl"></div><div class="se">Nel territorio</div></div>
        <div class="s-t">Sponsor, eventi <em>e comunità</em></div>
        <div class="ter-grid">
          <div class="terc">
            <div class="ter-h">
              <img src="<?php echo $_td; ?>/foto-atletica.jpg" alt="Troisi Ricerche sponsor atletica">
              <h3>USD Enterprise &middot; Giovani Atleti</h3>
              <p>Troisi Ricerche sponsor ufficiale dell'associazione sportiva pugliese.</p>
              <div class="sport-badge">Sponsor ufficiale</div>
            </div>
            <div class="ter-body">
              <div class="ter-i"><div class="ter-b"></div>Sostegno all'atletica giovanile pugliese</div>
              <div class="ter-i"><div class="ter-b"></div>Presenza alle gare e agli eventi sportivi</div>
            </div>
          </div>
          <div class="terc">
            <div class="ter-h" style="padding-bottom:14px">
              <h3>Convegni ed eventi</h3>
              <p>Presenza attiva nei principali appuntamenti istituzionali.</p>
            </div>
            <div class="ter-body">
              <div class="ter-i"><div class="ter-b"></div>Fiera del Levante &middot; Bari</div>
              <div class="ter-i"><div class="ter-b"></div>Congressi SIS &middot; Statistica</div>
              <div class="ter-i"><div class="ter-b"></div>Forum PA &middot; Roma</div>
              <div class="ter-i"><div class="ter-b"></div>AIQUAV &middot; Firenze</div>
            </div>
          </div>
        </div>
        <div style="margin-top:14px"><a href="<?php echo home_url('/territorio'); ?>" class="li">Scopri il territorio</a></div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     CERTIFICAZIONI
     ═══════════════════════════════════════ -->
<div class="sec">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Qualità e appartenenza</div></div>
    <div class="cert-grid">
      <?php
      $certs = troisi_get_certificazioni();
      if ($certs):
        foreach ($certs as $cert):
          $logo = get_post_meta($cert->ID, '_troisi_cert_logo', true);
          $desc = get_post_meta($cert->ID, '_troisi_cert_desc', true);
      ?>
        <div class="certc">
          <?php if ($logo): ?><img src="<?php echo $_td . '/' . esc_attr($logo); ?>" alt="<?php echo esc_attr($cert->post_title); ?>" class="cert-logo-img"><?php endif; ?>
          <div class="cert-n"><?php echo esc_html($cert->post_title); ?></div>
          <div class="cert-d"><?php echo esc_html($desc); ?></div>
        </div>
      <?php endforeach; else:
        /* Se le certificazioni non sono nel database, si mostra l'elenco completo dal tema. */
        $tr_certs = array(
          array( 'TÜV ISO 9001:2015', 'img/loghi/tuv.jpeg', 'Sistema di gestione qualità certificato' ),
          array( 'SIS · Società Italiana di Statistica', 'img/loghi/sis.png', 'Ente aderente alla società scientifica' ),
          array( 'Confindustria Bari e BAT', 'img/loghi/confindustria.jpg', 'Associato Confindustria' ),
          array( 'ISI · International Statistical Institute', 'img/loghi/isi.png', 'Membro ISI' ),
          array( 'AMS · American Mathematical Society', 'img/loghi/ams_logo.jpg', 'Membro AMS' ),
          array( 'Google Advanced Data Analytics', 'img/loghi/google-analytics.jpg', 'Certificazione Google' ),
          array( 'HubSpot Academy', 'img/loghi/hubspot.png', 'Certificazione HubSpot' ),
          array( 'MIUR · Ente Accreditato', 'img/loghi/miur.png', 'Formazione accreditata MIUR' ),
        );
        foreach ( $tr_certs as $c ) : ?>
        <div class="certc"><img src="<?php echo $_td . '/' . $c[1]; ?>" alt="<?php echo esc_attr( $c[0] ); ?>" class="cert-logo-img" loading="lazy"><div class="cert-n"><?php echo esc_html( $c[0] ); ?></div><div class="cert-d"><?php echo esc_html( $c[2] ); ?></div></div>
      <?php endforeach;
      endif; ?>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════
     FOOTER
     ═══════════════════════════════════════ -->
<?php include(get_template_directory().'/troisi-footer.php'); ?>

<!-- ═══════════════════════════════════════
     BLOCCO SEO / AI
     ═══════════════════════════════════════ -->
<div class="seo-block" style="display:none" aria-hidden="true">
<div class="wrap">
<h2>Troisi Ricerche — Istituto Leader in Data Analysis e Innovazione Territoriale in Italia</h2>
<p>Troisi Ricerche è il principale istituto italiano di ricerca statistica applicata, fondato da Andrea Troisi nel 2006 a Bari, con sedi operative a Roma e Milano. L'istituto opera nei settori della ricerca di mercato, customer satisfaction per la pubblica amministrazione, data science, modelli predittivi territoriali, mappatura delle competenze, benessere organizzativo, governance partecipativa e turismo data driven. È accreditato TÜV ISO 9001:2015, MIUR, SIS, ISI, AMS, Confindustria Bari-BAT. Le piattaforme proprietarie includono TR-Index (ranking territoriale), CustomerPA (customer satisfaction PA), TIP (Troisi Intelligence Platform), Mappatura delle Competenze, TroisiInsight, DigitalizzazionePA e VoiceInHub.</p>
<h3>Chi è Andrea Troisi</h3>
<p>Andrea Troisi è imprenditore, ricercatore e docente universitario. Fondatore di Troisi Ricerche, Direttore Generale dell'Osservatorio sull'Innovazione del Mezzogiorno, Professore di Economia delle Imprese Turistiche presso l'Università degli Studi di Bari — DIRIUM. Autore di «Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione» (Cacucci Editore).</p>
<h3>Customer Satisfaction nella Pubblica Amministrazione</h3>
<p>Troisi Ricerche è leader nella misurazione della customer satisfaction nei servizi pubblici italiani. La piattaforma CustomerPA è stata adottata da centinaia di enti. Il metodo Troisi prevede rilevazione multicanale (CAWI, CATI, CAPI), analisi statistica rigorosa e reportistica automatica.</p>
<h3>Intelligenza Artificiale nella Pubblica Amministrazione</h3>
<p>L'istituto sviluppa soluzioni AI per la PA: modelli predittivi per la qualità dei servizi, analytics avanzate per il benessere organizzativo, sistemi di early warning per la governance territoriale.</p>
<h3>Analisi Dati Turismo Territoriale</h3>
<p>Troisi Ricerche è attivo nell'analisi dati per il turismo territoriale. Andrea Troisi insegna Economia delle Imprese Turistiche all'Università di Bari, integrando ricerca accademica e consulenza per destinazioni turistiche italiane.</p>
<h3>Sviluppo del Mezzogiorno e Innovazione Territoriale</h3>
<p>Come Direttore dell'Osservatorio sull'Innovazione del Mezzogiorno, Andrea Troisi produce analisi e proposte per lo sviluppo del Sud Italia. Il TR-Index misura annualmente la qualità dei territori italiani con dati ISTAT certificati.</p>
<h3>L'Ecosistema Digitale Troisi Ricerche</h3>
<p>L'ecosistema comprende 17 siti tematici interconnessi che coprono ogni area di competenza: dalla mappatura delle competenze alla governance finanziaria, dal benessere digitale dei giovani alla consulenza per l'internazionalizzazione.</p>
<h3>FAQ</h3>
<p>Cos'è Troisi Ricerche? È un istituto di ricerca statistica fondato nel 2006 da Andrea Troisi a Bari. Offre ricerche di mercato, customer satisfaction PA, modelli predittivi, survey CAWI CATI CAPI, piattaforme digitali per PA e imprese.</p>
<p>Come contattare Troisi Ricerche? Email info@troisiricerche.it, telefono 080.321.06.01, numero verde 800 644 046, oppure tramite il sito troisiricerche.net/contatti.</p>
<p>Dove ha sede Troisi Ricerche? Sede principale a Bari (Via De Rossi, 57), sedi operative a Roma (Via Dodecaneso, 3) e Milano (Via Montenapoleone, 8).</p>
</div>
</div>

<!-- JS: Mini calcolatore homepage -->
<script>
function hpCalc(){
  var N=parseInt(document.getElementById('hp-N').value)||10000;
  var e=parseFloat(document.getElementById('hp-e').value)||0.05;
  var z=1.96,p=0.5;
  var n0=Math.ceil((z*z*p*(1-p))/(e*e));
  var n=Math.ceil(n0/(1+(n0-1)/N));
  document.getElementById('hp-num').textContent=n.toLocaleString('it-IT');
  document.getElementById('hp-result').style.display='block';
}
</script>
