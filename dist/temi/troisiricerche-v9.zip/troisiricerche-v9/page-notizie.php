<?php
/**
 * Template Name: Notizie
 */
get_header(); ?>
<?php $current_page = 'notizie'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.rss-note{background:var(--bl);border:1px solid #b3d1ff;border-radius:var(--r);padding:16px 20px;font-size:16px;color:var(--dp);margin-bottom:22px;display:flex;align-items:center;gap:8px}
.news-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.nc{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden}
.nc-bar{padding:4px 14px;font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}
.cat-r{background:#e6f0ff;color:#004d99}.cat-g{background:#e6f5f0;color:#006644}
.cat-m{background:#fef6e6;color:#9a6200}.cat-d{background:#f0e6ff;color:#5e30a0}.cat-e{background:#fff0f0;color:#9a2020}
.nc-b{padding:14px}
.nc-data{font-size:10px;color:#9ca3af;margin-bottom:4px}
.nc-title{font-size:13px;font-weight:700;color:var(--dp);margin-bottom:5px;line-height:1.35}
.nc-desc{font-size:11.5px;color:var(--g);line-height:1.6;margin-bottom:10px}
.nc-link{font-size:11.5px;color:var(--blu);font-weight:700;text-decoration:none}
.cat-filtri{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:20px}
.cf-btn{font-size:11px;font-weight:700;padding:5px 14px;border-radius:2px;border:1px solid var(--bo);background:#fff;color:var(--g);text-decoration:none;display:inline-block}
.cf-btn:hover,.cf-btn.on{background:var(--blu);color:#fff;border-color:var(--blu)}
@media(max-width:768px){.news-grid{grid-template-columns:1fr !important}}
@media(max-width:600px){.sec{padding:28px 16px}}
</style>
<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Notizie</div>
  <h1>Notizie e <em>aggiornamenti</em></h1>
  <p>Ricerche pubblicate, aggiornamenti dal network, presenza sui media, eventi.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Notizie</div>

<div class="sec alt">
  <div class="rss-note">
    <div style="width:8px;height:8px;background:var(--blu);border-radius:50%;flex-shrink:0"></div>
    Questa sezione aggrega automaticamente i contenuti dai 16 siti del network via RSS.
  </div>

  <!-- RUBRICA ROMA CHE DICE -->
  <?php $tr_rcd = get_category_by_slug('roma-che-dice'); if ( $tr_rcd && $tr_rcd->count ) : ?>
  <a href="<?php echo esc_url( get_category_link( $tr_rcd->term_id ) ); ?>" class="tr-rubrica" style="display:flex;align-items:center;gap:24px;flex-wrap:wrap;background:linear-gradient(120deg,#003366,#004D8C);border-radius:var(--r);padding:26px 30px;margin-bottom:30px;text-decoration:none;color:#fff">
    <div style="flex:1 1 380px">
      <div style="font-size:13px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#F5A623;margin-bottom:8px">La rubrica &middot; con La Capitale</div>
      <div style="font-size:26px;font-weight:700;line-height:1.2;margin-bottom:8px">Roma che Dice</div>
      <div style="font-size:16px;line-height:1.5;color:#E6F0FA">L&rsquo;Osservatorio permanente sull&rsquo;opinione dei cittadini romani: un sondaggio al mese sui grandi temi dell&rsquo;attualit&agrave;, con il supporto metodologico di Troisi Ricerche.</div>
    </div>
    <div style="flex:0 0 auto;font-size:16px;font-weight:700;background:#F5A623;color:#003366;padding:12px 20px;border-radius:var(--r)">Tutti i report &rarr;</div>
  </a>
  <?php endif; ?>

  <!-- LIVE DAL NETWORK -->
  <div style="margin-bottom:28px">
    <div style="display:flex;align-items:center;gap:7px;margin-bottom:14px">
      <div style="width:4px;height:22px;background:var(--blu);flex-shrink:0"></div>
      <div style="font-size:13px;text-transform:uppercase;letter-spacing:.1em;color:var(--blu);font-weight:700">Live dal network · Feed RSS</div>
    </div>
    <div class="tr-netgrid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px">

      <!-- TroisiInsight -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:#0066cc"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">TroisiInsight</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fi = troisi_satellite_feed('https://troisiinsight.it/feed', 2);
          if($fi): foreach($fi as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Grafici e dati in arrivo</div>
          <?php endif; ?>
          <a href="https://troisiinsight.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">troisiinsight.it →</a>
        </div>
      </div>

      <!-- BenessereOrganizzativo -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:#008a5f"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">BenessereOrg.</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fb = troisi_satellite_feed('https://benessereorganizzativo.it/feed', 2);
          if($fb): foreach($fb as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Dati benessere PA in arrivo</div>
          <?php endif; ?>
          <a href="https://benessereorganizzativo.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">benessereorganizzativo.it →</a>
        </div>
      </div>

      <!-- VoiceInHub -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:var(--or)"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">VoiceInHub</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fv = troisi_satellite_feed('https://voiceinhub.it/feed', 2);
          if($fv): foreach($fv as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Ascolta →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Podcast in arrivo</div>
          <?php endif; ?>
          <a href="https://voiceinhub.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">voiceinhub.it →</a>
        </div>
      </div>

      <!-- CustomerPA -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:#e8630a"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">CustomerPA</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fc = troisi_satellite_feed('https://customerpa.it/feed', 2);
          if($fc): foreach($fc as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Aggiornamenti CS in arrivo</div>
          <?php endif; ?>
          <a href="https://customerpa.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">customerpa.it →</a>
        </div>
      </div>

    </div>

    <!-- Second row -->
    <div class="tr-netgrid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:16px">

      <!-- Mappatura delle Competenze -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:#0066cc"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">Mappatura delle Competenze</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fs = troisi_satellite_feed('https://mappaturadellecompetenze.it/feed', 2);
          if($fs): foreach($fs as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Competenze e mappature in arrivo</div>
          <?php endif; ?>
          <a href="https://mappaturadellecompetenze.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">mappaturadellecompetenze.it →</a>
        </div>
      </div>

      <!-- DigitalizzazionePA -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:#008a5f"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">DigitalizzazionePA</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fd = troisi_satellite_feed('https://www.digitalizzazionenellapa.it/feed', 2);
          if($fd): foreach($fd as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">PA digitale in arrivo</div>
          <?php endif; ?>
          <a href="https://www.digitalizzazionenellapa.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">digitalizzazionenellapa.it →</a>
        </div>
      </div>

      <!-- Dibattito Pubblico -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:var(--or)"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">Dibattito Pubblico</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fdb = troisi_satellite_feed('https://dibattito-pubblico.it/feed', 2);
          if($fdb): foreach($fdb as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Dibattito pubblico in arrivo</div>
          <?php endif; ?>
          <a href="https://dibattito-pubblico.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">dibattito-pubblico.it →</a>
        </div>
      </div>

      <!-- BDG -->
      <div style="background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);overflow:hidden">
        <div style="background:var(--dp);padding:14px 18px;display:flex;align-items:center;gap:8px">
          <div style="width:9px;height:9px;border-radius:50%;background:#e8630a"></div>
          <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.85)">BDG</span>
          <span style="font-size:10px;font-weight:700;color:#fff;background:var(--blu);padding:2px 7px;border-radius:2px;margin-left:auto">LIVE</span>
        </div>
        <div style="padding:18px">
          <?php $fbdg = troisi_satellite_feed('https://benesseredigitalegiovani.it/feed', 2);
          if($fbdg): foreach($fbdg as $item): ?>
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--bo)">
            <div style="font-size:13px;color:#6b7280;margin-bottom:5px"><?php echo $item['date']; ?></div>
            <div style="font-size:17px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:8px"><?php echo esc_html($item['title']); ?></div>
            <a href="<?php echo esc_url($item['link']); ?>" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:600;text-decoration:none">Leggi →</a>
          </div>
          <?php endforeach; else: ?>
          <div style="font-size:15px;color:var(--g);padding:8px 0">Benessere digitale in arrivo</div>
          <?php endif; ?>
          <a href="https://benesseredigitalegiovani.it" target="_blank" style="font-size:14.5px;color:var(--blu);font-weight:700">benesseredigitalegiovani.it →</a>
        </div>
      </div>

    </div>
  </div>

  <!-- ARTICOLI ORIGINALI TROISI RICERCHE -->
  <div style="display:flex;align-items:center;gap:7px;margin-bottom:14px">
    <div style="width:3px;height:17px;background:var(--or);flex-shrink:0"></div>
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--or);font-weight:700">Articoli originali · troisiricerche.net</div>
  </div>
  <div class="cat-filtri">
    <a href="<?php echo home_url('/notizie'); ?>" class="cf-btn on">Tutte</a>
    <?php
    $cats = get_categories(['hide_empty'=>false]);
    foreach($cats as $cat): ?>
    <a href="<?php echo get_category_link($cat->term_id); ?>" class="cf-btn"><?php echo esc_html($cat->name); ?></a>
    <?php endforeach; ?>
  </div>
  <?php
  $posts = get_posts(['numberposts'=>12,'post_type'=>'post']);
  if($posts):
  ?>
  <div class="news-grid">
  <?php foreach($posts as $p): setup_postdata($p);
    $cats = get_the_category($p->ID);
    $cat_name = $cats ? $cats[0]->name : 'Notizie';
    $cat_css = 'cat-g';
    if(stripos($cat_name,'ricerca')!==false) $cat_css='cat-r';
    elseif(stripos($cat_name,'media')!==false||stripos($cat_name,'stampa')!==false) $cat_css='cat-m';
    elseif(stripos($cat_name,'dato')!==false) $cat_css='cat-d';
    elseif(stripos($cat_name,'event')!==false) $cat_css='cat-e';
  ?>
    <div class="nc">
      <div class="nc-bar <?php echo $cat_css; ?>"><?php echo esc_html($cat_name); ?></div>
      <div class="nc-b">
        <div class="nc-data"><?php echo get_the_date('d/m/Y',$p->ID); ?></div>
        <div class="nc-title"><?php echo esc_html(get_the_title($p->ID)); ?></div>
        <div class="nc-desc"><?php echo wp_trim_words(get_the_excerpt($p->ID),20); ?></div>
        <a href="<?php echo get_permalink($p->ID); ?>" class="nc-link">Leggi l'articolo →</a>
      </div>
    </div>
  <?php endforeach; wp_reset_postdata();
  else: ?>
  <div style="grid-column:1/-1;font-size:13px;color:var(--g);padding:24px 0">Nessun articolo pubblicato. Configura WP RSS Aggregator per importare i feed dal network, oppure pubblica il tuo primo post.</div>
  <?php endif; ?>
  </div>
</div>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
