<?php
/**
 * Template Name: Gioca con la statistica
 * Quattro giochi originali di Troisi Ricerche: Indovina il dato, Il sondaggio perfetto,
 * Il paradosso del compleanno, Le tre porte. Nessuna libreria esterna.
 */
get_header();
$current_page = 'giochi';
include(get_template_directory() . '/troisi-nav.php');
?>
<style>
.gs{--n:#003366;--b:#004D8C;--o:#F5A623;--od:#D95C14;--g:#00856A;--lb:#E6F0FA;--t:#1F2937;--mu:#6B7280;--bo:#E5E7EB;--bg:#F9FAFB;font-family:Inter,Arial,Helvetica,sans-serif;color:var(--t);background:#fff}
.gs *{box-sizing:border-box}
.gs-hero{background:linear-gradient(135deg,#00264d 0%,var(--n) 55%,var(--b) 100%);color:#fff;padding:64px 24px 56px;position:relative;overflow:hidden}
.gs-hero:after{content:'';position:absolute;right:-80px;top:-80px;width:360px;height:360px;border-radius:50%;background:radial-gradient(circle,rgba(245,166,35,.28),transparent 65%)}
.gs-in{max-width:1080px;margin:0 auto;position:relative;z-index:1}
.gs-kick{display:inline-block;font-size:12px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--o);margin-bottom:14px}
.gs-hero h1{font-size:clamp(32px,5vw,52px);line-height:1.08;margin:0 0 14px;font-weight:800;color:#fff}
.gs-hero h1 em{font-style:normal;color:var(--o)}
.gs-hero p{font-size:18px;line-height:1.6;max-width:680px;color:rgba(255,255,255,.82);margin:0}
.gs-nav{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
.gs-nav a{color:#fff;text-decoration:none;border:1px solid rgba(255,255,255,.3);padding:9px 16px;border-radius:999px;font-size:14px;font-weight:600;background:rgba(255,255,255,.06)}
.gs-nav a:hover{background:var(--o);border-color:var(--o);color:var(--n)}
.gs-sec{padding:56px 24px;border-bottom:1px solid var(--bo)}
.gs-sec:nth-of-type(even){background:var(--bg)}
.gs-h{display:flex;align-items:baseline;gap:14px;margin-bottom:6px}
.gs-num{font-size:14px;font-weight:800;color:var(--od);letter-spacing:.1em}
.gs-sec h2{font-size:clamp(24px,3.2vw,34px);margin:0;color:var(--n);font-weight:800}
.gs-lead{font-size:16.5px;line-height:1.65;color:#374151;max-width:760px;margin:8px 0 26px}
.gs-card{background:#fff;border:1px solid var(--bo);border-radius:14px;padding:26px;box-shadow:0 6px 24px rgba(0,51,102,.06)}
.gs-btn{display:inline-flex;align-items:center;gap:8px;background:var(--o);color:var(--n);border:0;border-radius:8px;padding:12px 20px;font-weight:800;font-size:15px;cursor:pointer;font-family:inherit}
.gs-btn:hover{background:#ffb84a}
.gs-btn.sec{background:#fff;color:var(--n);border:1.5px solid var(--n)}
.gs-btn.sec:hover{background:var(--lb)}
.gs-btn:disabled{opacity:.45;cursor:default}
.gs-row{display:flex;flex-wrap:wrap;gap:12px;align-items:center}
.gs-small{font-size:13px;color:var(--mu);line-height:1.55}
.gs-learn{margin-top:22px;background:var(--lb);border-left:4px solid var(--b);border-radius:8px;padding:16px 18px;font-size:15px;line-height:1.6}
.gs-learn b{color:var(--n)}
/* Indovina il dato */
.gd-q{font-size:21px;font-weight:700;color:var(--n);line-height:1.35;margin:6px 0 18px;min-height:58px}
.gd-prog{font-size:13px;font-weight:700;color:var(--od);letter-spacing:.08em;text-transform:uppercase}
.gd-val{font-size:44px;font-weight:800;color:var(--b);margin:6px 0}
.gs input[type=range]{width:100%;accent-color:#D95C14;height:28px}
.gd-scale{display:flex;justify-content:space-between;font-size:12px;color:var(--mu)}
.gd-res{margin-top:18px;padding:18px;border-radius:10px;background:#FFF7E8;border:1px solid #F8D9A0;display:none}
.gd-res.show{display:block}
.gd-bar{position:relative;height:14px;background:#EEF2F7;border-radius:7px;margin:26px 0 30px}
.gd-mk{position:absolute;top:-22px;transform:translateX(-50%);font-size:12px;font-weight:700;white-space:nowrap}
.gd-dot{position:absolute;top:-3px;width:20px;height:20px;border-radius:50%;transform:translateX(-50%);border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.25)}
.gd-score{font-size:15px;font-weight:700}
.gd-final{text-align:center;padding:10px 0}
.gd-final .big{font-size:56px;font-weight:800;color:var(--od)}
/* Sondaggio */
.sp-grid{display:grid;grid-template-columns:1fr 1.25fr;gap:26px}
.sp-n{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 18px}
.sp-n button{border:1.5px solid var(--bo);background:#fff;border-radius:8px;padding:9px 14px;font-weight:700;font-size:15px;cursor:pointer;font-family:inherit;color:var(--n)}
.sp-n button.on{background:var(--n);color:#fff;border-color:var(--n)}
.sp-big{font-size:40px;font-weight:800;color:var(--b)}
.sp-me{font-size:15px;color:var(--t)}
.sp-svg{width:100%;height:auto;display:block;background:#fff;border:1px solid var(--bo);border-radius:10px}
/* Compleanno */
.bd-grid{display:grid;grid-template-columns:1fr 1fr;gap:26px}
.bd-p{font-size:52px;font-weight:800;color:var(--od);line-height:1}
.bd-room{display:grid;grid-template-columns:repeat(10,1fr);gap:5px;margin-top:14px}
.bd-room span{font-size:11px;text-align:center;padding:6px 0;border-radius:6px;background:#EEF2F7;color:var(--n);font-weight:600}
.bd-room span.hit{background:var(--o);color:var(--n)}
/* Monty Hall */
.mh-doors{display:flex;gap:18px;justify-content:center;margin:10px 0 18px;flex-wrap:wrap}
.mh-door{width:130px;height:190px;border-radius:10px 10px 4px 4px;background:linear-gradient(180deg,var(--b),var(--n));color:#fff;border:0;cursor:pointer;font-size:34px;font-weight:800;position:relative;font-family:inherit;box-shadow:0 8px 20px rgba(0,51,102,.18);transition:transform .15s}
.mh-door:hover{transform:translateY(-3px)}
.mh-door.sel{outline:4px solid var(--o);outline-offset:3px}
.mh-door.open{background:#F3F4F6;color:var(--t);cursor:default}
.mh-door .lbl{position:absolute;left:0;right:0;bottom:14px;font-size:13px;font-weight:700;opacity:.9}
.mh-door.open .prize{font-size:60px}
.mh-msg{text-align:center;font-size:18px;font-weight:700;color:var(--n);min-height:52px}
.mh-stats{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:18px}
.mh-stat{background:var(--bg);border:1px solid var(--bo);border-radius:10px;padding:14px}
.mh-stat b{font-size:26px;color:var(--b)}
.mh-bar{height:12px;border-radius:6px;background:#E5E7EB;margin-top:8px;overflow:hidden}
.mh-bar i{display:block;height:100%;background:var(--od);width:0;transition:width .6s}
.gs-cta{background:var(--n);color:#fff;padding:52px 24px;text-align:center}
.gs-cta h2{color:#fff;font-size:28px;margin:0 0 10px}
.gs-cta p{color:rgba(255,255,255,.8);font-size:16px;margin:0 0 22px}
@media(max-width:820px){.sp-grid,.bd-grid{grid-template-columns:1fr}.mh-door{width:92px;height:140px;font-size:26px}.gd-val{font-size:36px}}
</style>

<main class="gs">
  <section class="gs-hero">
    <div class="gs-in">
      <span class="gs-kick">Troisi Ricerche · Gioca con la statistica</span>
      <h1>I numeri non mentono. <em>L'intuito sì.</em></h1>
      <p>Quattro giochi per mettere alla prova il tuo senso dei numeri: stime, sondaggi, coincidenze e probabilità. Si gioca in un minuto, si capisce qualcosa che resta. I dati vengono dalle analisi dei nostri osservatori.</p>
      <nav class="gs-nav" aria-label="Giochi">
        <a href="#indovina-il-dato">Indovina il dato</a>
        <a href="#sondaggio-perfetto">Il sondaggio perfetto</a>
        <a href="#paradosso-compleanno">Il paradosso del compleanno</a>
        <a href="#tre-porte">Le tre porte</a>
      </nav>
    </div>
  </section>

  <!-- 1. INDOVINA IL DATO -->
  <section class="gs-sec" id="indovina-il-dato">
    <div class="gs-in">
      <div class="gs-h"><span class="gs-num">01</span><h2>Indovina il dato</h2></div>
      <p class="gs-lead">Cinque domande sull'Italia. Sposta il cursore sulla tua stima, poi scopri il dato vero e quanto ti sei avvicinato. Quasi tutti sbagliano nella stessa direzione: vediamo tu.</p>
      <div class="gs-card" id="gd">
        <div class="gd-prog" id="gd-prog"></div>
        <div class="gd-q" id="gd-q"></div>
        <div class="gd-val" id="gd-val"></div>
        <input type="range" id="gd-r" aria-label="La tua stima">
        <div class="gd-scale"><span id="gd-min"></span><span id="gd-max"></span></div>
        <div class="gs-row" style="margin-top:18px"><button class="gs-btn" id="gd-go">Conferma la stima</button><button class="gs-btn sec" id="gd-next" style="display:none">Prossima domanda →</button></div>
        <div class="gd-res" id="gd-res"></div>
      </div>
    </div>
  </section>

  <!-- 2. IL SONDAGGIO PERFETTO -->
  <section class="gs-sec" id="sondaggio-perfetto">
    <div class="gs-in">
      <div class="gs-h"><span class="gs-num">02</span><h2>Il sondaggio perfetto</h2></div>
      <p class="gs-lead">In una città immaginaria una quota di cittadini è soddisfatta dei servizi comunali. Solo noi conosciamo il valore vero. Scegli quante persone intervistare e lancia il sondaggio: quanto si avvicina la tua stima?</p>
      <div class="sp-grid">
        <div class="gs-card">
          <div class="gs-small" style="font-weight:700;color:var(--n)">Quante persone intervisti?</div>
          <div class="sp-n" id="sp-n"></div>
          <div class="gs-row"><button class="gs-btn" id="sp-go">Fai un sondaggio</button><button class="gs-btn sec" id="sp-100">Fanne 100</button></div>
          <div style="margin-top:22px">
            <div class="gs-small">Il tuo ultimo sondaggio dice</div>
            <div class="sp-big" id="sp-est">—</div>
            <div class="sp-me" id="sp-me"></div>
            <div class="gs-small" id="sp-cov" style="margin-top:10px"></div>
          </div>
        </div>
        <div class="gs-card">
          <svg class="sp-svg" id="sp-svg" viewBox="0 0 560 300" role="img" aria-label="Risultati dei sondaggi simulati"></svg>
          <div class="gs-small" style="margin-top:8px">Ogni punto è un sondaggio. La linea arancione è il valore vero; la fascia azzurra è l'intervallo in cui cade il 95% dei sondaggi con quel numero di interviste.</div>
        </div>
      </div>
      <div class="gs-learn"><b>Cosa insegna.</b> L'errore di un sondaggio non dipende dalla grandezza della città, ma soprattutto da quante persone intervisti: per <b>dimezzare</b> il margine di errore servono <b>quattro volte</b> le interviste. È il calcolo che facciamo ogni volta che progettiamo un'indagine. <a href="<?php echo esc_url(home_url('/strumenti/calcola-campione/')); ?>">Prova il nostro calcolatore del campione →</a></div>
    </div>
  </section>

  <!-- 3. PARADOSSO DEL COMPLEANNO -->
  <section class="gs-sec" id="paradosso-compleanno">
    <div class="gs-in">
      <div class="gs-h"><span class="gs-num">03</span><h2>Il paradosso del compleanno</h2></div>
      <p class="gs-lead">In una stanza ci sono alcune persone. Quante ne servono perché ci sia almeno il 50% di probabilità che due compiano gli anni lo stesso giorno? Prima di muovere il cursore, fai la tua ipotesi.</p>
      <div class="bd-grid">
        <div class="gs-card">
          <div class="gs-small" style="font-weight:700;color:var(--n)">Persone nella stanza: <span id="bd-nv" style="color:var(--od);font-size:18px"></span></div>
          <input type="range" id="bd-n" min="2" max="80" value="10" aria-label="Persone nella stanza">
          <div class="gs-small" style="margin-top:12px">Probabilità che almeno due festeggino lo stesso giorno</div>
          <div class="bd-p" id="bd-p"></div>
          <div class="gs-row" style="margin-top:16px"><button class="gs-btn" id="bd-sim">Riempi una stanza a caso</button></div>
          <div class="gs-small" id="bd-msg" style="margin-top:12px;min-height:40px"></div>
          <div class="bd-room" id="bd-room"></div>
        </div>
        <div class="gs-card">
          <svg class="sp-svg" id="bd-svg" viewBox="0 0 560 300" role="img" aria-label="Probabilità di un compleanno in comune al crescere delle persone"></svg>
        </div>
      </div>
      <div class="gs-learn"><b>Cosa insegna.</b> Bastano <b>23 persone</b> per superare il 50%, e con 57 si arriva al 99%. Il nostro intuito conta i compleanni uguali al <i>nostro</i>, ma le coppie possibili crescono molto più in fretta delle persone: con 23 persone le coppie sono 253. Per questo in statistica le "coincidenze" vanno sempre controllate con i numeri.</div>
    </div>
  </section>

  <!-- 4. LE TRE PORTE -->
  <section class="gs-sec" id="tre-porte">
    <div class="gs-in">
      <div class="gs-h"><span class="gs-num">04</span><h2>Le tre porte</h2></div>
      <p class="gs-lead">Dietro una porta c'è un'auto, dietro le altre due una capra. Scegli una porta: il conduttore, che sa dov'è l'auto, ne apre un'altra con una capra e ti chiede se vuoi cambiare. Conviene?</p>
      <div class="gs-card">
        <div class="mh-doors" id="mh-doors"></div>
        <div class="mh-msg" id="mh-msg">Scegli una porta.</div>
        <div class="gs-row" style="justify-content:center"><button class="gs-btn sec" id="mh-new">Nuova partita</button><button class="gs-btn" id="mh-sim">Simula 1.000 partite</button></div>
        <div class="mh-stats">
          <div class="mh-stat"><div class="gs-small">Chi <b style="font-size:inherit;color:inherit">resta</b> sulla prima scelta vince</div><b id="mh-s">—</b><div class="mh-bar"><i id="mh-sb"></i></div></div>
          <div class="mh-stat"><div class="gs-small">Chi <b style="font-size:inherit;color:inherit">cambia</b> porta vince</div><b id="mh-c">—</b><div class="mh-bar"><i id="mh-cb"></i></div></div>
        </div>
      </div>
      <div class="gs-learn"><b>Cosa insegna.</b> Cambiare porta fa vincere <b>2 volte su 3</b>. La prima scelta ha 1 probabilità su 3 di essere giusta e l'apertura del conduttore non la cambia: le altre 2 probabilità su 3 si "concentrano" sulla porta rimasta chiusa. Quando arriva un'informazione nuova, la probabilità va ricalcolata: è il cuore del ragionamento statistico.</div>
    </div>
  </section>

  <section class="gs-cta">
    <div class="gs-in">
      <h2>Ti è piaciuto giocare con i numeri?</h2>
      <p>Ogni mese «Il dato è tratto» porta i dati dei nostri osservatori, con i grafici e una lettura. E se hai un'indagine da progettare, parliamone.</p>
      <div class="gs-row" style="justify-content:center"><a class="gs-btn" href="https://calendly.com/andreatroisi/30min" target="_blank" rel="noopener">Fissiamo 30 minuti</a><a class="gs-btn sec" style="background:transparent;color:#fff;border-color:#fff" href="<?php echo esc_url(home_url('/notizie/')); ?>">Leggi le analisi</a></div>
    </div>
  </section>
</main>

<script>
(function(){
var fmt=function(v,d){return v.toLocaleString('it-IT',{minimumFractionDigits:d,maximumFractionDigits:d});};
var $=function(id){return document.getElementById(id);};
var NS='http://www.w3.org/2000/svg';
function el(t,a,p){var e=document.createElementNS(NS,t);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e;}
function txt(p,x,y,s,a){var t=el('text',Object.assign({x:x,y:y,'font-size':12,fill:'#6B7280','font-family':'Arial,Helvetica,sans-serif'},a||{}),p);t.textContent=s;return t;}

/* ---------- 1. Indovina il dato ---------- */
var Q=[
 {q:'Quanti italiani su 100 presentano da soli, online, la dichiarazione dei redditi?',v:11.8,min:0,max:100,st:0.5,d:1,u:'%',ctx:'La media UE è 38,2%; in Danimarca 84,9%. Dati 2025.',src:'CustomerPA',url:'https://www.customerpa.it/2026/09/01/dichiarazione-redditi-online-italia-europa-2025/'},
 {q:'Quante imprese italiane su 100 fanno formazione al proprio personale?',v:68.9,min:0,max:100,st:0.5,d:1,u:'%',ctx:'Più della media europea.',src:'Benessere Organizzativo',url:'https://www.benessereorganizzativo.it/formazione-continua-imprese-italia-cvts/'},
 {q:'Ogni 100 imprese attive, quante nuove imprese sono nate in Italia nel 2023?',v:7.8,min:0,max:30,st:0.1,d:1,u:'',ctx:'La media UE è 10,5: l\'Italia è terzultima.',src:'Governance Finanziaria',url:'https://www.governancefinanziaria.it/nascite-cessazioni-imprese-italia-europa-2023/'},
 {q:'Che quota della forza lavoro allargata vorrebbe lavorare, o lavorare di più, senza riuscirci? (Italia, 2025)',v:14.7,min:0,max:50,st:0.1,d:1,u:'%',ctx:'Media UE 11,0%. Nel 2015 l\'Italia era al 26,1%.',src:'Mappatura delle Competenze',url:'https://www.mappaturadellecompetenze.it/2026/09/20/capitale-umano-inutilizzato-slack-italia/'},
 {q:'Quante auto ci sono in Italia ogni 1.000 abitanti?',v:701,min:0,max:1000,st:1,d:0,u:'',ctx:'È il valore più alto d\'Europa.',src:'CustomerPA',url:'https://www.customerpa.it/2026/09/15/auto-per-abitante-italia-prima-europa-2024/'},
 {q:'Che percentuale dei consumi finali di energia in Italia viene da fonti rinnovabili? (2025)',v:20.5,min:0,max:100,st:0.5,d:1,u:'%',ctx:'La media UE è 26%; sulla sola elettricità l\'Italia arriva al 43%.',src:'TroisiInsight',url:'https://www.troisiinsight.it/2026/09/21/energia-rinnovabile-2025-italia-20-per-cento-europa/'},
 {q:'Quanti giovani su 100 abbandonano precocemente la scuola in Italia? (2025)',v:8.2,min:0,max:40,st:0.1,d:1,u:'%',ctx:'Sotto la media europea e sotto l\'obiettivo 2030.',src:'CustomerPA',url:'https://www.customerpa.it/2026/08/25/abbandono-scolastico-italia-2025-sotto-media-europea/'},
 {q:'Quanti bambini su 100, dai 3 anni, frequentano la scuola dell\'infanzia in Italia?',v:92.4,min:0,max:100,st:0.5,d:1,u:'%',ctx:'Il 73,4% a tempo pieno.',src:'CustomerPA',url:'https://www.customerpa.it/2026/09/08/scuola-infanzia-3-6-anni-tempo-pieno-italia-europa/'},
 {q:'Di quanto è cresciuto l\'export della Puglia nel primo semestre 2026?',v:15.2,min:-20,max:40,st:0.1,d:1,u:'%',ctx:'Il Mezzogiorno +5,2%, l\'Italia +4,5%.',src:'Consulenza Internazionalizzazione',url:'https://www.consulenzainternazionalizzazione.it/?p=96'},
 {q:'Quanti morti in incidenti stradali ci sono in Italia ogni 100.000 abitanti?',v:5.1,min:0,max:20,st:0.1,d:1,u:'',ctx:'Più della media europea.',src:'Dibattito Pubblico',url:'https://www.dibattito-pubblico.it/2026/09/11/sicurezza-stradale-morti-italia-europa/'}
];
var round=[],qi=0,tot=0,cur;
function shuffle(a){for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;}return a;}
function show(){cur=round[qi];var r=$('gd-r');r.min=cur.min;r.max=cur.max;r.step=cur.st;r.value=(cur.min+cur.max)/2;$('gd-prog').textContent='Domanda '+(qi+1)+' di '+round.length;$('gd-q').textContent=cur.q;$('gd-min').textContent=fmt(cur.min,0)+cur.u;$('gd-max').textContent=fmt(cur.max,0)+cur.u;upd();$('gd-res').className='gd-res';$('gd-go').style.display='';$('gd-go').disabled=false;$('gd-next').style.display='none';r.disabled=false;}
function upd(){$('gd-val').textContent=fmt(+$('gd-r').value,cur.d)+cur.u;}
function start(){round=shuffle(Q.slice()).slice(0,5);qi=0;tot=0;show();}
$('gd-r').addEventListener('input',upd);
$('gd-go').addEventListener('click',function(){var g=+$('gd-r').value,span=cur.max-cur.min,err=Math.abs(g-cur.v)/span,pts=Math.max(0,Math.round(100*(1-err*4)));tot+=pts;$('gd-r').disabled=true;this.style.display='none';
 var pg=(g-cur.min)/span*100,pv=(cur.v-cur.min)/span*100;
 var verdict=err<0.02?'Centro pieno!':err<0.06?'Molto vicino.':err<0.15?'Non male.':'Lontano: il dato sorprende quasi tutti.';
 var dir=g>cur.v?'Hai sovrastimato':'Hai sottostimato';
 $('gd-res').innerHTML='<div class="gd-score">'+verdict+' +'+pts+' punti</div><div class="gd-bar"><span class="gd-dot" style="left:'+pg+'%;background:#9CA3AF"></span><span class="gd-mk" style="left:'+pg+'%;color:#6B7280">tu: '+fmt(g,cur.d)+cur.u+'</span><span class="gd-dot" style="left:'+pv+'%;background:#D95C14"></span><span class="gd-mk" style="left:'+pv+'%;top:22px;color:#D95C14">vero: '+fmt(cur.v,cur.d)+cur.u+'</span></div><div>'+(err<0.02?'':dir+' di '+fmt(Math.abs(g-cur.v),cur.d)+(cur.u||'')+'. ')+cur.ctx+'</div><div class="gs-small" style="margin-top:8px">Fonte: analisi di <a href="'+cur.url+'" target="_blank" rel="noopener">'+cur.src+'</a> su dati ufficiali.</div>';
 $('gd-res').className='gd-res show';var nx=$('gd-next');nx.style.display='';nx.textContent=qi<round.length-1?'Prossima domanda →':'Vedi il risultato →';});
$('gd-next').addEventListener('click',function(){qi++;if(qi<round.length){show();return;}
 var msg=tot>=400?'Hai l\'occhio dello statistico.':tot>=250?'Buon intuito: con i dati diventa ottimo.':'I numeri veri sorprendono: per questo li misuriamo.';
 $('gd').innerHTML='<div class="gd-final"><div class="gd-prog">Il tuo punteggio</div><div class="big">'+tot+' / 500</div><p style="font-size:17px;color:#003366;font-weight:700">'+msg+'</p><button class="gs-btn" onclick="location.hash=\'indovina-il-dato\';location.reload()">Gioca ancora</button></div>';});
start();

/* ---------- 2. Il sondaggio perfetto ---------- */
var P=0.42+Math.round(Math.random()*16)/100, Ns=[25,100,400,1000,2500], n=100, polls=[];
var box=$('sp-n');Ns.forEach(function(k){var b=document.createElement('button');b.textContent=k.toLocaleString('it-IT');b.onclick=function(){n=k;polls=[];[].forEach.call(box.children,function(c){c.className='';});b.className='on';draw();$('sp-est').textContent='—';$('sp-me').textContent='';$('sp-cov').textContent='';};if(k===n)b.className='on';box.appendChild(b);});
function poll(){var s=0;for(var i=0;i<n;i++)if(Math.random()<P)s++;return s/n;}
function me(){return 1.96*Math.sqrt(P*(1-P)/n);}
function draw(){var sv=$('sp-svg');while(sv.firstChild)sv.removeChild(sv.firstChild);var L=40,R=540,T=20,B=260,x=function(v){return L+(v-0.2)/0.6*(R-L);};
 for(var v=0.2;v<=0.801;v+=0.1){el('line',{x1:x(v),x2:x(v),y1:T,y2:B,stroke:'#EEF2F7'},sv);txt(sv,x(v),B+18,Math.round(v*100)+'%',{'text-anchor':'middle'});}
 var m=me();el('rect',{x:x(P-m),y:T,width:x(P+m)-x(P-m),height:B-T,fill:'#E6F0FA'},sv);
 polls.forEach(function(e,i){var y=B-8-(i%24)*10;el('circle',{cx:x(Math.max(.2,Math.min(.8,e))),cy:y,r:4.2,fill:Math.abs(e-P)<=m?'#004D8C':'#D95C14','fill-opacity':.8},sv);});
 el('line',{x1:x(P),x2:x(P),y1:T-6,y2:B,stroke:'#F5A623','stroke-width':3},sv);txt(sv,x(P),T-8+2,'valore vero',{'text-anchor':'middle',fill:'#D95C14','font-weight':'bold'});
 txt(sv,L,B+36,n.toLocaleString('it-IT')+' interviste · margine ±'+fmt(m*100,1)+' punti',{fill:'#003366','font-weight':'bold'});}
function run(k){for(var i=0;i<k;i++)polls.push(poll());if(polls.length>240)polls=polls.slice(-240);var last=polls[polls.length-1],m=me();$('sp-est').textContent=fmt(last*100,1)+'% soddisfatti';$('sp-me').textContent='Margine di errore con '+n.toLocaleString('it-IT')+' interviste: ±'+fmt(m*100,1)+' punti.';var inn=polls.filter(function(e){return Math.abs(e-P)<=m;}).length;$('sp-cov').innerHTML='Valore vero: <b>'+fmt(P*100,0)+'%</b>. Dei tuoi '+polls.length+' sondaggi, '+inn+' ('+fmt(inn/polls.length*100,0)+'%) sono caduti entro il margine.';draw();}
$('sp-go').onclick=function(){run(1);};$('sp-100').onclick=function(){run(100);};draw();

/* ---------- 3. Paradosso del compleanno ---------- */
function pb(k){var q=1;for(var i=0;i<k;i++)q*=(365-i)/365;return 1-q;}
function bdDraw(k){var sv=$('bd-svg');while(sv.firstChild)sv.removeChild(sv.firstChild);var L=46,R=540,T=20,B=260,x=function(v){return L+(v-2)/78*(R-L);},y=function(p){return B-p*(B-T);};
 [0,.25,.5,.75,1].forEach(function(p){el('line',{x1:L,x2:R,y1:y(p),y2:y(p),stroke:'#EEF2F7'},sv);txt(sv,L-8,y(p)+4,Math.round(p*100)+'%',{'text-anchor':'end'});});
 [10,20,30,40,50,60,70,80].forEach(function(v){txt(sv,x(v),B+18,v,{'text-anchor':'middle'});});
 txt(sv,(L+R)/2,B+36,'persone nella stanza',{'text-anchor':'middle'});
 var d='';for(var i=2;i<=80;i++)d+=(i===2?'M':'L')+x(i)+','+y(pb(i));el('path',{d:d,fill:'none',stroke:'#004D8C','stroke-width':3},sv);
 el('line',{x1:x(23),x2:x(23),y1:y(.5),y2:B,stroke:'#F5A623','stroke-dasharray':'4 4','stroke-width':2},sv);el('line',{x1:L,x2:x(23),y1:y(.5),y2:y(.5),stroke:'#F5A623','stroke-dasharray':'4 4','stroke-width':2},sv);txt(sv,x(23)+6,y(.5)-8,'23 persone = 50,7%',{fill:'#D95C14','font-weight':'bold'});
 el('circle',{cx:x(k),cy:y(pb(k)),r:7,fill:'#D95C14',stroke:'#fff','stroke-width':2},sv);}
function bdUpd(){var k=+$('bd-n').value;$('bd-nv').textContent=k;$('bd-p').textContent=fmt(pb(k)*100,1)+'%';bdDraw(k);}
$('bd-n').addEventListener('input',function(){bdUpd();$('bd-room').innerHTML='';$('bd-msg').textContent='';});
var MESI=['gen','feb','mar','apr','mag','giu','lug','ago','set','ott','nov','dic'],GG=[31,28,31,30,31,30,31,31,30,31,30,31];
function lab(d){var m=0;while(d>=GG[m]){d-=GG[m];m++;}return (d+1)+' '+MESI[m];}
$('bd-sim').onclick=function(){var k=+$('bd-n').value,days=[],cnt={};for(var i=0;i<k;i++){var d=Math.floor(Math.random()*365);days.push(d);cnt[d]=(cnt[d]||0)+1;}
 var hits=Object.keys(cnt).filter(function(d){return cnt[d]>1;});$('bd-room').innerHTML=days.map(function(d){return '<span class="'+(cnt[d]>1?'hit':'')+'">'+lab(d)+'</span>';}).join('');
 $('bd-msg').innerHTML=hits.length?'<b style="color:#D95C14">Coincidenza!</b> '+hits.map(function(d){return lab(+d);}).join(', ')+' '+(hits.length>1?'sono condivisi':'è condiviso')+' da più persone.':'Nessun compleanno in comune questa volta. Riprova, o aggiungi persone.';};
bdUpd();

/* ---------- 4. Le tre porte ---------- */
var car,pick,opened,phase,st={s:[0,0],c:[0,0]};
function mhNew(){car=Math.floor(Math.random()*3);pick=null;opened=null;phase=0;render();$('mh-msg').textContent='Scegli una porta.';}
function render(fin){var w=$('mh-doors');w.innerHTML='';for(var i=0;i<3;i++){(function(i){var b=document.createElement('button');b.className='mh-door'+(i===pick?' sel':'')+((i===opened||fin)?' open':'');b.setAttribute('aria-label','Porta '+(i+1));
 if(i===opened||fin){b.innerHTML='<span class="prize">'+(i===car?'🚗':'🐐')+'</span><span class="lbl">Porta '+(i+1)+'</span>';}else{b.innerHTML=(i+1)+'<span class="lbl">Porta</span>';}
 b.onclick=function(){click(i);};w.appendChild(b);})(i);}}
function click(i){if(phase===0){pick=i;var c=[0,1,2].filter(function(d){return d!==pick&&d!==car;});opened=c[Math.floor(Math.random()*c.length)];phase=1;render();
 $('mh-msg').innerHTML='Il conduttore apre la porta '+(opened+1)+': c\'è una capra.<br>Resti sulla '+(pick+1)+' o cambi? Clicca la porta che vuoi.';}
 else if(phase===1&&i!==opened){var sw=i!==pick;pick=i;phase=2;var win=pick===car;var k=sw?'c':'s';st[k][1]++;if(win)st[k][0]++;render(true);
 $('mh-msg').innerHTML=(win?'Hai vinto l\'auto!':'Capra! L\'auto era dietro la porta '+(car+1)+'.')+' Hai '+(sw?'cambiato':'tenuto la prima scelta')+'.';stats();}}
function stats(){['s','c'].forEach(function(k){var a=st[k];$('mh-'+k).textContent=a[1]?fmt(a[0]/a[1]*100,0)+'% ('+a[0].toLocaleString('it-IT')+' su '+a[1].toLocaleString('it-IT')+')':'—';$('mh-'+k+'b').style.width=a[1]?(a[0]/a[1]*100)+'%':'0';});}
$('mh-new').onclick=mhNew;
$('mh-sim').onclick=function(){for(var j=0;j<1000;j++){var c=Math.floor(Math.random()*3),p=Math.floor(Math.random()*3),o=[0,1,2].filter(function(d){return d!==p&&d!==c;})[0],sw=[0,1,2].filter(function(d){return d!==p&&d!==o;})[0];st.s[1]++;if(p===c)st.s[0]++;st.c[1]++;if(sw===c)st.c[0]++;}stats();$('mh-msg').textContent='1.000 partite simulate per ciascuna strategia: guarda le barre.';};
mhNew();
})();
</script>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
