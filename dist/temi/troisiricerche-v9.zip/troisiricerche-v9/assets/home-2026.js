/* 10.3.0 – Apertura della home: parola che cambia + numero a puntini. I temi arrivano da data-h26 (JSON). */
(function () {
  var box = document.querySelector('[data-h26]');
  if (!box) return;
  var T;
  try { T = JSON.parse(box.getAttribute('data-h26')); } catch (e) { return; }
  if (!T || !T.length) return;
  var ridotto = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (id) { return document.getElementById(id); }, par = $('h26-parola');
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function lettere(str, cls) { return str.split('').map(function (ch) { var i = document.createElement('i'); i.textContent = ch === ' ' ? ' ' : ch; if (cls) i.className = cls; return i; }); }
  function cambiaParola(str) {
    if (ridotto) { par.textContent = str; return; }
    var vecchie = [].slice.call(par.children);
    if (!vecchie.length) { par.textContent = ''; lettere(str).forEach(function (i) { par.appendChild(i); }); return; }
    vecchie.forEach(function (i, k) { setTimeout(function () { i.className = 'su'; }, k * 12); });
    setTimeout(function () {
      par.textContent = ''; var nuove = lettere(str, 'giu'); nuove.forEach(function (i) { par.appendChild(i); });
      requestAnimationFrame(function () { nuove.forEach(function (i, k) { setTimeout(function () { i.className = ''; }, k * 16); }); });
    }, 240 + vecchie.length * 12);
  }
  var cv = $('h26-cv'), ctx = cv.getContext('2d'), W, H, dpr = Math.min(2, window.devicePixelRatio || 1), N = 1600, P = [];
  var OR = [245, 166, 35], BI = [255, 255, 255];
  function dim() {
    var r = cv.getBoundingClientRect(); W = r.width; H = r.height; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); N = W < 500 ? 1000 : 1600;
    while (P.length < N) P.push({ x: Math.random() * W, y: Math.random() * H, vx: 0, vy: 0, tx: null, ty: null, r: BI.slice(), t: BI.slice(), a: .15, ta: .15, rad: 1.3 });
    P.length = N;
  }
  function punti(str) {
    var o = document.createElement('canvas'), c = o.getContext('2d'), fs = 200; o.width = 1500; o.height = 300;
    c.font = '900 ' + fs + 'px "Titillium Web", "Arial Black", sans-serif'; c.fillText(str, 10, fs);
    var d = c.getImageData(0, 0, o.width, o.height).data, pts = [], x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1, st = 5;
    for (var y = 0; y < o.height; y += st) for (var x = 0; x < o.width; x += st) {
      if (d[(y * o.width + x) * 4 + 3] > 128) { pts.push([x, y]); x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    }
    var s = Math.min(W * .92 / (x1 - x0 + 1), H * .72 / (y1 - y0 + 1)), ox = (W - (x1 - x0) * s) / 2, oy = (H - (y1 - y0) * s) / 2;
    return pts.map(function (q) { return { x: ox + (q[0] - x0) * s, y: oy + (q[1] - y0) * s }; });
  }
  function colore(n) { return /\d/.test(n) ? OR : BI; }
  function forma(str, col) {
    var pts = punti(str);
    for (var i = pts.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var z = pts[i]; pts[i] = pts[j]; pts[j] = z; }
    var t0 = performance.now();
    for (var n = 0; n < N; n++) {
      var p = P[n], q = pts[n]; p.rit = t0 + Math.random() * 400;
      if (q) { p.tx = q.x; p.ty = q.y; p.t = col; p.ta = 1; p.rad = W < 500 ? 1.5 : 1.8; }
      else { p.tx = null; p.t = BI; p.ta = .14; p.rad = 1; p.vx = (Math.random() - .5) * .5; p.vy = (Math.random() - .5) * .5; }
      if (ridotto && q) { p.x = q.x; p.y = q.y; p.r = col.slice(); p.a = 1; }
    }
  }
  function disegna() {
    ctx.clearRect(0, 0, W, H); var now = performance.now();
    for (var i = 0; i < N; i++) {
      var p = P[i];
      if (p.tx !== null && now > p.rit) { p.vx += (p.tx - p.x) * .045; p.vy += (p.ty - p.y) * .045; p.vx *= .8; p.vy *= .8; }
      p.x += p.vx; p.y += p.vy;
      if (p.tx === null) { if (p.x < 0) p.x = W; if (p.x > W) p.x = 0; if (p.y < 0) p.y = H; if (p.y > H) p.y = 0; }
      for (var c = 0; c < 3; c++) p.r[c] += (p.t[c] - p.r[c]) * .08; p.a += (p.ta - p.a) * .06;
      ctx.fillStyle = 'rgba(' + (p.r[0] | 0) + ',' + (p.r[1] | 0) + ',' + (p.r[2] | 0) + ',' + p.a.toFixed(2) + ')';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.rad, 0, 6.283); ctx.fill();
    }
    requestAnimationFrame(disegna);
  }
  var k = 0, timer, pn = $('h26-pn');
  T.forEach(function (d, i) {
    var b = document.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', d.m);
    b.addEventListener('click', function () { k = i; vai(i); riparti(); }); pn.appendChild(b);
  });
  function vai(i) {
    var d = T[i]; cambiaParola(d.p); forma(d.n, colore(d.n));
    $('h26-prod').textContent = d.m; $('h26-desc').textContent = d.d;
    var x = esc(d.x), n = esc(d.n);
    if (/\d/.test(d.n) && x.indexOf(n) > -1) x = x.replace(n, '<b>' + n + '</b>');
    $('h26-dato').innerHTML = x + (d.h ? ' · ' + esc(d.h) : '');
    var a = $('h26-link'); a.href = d.u; a.textContent = d.h ? "Leggi l'analisi →" : 'Vai al sito →';
    [].forEach.call(pn.children, function (b, j) { b.setAttribute('aria-current', j === i ? 'true' : 'false'); });
  }
  function riparti() { clearInterval(timer); timer = setInterval(function () { k = (k + 1) % T.length; vai(k); }, 3800); }
  function avvia() { dim(); par.textContent = ''; lettere(T[0].p).forEach(function (i) { par.appendChild(i); }); vai(0); requestAnimationFrame(disegna); riparti(); }
  var rt; window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { dim(); forma(T[k].n, colore(T[k].n)); }, 200); });
  (document.fonts && document.fonts.load ? document.fonts.load('900 100px "Titillium Web"') : Promise.resolve()).then(avvia, avvia);
})();
