<?php
/**
 * troisi-footer.php
 * Footer riutilizzabile per tutte le pagine interne
 */
$_td = get_template_directory_uri();
?>
<!-- FOOTER -->
<div class="troisi-footer">
  <div class="fg">
    <div>
      <div class="fb-top">
        <img src="<?php echo $_td; ?>/logo-troisi-header-bianco.png" alt="Troisi Ricerche" class="fb-logo" width="395" height="220">
        <div>
          <div class="fb-name">Troisi Ricerche</div>
          <div class="fb-sub">Istituto di Ricerca Statistica &middot; dal 2006</div>
        </div>
      </div>
      <p class="fb-p">Ricerca statistica applicata per enti pubblici, imprese e territori. Customer satisfaction, benessere organizzativo, governance partecipativa, mappatura delle competenze.</p>
      <div class="fb-legal">Troisi Ricerche S.r.l. Unipersonale &middot; P.IVA 07216100722<br>Via De Rossi, 57 — 70122 Bari (BA) &middot; REA BA-541094</div>
      <div class="fb-sedi">
        <div class="fb-sede">Bari &middot; sede principale · Via De Rossi, 57</div>
        <div class="fb-sede">Roma &middot; sede operativa · Via Dodecaneso, 3</div>
        <div class="fb-sede">Milano &middot; sede operativa · Via Montenapoleone, 8</div>
      </div>
    </div>
    <div>
      <div class="fc-h4">Il sito</div>
      <ul class="fc-ul">
        <li><a href="<?php echo home_url('/chi-siamo'); ?>">Chi siamo</a></li>
        <li><a href="<?php echo home_url('/la-ricerca'); ?>">La ricerca</a></li>
        <li><a href="<?php echo home_url('/casi-studio'); ?>">Casi studio</a></li>
        <li><a href="<?php echo home_url('/servizi'); ?>">Servizi</a></li>
        <li><a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a></li>
        <li><a href="<?php echo home_url('/clienti'); ?>">Clienti</a></li>
        <li><a href="<?php echo home_url('/media'); ?>">Media</a></li>
        <li><a href="<?php echo home_url('/rassegna-stampa'); ?>">Rassegna Stampa</a></li>
        <li><a href="<?php echo home_url('/territorio'); ?>">Territorio</a></li>
        <li><a href="<?php echo home_url('/notizie'); ?>">Notizie</a></li>
        <li><a href="<?php echo home_url('/contatti'); ?>">Contatti</a></li>
      </ul>
    </div>
    <div>
      <div class="fc-h4">Il network</div>
      <ul class="fc-ul">
        <li><a href="https://t-index.it" target="_blank" rel="noopener">TR-Index</a></li>
        <li><a href="https://customerpa.it" target="_blank" rel="noopener">CustomerPA</a></li>
        <li><a href="https://benessereorganizzativo.it" target="_blank" rel="noopener">BenessereOrg.</a></li>
        <li><a href="https://troisiinsight.it" target="_blank" rel="noopener">TroisiInsight</a></li>
        <li><a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener">Mappatura delle Competenze</a></li>
        <li><a href="https://www.digitalizzazionenellapa.it" target="_blank" rel="noopener">DigitalizzazionePA</a></li>
      </ul>
    </div>
    <div>
      <div class="fc-h4">Piattaforme</div>
      <ul class="fc-ul">
        <li><a href="https://voiceinhub.it" target="_blank" rel="noopener">VoiceInHub</a></li>
        <li><a href="https://tip.troisiricerche.it" target="_blank" rel="noopener">TIP Platform</a></li>
        <li><a href="https://dibattito-pubblico.it" target="_blank" rel="noopener">Dibattito Pubblico</a></li>
        <li><a href="https://www.delfiweb.it" target="_blank" rel="noopener">DELFI · dati dei comuni</a></li>
        <li><a href="https://www.ricerchedimercato.eu" target="_blank" rel="noopener">Ricerche di mercato</a></li>
        <li><a href="https://www.ricerchequalitative.it" target="_blank" rel="noopener">Ricerche qualitative</a></li>
        <li><a href="https://greenlife4seas.poliba.it" target="_blank" rel="noopener">GreenLife4Seas</a></li>
        <li><a href="https://andreatroisi.it" target="_blank" rel="noopener">andreatroisi.it</a></li>
      </ul>
    </div>
    <div>
      <div class="fc-h4">Contatti</div>
      <ul class="fc-ul">
        <li><a href="mailto:info@troisiricerche.it">info@troisiricerche.it</a></li>
        <li><a href="tel:+390803210601">+39 080.321.06.01</a></li>
        <li><a href="tel:800644046">Num. verde: 800 644 046</a></li>
        <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener">LinkedIn</a></li>
        <li><a href="https://www.facebook.com/troisiricerche" target="_blank" rel="noopener">Facebook</a></li>
        <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank" rel="noopener">YouTube</a></li>
        <li><a href="https://www.iubenda.com/privacy-policy/28809400" class="iubenda-white iubenda-noiframe iubenda-embed" title="Privacy Policy" target="_blank" rel="noopener">Privacy Policy</a></li>
        <li><a href="https://www.iubenda.com/privacy-policy/28809400/cookie-policy" class="iubenda-white iubenda-noiframe iubenda-embed" title="Cookie Policy" target="_blank" rel="noopener">Cookie Policy</a></li>
      </ul>
    </div>
  </div>
  <div class="fbot">
    <span>&copy; <?php echo date('Y'); ?> Troisi Ricerche S.r.l. Unipersonale &middot; P.IVA 07216100722</span>
    <div>
      <a href="https://www.iubenda.com/privacy-policy/28809400" target="_blank" rel="noopener">Privacy</a>
      <a href="https://www.iubenda.com/privacy-policy/28809400/cookie-policy" target="_blank" rel="noopener">Cookie</a>
      <a href="<?php echo home_url('/note-legali'); ?>">Note legali</a>
    </div>
  </div>
</div>
<!-- iubenda Privacy Policy widget -->
<script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0]; s.src="https://cdn.iubenda.com/iubenda.js"; tag.parentNode.insertBefore(s,tag);}; if(w.addEventListener){w.addEventListener("load", loader, false);}else if(w.attachEvent){w.attachEvent("onload", loader);}else{w.onload = loader;}})(window, document);</script>
<?php wp_footer(); ?>
</body>
</html>
