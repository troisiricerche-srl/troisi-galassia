<?php
/**
 * Template Name: Chi Siamo
 * Troisi Ricerche v9 — Designers Italia responsive
 */
get_header(); $current_page = 'chi-siamo';
include(get_template_directory() . '/troisi-nav.php');
$_td = get_template_directory_uri(); ?>
<style>
.andrea-hero{background:var(--dp);padding:32px 28px;display:grid;grid-template-columns:120px 1fr;gap:28px;align-items:center;border-radius:var(--r-lg)}
.af{width:116px;height:116px;border-radius:50%;object-fit:cover;border:4px solid var(--blu)}
.an{font-size:20px;font-weight:700;color:#fff;margin-bottom:3px}
.ar{font-size:11px;color:rgba(255,255,255,.48);margin-bottom:12px}
.ab{font-size:13px;color:rgba(255,255,255,.7);line-height:1.75}
.timeline{position:relative;padding-left:28px;margin-top:8px}
.timeline::before{content:'';position:absolute;left:9px;top:4px;bottom:0;width:2px;background:var(--bo)}
.tl-item{position:relative;margin-bottom:26px}
.tl-dot{position:absolute;left:-24px;top:5px;width:11px;height:11px;border-radius:50%;background:var(--blu);border:2px solid #fff;box-shadow:0 0 0 2px var(--blu)}
.tl-anno{font-size:10.5px;font-weight:700;color:var(--blu);margin-bottom:3px}
.tl-tit{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:4px}
.tl-desc{font-size:12.5px;color:var(--g);line-height:1.65}
.cs-grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.m-card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;border-top:3px solid var(--blu);transition:box-shadow .2s var(--ease)}
.m-card:hover{box-shadow:var(--shadow-md)}
.m-card .ic{font-size:22px;margin-bottom:8px}
.m-card h3{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:5px}
.m-card p{font-size:12.5px;color:var(--g);line-height:1.65;margin:0}
.team-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.t-card{background:#fff;border:1px solid var(--bo);border-radius:var(--r-lg);padding:20px;border-top:3px solid var(--or);transition:box-shadow .2s var(--ease)}
.t-card:hover{box-shadow:var(--shadow-md)}
.t-card .ic{font-size:22px;margin-bottom:8px}
.t-card h3{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:5px}
.t-card p{font-size:12.5px;color:var(--g);line-height:1.65;margin:0}
.t-card p strong{color:var(--dp)}
.collab-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}
.collab-item{background:#fff;border:1px solid var(--bo);border-radius:var(--r);padding:9px 12px;font-size:12px;color:var(--t);transition:background .15s}
.collab-item:hover{background:var(--bl)}
.sedi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.sede-card{background:var(--dp);border-radius:var(--r-lg);padding:22px;color:#fff}
.sede-city{font-size:18px;font-weight:700;margin-bottom:3px}
.sede-role{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:rgba(255,255,255,.42);margin-bottom:10px}
.sede-info{font-size:12px;color:rgba(255,255,255,.6);line-height:1.65}
.s-t{font-size:20px;font-weight:700;color:var(--dp);margin-bottom:8px}.s-t em{color:var(--blu);font-style:normal}
.s-d{font-size:13px;color:var(--g);margin-bottom:22px;line-height:1.75;max-width:680px}
@media(max-width:900px){.andrea-hero{grid-template-columns:1fr;text-align:center;gap:16px}.af{margin:0 auto}.cs-grid3,.team-grid{grid-template-columns:1fr 1fr}.collab-grid{grid-template-columns:repeat(3,1fr)}.sedi-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.andrea-hero{padding:24px 16px}.cs-grid3,.team-grid,.sedi-grid{grid-template-columns:1fr}.collab-grid{grid-template-columns:repeat(2,1fr)}.an{font-size:18px}}
</style>

<div class="ph"><div class="wrap">
  <div class="ph-ey">Troisi Ricerche &middot; Chi siamo</div>
  <h1>L'istituto, il fondatore, <em>il metodo</em></h1>
  <p>Troisi Ricerche è un istituto di ricerca statistica fondato da Andrea Troisi nel 2006. Vent'anni di lavoro sul campo, metodo scientifico rigoroso, presenza nazionale.</p>
</div></div>
<div class="bc"><div class="wrap"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Chi siamo</div></div>

<div class="sec alt"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Il fondatore</div></div>
  <div class="andrea-hero">
    <img src="<?php echo $_td; ?>/foto-andrea.jpg" alt="Andrea Troisi" class="af">
    <div>
      <div class="an"><?php echo esc_html(troisi_opt("andrea_nome","Andrea Troisi")); ?></div>
      <div class="ar"><?php echo esc_html(troisi_opt("andrea_ruolo","Fondatore e Direttore scientifico · Troisi Ricerche · Bari")); ?></div>
      <div class="ab">Statistico, ricercatore e autore. Specializzato in customer satisfaction, benessere organizzativo e governance territoriale. Dal 2006 guida Troisi Ricerche con un approccio che coniuga rigore scientifico e concretezza applicativa. Fondatore di un ecosistema di 16 siti e piattaforme per la governance pubblica. Autore di numerosi volumi per Cacucci Editore, tra cui "Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza" (2026). Ospite fisso su Tele Lazio Nord nel programma Drive In, conduttore di "Il Dato è Tratto" su Controradio, membro SIS, ISI e AMS, associato Confindustria Bari-BAT. Professore universitario all'Università degli Studi di Bari Aldo Moro (Dipartimento DIRIUM).</div>
    </div>
  </div>
</div></div>

<div class="sec"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Mission e metodo</div></div>
  <div class="s-t">Trasformare i dati in <em>conoscenza utile</em></div>
  <div class="cs-grid3">
    <div class="m-card"><div class="ic">🎯</div><h3>La mission</h3><p>Trasformare dati statistici complessi in conoscenza accessibile e utile per chi decide nella PA, nelle imprese e nei territori. Rigore scientifico unito a linguaggio comprensibile.</p></div>
    <div class="m-card"><div class="ic">🔬</div><h3>Il metodo</h3><p>Approccio statistico proprietario: Customer Satisfaction Index, TR-Index, modelli di benessere organizzativo. Ogni strumento nasce da anni di ricerca applicata sul campo.</p></div>
    <div class="m-card"><div class="ic">🌐</div><h3>Il network</h3><p>16 siti specializzati, ognuno dedicato a un tema. Un ecosistema integrato che parte da troisiricerche.net come hub e si espande in strumenti, piattaforme e dati.</p></div>
  </div>
</div></div>

<div class="sec alt" id="storia"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">La nostra storia</div></div>
  <div class="s-t">Dal <em>2006</em> a oggi</div>
  <div class="timeline">
    <?php
    $tl_posts = troisi_get_timeline();
    if ($tl_posts):
      foreach ($tl_posts as $tl):
        $anno = get_post_meta($tl->ID, '_troisi_anno', true);
        $desc = get_post_meta($tl->ID, '_troisi_tl_desc', true);
        $ev = get_post_meta($tl->ID, '_troisi_tl_evidenza', true);
        $dot_style = $ev ? ' style="background:var(--or);box-shadow:0 0 0 2px var(--or)"' : '';
    ?>
    <div class="tl-item"><div class="tl-dot"<?php echo $dot_style; ?>></div><div class="tl-anno"><?php echo esc_html($anno); ?></div><div class="tl-tit"><?php echo esc_html($tl->post_title); ?></div><div class="tl-desc"><?php echo esc_html($desc); ?></div></div>
    <?php endforeach; else: ?>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2006</div><div class="tl-tit">Fondazione di Troisi Ricerche</div><div class="tl-desc">Andrea Troisi fonda l'istituto a Bari. Prime ricerche sulla customer satisfaction nelle pubbliche amministrazioni pugliesi.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2010</div><div class="tl-tit">Espansione nazionale e certificazione ISO</div><div class="tl-desc">Apertura della sede operativa a Roma. Prima certificazione TÜV ISO 9001. Avvio delle collaborazioni con ministeri e regioni.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2018</div><div class="tl-tit">Il modello statistico per la customer satisfaction nella PA</div><div class="tl-desc">Esce per Cacucci Editore «Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione». Nello stesso anno nasce il TR-Index, indice proprietario per la misurazione delle performance territoriali, e prende avvio il network di siti specializzati.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2019</div><div class="tl-tit">Camera dei Deputati</div><div class="tl-desc">29 marzo 2019: il volume viene presentato in conferenza stampa alla Camera dei Deputati, in diretta su webtv.camera.it.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2021</div><div class="tl-tit">Il dibattito pubblico</div><div class="tl-desc">Con TenderCoop e Ti Quadro nasce la piattaforma Dibattito Pubblico: Troisi Ricerche entra nella governance delle grandi opere.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2022</div><div class="tl-tit">Di nuovo alla Camera, con Fondirigenti</div><div class="tl-desc">25 marzo 2022: il modello di competenze per la governance finanziaria, realizzato per Fondirigenti, presentato alla Camera dei Deputati.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2024</div><div class="tl-tit">La dimensione europea</div><div class="tl-desc">GreenLife4Seas (programma LIFE), poi SUMMA (Interreg Italia-Croazia) e CROSS-MOVE (Interreg IPA South Adriatic): progetti europei tra Italia, Croazia, Grecia, Albania e Montenegro.</div></div>
    <div class="tl-item"><div class="tl-dot"></div><div class="tl-anno">2026</div><div class="tl-tit">Senato della Repubblica</div><div class="tl-desc">15 giugno 2026: presentazione del libro «Le organizzazioni che si misurano» a Palazzo Madama.</div></div>
    <div class="tl-item"><div class="tl-dot" style="background:var(--or);box-shadow:0 0 0 2px var(--or)"></div><div class="tl-anno">2026</div><div class="tl-tit">Oggi: +200 clienti, network completo</div><div class="tl-desc">Un ecosistema maturo con strumenti per ogni area della governance pubblica: customer satisfaction, benessere, competenze, partecipazione, territorio.</div></div>
    <?php endif; ?>
  </div>
</div></div>

<div class="sec"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Le sedi</div></div>
  <div class="sedi-grid">
    <?php
    $sedi = troisi_get_sedi();
    if ($sedi):
      foreach ($sedi as $sede):
        $ruolo = get_post_meta($sede->ID, '_troisi_sede_ruolo', true);
        $info = get_post_meta($sede->ID, '_troisi_sede_info', true);
    ?>
    <div class="sede-card"><div class="sede-city"><?php echo esc_html($sede->post_title); ?></div><div class="sede-role"><?php echo esc_html($ruolo); ?></div><div class="sede-info"><?php echo wp_kses_post($info); ?></div></div>
    <?php endforeach; else: ?>
    <div class="sede-card"><div class="sede-city">Bari</div><div class="sede-role">Sede principale · Direzione scientifica</div><div class="sede-info">Sede legale e operativa principale: direzione scientifica, team di ricerca, coordinamento del network.<br>Via De Rossi, 57 · 70122 Bari (BA)<br>+39 080.321.06.01 · Numero verde 800 644 046</div></div>
    <div class="sede-card"><div class="sede-city">Roma</div><div class="sede-role">Sede operativa · PA nazionale</div><div class="sede-info">Presidio istituzionale: relazioni con ministeri, agenzie nazionali, Forum PA.<br>Via Dodecaneso, 3 · 00144 Roma (RM)</div></div>
    <div class="sede-card"><div class="sede-city">Milano</div><div class="sede-role">Sede operativa · Imprese</div><div class="sede-info">Presidio nord-Italia: relazioni con imprese, associazioni di categoria, committenti privati.<br>Via Montenapoleone, 8 · 20121 Milano (MI)</div></div>
    <?php endif; ?>
  </div>
</div></div>

<div class="sec alt" id="collaboratori"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Il team</div></div>
  <div class="s-t">Le <em>persone</em> dietro ai dati</div>
  <p class="s-d">Un team multidisciplinare di ricercatori, statistici, manager e formatori con esperienza diretta sul campo.</p>
  <div class="team-grid">
    <?php
    $team_attivo = troisi_get_team(true);
    if ($team_attivo):
      foreach ($team_attivo as $m):
        $icona = get_post_meta($m->ID, '_troisi_icona', true) ?: '👤';
        $ruolo = get_post_meta($m->ID, '_troisi_ruolo', true);
        $bio = get_post_meta($m->ID, '_troisi_bio', true);
    ?>
    <div class="t-card"><div class="ic"><?php echo $icona; ?></div><h3><?php echo esc_html($m->post_title); ?></h3><p><strong><?php echo esc_html($ruolo); ?>.</strong> <?php echo esc_html($bio); ?></p></div>
    <?php endforeach; else: ?>
    <div class="t-card"><div class="ic">📐</div><h3>Carlo Cusatelli</h3><p><strong>Responsabile Statistico.</strong> Ricercatore confermato di Statistica all'Università di Bari, ricercatore senior FSE e Tecnologo ISTAT. Autore di numerose pubblicazioni di statistica multivariata.</p></div>
    <div class="t-card"><div class="ic">🌐</div><h3>Davide Manganelli</h3><p><strong>Business Development.</strong> Strategic Expansion Consultant con esperienza internazionale. Guida la crescita e lo sviluppo di nuovi mercati.</p></div>
    <div class="t-card"><div class="ic">📊</div><h3>Brixhilda Lleshi, PhD</h3><p><strong>Project Manager & Data Analyst.</strong> Ingegnere Civile specializzata in analisi dati. Coordina i progetti complessi garantendo qualità, tempi e risultati misurabili.</p></div>
    <div class="t-card"><div class="ic">🎓</div><h3>Elena Caramia</h3><p><strong>Formazione & Coaching.</strong> Coach Professionista MCI, Practitioner e Technician in PNL. Formatrice, Orientatrice, Esperta in gestione delle risorse umane e formazione continua.</p></div>
    <div class="t-card"><div class="ic">🔬</div><h3>Debora Cazzetta, PhD</h3><p><strong>Ricercatrice.</strong> Data analyst, specialista in semiotica e linguistica, con esperienza ultra-decennale nella qualitative marketing research. Dottore di ricerca.</p></div>
    <div class="t-card"><div class="ic">💼</div><h3>Stefania Fanelli</h3><p><strong>Account & Administrative Management.</strong> Marketing Solutions, PR events. Strong problem solving, diplomacy and team builder skills. Specializzazione in Relazioni Internazionali.</p></div>
    <?php endif; ?>
  </div>
</div></div>

<div class="sec"><div class="wrap">
  <div class="sh"><div class="sl"></div><div class="se">Chi ha contribuito a costruire Troisi Ricerche</div></div>
  <div class="s-t"><em>Grazie</em> a chi ha fatto parte di questa storia</div>
  <p class="s-d">In vent'anni di attività, oltre 70 professionisti — statistici, ricercatori, esperti di governance, analisti, informatici, comunicatori, formatori — hanno scelto di far parte di Troisi Ricerche. A ciascuno di loro va la nostra gratitudine più sincera. Ogni nome qui sotto rappresenta una storia, un contributo, un pezzo della nostra storia comune.</p>
  <div class="collab-grid">
    <?php
    $storici = troisi_get_team(false);
    if ($storici):
      foreach ($storici as $s): ?>
    <div class="collab-item"><?php echo esc_html($s->post_title); ?></div>
      <?php endforeach;
    else:
      $collaboratori=['Silvia Gravili','Giuseppe Raffaele','Barbara Di Bari','Margherita Console','Gemma Di Poppa','Adriana Fanelli','Fabiana Ferrante','Massimiliano Gaeta','Leonardo Lovecchio','Rossella Vantaggio','Monica Fabiano','Andrea Fistetto','Domenico Ficco','Enza Moscaritolo','Luca Tisselli','Marco Mancarella','Davide Catizone','Raffaele Nitti','Francesco Gismondi','Maria Teresa Digennaro','Stefano Iacovino','Rossella Sgaramella','Eva Cossa','Andrea Picciuolo','Niccolò Accettura','Mattia Caputo','Valentina Battista','Alessia Forciniti','Valeria Elisabetta Volponi','Botelho Rosli de Jesus','Carmela Piccolo','Debora Bettinardi','Denis Damiani','Elide Paoletti','Elisabetta Battista','Felicia Risci','Franca Vigolo','Roberto Leone','Silvia Bettinardi','Giuseppe Remine','Ivan Remine','Paolo Inno','Paolo Binetti','Giacomo Carreras','Alessandro Cafagno','Daniele Leuzzi','Giuseppe Rubino','Andrea Belcredi','Daniele Cavallo','Elena Ciliberti','Salvatore Alì','Saverio De Bellis','Simone Bottalico','Vera Ciliberti','Diana Sanna','Ornella La Tegola','Mariateresa Caldarola','Andrea Venturelli','Nicola D\'Elia','Manuela Mirizzi','Francesca Traldi'];
      foreach($collaboratori as $c): ?>
    <div class="collab-item"><?php echo esc_html($c); ?></div>
      <?php endforeach;
    endif; ?>
    <div class="collab-item" style="border:1px dashed var(--bo);color:var(--g);font-style:italic;grid-column:span 2">… e a tutti coloro che, in modi grandi e piccoli, hanno contribuito a rendere Troisi Ricerche quello che è oggi.</div>
  </div>
</div></div>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
