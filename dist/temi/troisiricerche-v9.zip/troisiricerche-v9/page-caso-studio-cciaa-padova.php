<?php
/**
 * Template Name: Scheda Progetto — CCIAA Padova
 * Post/Page da creare in WordPress come contenuto per La Ricerca o caso studio autonomo
 */
// Usato come pagina statica o post nella categoria "Casi Studio"
get_header(); ?>
<?php $current_page = 'casi-studio'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
.ph-meta{display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap}
.ph-cat{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:2px 9px;background:var(--blu);color:#fff;border-radius:2px}
.ph-year{font-size:11px;color:rgba(255,255,255,.45)}
.ph h1{font-size:26px;font-weight:700;color:#fff;margin-bottom:8px;line-height:1.2}
.ph-sub{font-size:13.5px;color:rgba(255,255,255,.62);max-width:640px;line-height:1.7}
.li{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);font-weight:700;border:1px solid #b3d1ff;padding:4px 12px;border-radius:2px;background:var(--bl);text-decoration:none}
.li::after{content:'→'}
.le{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--g);font-weight:600;border:1px solid var(--bo);padding:4px 12px;border-radius:2px;text-decoration:none}
.le::after{content:'↗';color:#9ca3af}

/* Layout principale */
.prog-layout{max-width:1060px;margin:0 auto;padding:32px 24px;display:grid;grid-template-columns:1fr 300px;gap:28px;align-items:start}

/* Scheda tecnica sidebar */
.scheda-tecnica{background:var(--dp);border-radius:var(--r);padding:22px;position:sticky;top:80px}
.st-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.38);margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.1)}
.st-row{display:flex;flex-direction:column;gap:2px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.07)}
.st-row:last-of-type{border-bottom:none}
.st-label{font-size:10px;color:rgba(255,255,255,.38);text-transform:uppercase;letter-spacing:.05em}
.st-val{font-size:12.5px;color:rgba(255,255,255,.82);font-weight:600;line-height:1.4}
.st-nums{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.1)}
.sn{text-align:center}
.sn-v{font-size:26px;font-weight:700;color:var(--or);line-height:1}
.sn-l{font-size:9.5px;color:rgba(255,255,255,.42);line-height:1.3;margin-top:2px}

/* Contenuto articolo */
.art-body{}
.art-body h2{font-size:18px;font-weight:700;color:var(--dp);margin-top:26px;margin-bottom:10px;padding-left:10px;border-left:3px solid var(--blu)}
.art-body h3{font-size:15px;font-weight:700;color:var(--dp);margin-top:18px;margin-bottom:7px}
.art-body p{font-size:13.5px;color:#3a4558;line-height:1.85;margin-bottom:14px}
.art-body strong{color:var(--dp)}

/* Numeri chiave */
.numeri-band{background:var(--dp);border-radius:var(--r);padding:22px 28px;margin:22px 0;display:grid;grid-template-columns:repeat(3,1fr);gap:0}
.nb-item{text-align:center;padding:0 16px}
.nb-item:not(:last-child){border-right:1px solid rgba(255,255,255,.1)}
.nb-val{font-size:34px;font-weight:700;color:var(--or);line-height:1;margin-bottom:3px}
.nb-label{font-size:11px;color:rgba(255,255,255,.5);line-height:1.4}

/* Filiere */
.filiere-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:16px 0}
.filiera-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:16px;border-top:3px solid var(--blu)}
.filiera-card.meccanica{border-top-color:#5a6a85}
.filiera-card.casa{border-top-color:var(--vd)}
.fc-name{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:4px}
.fc-n{font-size:11px;color:var(--g);margin-bottom:8px}
.fc-finding{font-size:12px;color:var(--g);line-height:1.6;padding-top:8px;border-top:1px solid var(--bo)}
.fc-tag{display:inline-block;font-size:10px;font-weight:700;padding:2px 7px;border-radius:2px;margin-bottom:6px}
.tag-warning{background:#fff3e0;color:#b45309;border:1px solid #ffd080}
.tag-ok{background:#e6f5ee;color:#00663a;border:1px solid #a0d4b8}

/* Metodologia box */
.metodo-box{background:var(--bl);border:1px solid #b3d1ff;border-radius:var(--r);padding:18px 20px;margin:16px 0}
.mb-title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--bd);margin-bottom:10px}
.mb-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
.mb-item{font-size:12.5px;color:var(--bd);display:flex;gap:6px;align-items:flex-start}
.mb-item::before{content:'▸';color:var(--blu);flex-shrink:0;margin-top:1px}

/* Rassegna stampa */
.stampa-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
.stampa-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:14px;display:flex;gap:12px;align-items:flex-start}
.sc-testata{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--blu);margin-bottom:3px}
.sc-data{font-size:10px;color:var(--g);margin-bottom:5px}
.sc-title{font-size:12.5px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:4px}
.sc-desc{font-size:11.5px;color:var(--g);line-height:1.55}
.sc-icon{font-size:20px;flex-shrink:0;margin-top:2px}

/* Evento Chain Reactions */
.evento-box{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:20px;border-left:4px solid var(--vd);margin-top:16px}
.eb-badge{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:2px 8px;border-radius:2px;background:#e6f5ee;color:#00663a;border:1px solid #a0d4b8;display:inline-block;margin-bottom:8px}
.eb-title{font-size:15px;font-weight:700;color:var(--dp);margin-bottom:4px}
.eb-sub{font-size:11px;color:var(--g);margin-bottom:10px}
.eb-agenda{font-size:12px;color:var(--g);line-height:1.75}
.eb-agenda strong{color:var(--t)}

@media(max-width:900px){
  .prog-layout{grid-template-columns:1fr}
  .scheda-tecnica{position:static}
  .filiere-grid{grid-template-columns:1fr}
  .numeri-band{grid-template-columns:1fr}
  .nb-item:not(:last-child){border-right:none;border-bottom:1px solid rgba(255,255,255,.1);padding-bottom:12px;margin-bottom:8px}
}
</style>

<div class="ph">
  <div class="ph-meta">
    <span class="ph-cat">Caso Studio · Ricerca applicata</span>
    <span class="ph-year">2018–2021</span>
    <span class="ph-year" style="background:rgba(255,255,255,.07);padding:2px 8px;border-radius:2px">Veneto · Nord-Est</span>
  </div>
  <h1>Mappatura Dinamica delle Imprese<br><em>Camera di Commercio di Padova</em></h1>
  <p class="ph-sub">Ricerca quantitativa su tre filiere strategiche del territorio padovano: Casa/efficienza energetica, Informatica/ICT, Meccanica di precisione. 244 imprese, 14.700 dati, con successiva partecipazione al progetto europeo Interreg Chain Reactions.</p>
</div>
<div class="bc">
  <a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo;
  <a href="<?php echo home_url('/la-ricerca'); ?>">La ricerca</a> &rsaquo;
  Mappatura Dinamica — CCIAA Padova
</div>

<div class="prog-layout">

  <!-- CORPO PRINCIPALE -->
  <div class="art-body">

    <h2>Il contesto: Padova Innovation Hub</h2>
    <p>Nel 2014, la <strong>Camera di Commercio di Padova</strong> ha avviato il progetto <strong>Padova Innovation Hub</strong>, finanziato con 500.000 euro, con durata quinquennale. L'obiettivo: accompagnare le imprese del territorio padovano ad aggregarsi e avviare processi di innovazione, superando i gap conoscitivi sulle opportunità di investimento disponibili a livello nazionale ed europeo.</p>
    <p>Troisi Ricerche è stata incaricata della <strong>fase di mappatura e monitoraggio</strong>: una ricerca quantitativa per comprendere la propensione all'innovazione delle imprese delle tre filiere strategiche individuate come prioritarie per il territorio.</p>

    <div class="numeri-band">
      <div class="nb-item">
        <div class="nb-val">244</div>
        <div class="nb-label">Imprese coinvolte nelle 3 filiere</div>
      </div>
      <div class="nb-item">
        <div class="nb-val">60</div>
        <div class="nb-label">Domande a questionario per impresa</div>
      </div>
      <div class="nb-item">
        <div class="nb-val">14.700</div>
        <div class="nb-label">Dati disponibili per l'analisi</div>
      </div>
    </div>

    <h2>La metodologia</h2>
    <p>La mappatura si è distinta per un approccio multi-metodo e multi-fonte, con un'architettura metodologica capace di garantire la comparabilità dei risultati tra filiere diverse e la possibilità per la CCIAA di aggiornare i database ottenuti nel tempo (da qui la definizione di <strong>"dinamica"</strong>).</p>

    <div class="metodo-box">
      <div class="mb-title">Architettura metodologica</div>
      <div class="mb-grid">
        <div class="mb-item">Ricerca quantitativa campionaria</div>
        <div class="mb-item">Interviste CATI/CAMI — telefono e mobile</div>
        <div class="mb-item">Interviste CAWI — web</div>
        <div class="mb-item">Analisi on desk dei trend tecnologici europei</div>
        <div class="mb-item">Focus group per approfondimento qualitativo</div>
        <div class="mb-item">Confronto con Galileo Visionary District</div>
      </div>
    </div>

    <p>Previsto dal capitolato CCIAA: 50 interviste per filiera. <strong>Realizzate in media: 80 per filiera</strong> — il 60% in più rispetto all'obiettivo contrattuale, garantendo una maggiore rappresentatività statistica del campione.</p>

    <p>Il questionario, strutturato in 5 sezioni (propensione all'innovazione, l'impresa e le nuove tecnologie, rapporti di filiera, profilo dell'impresa, profilo dell'amministratore), copriva 60 domande per un totale di 36 variabili analizzate.</p>

    <h2>Le tre filiere e i principali risultati</h2>

    <div class="filiere-grid">
      <div class="filiera-card casa">
        <div class="fc-name">🏠 Filiera "Casa"</div>
        <div class="fc-n">4.581 imprese nel territorio · 80 intervistati</div>
        <span class="fc-tag tag-warning">Criticità emergente</span>
        <div class="fc-finding">Il 59,5% delle imprese del sistema casa <strong>non conosce Industria 4.0</strong>. Approccio tradizionale all'innovazione, scarsa collaborazione con università e ricerca. Orientamento al futuro: più personalizzazione, più tecnologia, più collaborazione — per superare costi elevati e burocrazia.</div>
      </div>
      <div class="filiera-card">
        <div class="fc-name">💻 Filiera "Informatica/ICT"</div>
        <div class="fc-n">425 imprese nel territorio · 80 intervistati</div>
        <span class="fc-tag tag-warning">Paradosso innovativo</span>
        <div class="fc-finding">Forte spinta al miglioramento ma il <strong>72,5% opera in autonomia</strong>, senza collaborare. Il 55,7% si autofinanzia; le banche rappresentano il 40,5% delle fonti. Collo di bottiglia finanziario e diffidenza verso aperture esterne. Prospettiva: da filiera a propulsore trasversale per tutte le filiere.</div>
      </div>
      <div class="filiera-card meccanica">
        <div class="fc-name">⚙️ Filiera "Meccanica"</div>
        <div class="fc-n">407 imprese nel territorio · 80 intervistati</div>
        <span class="fc-tag tag-ok">Potenziale elevato</span>
        <div class="fc-finding">Filiera con le potenzialità innovative più considerevoli del territorio, ma con difficoltà strutturali legate alle dimensioni aziendali mediamente ridotte. Mancanza di risorse per investimenti strategici. Il progetto punta a creare collaborazioni strutturate tra realtà di settori complementari.</div>
      </div>
    </div>

    <h2>Impatto e sviluppi</h2>
    <p>I risultati della mappatura sono stati presentati in una <strong>conferenza stampa pubblica</strong> con ampia copertura mediatica (Il Gazzettino, 10 novembre 2018; Il Mattino di Padova, 12 novembre 2018). La ricerca è diventata la base conoscitiva su cui la CCIAA di Padova ha costruito i successivi workshop di sensibilizzazione per le imprese delle filiere mappate.</p>

    <p>La collaborazione si è successivamente estesa al progetto europeo <strong>Chain Reactions</strong>, finanziato da Interreg CENTRAL EUROPE, nell'ambito del quale Andrea Troisi ha presentato l'analisi sull'incidenza economica della filiera biomedicale in Veneto.</p>

    <!-- Evento Chain Reactions -->
    <div class="evento-box">
      <span class="eb-badge">Progetto europeo · Interreg CENTRAL EUROPE</span>
      <div class="eb-title">Workshop Chain Reactions — La filiera biomedicale in Veneto</div>
      <div class="eb-sub">12 gennaio 2021 · Online · ore 11:00–13:00</div>
      <div class="eb-agenda">
        Saluti: <strong>Luca Montagnin</strong> — referente per l'innovazione, Giunta CCIAA Padova<br>
        Il progetto europeo Chain Reactions: obiettivi e attività — <strong>Andrea Galeota</strong>, CCIAA Padova<br>
        <strong>L'importanza del settore biomedicale in Veneto: incidenza economica — Andrea Troisi, Troisi Ricerche</strong><br>
        I trend tecnologici del settore biomedicale — Emiliano Fabris, Galileo Visionary District<br>
        L'Osservatorio Biomedicale: Veneto e aspetti regolatori — Sandro Storelli, CNA Padova
      </div>
    </div>

    <h2>Rassegna stampa</h2>

    <div class="stampa-grid">
      <div class="stampa-card">
        <span class="sc-icon">📰</span>
        <div>
          <div class="sc-testata">Il Gazzettino — Padova</div>
          <div class="sc-data">Sabato 10 novembre 2018 · pag. X</div>
          <div class="sc-title">Le imprese a lezione di innovazione per non perdere le sfide dei mercati</div>
          <p class="sc-desc">Copertura della conferenza stampa di presentazione. Citato: Luca Montagnin (Giunta camerale), dati chiave sulla filiera casa e informatica. Menzione esplicita della ricerca Troisi Ricerche e di Andrea Troisi tra i relatori.</p>
        </div>
      </div>
      <div class="stampa-card">
        <span class="sc-icon">📰</span>
        <div>
          <div class="sc-testata">Il Mattino di Padova</div>
          <div class="sc-data">Lunedì 12 novembre 2018</div>
          <div class="sc-title">Casa, meccanica e Ict: un'unica filiera per l'innovazione</div>
          <p class="sc-desc">Copertura del Progetto Padova Innovation Hub. Citati: Luca Montagnin, Ruggero Targhetta (Euris srl), Boris Sartori (Tecna) e <strong>Andrea Troisi, Troisi Ricerche</strong> — tra i relatori della conferenza stampa di presentazione dello studio.</p>
        </div>
      </div>
    </div>

  </div>

  <!-- SCHEDA TECNICA SIDEBAR -->
  <div class="scheda-tecnica">
    <div class="st-title">Scheda tecnica del progetto</div>
    <div class="st-row">
      <div class="st-label">Committente</div>
      <div class="st-val">Camera di Commercio di Padova</div>
    </div>
    <div class="st-row">
      <div class="st-label">Progetto quadro</div>
      <div class="st-val">Padova Innovation Hub</div>
    </div>
    <div class="st-row">
      <div class="st-label">Tipo di ricerca</div>
      <div class="st-val">Mappatura quantitativa — indagine campionaria CATI/CAMI/CAWI</div>
    </div>
    <div class="st-row">
      <div class="st-label">Avvio rilevazioni</div>
      <div class="st-val">22 settembre 2018</div>
    </div>
    <div class="st-row">
      <div class="st-label">Territorio</div>
      <div class="st-val">Provincia di Padova — Regione Veneto</div>
    </div>
    <div class="st-row">
      <div class="st-label">Filiere indagate</div>
      <div class="st-val">Casa / efficienza energetica<br>Informatica / ICT<br>Meccanica di precisione</div>
    </div>
    <div class="st-row">
      <div class="st-label">Sviluppo europeo</div>
      <div class="st-val">Interreg CENTRAL EUROPE — Chain Reactions (2021)</div>
    </div>
    <div class="st-row">
      <div class="st-label">Rassegna stampa</div>
      <div class="st-val">Il Gazzettino (10/11/2018)<br>Il Mattino di Padova (12/11/2018)</div>
    </div>

    <div class="st-nums">
      <div class="sn"><div class="sn-v">244</div><div class="sn-l">Imprese coinvolte</div></div>
      <div class="sn"><div class="sn-v">60</div><div class="sn-l">Domande per questionario</div></div>
      <div class="sn" style="grid-column:1/-1"><div class="sn-v">14.700</div><div class="sn-l">Dati disponibili per l'analisi</div></div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(255,255,255,.1)">
      <a href="<?php echo home_url('/contatti'); ?>" style="display:block;background:var(--blu);color:#fff;text-align:center;padding:9px;border-radius:var(--r);font-size:12.5px;font-weight:700;text-decoration:none;margin-bottom:6px">Richiedici una mappatura simile →</a>
      <a href="<?php echo home_url('/la-ricerca'); ?>" style="display:block;background:rgba(255,255,255,.07);color:rgba(255,255,255,.7);text-align:center;padding:8px;border-radius:var(--r);font-size:12px;font-weight:600;text-decoration:none;border:1px solid rgba(255,255,255,.12)">La nostra metodologia</a>
    </div>
  </div>

</div>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>
