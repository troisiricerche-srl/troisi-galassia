<?php get_header(); ?>
<?php $current_page = 'notizie'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
:root{--blu:#0066cc;--bd:#004d99;--dp:#00264d;--bl:#e6f0ff;--bg:#f5f6fa;--bo:#d9e0ed;--g:#5a6a85;--t:#1a1a2e;--or:#e8a020;--r:4px}
body{margin:0;padding:0;font-family:'Titillium Web','Segoe UI',system-ui,sans-serif;background:var(--bg)}
.ph{background:var(--dp);padding:36px 24px;color:#fff}
.ph-meta{display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap}
.ph-cat{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:2px 9px;background:var(--blu);color:#fff;border-radius:2px}
.ph-date{font-size:11px;color:rgba(255,255,255,.45)}
.ph-source{font-size:11px;color:rgba(255,255,255,.45);padding:2px 8px;border:1px solid rgba(255,255,255,.14);border-radius:2px}
.ph h1{font-size:24px;font-weight:700;color:#fff;margin-bottom:8px;line-height:1.25}
.ph-excerpt{font-size:13.5px;color:rgba(255,255,255,.62);max-width:640px;line-height:1.7}
.bc{background:#fff;border-bottom:1px solid var(--bo);padding:10px 24px;font-size:11.5px;color:var(--g)}
.bc a{color:var(--g);text-decoration:none}

/* Article layout */
.art-layout{max-width:1060px;margin:0 auto;padding:32px 24px;display:grid;grid-template-columns:1fr 280px;gap:28px;align-items:start}
.art-main{}
.art-img-wrap{width:100%;border-radius:var(--r);overflow:hidden;margin-bottom:22px;background:var(--bg);border:1px solid var(--bo)}
.art-img{width:100%;height:340px;object-fit:cover;display:block}
.art-content{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:28px}
.art-content h2{font-size:18px;font-weight:700;color:var(--dp);margin-top:24px;margin-bottom:9px;padding-left:10px;border-left:3px solid var(--blu)}
.art-content h3{font-size:15px;font-weight:700;color:var(--dp);margin-top:18px;margin-bottom:7px}
.art-content p{font-size:13.5px;color:#3a4558;line-height:1.85;margin-bottom:14px}
.art-content ul,.art-content ol{font-size:13.5px;color:#3a4558;line-height:1.85;padding-left:22px;margin-bottom:14px}
.art-content a{color:var(--blu)}
.art-content img{max-width:100%;border-radius:var(--r)}
.art-content blockquote{border-left:4px solid var(--blu);padding:10px 16px;background:var(--bl);border-radius:0 var(--r) var(--r) 0;font-size:13.5px;color:var(--bd);margin:16px 0;font-style:italic}
.art-content table{width:100%;border-collapse:collapse;font-size:13px;margin-bottom:16px}
.art-content th{background:var(--dp);color:#fff;padding:9px 12px;text-align:left;font-weight:700;font-size:12px}
.art-content td{padding:8px 12px;border-bottom:1px solid var(--bo)}
.art-content tr:nth-child(even) td{background:var(--bg)}

/* Author box */
.author-box{background:var(--dp);border-radius:var(--r);padding:18px;margin-top:20px;display:flex;align-items:center;gap:16px;color:#fff}
.ab-foto{width:52px;height:52px;border-radius:50%;object-fit:cover;border:2px solid var(--blu);flex-shrink:0}
.ab-name{font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
.ab-role{font-size:11px;color:rgba(255,255,255,.45)}

/* Tags */
.art-tags{display:flex;flex-wrap:wrap;gap:6px;margin-top:18px;padding-top:14px;border-top:1px solid var(--bo)}
.art-tag{font-size:11px;padding:3px 10px;background:var(--bl);border:1px solid #b3d1ff;border-radius:2px;color:var(--bd);text-decoration:none}
.art-tag:hover{background:var(--bm)}

/* Sidebar */
.art-sidebar{}
.sb-card{background:#fff;border:0.5px solid var(--bo);border-radius:var(--r);padding:18px;margin-bottom:14px}
.sb-title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--g);margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--bo)}
.sb-post{padding:8px 0;border-bottom:1px solid var(--bg);display:block;text-decoration:none}
.sb-post:last-child{border-bottom:none;padding-bottom:0}
.sp-cat{font-size:9.5px;font-weight:700;color:var(--blu);text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px}
.sp-title{font-size:12.5px;font-weight:700;color:var(--dp);line-height:1.35;margin-bottom:2px}
.sp-title:hover{color:var(--blu)}
.sp-date{font-size:10.5px;color:var(--g)}

/* Sat links sidebar */
.sb-sat{display:flex;flex-direction:column;gap:6px}
.ss-link{display:flex;align-items:center;justify-content:space-between;padding:7px 10px;background:var(--bg);border:1px solid var(--bo);border-radius:var(--r);text-decoration:none;font-size:11.5px;color:var(--t);font-weight:600}
.ss-link:hover{border-color:var(--blu);color:var(--blu)}
.ss-link::after{content:'↗';font-size:10px;color:#9ca3af}

/* Back nav */
.back-nav{background:#fff;border-top:1px solid var(--bo);padding:14px 24px;font-size:12px}
.back-nav a{color:var(--g);text-decoration:none;display:inline-flex;align-items:center;gap:5px}
.back-nav a::before{content:'←'}
.back-nav a:hover{color:var(--blu)}

@media(max-width:800px){
  .art-layout{grid-template-columns:1fr}
  .art-sidebar{display:none}
}
</style>

<?php
while (have_posts()) : the_post();
  $category = '';
  $cats = get_the_category();
  if ($cats) $category = $cats[0]->name;
  $source = get_post_meta(get_the_ID(), 'fonte_satellite', true);
?>

<div class="ph">
  <div class="ph-meta">
    <?php if ($category) : ?><span class="ph-cat"><?php echo esc_html($category); ?></span><?php endif; ?>
    <span class="ph-date"><?php echo get_the_date('j F Y'); ?></span>
    <?php if ($source) : ?><span class="ph-source"><?php echo esc_html($source); ?></span><?php endif; ?>
  </div>
  <h1><?php the_title(); ?></h1>
  <?php if (has_excerpt()) : ?><p class="ph-excerpt"><?php the_excerpt(); ?></p><?php endif; ?>
</div>
<div class="bc">
  <a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo;
  <a href="<?php echo home_url('/notizie'); ?>">Notizie</a> &rsaquo;
  <?php the_title(); ?>
</div>

<div class="art-layout">
  <div class="art-main">
    <?php if (has_post_thumbnail()) : ?>
    <div class="art-img-wrap">
      <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="art-img">
    </div>
    <?php endif; ?>

    <div class="art-content">
      <?php the_content(); ?>

      <!-- Author -->
      <div class="author-box">
        <img src="<?php echo get_template_directory_uri(); ?>/foto-andrea.jpg" alt="Andrea Troisi" class="ab-foto">
        <div>
          <div class="ab-name">Andrea Troisi</div>
          <div class="ab-role">Fondatore e Direttore Scientifico — Troisi Ricerche</div>
        </div>
      </div>

      <!-- Tags -->
      <?php $tags = get_the_tags(); if ($tags) : ?>
      <div class="art-tags">
        <?php foreach ($tags as $tag) : ?>
        <a href="<?php echo get_tag_link($tag->term_id); ?>" class="art-tag"><?php echo esc_html($tag->name); ?></a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- SIDEBAR -->
  <div class="art-sidebar">
    <div class="sb-card">
      <div class="sb-title">Ultimi articoli</div>
      <?php
      $recenti = new WP_Query(['posts_per_page' => 5, 'post__not_in' => [get_the_ID()]]);
      while ($recenti->have_posts()) : $recenti->the_post();
        $sc = get_the_category(); $sc_name = $sc ? $sc[0]->name : 'Notizie';
      ?>
      <a href="<?php the_permalink(); ?>" class="sb-post">
        <div class="sp-cat"><?php echo esc_html($sc_name); ?></div>
        <div class="sp-title"><?php the_title(); ?></div>
        <div class="sp-date"><?php echo get_the_date('j M Y'); ?></div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <div class="sb-card">
      <div class="sb-title">Il network Troisi Ricerche</div>
      <div class="sb-sat">
        <a href="https://t-index.it" target="_blank" rel="noopener" class="ss-link" target="_blank">TR-Index</a>
        <a href="https://customerpa.it" target="_blank" rel="noopener" class="ss-link" target="_blank">CustomerPA</a>
        <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener" class="ss-link" target="_blank">Benessere Org.</a>
        <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" class="ss-link" target="_blank">Dibattito Pubblico</a>
        <a href="<?php echo home_url('/servizi'); ?>" class="ss-link">Tutti i servizi</a>
      </div>
    </div>

    <div class="sb-card" style="background:var(--dp)">
      <div class="sb-title" style="color:rgba(255,255,255,.42);border-color:rgba(255,255,255,.1)">Hai un progetto di ricerca?</div>
      <p style="font-size:12px;color:rgba(255,255,255,.6);line-height:1.65;margin-bottom:12px">Contattaci per una consulenza senza impegno. Rispondiamo entro 24h.</p>
      <a href="<?php echo home_url('/contatti'); ?>" style="display:block;background:var(--blu);color:#fff;text-align:center;padding:9px;border-radius:var(--r);font-size:12.5px;font-weight:700;text-decoration:none">Contattaci →</a>
    </div>
  </div>
</div>

<div class="back-nav wrap">
  <a href="<?php echo home_url('/notizie'); ?>">Torna alle notizie</a>
</div>

<?php
endwhile;
include(get_template_directory() . '/troisi-footer.php');
?>
