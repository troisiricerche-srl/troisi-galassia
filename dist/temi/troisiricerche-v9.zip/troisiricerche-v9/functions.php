<?php
/**
 * functions.php — Troisi Ricerche v9
 * Responsive, stile Designers Italia
 */

// ═══════════════════════════════════════
// FONT — Titillium Web + Lora
// ═══════════════════════════════════════
function troisi_enqueue_fonts() {
    wp_enqueue_style('troisi-fonts',
        'https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;0,700;1,400&family=Titillium+Web:wght@300;400;600;700;900&display=swap',
        [], null
    );
}
add_action('wp_enqueue_scripts', 'troisi_enqueue_fonts');

// ═══════════════════════════════════════
// v10 — RESTYLING TROISI FORMAZIONE
// ═══════════════════════════════════════
// Foglio di stile unico: caricato nell'head, vince sugli stili interni delle pagine grazie ai selettori "html body".
function troisi_enqueue_skin() {
    $f = get_template_directory() . '/tr-skin.css';
    wp_enqueue_style('troisi-skin', get_template_directory_uri() . '/tr-skin.css', ['troisi-fonts'], file_exists($f) ? filemtime($f) : '10.0.0');
}
add_action('wp_enqueue_scripts', 'troisi_enqueue_skin', 20);

// Classe del body con il nome del template usato (es. trt-front-page, trt-page-chi-siamo):
// serve a scalare i caratteri pagina per pagina senza collisioni tra classi omonime.
add_filter('template_include', function ($t) { $GLOBALS['troisi_tpl'] = basename($t, '.php'); return $t; }, 99);
add_filter('body_class', function ($c) {
    if (!empty($GLOBALS['troisi_tpl'])) $c[] = 'trt-' . sanitize_html_class($GLOBALS['troisi_tpl']);
    return $c;
});

// Intestazione: ombra e logo ridotto quando si scorre (come troisiformazione.it).
add_action('wp_footer', function () {
    echo "<script>(function(){var n=document.querySelector('.navbar');if(!n)return;function f(){n.classList.toggle('tr-scrolled',window.pageYOffset>50);}window.addEventListener('scroll',f,{passive:true});f();})();</script>\n";
}, 99);

// ═══════════════════════════════════════
// THEME SUPPORT
// ═══════════════════════════════════════
add_theme_support('post-thumbnails');
add_theme_support('title-tag');
add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);

// ═══════════════════════════════════════
// FIX: Forza blog_public = 1 (visibilità motori di ricerca)
// ═══════════════════════════════════════
function troisi_force_blog_public() {
    if (get_option('blog_public') != 1) {
        update_option('blog_public', 1);
    }
}
add_action('init', 'troisi_force_blog_public');

// ═══════════════════════════════════════
// REGISTRA TEMPLATE DI PAGINA
// ═══════════════════════════════════════
add_filter('theme_page_templates', function($templates) {
    return array_merge($templates, [
        'page-chi-siamo.php'       => 'Chi Siamo',
        'page-la-ricerca.php'      => 'La Ricerca',
        'page-strumenti.php'       => 'Strumenti',
        'page-servizi.php'         => 'Servizi',
        'page-casi-studio.php'     => 'Casi Studio',
        'page-media.php'           => 'Media',
        'page-territorio.php'      => 'Territorio',
        'page-rassegna-stampa.php' => 'Rassegna Stampa',
        'page-notizie.php'         => 'Notizie',
        'page-clienti.php'         => 'Clienti',
        'page-contatti.php'        => 'Contatti',
    ]);
});

// ═══════════════════════════════════════
// FEED RSS DAI SITI SATELLITE
// ═══════════════════════════════════════
function troisi_satellite_feed($url, $limit = 3) {
    // Compatibilità: ricava il sito dall'URL del feed e usa la lettura via REST/RSS.
    $host = preg_replace('/^www\./', '', (string) parse_url($url, PHP_URL_HOST));
    foreach (troisi_network_sites() as $key => $site) {
        if (preg_replace('/^www\./', '', parse_url($site['url'], PHP_URL_HOST)) === $host) {
            return troisi_network_latest($key, $limit);
        }
    }
    return [];
}

// ═══════════════════════════════════════
// NETWORK: siti satellite e ultimi articoli
// ═══════════════════════════════════════
function troisi_network_sites() {
    return [
        'troisiinsight' => ['nome' => 'TroisiInsight', 'url' => 'https://www.troisiinsight.it', 'colore' => '#0066cc', 'giorno' => 'lunedì', 'etichetta' => 'Analisi dati'],
        'customerpa' => ['nome' => 'CustomerPA', 'url' => 'https://www.customerpa.it', 'colore' => '#1d4ed8', 'giorno' => 'martedì', 'etichetta' => 'Servizi pubblici'],
        'benessereorganizzativo' => ['nome' => 'BenessereOrganizzativo', 'url' => 'https://www.benessereorganizzativo.it', 'colore' => '#008a5f', 'giorno' => 'mercoledì', 'etichetta' => 'Lavoro e organizzazioni'],
        'digitalizzazionepa' => ['nome' => 'DigitalizzazionePA', 'url' => 'https://www.digitalizzazionenellapa.it', 'colore' => '#0ea5e9', 'giorno' => 'giovedì', 'etichetta' => 'Trasformazione digitale'],
        'dibattitopubblico' => ['nome' => 'Dibattito Pubblico', 'url' => 'https://www.dibattito-pubblico.it', 'colore' => '#e07a1a', 'giorno' => 'venerdì', 'etichetta' => 'Partecipazione e opere'],
        'bdg' => ['nome' => 'Benessere Digitale Giovani', 'url' => 'https://www.benesseredigitalegiovani.it', 'colore' => '#065a51', 'giorno' => 'sabato', 'etichetta' => 'Giovani e digitale'],
        'mappatura' => ['nome' => 'Mappatura delle Competenze', 'url' => 'https://www.mappaturadellecompetenze.it', 'colore' => '#1a3a5c', 'giorno' => 'domenica', 'etichetta' => 'Competenze e lavoro'],
        'governancefinanziaria' => ['nome' => 'Governance Finanziaria', 'url' => 'https://www.governancefinanziaria.it', 'colore' => '#b8860b', 'giorno' => 'mercoledì, ogni due settimane', 'etichetta' => 'Finanza, ESG e digitale'],
        'internazionalizzazione' => ['nome' => 'Consulenza Internazionalizzazione', 'url' => 'https://www.consulenzainternazionalizzazione.it', 'colore' => '#0d7a6e', 'giorno' => 'giovedì, ogni due settimane', 'etichetta' => 'Export e mercati esteri'],
    ];
}

function troisi_network_is_placeholder($title) {
    $t = strtolower(trim(wp_strip_all_tags((string) $title)));
    return $t === '' || strpos($t, 'ciao mondo') !== false || strpos($t, 'hello world') !== false;
}

function troisi_network_http_args() {
    return [
        'timeout'     => 10,
        'redirection' => 5,
        'user-agent'  => 'Mozilla/5.0 (compatible; TroisiRicercheHub/9.5; +https://www.troisiricerche.net)',
        'headers'     => ['Accept' => 'application/json, application/rss+xml, application/xml;q=0.9, */*;q=0.8'],
    ];
}

// Primo grafico SVG dell'articolo, ripulito: si usa come anteprima quando manca l'immagine in evidenza (10.1.1)
function troisi_network_svg($html) {
    if (!$html || !preg_match_all('#<svg\b[^>]*>.*?</svg>#is', $html, $m)) return '';
    foreach ($m[0] as $svg) {
        if (strlen($svg) < 1500) continue; // salta icone e piccoli simboli
        $geo = ['x'=>1,'y'=>1,'x1'=>1,'x2'=>1,'y1'=>1,'y2'=>1,'cx'=>1,'cy'=>1,'r'=>1,'rx'=>1,'ry'=>1,'width'=>1,'height'=>1,'d'=>1,'points'=>1,'transform'=>1,
                'fill'=>1,'stroke'=>1,'stroke-width'=>1,'stroke-dasharray'=>1,'stroke-linecap'=>1,'stroke-linejoin'=>1,'opacity'=>1,'fill-opacity'=>1,'stroke-opacity'=>1,
                'font-size'=>1,'font-weight'=>1,'font-family'=>1,'font-style'=>1,'text-anchor'=>1,'dominant-baseline'=>1,'dy'=>1,'dx'=>1,'style'=>1];
        $allowed = ['svg' => ['viewbox'=>1,'role'=>1,'aria-label'=>1,'xmlns'=>1,'preserveaspectratio'=>1],
                    'g'=>$geo,'line'=>$geo,'rect'=>$geo,'circle'=>$geo,'ellipse'=>$geo,'path'=>$geo,'polyline'=>$geo,'polygon'=>$geo,'text'=>$geo,'tspan'=>$geo,'title'=>[]];
        $clean = wp_kses($svg, $allowed);
        $clean = preg_replace('#<svg\b#i', '<svg preserveAspectRatio="xMidYMid meet" aria-hidden="true" focusable="false"', $clean, 1);
        return $clean;
    }
    return '';
}

// Legge gli ultimi articoli di un sito: prima REST API (con immagine), poi RSS.
function troisi_network_fetch($key, $limit = 4) {
    $sites = troisi_network_sites();
    if (!isset($sites[$key])) return ['items' => [], 'via' => 'sconosciuto', 'errore' => 'sito non configurato'];
    $base = $sites[$key]['url'];
    $items = [];
    $errore = '';

    $q = 'per_page=' . ($limit + 2) . '&_embed=wp:featuredmedia&_fields=date,link,title,excerpt,content,_links,_embedded';
    $res = wp_remote_get($base . '/wp-json/wp/v2/posts?' . $q, troisi_network_http_args());
    // Siti con permalink semplici: /wp-json/ non esiste, si usa ?rest_route=
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) {
        $res2 = wp_remote_get($base . '/?rest_route=/wp/v2/posts&' . $q, troisi_network_http_args());
        if (!is_wp_error($res2) && wp_remote_retrieve_response_code($res2) === 200) $res = $res2;
    }
    if (is_wp_error($res)) {
        $errore = 'REST: ' . $res->get_error_message();
    } elseif (wp_remote_retrieve_response_code($res) !== 200) {
        $errore = 'REST: HTTP ' . wp_remote_retrieve_response_code($res);
    } else {
        $posts = json_decode(wp_remote_retrieve_body($res), true);
        if (is_array($posts)) {
            foreach ($posts as $p) {
                $title = html_entity_decode(wp_strip_all_tags($p['title']['rendered'] ?? ''), ENT_QUOTES, 'UTF-8');
                if (troisi_network_is_placeholder($title)) continue;
                $img = '';
                if (!empty($p['_embedded']['wp:featuredmedia'][0])) {
                    $m = $p['_embedded']['wp:featuredmedia'][0];
                    $img = $m['media_details']['sizes']['medium_large']['source_url']
                        ?? $m['media_details']['sizes']['large']['source_url']
                        ?? $m['source_url'] ?? '';
                }
                $svg = $img ? '' : troisi_network_svg($p['content']['rendered'] ?? '');
                $items[] = [
                    'title' => $title,
                    'link'  => $p['link'] ?? $base,
                    'ts'    => strtotime($p['date'] ?? 'now'),
                    'date'  => date_i18n('j M Y', strtotime($p['date'] ?? 'now')),
                    'desc'  => wp_trim_words(html_entity_decode(wp_strip_all_tags($p['excerpt']['rendered'] ?? ''), ENT_QUOTES, 'UTF-8'), 22),
                    'img'   => $img,
                    'svg'   => $svg,
                ];
                if (count($items) >= $limit) break;
            }
            if ($items) return ['items' => $items, 'via' => 'REST', 'errore' => ''];
        } else {
            $errore = 'REST: risposta non valida';
        }
    }

    // Ripiego: feed RSS
    $res = wp_remote_get($base . '/feed/', troisi_network_http_args());
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) $res = wp_remote_get($base . '/?feed=rss2', troisi_network_http_args());
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200 && function_exists('simplexml_load_string')) {
        $xml = @simplexml_load_string(wp_remote_retrieve_body($res));
        if ($xml && isset($xml->channel->item)) {
            foreach ($xml->channel->item as $it) {
                $title = html_entity_decode((string) $it->title, ENT_QUOTES, 'UTF-8');
                if (troisi_network_is_placeholder($title)) continue;
                $ts = strtotime((string) $it->pubDate);
                $items[] = [
                    'title' => $title,
                    'link'  => (string) $it->link,
                    'ts'    => $ts,
                    'date'  => date_i18n('j M Y', $ts),
                    'desc'  => wp_trim_words(html_entity_decode(wp_strip_all_tags((string) $it->description), ENT_QUOTES, 'UTF-8'), 22),
                    'img'   => '',
                    'svg'   => troisi_network_svg((string) $it->children('content', true)->encoded),
                ];
                if (count($items) >= $limit) break;
            }
            if ($items) return ['items' => $items, 'via' => 'RSS', 'errore' => $errore];
        }
    } else {
        $errore .= ($errore ? ' · ' : '') . 'RSS: ' . (is_wp_error($res) ? $res->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($res));
    }
    return ['items' => [], 'via' => 'nessuno', 'errore' => $errore];
}

// Versione con cache: 1 ora; se la lettura fallisce usa l'ultimo risultato buono.
function troisi_network_latest($key, $limit = 4) {
    $tkey = 'tr_net95_' . $key;
    $cached = get_transient($tkey);
    if (is_array($cached) && count($cached) >= min($limit, 1)) return array_slice($cached, 0, $limit);
    $r = troisi_network_fetch($key, max($limit, 4));
    if ($r['items']) {
        set_transient($tkey, $r['items'], HOUR_IN_SECONDS);
        update_option('tr_net95_last_' . $key, ['items' => $r['items'], 'quando' => time()], false);
        return array_slice($r['items'], 0, $limit);
    }
    set_transient($tkey, [], 10 * MINUTE_IN_SECONDS); // evita di martellare un sito che non risponde
    $last = get_option('tr_net95_last_' . $key);
    return (is_array($last) && !empty($last['items'])) ? array_slice($last['items'], 0, $limit) : [];
}

// Tutti gli ultimi articoli del network, ordinati per data
function troisi_network_all($per_site = 1) {
    $out = [];
    foreach (troisi_network_sites() as $key => $site) {
        foreach (troisi_network_latest($key, $per_site) as $it) {
            $out[] = array_merge($it, ['site' => $key, 'site_name' => $site['nome'], 'site_url' => $site['url'], 'colore' => $site['colore'], 'etichetta' => $site['etichetta']]);
        }
    }
    usort($out, function ($a, $b) { return ($b['ts'] ?? 0) <=> ($a['ts'] ?? 0); });
    return $out;
}

// Diagnostica per amministratori: /?tr_diag=1 (legge i siti senza cache)
add_action('template_redirect', function () {
    if (empty($_GET['tr_diag']) || !current_user_can('manage_options')) return;
    header('Content-Type: text/plain; charset=utf-8');
    echo "Diagnostica network Troisi Ricerche — " . date_i18n('d/m/Y H:i') . "\n\n";
    foreach (troisi_network_sites() as $key => $site) {
        delete_transient('tr_net95_' . $key);
        $r = troisi_network_fetch($key, 2);
        echo str_pad($site['nome'], 30) . ' via ' . $r['via'] . ' · ' . count($r['items']) . ' articoli';
        if ($r['items']) echo ' · ultimo: ' . $r['items'][0]['date'] . ' — ' . $r['items'][0]['title'] . ($r['items'][0]['img'] ? ' [img]' : ' [senza img]');
        if ($r['errore']) echo ' · errore: ' . $r['errore'];
        echo "\n";
        if ($r['items']) {
            set_transient('tr_net95_' . $key, $r['items'], HOUR_IN_SECONDS);
            update_option('tr_net95_last_' . $key, ['items' => $r['items'], 'quando' => time()], false);
        }
    }
    exit;
});

// ═══════════════════════════════════════
// ASSET ESTERNI (foto Senato da andreatroisi.it): copia locale una tantum
// ═══════════════════════════════════════
function troisi_remote_asset($url) {
    $map = get_option('troisi_remote_assets', []);
    if (!is_array($map)) $map = [];
    if (!empty($map[$url])) return $map[$url];
    $fail = get_transient('troisi_ra_fail_' . md5($url));
    if ($fail) return $url;
    $res = wp_remote_get($url, ['timeout' => 15, 'user-agent' => 'Mozilla/5.0 (compatible; TroisiRicercheHub/9.5)']);
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
        $body = wp_remote_retrieve_body($res);
        $up = wp_upload_bits('tr-' . basename(parse_url($url, PHP_URL_PATH)), null, $body);
        if (empty($up['error']) && !empty($up['url'])) {
            $map[$url] = $up['url'];
            update_option('troisi_remote_assets', $map, false);
            return $up['url'];
        }
    }
    set_transient('troisi_ra_fail_' . md5($url), 1, HOUR_IN_SECONDS);
    return $url; // ripiego: immagine servita dal sito di origine
}

function troisi_senato_2026() {
    $b = 'https://www.andreatroisi.it/wp-content/themes/andreatroisi-theme/img/';
    return [
        'data'   => '15 giugno 2026',
        'luogo'  => 'Senato della Repubblica · Palazzo Madama, Sala Caduti di Nassirya · Roma',
        'testo'  => 'Conferenza stampa di presentazione del libro «Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza» (Cacucci Editore). Modera Renato Piccoli (giornalista Rai); intervengono la prof.ssa Amelia Manuti, Nicola Armenise e la dott.ssa Ilaria Agosta (vicepresidente AIDP). Andrea Troisi presenta l\'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate, da lui promosso, con l\'IBO Score e l\'Oscar del Benessere Organizzativo.',
        'foto'   => [
            ['src' => $b . 'senato-2026-podio.jpg', 'cap' => 'Andrea Troisi al Senato della Repubblica · Palazzo Madama, Sala Caduti di Nassirya · 15 giugno 2026'],
            ['src' => $b . 'senato-2026-panel.jpg', 'cap' => 'Il tavolo dei relatori · Presentazione di «Le organizzazioni che si misurano»'],
            ['src' => $b . 'senato-2026-senatotv.jpg', 'cap' => 'La conferenza stampa trasmessa da Senato TV'],
            ['src' => $b . 'senato-2026-locandina.jpg', 'cap' => 'Locandina ufficiale del Senato della Repubblica · lunedì 15 giugno 2026, ore 9'],
        ],
        'link'   => [
            ['href' => 'https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/', 'label' => 'Lo Speciale — l\'articolo'],
            ['href' => 'https://www.takethedate.it/Eventi/54392-conferenza-stampa-presentazione-del-libro-le-organizzazioni-che-si-misurano.html', 'label' => 'Take The Date — scheda dell\'evento'],
        ],
    ];
}

function troisi_copertina_benessere() {
    $f = get_template_directory() . '/copertina-benessere.jpg';
    if (file_exists($f)) return get_template_directory_uri() . '/copertina-benessere.jpg';
    $u = wp_get_attachment_image_url(271, 'large');
    return $u ? $u : troisi_remote_asset('https://www.andreatroisi.it/wp-content/themes/andreatroisi-theme/img/libro-organizzazioni-copertina.jpg');
}

// Svuota la cache del network quando si aggiorna il tema
add_action('after_switch_theme', function () {
    foreach (array_keys(troisi_network_sites()) as $key) delete_transient('tr_net95_' . $key);
});

// ═══════════════════════════════════════
// AUTO-CREA PAGINE ALL'ATTIVAZIONE
// ═══════════════════════════════════════
function troisi_create_pages() {
    $pages = [
        'chi-siamo' => 'Chi Siamo',
        'la-ricerca' => 'La Ricerca',
        'strumenti' => 'Strumenti',
        'servizi' => 'Servizi',
        'casi-studio' => 'Casi Studio',
        'caso-studio-cciaa-padova' => 'Caso Studio CCIAA Padova',
        'media' => 'Media',
        'territorio' => 'Per il Territorio',
        'rassegna-stampa' => 'Rassegna Stampa',
        'notizie' => 'Notizie',
        'clienti' => 'Clienti',
        'contatti' => 'Contatti',
        'giochi-statistica' => 'Gioca con la statistica',
    ];
    foreach ($pages as $slug => $title) {
        if (!get_page_by_path($slug)) {
            wp_insert_post([
                'post_title'  => $title,
                'post_name'   => $slug,
                'post_status' => 'publish',
                'post_type'   => 'page',
            ]);
        }
    }
    // Sottopagine strumenti
    $parent = get_page_by_path('strumenti');
    $parent_id = $parent ? $parent->ID : 0;
    $sub = [
        'calcola-campione' => 'Calcola il Campione',
        'tip-platform' => 'TIP Platform',
        'dibattito-pubblico' => 'Dibattito Pubblico',
        't-index' => 'TR-Index',
        'troisiinsight' => 'TroisiInsight',
        'benessere-organizzativo' => 'Benessere Organizzativo',
        'customerpa' => 'CustomerPA',
        'skillprint' => 'Mappatura delle Competenze',
        'voiceinhub' => 'VoiceInHub',
        'digitalizzazione-pa' => 'DigitalizzazionePA',
    ];
    foreach ($sub as $slug => $title) {
        if (!get_page_by_path("strumenti/$slug")) {
            wp_insert_post([
                'post_title'   => $title,
                'post_name'    => $slug,
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_parent'  => $parent_id,
            ]);
        }
    }
}
add_action('after_switch_theme', 'troisi_create_pages');

// Crea la pagina dei giochi anche senza riattivare il tema (una sola volta)
add_action('init', function () {
    if (get_option('troisi_giochi_page_v1')) return;
    if (!get_page_by_path('giochi-statistica')) {
        wp_insert_post([
            'post_title'  => 'Gioca con la statistica',
            'post_name'   => 'giochi-statistica',
            'post_status' => 'publish',
            'post_type'   => 'page',
            'post_excerpt'=> 'Quattro giochi di Troisi Ricerche per mettere alla prova il senso dei numeri: Indovina il dato, Il sondaggio perfetto, Il paradosso del compleanno, Le tre porte.',
        ]);
    }
    update_option('troisi_giochi_page_v1', 1, false);
}, 20);

// ═══════════════════════════════════════
// INCLUDE: CPT, Opzioni Tema, Importazione
// ═══════════════════════════════════════
require_once get_template_directory() . '/inc/cpt.php';
require_once get_template_directory() . '/inc/options.php';
require_once get_template_directory() . '/inc/import.php';
require_once get_template_directory() . '/inc/clienti-dati.php';
require_once get_template_directory() . '/inc/home-2026.php'; // 10.3.0
?>
