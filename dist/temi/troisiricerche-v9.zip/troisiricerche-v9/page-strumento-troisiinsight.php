<?php
/**
 * Template Name: Strumento — TroisiInsight
 */
get_header();
$current_page = 'strumenti';
include(get_template_directory() . '/troisi-nav.php');
?>
<style>
</style>
<div class="ph">
  <div class="ph-ey">Strumenti &middot; Troisi Ricerche</div>
  <h1>📊 <em>TroisiInsight</em></h1>
  <p>Dashboard di dati statistici in tempo reale</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; <a href="<?php echo home_url('/strumenti'); ?>">Strumenti</a> &rsaquo; TroisiInsight</div>
<div class="sec alt">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Cos'è TroisiInsight</div></div>
    <div class="s-t">Un progetto del <em>network Troisi Ricerche</em></div>
    <p class="s-d">//troisiinsight.it</p>
    <p class="s-d">TroisiInsight pubblica grafici e analisi aggiornate su benessere organizzativo, customer satisfaction PA e indicatori sociali. I dati sono elaborati da Troisi Ricerche e presentati in format interattivo e accessibile.</p>
    <div class="cta-box">
      <h3>Visita TroisiInsight</h3>
      <p>Accedi al sito dedicato per esplorare tutte le funzionalità, i dati e i contenuti di TroisiInsight.</p>
      <a href="https" target="_blank" rel="noopener" class="cta-p">Vai su https ↗</a>
      <a href="<?php echo home_url('/contatti'); ?>" class="cta-s">Contattaci →</a>
    </div>
  </div>
</div>
<?php include(get_template_directory() . '/troisi-footer.php'); ?>
