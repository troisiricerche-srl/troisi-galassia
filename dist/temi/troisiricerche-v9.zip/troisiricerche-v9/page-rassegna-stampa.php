<?php
/**
 * Template Name: Rassegna Stampa
 */
get_header(); ?>
<?php $current_page = 'rassegna-stampa'; include(get_template_directory() . '/troisi-nav.php'); ?>
<style>
/* Lightbox per immagini cliccabili */
.img-zoom{cursor:zoom-in;transition:opacity .2s}
.img-zoom:hover{opacity:.92}
.lightbox-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9999;align-items:center;justify-content:center;padding:20px}
.lightbox-overlay.open{display:flex}
.lightbox-inner{position:relative;max-width:90vw;max-height:90vh}
.lightbox-inner img{max-width:90vw;max-height:85vh;object-fit:contain;border-radius:4px;display:block}
.lightbox-close{position:absolute;top:-14px;right:-14px;width:32px;height:32px;background:#fff;border:none;border-radius:50%;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:700;color:#333;line-height:1}
.lightbox-caption{color:rgba(255,255,255,.72);font-size:12px;text-align:center;margin-top:10px;max-width:700px;line-height:1.5}

.sec{padding:36px 0}.sec.alt{background:#fff}

/* Stats band */
.stats-band{background:var(--dp);display:grid;grid-template-columns:repeat(5,1fr)}
.sb{text-align:center;padding:20px 12px;border-right:1px solid rgba(255,255,255,.08)}
.sb:last-child{border-right:none}
.sbv{font-size:24px;font-weight:700;color:var(--or);line-height:1}
.sbl{font-size:9.5px;color:rgba(255,255,255,.42);text-transform:uppercase;letter-spacing:.04em;margin-top:3px;line-height:1.4}

/* Section header */

/* Trittico flagship */
.trittico{background:var(--dp);border-radius:var(--r);padding:28px;margin-bottom:28px}
.tr-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--or);margin-bottom:6px}
.tr-titolo{font-size:17px;font-weight:700;color:#fff;margin-bottom:4px}
.tr-sub{font-size:12.5px;color:rgba(255,255,255,.52);margin-bottom:20px;line-height:1.6}
.tr-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.tr-card{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:var(--r);padding:18px;border-top:3px solid var(--or)}
.tr-testata{font-size:18px;font-weight:700;color:var(--or);margin-bottom:3px}
.tr-data{font-size:10.5px;color:rgba(255,255,255,.32);margin-bottom:8px}
.tr-titolo-art{font-size:12.5px;color:#fff;font-weight:600;line-height:1.45;margin-bottom:8px}
.tr-desc{font-size:11.5px;color:rgba(255,255,255,.52);line-height:1.6}
.tr-badge{display:inline-block;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:2px 8px;border-radius:2px;background:rgba(232,160,32,.18);color:var(--or);border:1px solid rgba(232,160,32,.3);margin-bottom:8px}
.tr-link{display:inline-flex;align-items:center;gap:4px;font-size:11px;color:rgba(255,255,255,.55);text-decoration:none;margin-top:8px;border:1px solid rgba(255,255,255,.12);padding:4px 10px;border-radius:2px}
.tr-link:hover{color:#fff;border-color:rgba(255,255,255,.35)}
.tr-link::after{content:'↗'}

/* Camera Deputati — sezione speciale */
.camera-section{background:#fff;border-radius:var(--r);padding:28px;margin-bottom:28px;border:1px solid var(--bo);border-left:4px solid #cc0000}
.camera-label{display:inline-flex;align-items:center;gap:8px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#cc0000;margin-bottom:6px}
.camera-titolo{font-size:17px;font-weight:700;color:var(--dp);margin-bottom:4px}
.camera-sub{font-size:12.5px;color:var(--g);margin-bottom:18px;line-height:1.6}
.camera-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.cb{background:var(--bg);border-radius:var(--r);padding:18px;border:1px solid var(--bo)}
.cb-anno{font-size:10px;font-weight:700;color:#cc0000;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.cb-title{font-size:13.5px;font-weight:700;color:var(--dp);margin-bottom:6px;line-height:1.35}
.cb-desc{font-size:12px;color:var(--g);line-height:1.65;margin-bottom:10px}
.cb-tag{display:inline-block;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:2px 8px;border-radius:2px;background:#ffeaea;color:#cc0000;border:1px solid #ffcccc}
.cb-link{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);font-weight:600;text-decoration:none;margin-top:8px}
.cb-link::after{content:'↗'}

/* Blocco progetto */
.progetto{background:#fff;border-radius:var(--r);border:0.5px solid var(--bo);margin-bottom:20px;overflow:hidden}
.prj-head{padding:20px 24px;border-bottom:1px solid var(--bg);display:flex;align-items:flex-start;gap:16px}
.prj-anno-badge{background:var(--dp);color:var(--or);font-size:11px;font-weight:700;padding:5px 11px;border-radius:var(--r);flex-shrink:0;line-height:1.4;text-align:center;min-width:44px}
.prj-meta{flex:1}
.prj-progetto{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--blu);margin-bottom:3px}
.prj-title{font-size:16px;font-weight:700;color:var(--dp);margin-bottom:3px;line-height:1.3}
.prj-committente{font-size:12px;color:var(--g)}
.prj-committente strong{color:var(--t)}
.prj-body{padding:0 24px 20px}
.prj-articoli{display:flex;flex-direction:column;gap:8px;padding-top:16px}

/* Card articolo */
.art{border-left:3px solid var(--bo);padding:10px 14px;background:var(--bg);border-radius:0 var(--r) var(--r) 0;display:flex;gap:12px;align-items:flex-start}
.art.naz{border-left-color:var(--or)}
.art.locale{border-left-color:var(--blu)}
.art.radio{border-left-color:var(--vd)}
.art.tv{border-left-color:#9333ea}
.art.online{border-left-color:#0891b2}
.art-icon{font-size:18px;flex-shrink:0;margin-top:1px}
.art-content{flex:1}
.art-testata{font-size:11.5px;font-weight:700;color:var(--dp)}
.art-meta{font-size:10.5px;color:var(--g);margin-bottom:4px}
.art-titolo{font-size:12.5px;color:var(--t);line-height:1.45;margin-bottom:4px}
.art-desc{font-size:11.5px;color:var(--g);line-height:1.55}
.art-link{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--blu);text-decoration:none;font-weight:600;margin-top:5px}
.art-link::after{content:'↗';color:#9ca3af}
.art-badge{display:inline-block;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:2px 7px;border-radius:2px;margin-left:6px}
.b-naz{background:#fff3d4;color:#996600;border:1px solid #ffd080}
.b-loc{background:var(--bl);color:var(--bd);border:1px solid #b3d1ff}
.b-eu{background:#e8f0ff;color:#003399;border:1px solid #99b3ff}
.b-tv{background:#f5e6ff;color:#6600cc;border:1px solid #cc99ff}

/* Navigazione indice laterale / top */
.indice{background:#fff;border:1px solid var(--bo);border-radius:var(--r);padding:20px 24px;margin-bottom:28px}
.indice-title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--g);margin-bottom:12px}
.indice-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.indice-item{font-size:11.5px;color:var(--blu);text-decoration:none;padding:5px 8px;border-radius:2px;background:var(--bl);border:1px solid #d0e4ff;display:flex;align-items:center;gap:4px}
.indice-item:hover{background:#d0e4ff}
.indice-anno{font-size:10px;color:var(--g);margin-left:auto;font-weight:600}

/* SUMMA highlight box */
.summa-box{background:var(--dp);border-radius:var(--r);padding:18px 22px;margin-top:14px;display:flex;gap:16px;align-items:center}
.summa-flag{font-size:26px;flex-shrink:0}
.summa-content{}
.summa-label{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.35);margin-bottom:3px}
.summa-title{font-size:13px;font-weight:700;color:#fff;margin-bottom:3px}
.summa-desc{font-size:11.5px;color:rgba(255,255,255,.52);line-height:1.5}

/* Responsive */
@media(max-width:768px){
  .stats-band{grid-template-columns:repeat(2,1fr)}
  .tr-grid,.camera-grid,.indice-grid{grid-template-columns:1fr}
  .prj-head{flex-direction:column;gap:10px}
}
@media(max-width:600px){.sec{padding:28px 16px}}
</style>

<div class="ph">
  <div class="ph-ey">Troisi Ricerche &middot; Rassegna Stampa</div>
  <h1>La ricerca, <em>raccontata dai media</em></h1>
  <p>Da La Capitale al Senato della Repubblica, dal Corriere della Sera alla prima pagina della Gazzetta del Mezzogiorno: vent'anni di ricerca raccontati dalla stampa, dalla più recente.</p>
</div>
<div class="bc"><a href="<?php echo home_url('/'); ?>">Home</a> &rsaquo; Rassegna Stampa</div>

<div class="stats-band">
  <div class="sb"><div class="sbv">3</div><div class="sbl">Testate nazionali<br>nello stesso anno</div></div>
  <div class="sb"><div class="sbv">2×</div><div class="sbl">Camera dei Deputati<br>(2019 · 2022)</div></div>
  <div class="sb"><div class="sbv">RAI</div><div class="sbl">TG3 Puglia<br>"La Puglia che va"</div></div>
  <div class="sb"><div class="sbv">15+</div><div class="sbl">Progetti con copertura<br>mediatica documentata</div></div>
  <div class="sb"><div class="sbv">EU</div><div class="sbl">Stampa internazionale<br>SUMMA · GreenLife4Seas</div></div>
</div>

<div class="sec alt">
<div class="wrap">

  <!-- INDICE NAVIGAZIONE -->
  <div class="indice">
    <div class="indice-title">📋 Dalla più recente</div>
    <div class="indice-grid">
      <a href="#la-capitale" class="indice-item">Roma che Dice · La Capitale <span class="indice-anno">2026</span></a>
      <a href="#senato" class="indice-item">Senato della Repubblica <span class="indice-anno">2026</span></a>
      <a href="#summa" class="indice-item">SUMMA Interreg <span class="indice-anno">2025–2026</span></a>
      <a href="#cibari" class="indice-item">CiBari (3 edizioni) <span class="indice-anno">2023–2025</span></a>
      <a href="#smart-city-poliba" class="indice-item">Smart City · Politecnico di Bari <span class="indice-anno">2025</span></a>
      <a href="#aiquav" class="indice-item">AIQUAV + VP PE <span class="indice-anno">2023</span></a>
      <a href="#rai" class="indice-item">RAI 3 · TV e radio <span class="indice-anno">2023</span></a>
      <a href="#food-policy" class="indice-item">Food Policy Bari <span class="indice-anno">2022</span></a>
      <a href="#fondirigenti" class="indice-item">Fondirigenti · Corriere <span class="indice-anno">2021–2022</span></a>
      <a href="#trittico" class="indice-item">Sole 24 Ore · Repubblica · Corriere <span class="indice-anno">2021–2022</span></a>
      <a href="#duc-bari" class="indice-item">DUC Bari + Bisceglie <span class="indice-anno">2019–2020</span></a>
      <a href="#trieste-trasporti" class="indice-item">Trieste Trasporti <span class="indice-anno">2016–2020</span></a>
      <a href="#camera" class="indice-item">Camera dei Deputati <span class="indice-anno">2019 · 2022</span></a>
      <a href="#cciaa-padova" class="indice-item">Mappatura CCIAA Padova <span class="indice-anno">2018–2021</span></a>
      <a href="#mense-bari" class="indice-item">Mense Scolastiche Bari <span class="indice-anno">2018</span></a>
      <a href="#doing-business-eau" class="indice-item">Doing Business EAU <span class="indice-anno">2016</span></a>
      <a href="#qualita-puglia" class="indice-item">Qualità vita Puglia <span class="indice-anno">2011</span></a>
    </div>
  </div>

  <div class="sh"><div class="sl"></div><div class="se">Rassegna stampa, dalla più recente</div></div>

  <!-- ROMA CHE DICE · LA CAPITALE -->
  <div class="progetto" id="la-capitale">
    <div class="prj-head">
      <div class="prj-anno-badge">2026</div>
      <div class="prj-meta">
        <div class="prj-progetto">Osservatorio · Roma</div>
        <div class="prj-title">«Roma, che dici?» — L'opinione dei romani con La Capitale</div>
        <div class="prj-committente">Progetto editoriale di <strong>La Capitale</strong> &mdash; supporto metodologico Troisi Ricerche · 1.000 interviste CAWI per report</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">La Capitale <span class="art-badge b-naz">Report n. 2</span></div>
            <div class="art-meta">3 ottobre 2026 · Roma</div>
            <div class="art-titolo">I romani e l'intelligenza artificiale: al via il nuovo sondaggio</div>
            <a href="https://www.lacapitale.it/articolo/sondaggio-romani-lintelligenza-artificiale-troisi-ricerche" target="_blank" rel="noopener" class="art-link">Leggi su La Capitale</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">La Capitale <span class="art-badge b-naz">Report n. 1</span></div>
            <div class="art-meta">10 agosto 2026 · Roma</div>
            <div class="art-titolo">Social vietati agli under 15, quasi il 90% degli intervistati è favorevole</div>
            <a href="https://www.lacapitale.it/articolo/social-minori-sondaggio-roma-divieto-under-15" target="_blank" rel="noopener" class="art-link">Leggi su La Capitale</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">La Capitale</div>
            <div class="art-meta">3 agosto 2026 · Roma</div>
            <div class="art-titolo">Divieto dei social ai minori, parte il primo sondaggio di «Roma, che dici?»</div>
            <a href="https://www.lacapitale.it/articolo/divieto-social-minori-sondaggio-roma-che-dici" target="_blank" rel="noopener" class="art-link">Leggi su La Capitale</a>
          </div>
        </div>
      </div>
      <?php $rc = get_category_by_slug('roma-che-dice'); if ($rc): ?>
      <a href="<?php echo esc_url(get_category_link($rc)); ?>" class="art-link" style="margin-top:12px">Tutti i report nella rubrica Roma che Dice</a>
      <?php endif; ?>
    </div>
  </div>

  <!-- SENATO DELLA REPUBBLICA -->
  <?php $sen = troisi_senato_2026(); ?>
  <div class="progetto" id="senato">
    <div class="prj-head">
      <div class="prj-anno-badge">2026</div>
      <div class="prj-meta">
        <div class="prj-progetto">Istituzioni · Senato della Repubblica</div>
        <div class="prj-title">«Le organizzazioni che si misurano» al Senato</div>
        <div class="prj-committente"><?php echo esc_html($sen['luogo']); ?> &mdash; <?php echo esc_html($sen['data']); ?></div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art naz">
          <div class="art-icon">🏛️</div>
          <div class="art-content">
            <div class="art-testata">Senato della Repubblica <span class="art-badge b-naz">Senato TV</span></div>
            <div class="art-meta"><?php echo esc_html($sen['data']); ?> · Roma</div>
            <div class="art-desc"><?php echo esc_html($sen['testo']); ?></div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px">
              <?php foreach ($sen['foto'] as $f): ?>
              <img class="img-zoom" data-caption="<?php echo esc_attr($f['cap']); ?>" src="<?php echo esc_url(troisi_remote_asset($f['src'])); ?>" alt="<?php echo esc_attr($f['cap']); ?>" loading="lazy" style="width:100%;height:110px;object-fit:cover;border-radius:3px;display:block">
              <?php endforeach; ?>
            </div>
            <div style="display:flex;gap:12px;flex-wrap:wrap">
              <?php foreach ($sen['link'] as $l): ?><a href="<?php echo esc_url($l['href']); ?>" target="_blank" rel="noopener" class="art-link"><?php echo esc_html($l['label']); ?></a><?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 12 — SUMMA Interreg -->
  <div class="progetto" id="summa">
    <div class="prj-head">
      <div class="prj-anno-badge">2025–<br>2026</div>
      <div class="prj-meta">
        <div class="prj-progetto">Europeo Transnazionale · Adriatico</div>
        <div class="prj-title">SUMMA — Biglietto Unico Adriatico</div>
        <div class="prj-committente">Per il <strong>Comune di Pescara</strong>, partner del progetto Interreg Italy-Croatia (capofila Comune di Caorle) &mdash; €2,6M · 80% fondi EU</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="summa-box">
        <div class="summa-flag">🌊🇭🇷</div>
        <div class="summa-content">
          <div class="summa-label">Progetto in corso · 2025–2026</div>
          <div class="summa-title">SUMMA — da Caorle a Spalato</div>
          <div class="summa-desc">Progetto transnazionale per il biglietto unico dei trasporti nell'area adriatica. Troisi Ricerche cura lo studio di fattibilità tecnologica, finanziaria e giuridica. Tappe 2025: meeting di Pescara (febbraio) e Mid-Term Conference di Spalato (maggio).</div>
        </div>
      </div>
      <div class="prj-articoli" style="margin-top:14px">
        <div class="art naz">
          <div class="art-icon">🇪🇺</div>
          <div class="art-content">
            <div class="art-testata">Stampa italiana e croata <span class="art-badge b-eu">Interreg Italy-Croatia</span></div>
            <div class="art-meta">2025–2026 · Adriatico</div>
            <div class="art-titolo">SUMMA: il biglietto unico adriatico prende forma — €2,6 milioni di fondi europei</div>
            <div class="art-desc">Il progetto SUMMA — acronimo per il sistema integrato di mobilità nell'area adriatica — viene seguito dalla stampa italiana e croata in entrambe le sponde. Troisi Ricerche porta il modello "Da Bari al Pireo" nella dimensione transnazionale.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 9 — CiBari -->
  <div class="progetto" id="cibari">
    <div class="prj-head">
      <div class="prj-anno-badge">2023–<br>2025</div>
      <div class="prj-meta">
        <div class="prj-progetto">Università · Bari</div>
        <div class="prj-title">CiBari — Sindrome Metabolica (3 edizioni)</div>
        <div class="prj-committente">Committente: <strong>Università degli Studi di Bari Aldo Moro</strong> &mdash; 1.000 intervistati (2025)</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Stampa locale Bari <span class="art-badge b-loc">Salute pubblica</span></div>
            <div class="art-meta">17 ottobre 2025 · 3 testate · conferenza stampa Pinacoteca Giaquinto</div>
            <div class="art-titolo">CiBari 2025 — prima survey nazionale sulla sindrome metabolica</div>
            <div class="art-desc">Tre testate locali coprono CiBari 2025: Gazzetta del Mezzogiorno (citazione diretta Andrea Troisi: «quasi un cittadino su due non ha mai sentito parlare di questa condizione»), Quotidiano di Bari, Quotidiano di Puglia.</div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px">
              <img class="img-zoom" src="<?php echo get_template_directory_uri(); ?>/img/cibari/cibari2025_articolo_gazzetta_mezzogiorno_17ott2025.jpeg"
                   alt="Gazzetta del Mezzogiorno 17 ottobre 2025 — CiBari 2025"
                   style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
              <img class="img-zoom" src="<?php echo get_template_directory_uri(); ?>/img/cibari/cibari2025_articolo_quotidiano_bari_17ott2025.jpeg"
                   alt="Quotidiano di Bari 17 ottobre 2025 — CiBari 2025"
                   style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
              <img class="img-zoom" src="<?php echo get_template_directory_uri(); ?>/img/cibari/cibari2025_articolo_quotidiano_puglia_17ott2025.jpeg"
                   alt="Quotidiano di Puglia 17 ottobre 2025 — CiBari 2025"
                   style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- SMART CITY · POLITECNICO DI BARI 2025 -->
  <div class="progetto" id="smart-city-poliba">
    <div class="prj-head">
      <div class="prj-anno-badge">2025</div>
      <div class="prj-meta">
        <div class="prj-progetto">Convegno · Bari</div>
        <div class="prj-title">Smart City — Governance, Competenze e Risorse</div>
        <div class="prj-committente">Politecnico di Bari, 3 ottobre 2025 &mdash; promosso da <strong>Osservatorio sull'Innovazione del Mezzogiorno</strong>, Fondimpresa e Politecnico. Andrea Troisi interviene come direttore dell'Osservatorio.</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">Il Giardino della Cultura <span class="art-badge b-loc">Web</span></div>
            <div class="art-meta">14 ottobre 2025</div>
            <div class="art-titolo">Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro</div>
            <a href="https://www.ilgiardinodellacultura.com/2025/10/14/smart-city-italia-mezzogiorno-competenze-pnrr/" target="_blank" rel="noopener" class="art-link">Leggi su Il Giardino della Cultura</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">BitMAT <span class="art-badge b-naz">Nazionale</span></div>
            <div class="art-meta">10 ottobre 2025</div>
            <div class="art-titolo">Smart City: 10 miliardi dal PNRR, ma il Sud resta indietro</div>
            <a href="https://www.bitmat.it/vertical/smart-home-city/smart-city-10-miliardi-dal-pnrr-ma-il-sud-resta-indietro/" target="_blank" rel="noopener" class="art-link">Leggi su BitMAT</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">MF Milano Finanza <span class="art-badge b-naz">Nazionale</span></div>
            <div class="art-meta">8 ottobre 2025</div>
            <div class="art-titolo">Quel sogno chiamato smart city, ma il Sud è ancora troppo indietro</div>
            <a href="https://www.milanofinanza.it/news/quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-troppo-indietro-202510081638248255" target="_blank" rel="noopener" class="art-link">Leggi su MF Milano Finanza</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">Adriaeco <span class="art-badge b-loc">Web</span></div>
            <div class="art-meta">8 ottobre 2025</div>
            <div class="art-titolo">Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro</div>
            <a href="https://www.adriaeco.eu/2025/10/08/il-sogno-delle-smart-city-stanziati-10-miliardi-ma-mancano-le-competenze-ed-il-sud-resta-indietro/" target="_blank" rel="noopener" class="art-link">Leggi su Adriaeco</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">Business &amp; Gentlemen <span class="art-badge b-loc">Web</span></div>
            <div class="art-meta">ottobre 2025</div>
            <div class="art-titolo">Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro</div>
            <a href="https://www.businessgentlemen.it/2025/10/il-sogno-delle-smart-city-stanziati-10-miliardi-ma-mancano-le-competenze-ed-il-sud-resta-indietro/" target="_blank" rel="noopener" class="art-link">Leggi su Business &amp; Gentlemen</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">Oggi Quotidiano <span class="art-badge b-naz">Nazionale</span></div>
            <div class="art-meta">7 ottobre 2025</div>
            <div class="art-titolo">Quel sogno chiamato Smart City ma il Sud è ancora troppo indietro</div>
            <a href="https://www.oggiquotidiano.it/economia/102543-quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-troppo-indietro/" target="_blank" rel="noopener" class="art-link">Leggi su Oggi Quotidiano</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">INpressMAGAZINE <span class="art-badge b-loc">Web</span></div>
            <div class="art-meta">6 ottobre 2025</div>
            <div class="art-titolo">Quel sogno chiamato Smart City ma il Sud è ancora indietro</div>
            <a href="https://www.inpressmagazine.com/quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-indietro/" target="_blank" rel="noopener" class="art-link">Leggi su INpressMAGAZINE</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">@Nordest <span class="art-badge b-loc">Web</span></div>
            <div class="art-meta">8 ottobre 2025</div>
            <div class="art-titolo">Il sogno delle Smart City e la sfida delle competenze</div>
            <a href="https://www.anordest.it/il-sogno-delle-smart-city-e-la-sfida-delle-competenze/" target="_blank" rel="noopener" class="art-link">Leggi su @Nordest</a>
          </div>
        </div>
        <div class="art online">
          <div class="art-icon">🌐</div>
          <div class="art-content">
            <div class="art-testata">ComunicatiStampa.net <span class="art-badge b-loc">Comunicato stampa</span></div>
            <div class="art-meta">7 ottobre 2025</div>
            <div class="art-titolo">Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro</div>
            <a href="https://www.comunicatistampa.net/smart-city-mancanza-competenze-sud-indietro/" target="_blank" rel="noopener" class="art-link">Leggi su ComunicatiStampa.net</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 10 — AIQUAV 2023 -->
  <div class="progetto" id="aiquav">
    <div class="prj-head">
      <div class="prj-anno-badge">2023</div>
      <div class="prj-meta">
        <div class="prj-progetto">Europeo · Bari</div>
        <div class="prj-title">AIQUAV 2023 + Food Policy — VP Parlamento Europeo</div>
        <div class="prj-committente">Committente: <strong>AIQUAV / UniBa</strong> &mdash; VP PE Pina Picierno · Moderatore RAI Danilo Giannese</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art tv">
          <div class="art-icon">📺</div>
          <div class="art-content">
            <div class="art-testata">RAI — Danilo Giannese <span class="art-badge b-tv">Moderatore RAI</span></div>
            <div class="art-meta">2023 · Bari · Convegno AIQUAV</div>
            <div class="art-titolo">AIQUAV 2023 — Qualità della vita e Food Policy, moderato da Danilo Giannese (RAI)</div>
            <div class="art-desc">Il convegno viene moderato dal giornalista RAI Danilo Giannese. Presenti la Vicepresidente del Parlamento Europeo Pina Picierno e rappresentanti del mondo scientifico italiano.</div>
            <a href="https://youtu.be/zB1iZVjzK5k" target="_blank" class="art-link">Guarda il video</a>
          </div>
        </div>
        <div class="art naz">
          <div class="art-icon">🇪🇺</div>
          <div class="art-content">
            <div class="art-testata">Presenza istituzionale europea <span class="art-badge b-naz">VP Parlamento Europeo</span></div>
            <div class="art-meta">2023 · Bari</div>
            <div class="art-titolo">Pina Picierno, VP del Parlamento Europeo, al convegno AIQUAV con Troisi Ricerche</div>
            <div class="art-desc">La presenza della Vicepresidente del Parlamento Europeo Pina Picierno all'evento AIQUAV organizzato con Troisi Ricerche consolida il posizionamento europeo dell'istituto.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 11 — RAI / Media nazionali generalisti -->
  <div class="progetto" id="rai">
    <div class="prj-head">
      <div class="prj-anno-badge">2023</div>
      <div class="prj-meta">
        <div class="prj-progetto">Media audiovisivi · Presenza televisiva nazionale</div>
        <div class="prj-title">RAI 3 TG Puglia — "La Puglia che va"</div>
        <div class="prj-committente">Programma speciale · Servizio dedicato alla sede di Bari e alla storia di Troisi Ricerche</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art tv">
          <div class="art-icon">📺</div>
          <div class="art-content">
            <div class="art-testata">RAI 3 TG Puglia <span class="art-badge b-tv">Televisione pubblica</span></div>
            <div class="art-meta">17 maggio 2023 · Servizio speciale · "La Puglia che va"</div>
            <div class="art-titolo">Troisi Ricerche protagonista del programma RAI 3 "La Puglia che va"</div>
            <div class="art-desc">Il TG3 Puglia dedica un servizio speciale alla sede di Bari e alla storia di Troisi Ricerche nell'ambito del programma "La Puglia che va" — vetrina delle eccellenze regionali sulla televisione pubblica nazionale.</div>
            <a href="https://www.rainews.it/tgr/puglia/video/2023/05/centri-di-ricerca-imprese-business-troisi-bari-puglia-che-va-22e2cb36-95fd-46a4-a8d5-8d7c452d5be6.html" target="_blank" class="art-link">Guarda il servizio RAI</a>
          </div>
        </div>
        <div class="art tv">
          <div class="art-icon">📺</div>
          <div class="art-content">
            <div class="art-testata">Tele Lazio Nord — "Drive In" <span class="art-badge b-tv">Ospite fisso</span></div>
            <div class="art-meta">Presenza televisiva regionale · Roma e Lazio</div>
            <div class="art-titolo">Andrea Troisi ospite fisso di "Drive In" su Tele Lazio Nord</div>
            <div class="art-desc">Presenza televisiva continuativa sull'emittente laziale con approfondimenti su ricerca di mercato, dati e scenari economici.</div>
            <a href="https://www.youtube.com/watch?v=qa3CJBMLXIY&list=PLOoGJz564GrV21MMzOLhiUlpEdW3Xbu8T" target="_blank" class="art-link">Playlist YouTube</a>
          </div>
        </div>
        <div class="art radio">
          <div class="art-icon">🎙️</div>
          <div class="art-content">
            <div class="art-testata">Controradio Bari <span class="art-badge b-loc">Radio · Fondatore e conduttore</span></div>
            <div class="art-meta">Programma "Il Dato è Tratto" · Bari</div>
            <div class="art-titolo">"Il Dato è Tratto" — Andrea Troisi fondatore e conduttore</div>
            <div class="art-desc">Programma radiofonico originale su Controradio Bari, fondato e condotto da Andrea Troisi: divulgazione scientifica sui dati, le ricerche e i metodi quantitativi applicati alla realtà pugliese.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 8 — Food Policy Bari -->
  <div class="progetto" id="food-policy">
    <div class="prj-head">
      <div class="prj-anno-badge">2022</div>
      <div class="prj-meta">
        <div class="prj-progetto">Salute · Bari</div>
        <div class="prj-title">Food Policy Bari — Oscar della Salute</div>
        <div class="prj-committente">Committente: <strong>Comune di Bari / PON Legalità</strong> &mdash; 1.090 interviste · 9 quartieri</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art naz">
          <div class="art-icon">🏆</div>
          <div class="art-content">
            <div class="art-testata">Oscar della Salute <span class="art-badge b-naz">Premio nazionale</span></div>
            <div class="art-meta">2022 · Premio Nazionale</div>
            <div class="art-titolo">Il progetto Food Policy Bari vince l'Oscar della Salute</div>
            <div class="art-desc">La ricerca di Troisi Ricerche sui comportamenti alimentari in 9 quartieri di Bari (1.090 interviste, finanziata PON Legalità EU) contribuisce a far vincere al Comune di Bari l'Oscar della Salute, il principale riconoscimento nazionale sulla salute pubblica.</div>
          </div>
        </div>
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Stampa locale Bari <span class="art-badge b-loc">Salute + legalità</span></div>
            <div class="art-meta">2022 · Bari</div>
            <div class="art-titolo">Alimentazione e legalità: Troisi Ricerche mappa i comportamenti alimentari nei quartieri di Bari</div>
            <div class="art-desc">La ricerca, con il suo focus sulle aree periferiche di Bari nell'ambito del programma PON Legalità, genera ampia copertura locale sul tema sicurezza alimentare e qualità della vita.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 7 — Fondirigenti Post-Covid + Governance -->
  <div class="progetto" id="fondirigenti">
    <div class="prj-head">
      <div class="prj-anno-badge">2021–<br>2022</div>
      <div class="prj-meta">
        <div class="prj-progetto">Nazionale · Camera dei Deputati</div>
        <div class="prj-title">Fondirigenti Post-Covid — Governance Finanziaria</div>
        <div class="prj-committente">Committente: <strong>Fondirigenti / Confindustria</strong> &mdash; 340 manager · Camera dei Deputati</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art naz">
          <div class="art-icon">🏛️</div>
          <div class="art-content">
            <div class="art-testata">webtv.camera.it <span class="art-badge b-naz">Camera dei Deputati</span></div>
            <div class="art-meta">25 marzo 2022 · Roma</div>
            <div class="art-titolo">Fondirigenti / Confindustria — Governance Finanziaria. Moderatore: Fabio Savelli (Corriere della Sera)</div>
            <div class="art-desc">L'evento si tiene alla Camera dei Deputati e viene trasmesso in diretta da webtv.camera.it. Moderatore: Fabio Savelli, giornalista economico del Corriere della Sera.</div>
            <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:6px">
              <a href="https://www.youtube.com/watch?v=-gykCKwqLxw" target="_blank" rel="noopener" class="art-link" style="color:#cc0000">▶ YouTube</a>
              <a href="https://www.radioradicale.it/scheda/663951/competenze-per-la-governance-finanziaria" target="_blank" rel="noopener" class="art-link">Radio Radicale</a>
              <a href="https://dirigentindustria.it/formazione/imprese-da-fondirigenti-un-modello-di-competenze-per-la-governance-finanziaria.html" target="_blank" rel="noopener" class="art-link">Dirigenti Industria</a>
            </div>
            <!-- Foto Camera dei Deputati -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px">
              <figure style="margin:0">
                <img class="img-zoom" data-caption="Camera dei Deputati" src="<?php echo get_template_directory_uri(); ?>/img/camera/fondirigenti_camera_25mar2022_relatori_al_banco.jpeg"
                     alt="Sala Camera dei Deputati — Andrea Troisi in collegamento video durante l'evento Fondirigenti 2022"
                     style="width:100%;border-radius:3px;display:block;object-fit:cover;max-height:160px">
                <figcaption style="font-size:10px;color:var(--g);margin-top:4px;line-height:1.5">Sala Camera dei Deputati, 25 marzo 2022 — Andrea Troisi in collegamento sul monitor</figcaption>
              </figure>
              <figure style="margin:0">
                <img class="img-zoom" data-caption="Camera dei Deputati" src="<?php echo get_template_directory_uri(); ?>/img/camera/fondirigenti_camera_25mar2022_foto_gruppo_6_persone.jpeg"
                     alt="Foto di gruppo relatori Camera dei Deputati — Fondirigenti/Confindustria marzo 2022"
                     style="width:100%;border-radius:3px;display:block;object-fit:cover;max-height:160px">
                <figcaption style="font-size:10px;color:var(--g);margin-top:4px;line-height:1.5">I relatori con badge istituzionali Camera dei Deputati — marzo 2022</figcaption>
              </figure>
            </div>
          </div>
        </div>
        <div class="art naz">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Corriere della Sera <span class="art-badge b-naz">Pag. 33 · Economia</span></div>
            <div class="art-meta">27 marzo 2022 · firma Fabio Savelli</div>
            <div class="art-titolo">"Attacchi informatici e formazione dei manager"</div>
            <div class="art-desc">48 ore dopo l'evento alla Camera, Fabio Savelli pubblica un articolo in pagina 33 del Corriere della Sera — Economia. Il cerchio si chiude: dall'Aula parlamentare alla prima pagina nazionale.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- TRITTICO NAZIONALE -->
  <div class="trittico" id="trittico">
    <div class="tr-label" style="color:var(--or);font-size:14px;font-weight:700;letter-spacing:.02em">⭐ Testate nazionali</div>
    <div style="font-size:13px;color:rgba(255,255,255,.55);margin-bottom:14px">nov 2021 / mar 2022</div>
    <div class="tr-titolo">Tre testate nazionali in cinque mesi</div>
    <div class="tr-sub">Il Sole 24 Ore, la Repubblica e il Corriere della Sera hanno dedicato spazio a Troisi Ricerche nell'arco di soli cinque mesi — un risultato rarissimo per un istituto privato di ricerca.</div>
    <div class="tr-grid">

      <div class="tr-card">
        <div class="tr-badge">Economia</div>
        <div class="tr-testata">Il Sole 24 Ore</div>
        <div class="tr-data">12 novembre 2021 · Sezione Economia</div>
        <div class="tr-titolo-art">"Ricerche di mercato con mission sviluppo"</div>
        <div class="tr-desc">Articolo dedicato con foto. Il quotidiano economico italiano più autorevole racconta il modello e la missione di Troisi Ricerche.</div>
      </div>

      <div class="tr-card">
        <div class="tr-badge">Eccellenze Lazio</div>
        <div class="tr-testata"><a href="https://roma.repubblica.it/dossier-adv/eccellenze-lazio/2021/11/15/news/troisi_ricerche_i_dati_analizzarli_e_interpretarli_per_prendere_le_decisioni-326423272/" target="_blank" rel="noopener" style="color:inherit">la Repubblica ↗</a></div>
        <div class="tr-data">15 novembre 2021 · Speciale Aziende Eccellenze Lazio</div>
        <div class="tr-titolo-art">"Troisi Ricerche: i dati, analizzarli e interpretarli per prendere le decisioni"</div>
        <div class="tr-desc">Speciale aziende d'eccellenza della rivista romana — posizionamento come istituto di riferimento nell'area Centro.</div>
        <a href="https://roma.repubblica.it/dossier-adv/eccellenze-lazio/2021/11/15/news/troisi_ricerche_i_dati_analizzarli_e_interpretarli_per_prendere_le_decisioni-326423272/" target="_blank" class="tr-link">Leggi l'articolo</a>
      </div>

      <div class="tr-card">
        <div class="tr-badge">Pag. 33 · Economia</div>
        <div class="tr-testata">Corriere della Sera</div>
        <div class="tr-data">27 marzo 2022 · pag. 33 · Economia</div>
        <div class="tr-titolo-art">"Attacchi informatici e formazione dei manager"</div>
        <div class="tr-desc">Firma: Fabio Savelli. L'articolo segue di 48 ore l'evento Fondirigenti/Confindustria alla Camera dei Deputati (25 marzo 2022), nel quale Troisi Ricerche ha presentato il modello di competenze per la Governance Finanziaria, moderato dallo stesso Savelli e trasmesso in diretta su webtv.camera.it.</div>
        <a href="<?php echo get_template_directory_uri(); ?>/img/pdf/corriere_della_sera_27mar2022_pag33_firma_fabio_savelli.pdf" target="_blank" class="tr-link">📄 Leggi l'articolo PDF</a>
      </div>

    </div>

    <!-- FOTO STAMPA NAZIONALE -->
    <div style="margin-top:24px">
      <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(255,255,255,.35);margin-bottom:12px">📰 Le pagine originali</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
        <figure style="margin:0">
          <img src="<?php echo get_template_directory_uri(); ?>/img/stampa/sole24ore_12nov2021_articolo_dedicato.jpeg"
               alt="Il Sole 24 Ore 12 novembre 2021 — articolo dedicato Troisi Ricerche"
               class="img-zoom" data-caption="Il Sole 24 Ore · 12 novembre 2021 · «Ricerche di mercato con mission sviluppo»"
               style="width:100%;height:180px;object-fit:cover;border-radius:var(--r);display:block">
          <figcaption style="font-size:10px;color:rgba(255,255,255,.35);margin-top:5px;line-height:1.4">Il Sole 24 Ore · 12 nov 2021 · <em style="color:rgba(255,255,255,.55)">clicca per ingrandire</em></figcaption>
        </figure>
        <figure style="margin:0">
          <img src="<?php echo get_template_directory_uri(); ?>/img/stampa/repubblica_15nov2021_eccellenze_lazio_1di5.png"
               alt="la Repubblica 15 novembre 2021 — Eccellenze Lazio (1 di 5)"
               class="img-zoom" data-caption="la Repubblica · 15 novembre 2021 · Speciale Eccellenze Lazio — pagina 1 di 5"
               style="width:100%;height:180px;object-fit:cover;border-radius:var(--r);display:block">
          <figcaption style="font-size:10px;color:rgba(255,255,255,.35);margin-top:5px;line-height:1.4">la Repubblica · 15 nov 2021 (1/5) · <em style="color:rgba(255,255,255,.55)">clicca per ingrandire</em></figcaption>
        </figure>
        <figure style="margin:0">
          <img src="<?php echo get_template_directory_uri(); ?>/img/stampa/repubblica_15nov2021_eccellenze_lazio_3di5_foto_andrea.png"
               alt="la Repubblica — foto istituzionale Andrea Troisi"
               class="img-zoom" data-caption="la Repubblica · Foto istituzionale Andrea Troisi + 3 sedi + ANAC (3/5)"
               style="width:100%;height:180px;object-fit:cover;border-radius:var(--r);display:block">
          <figcaption style="font-size:10px;color:rgba(255,255,255,.35);margin-top:5px;line-height:1.4">la Repubblica · foto Andrea + sedi (3/5) · <em style="color:rgba(255,255,255,.55)">clicca</em></figcaption>
        </figure>
      </div>
      <!-- Altre schermate Repubblica -->
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:10px">
        <figure style="margin:0">
          <img src="<?php echo get_template_directory_uri(); ?>/img/stampa/repubblica_15nov2021_eccellenze_lazio_4di5_sedi.png"
               alt="la Repubblica — tre sedi e numero verde"
               class="img-zoom" data-caption="la Repubblica · 3 sedi (Bari, Roma, Milano) + numero verde 800 644 046 (4/5)"
               style="width:100%;height:160px;object-fit:cover;border-radius:var(--r);display:block">
          <figcaption style="font-size:10px;color:rgba(255,255,255,.35);margin-top:5px;line-height:1.4">la Repubblica · 3 sedi + num. verde (4/5)</figcaption>
        </figure>
        <figure style="margin:0">
          <img src="<?php echo get_template_directory_uri(); ?>/img/stampa/repubblica_15nov2021_eccellenze_lazio_5di5_servizi.png"
               alt="la Repubblica — servizi Mappatura delle Competenze TR-Index CS PA"
               class="img-zoom" data-caption="la Repubblica · Mappatura delle Competenze · TR-Index · Customer Satisfaction PA (5/5)"
               style="width:100%;height:160px;object-fit:cover;border-radius:var(--r);display:block">
          <figcaption style="font-size:10px;color:rgba(255,255,255,.35);margin-top:5px;line-height:1.4">la Repubblica · servizi Mappatura delle Competenze · TR-Index (5/5)</figcaption>
        </figure>
      </div>
    </div>
  </div>

  <!-- 6 — DUC Bari + Bisceglie -->
  <div class="progetto" id="duc-bari">
    <div class="prj-head">
      <div class="prj-anno-badge">2019–<br>2020</div>
      <div class="prj-meta">
        <div class="prj-progetto">Commercio · Bari + BAT</div>
        <div class="prj-title">Distretto Urbano del Commercio — Bari e Bisceglie</div>
        <div class="prj-committente">Committente: <strong>Confcommercio Bari-BAT</strong> &mdash; 1.300 interviste</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Gazzetta del Mezzogiorno <span class="art-badge b-loc">Commercio locale</span></div>
            <div class="art-meta">14 gennaio 2020 · Bari · PRIMA PAGINA + pagg. II e III</div>
            <div class="art-titolo">DUC Bari: «Il commercio è a un bivio — Pronti alla nuova sfida»</div>
            <div class="art-desc">La Gazzetta del Mezzogiorno dedica la PRIMA PAGINA e due pagine interne alla ricerca sul Distretto Urbano del Commercio di Bari — 935 residenti + 365 fuori città intervistati.</div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px">
              <img class="img-zoom" data-caption="DUC Bari — Gazzetta del Mezzogiorno" src="<?php echo get_template_directory_uri(); ?>/img/duc-bari/gazzetta_PRIMA_PAGINA_14gen2020.jpg"
                   alt="Gazzetta del Mezzogiorno PRIMA PAGINA 14 gennaio 2020 — DUC Bari"
                   style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
              <img class="img-zoom" data-caption="DUC Bari — Gazzetta del Mezzogiorno" src="<?php echo get_template_directory_uri(); ?>/img/duc-bari/gazzetta_pagina2_14gen2020.jpg"
                   alt="Gazzetta del Mezzogiorno pag. II — DUC Bari"
                   style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
              <img class="img-zoom" data-caption="DUC Bari — Gazzetta del Mezzogiorno" src="<?php echo get_template_directory_uri(); ?>/img/duc-bari/gazzetta_pagina3_14gen2020.jpg"
                   alt="Gazzetta del Mezzogiorno pag. III — DUC Bari"
                   style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
            </div>
          </div>
        </div>
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">la Repubblica Bari <span class="art-badge b-loc">Economia locale</span></div>
            <div class="art-meta">12 gennaio 2020 · pag. 7 · firma Silvia Dipalo</div>
            <div class="art-titolo">«Shopping, i clienti vogliono orario continuato ed eventi»</div>
            <div class="art-desc">la Repubblica Bari dedica la pag. 7 ai risultati della ricerca sul commercio barese.</div>
            <img class="img-zoom" data-caption="DUC Bari — Gazzetta del Mezzogiorno" src="<?php echo get_template_directory_uri(); ?>/img/duc-bari/repubblica_bari_12gen2020_pag7.jpg"
                 alt="la Repubblica Bari 12 gennaio 2020 pag.7 — DUC Bari"
                 style="width:100%;max-height:160px;object-fit:cover;border-radius:3px;margin-top:8px;display:block">
          </div>
        </div>
        <div class="art tv">
          <div class="art-icon">📺</div>
          <div class="art-content">
            <div class="art-testata">TRM TV Bari <span class="art-badge b-tv">Televisione</span></div>
            <div class="art-meta">2019 · Bari · Telegiornale</div>
            <div class="art-titolo">Servizio TRM TV sul DUC Bari — presentazione dei risultati</div>
            <div class="art-desc">Il telegiornale regionale TRM dedica un servizio ai risultati della ricerca sul distretto commerciale.</div>
            <a href="https://www.youtube.com/watch?v=c4TU22nFTJQ" target="_blank" class="art-link">Guarda il servizio</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 2 — Trieste Trasporti -->
  <div class="progetto" id="trieste-trasporti">
    <div class="prj-head">
      <div class="prj-anno-badge">2016–<br>2025</div>
      <div class="prj-meta">
        <div class="prj-progetto">TPL · Trieste</div>
        <div class="prj-title">Customer Satisfaction Trieste Trasporti</div>
        <div class="prj-committente">Committente: <strong>Trieste Trasporti</strong> &mdash; 4 anni consecutivi · 98,1% soddisfazione</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Rivista "Muoversi Bene" <span class="art-badge b-loc">Settore TPL</span></div>
            <div class="art-meta">Pubblicazione settoriale trasporti pubblici locali</div>
            <div class="art-titolo">Risultati della customer satisfaction su Trieste Trasporti</div>
            <div class="art-desc">Il caso Trieste Trasporti viene pubblicato nella rivista specializzata del settore TPL. Il dato del 98,1% di soddisfazione diventa riferimento di settore. Il progetto confluisce nel libro Cacucci.</div>
            <img class="img-zoom" src="<?php echo get_template_directory_uri(); ?>/img/stampa-locale/rivista_muoversi_bene_trieste_trasporti_98percento.jpg"
                 alt="Rivista Muoversi Bene — Trieste Trasporti 98,1% soddisfazione"
                 data-caption="Rivista 'Muoversi Bene' — «Ascoltare la città fa crescere il servizio» · 98,1% soddisfazione · Trieste Trasporti"
                 style="width:100%;max-height:200px;object-fit:cover;border-radius:var(--r);margin-top:10px;display:block">
            <div style="margin-top:8px"><a href="<?php echo get_template_directory_uri(); ?>/img/stampa-locale/rivista_muoversi_bene_trieste_trasporti_98percento.jpg" target="_blank" class="art-link">Apri articolo →</a></div>
          </div>
        </div>
        <div class="art naz">
          <div class="art-icon">📗</div>
          <div class="art-content">
            <div class="art-testata">Cacucci Editore — Bari <span class="art-badge b-naz">Pubblicazione scientifica</span></div>
            <div class="art-meta">2019 · Presentato alla Camera dei Deputati</div>
            <div class="art-titolo">"Customer Satisfaction nella Pubblica Amministrazione" — caso studio Trieste Trasporti</div>
            <div class="art-desc">Il progetto diventa case study nel volume scientifico presentato ufficialmente alla Camera dei Deputati il 29 marzo 2019.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- CAMERA DEI DEPUTATI -->
  <div class="camera-section" id="camera">
    <div class="camera-label">🏛️ Camera dei Deputati — due volte</div>
    <div class="camera-titolo">Presenza istituzionale al Parlamento italiano</div>
    <div class="camera-sub">Troisi Ricerche è stata protagonista in Parlamento in due occasioni distinte, entrambe trasmesse in diretta su webtv.camera.it.</div>
    <div class="camera-grid">
      <div class="cb">
        <div class="cb-anno">29 Marzo 2019</div>
        <div class="cb-title">Presentazione libro "Customer Satisfaction nella PA"</div>
        <div class="cb-desc">Conferenza stampa ufficiale presso la Camera dei Deputati per la presentazione del volume edito da Cacucci Editore — il modello TR-Index come riferimento nazionale per la qualità nei servizi pubblici.</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px;margin-bottom:10px">
          <img class="img-zoom" data-caption="Camera dei Deputati" src="<?php echo get_template_directory_uri(); ?>/img/camera/andrea_al_banco_camera_deputati_2019.jpg"
               alt="Andrea Troisi al banco della Camera dei Deputati 2019 con libro Cacucci"
               style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
          <img class="img-zoom" data-caption="Camera dei Deputati" src="<?php echo get_template_directory_uri(); ?>/img/camera/webtv_camera_screenshot_29mar2019_libro_cacucci.jpg"
               alt="Screenshot webtv.camera.it — presentazione libro 29 marzo 2019"
               style="width:100%;height:120px;object-fit:cover;border-radius:3px;display:block">
        </div>
        <div><span class="cb-tag">Cacucci Editore</span> <span class="cb-tag">Customer Satisfaction PA</span></div>
        <a href="https://webtv.camera.it" target="_blank" class="cb-link">Archivio webtv.camera.it</a>
      </div>
      <div class="cb">
        <div class="cb-anno">25 Marzo 2022</div>
        <div class="cb-title">Fondirigenti / Confindustria — Governance Finanziaria</div>
        <div class="cb-desc">Evento Fondirigenti sulla Governance Finanziaria, moderato da Fabio Savelli del Corriere della Sera. Risultato: il Corriere pubblica un articolo in prima pagina Economia due giorni dopo. 340 manager coinvolti.</div>
        <div><span class="cb-tag">Fondirigenti</span> <span class="cb-tag">Confindustria</span> <span class="cb-tag">Fabio Savelli</span></div>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:8px">
          <a href="https://www.youtube.com/watch?v=-gykCKwqLxw" target="_blank" rel="noopener" class="cb-link" style="color:#cc0000;border-color:#ffcccc">▶ YouTube</a>
          <a href="https://www.radioradicale.it/scheda/663951/competenze-per-la-governance-finanziaria" target="_blank" rel="noopener" class="cb-link">Radio Radicale</a>
          <a href="https://dirigentindustria.it/formazione/imprese-da-fondirigenti-un-modello-di-competenze-per-la-governance-finanziaria.html" target="_blank" rel="noopener" class="cb-link">Dirigenti Industria</a>
        </div>
      </div>
    </div>
    <!-- FOTO CAMERA DEI DEPUTATI -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:20px">
      <figure style="margin:0">
        <img class="img-zoom" data-caption="Camera dei Deputati" src="<?php echo get_template_directory_uri(); ?>/img/camera/fondirigenti_camera_25mar2022_relatori_al_banco.jpeg"
             alt="Sala Camera dei Deputati — evento Fondirigenti 25 marzo 2022. Tre relatori al banco con Andrea Troisi in collegamento video sul monitor"
             style="width:100%;border-radius:var(--r);display:block;object-fit:cover;max-height:260px">
        <figcaption style="font-size:10.5px;color:var(--g);margin-top:6px;line-height:1.5">Camera dei Deputati, 25 marzo 2022 — Evento Fondirigenti / Governance Finanziaria. Andrea Troisi in collegamento sul monitor laterale</figcaption>
      </figure>
      <figure style="margin:0">
        <img class="img-zoom" data-caption="Camera dei Deputati" src="<?php echo get_template_directory_uri(); ?>/img/camera/fondirigenti_camera_25mar2022_foto_gruppo_6_persone.jpeg"
             alt="Foto di gruppo davanti al banco della Camera dei Deputati — relatori evento Fondirigenti con badge istituzionali"
             style="width:100%;border-radius:var(--r);display:block;object-fit:cover;max-height:260px">
        <figcaption style="font-size:10.5px;color:var(--g);margin-top:6px;line-height:1.5">I relatori dell'evento Fondirigenti con badge istituzionali Camera dei Deputati — marzo 2022</figcaption>
      </figure>
    </div>
  </div>

  <!-- 5 — CCIAA Padova / Mappatura Dinamica -->
  <div class="progetto" id="cciaa-padova">
    <div class="prj-head">
      <div class="prj-anno-badge">2018–<br>2021</div>
      <div class="prj-meta">
        <div class="prj-progetto">Europeo · Padova / Nord-Est</div>
        <div class="prj-title">Mappatura Dinamica delle Imprese</div>
        <div class="prj-committente">Committente: <strong>CCIAA Padova + Interreg EU</strong> &mdash; 244 imprese · 14.700 dati</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Il Gazzettino (Padova) <span class="art-badge b-eu">Fondo Interreg EU</span></div>
            <div class="art-meta">2019–2021 · Padova / Veneto</div>
            <div class="art-titolo">Interreg: Troisi Ricerche mappa le competenze delle imprese transfrontaliere</div>
            <div class="art-desc">Il progetto CCIAA Padova — finanziato dal programma europeo Interreg — viene seguito per tutta la sua durata dal Gazzettino. 244 imprese, 14.700 dati raccolti con metodo proprietario.</div>
            <a href="<?php echo home_url('/caso-studio-cciaa-padova/'); ?>" class="art-link">Scheda progetto completa</a>
          </div>
        </div>
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Il Mattino di Padova <span class="art-badge b-eu">Interreg EU</span></div>
            <div class="art-meta">2019–2021 · Padova</div>
            <div class="art-titolo">La mappatura dinamica delle competenze: un modello dall'Adriatico all'Europa</div>
            <div class="art-desc">Copertura parallela su Il Mattino di Padova — il secondo quotidiano del Nord-Est conferma il valore del progetto nel tessuto economico veneto.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 4 — Mense Scolastiche Bari -->
  <div class="progetto" id="mense-bari">
    <div class="prj-head">
      <div class="prj-anno-badge">2018</div>
      <div class="prj-meta">
        <div class="prj-progetto">Comunale · Bari</div>
        <div class="prj-title">Mense Scolastiche Bari — 4.000+ interviste</div>
        <div class="prj-committente">Committente: <strong>Comune di Bari / Ladisa</strong> &mdash; Istituto terzo indipendente</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Gazzetta del Mezzogiorno <span class="art-badge b-loc">Prima pagina</span></div>
            <div class="art-meta">2018 · Bari</div>
            <div class="art-titolo">La soddisfazione delle famiglie baresi per il servizio mensa: i dati di Troisi Ricerche</div>
            <div class="art-desc">Con oltre 4.000 interviste alle famiglie degli alunni, Troisi Ricerche agisce come istituto terzo indipendente — formula esplicitamente citata dalla Repubblica Bari. La ricerca genera copertura su tutti i principali media locali.</div>
          </div>
        </div>
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">la Repubblica Bari <span class="art-badge b-loc">Online + carta</span></div>
            <div class="art-meta">2018 · Bari</div>
            <div class="art-titolo">Mense scolastiche: "istituto terzo indipendente" certifica i dati di soddisfazione</div>
            <div class="art-desc">La Repubblica Bari cita esplicitamente la formula <em>"istituto terzo indipendente"</em> — elemento chiave del posizionamento di Troisi Ricerche come garante della qualità dei dati per le pubbliche amministrazioni.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 3 — Doing Business EAU -->
  <div class="progetto" id="doing-business-eau">
    <div class="prj-head">
      <div class="prj-anno-badge">2016</div>
      <div class="prj-meta">
        <div class="prj-progetto">Internazionale · Emirati Arabi</div>
        <div class="prj-title">Doing Business Emirati Arabi Uniti</div>
        <div class="prj-committente">Committente: <strong>CCIAA Bari</strong> &mdash; Con Ministro Farnesina · Presidente Fiera Levante</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">Gazzetta del Mezzogiorno <span class="art-badge b-loc">Economia regionale</span></div>
            <div class="art-meta">2016 · Bari</div>
            <div class="art-titolo">Missione negli Emirati Arabi — CCIAA Bari e Troisi Ricerche analizzano le opportunità di business</div>
            <div class="art-desc">La missione negli Emirati Arabi con il Ministero degli Esteri (Farnesina) e la presidenza di Fiera del Levante viene documentata dalla Gazzetta del Mezzogiorno. Troisi Ricerche porta il metodo Mappatura delle Competenze nelle relazioni economiche internazionali.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 1 — Qualità della vita in Puglia -->
  <div class="progetto" id="qualita-puglia">
    <div class="prj-head">
      <div class="prj-anno-badge">2011</div>
      <div class="prj-meta">
        <div class="prj-progetto">Regionale · Puglia</div>
        <div class="prj-title">Qualità della vita in Puglia</div>
        <div class="prj-committente">Committente: <strong>Codacons + Regione Puglia</strong> &mdash; 1.068 interviste face-to-face</div>
      </div>
    </div>
    <div class="prj-body">
      <div class="prj-articoli">
        <div class="art locale">
          <div class="art-icon">📰</div>
          <div class="art-content">
            <div class="art-testata">EPolis Bari <span class="art-badge b-loc">Prima pagina</span></div>
            <div class="art-meta">2011 · Quotidiano locale Puglia</div>
            <div class="art-titolo">Prima pagina dedicata alla ricerca sulla qualità della vita in Puglia</div>
            <div class="art-desc">La prima grande indagine di Troisi Ricerche su scala regionale — 1.068 interviste face-to-face in tutta la Puglia — finisce in prima pagina su EPolis, il quotidiano gratuito più diffuso della regione.</div>
            <a href="<?php echo get_template_directory_uri(); ?>/img/stampa-locale/rassegna-stampa-qualita-vita-puglia-2011.pdf" target="_blank" class="art-link">📄 Apri rassegna stampa PDF</a>
          </div>
        </div>
      </div>
    </div>
  </div>

</div><!-- /wrap -->
</div><!-- /sec alt -->

<!-- CTA FINALE -->
<div class="sec" style="background:var(--dp);padding:40px 24px;text-align:center">
  <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.35);margin-bottom:8px">Approfondisci</div>
  <div style="font-size:20px;font-weight:700;color:#fff;margin-bottom:8px">Vuoi vedere i progetti nel dettaglio?</div>
  <div style="font-size:13px;color:rgba(255,255,255,.55);margin-bottom:22px;max-width:500px;margin-left:auto;margin-right:auto;line-height:1.7">Ogni progetto ha una scheda completa con dati, metodi, committenti e risultati misurabili.</div>
  <a href="<?php echo home_url('/casi-studio/'); ?>" style="display:inline-flex;align-items:center;gap:6px;background:var(--or);color:#fff;font-size:12px;font-weight:700;padding:11px 24px;border-radius:var(--r);text-decoration:none;text-transform:uppercase;letter-spacing:.06em">Vai ai Casi Studio →</a>
</div>
<!-- SEZIONE VIDEO E MEDIA AUDIOVISIVI -->
<div class="sec" style="background:#fff">
  <div class="wrap">
    <div class="sh"><div class="sl"></div><div class="se">Televisione &amp; Web Video</div></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px">

      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #0066cc">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📺 Camera dei Deputati — webtv.camera.it</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">Presentazione libro Cacucci Editore</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">29 marzo 2019 · Conferenza stampa parlamentare · 11:30</div>
        <div style="font-size:13px;color:#1a1a2e;margin-bottom:12px;line-height:1.6"><em>«Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione»</em><br>Autori: Troisi A., Raffaele G., Gravili S.</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://webtv.camera.it" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:5px 12px;border-radius:2px;text-decoration:none;background:#e8f1fb">webtv.camera.it ↗</a>
        </div>
      </div>

      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #0066cc">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📺 Camera dei Deputati — Fondirigenti</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">Modello di competenze per la Governance finanziaria</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">25 marzo 2022 · Moderatore: Fabio Savelli, Corriere della Sera</div>
        <div style="font-size:13px;color:#1a1a2e;margin-bottom:12px;line-height:1.6">Massimo Sabatini (DG Fondirigenti) · Andrea Troisi · Matilde Marandola (AIDP). Trasmesso su webtv.camera.it.</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://www.youtube.com/watch?v=-gykCKwqLxw" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#fff;background:#cc0000;padding:5px 12px;border-radius:2px;text-decoration:none">▶ YouTube</a>
          <a href="https://www.fondirigenti.it/modello-di-competenze-per-la-governance-finanziaria" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:5px 12px;border-radius:2px;text-decoration:none;background:#e8f1fb">Fondirigenti ↗</a>
        </div>
      </div>

      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #e8a020">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📺 RAI 3 Puglia — TG Regionale</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">«La Puglia che va» — Servizio speciale</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">Giornalista: Salvatore Catapano (RAI) · Sede di Bari</div>
        <div style="font-size:13px;color:#1a1a2e;margin-bottom:12px;line-height:1.6">Servizio speciale realizzato nella sede di Bari. Andrea Troisi racconta la storia e i progetti dell'istituto.</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://www.rainews.it/tgr/puglia/video/2023/05/centri-di-ricerca-imprese-business-troisi-bari-puglia-che-va-22e2cb36-95fd-46a4-a8d5-8d7c452d5be6.html" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:5px 12px;border-radius:2px;text-decoration:none;background:#e8f1fb">Guarda su RAI ↗</a>
        </div>
      </div>

      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #e8a020">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📺 AIQUAV 2023 — Food Policy &amp; Well-Being</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">Sessione con Pina Picierno, VP Parlamento Europeo</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">21 settembre 2023 · Hotel Excelsior Bari · Moderatore: Danilo Giannese (RAI)</div>
        <div style="font-size:13px;color:#1a1a2e;margin-bottom:12px;line-height:1.6">Panel: Pina Picierno (VP PE) · Andrea Troisi · Paola Romano · Cesare Pinto · Filomena Corbo (UniBa).</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://youtu.be/zB1iZVjzK5k" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#fff;background:#cc0000;padding:5px 12px;border-radius:2px;text-decoration:none">▶ YouTube</a>
        </div>
      </div>

      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #5a2a8a">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📺 TRM TV Bari — DUC Bari</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">Presentazione risultati DUC Bari — Confcommercio</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">Gennaio 2020 · Intervista ad Andrea Troisi</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://www.youtube.com/watch?v=c4TU22nFTJQ" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#fff;background:#cc0000;padding:5px 12px;border-radius:2px;text-decoration:none">▶ YouTube</a>
          <a href="https://www.trmtv.it/home/economia/2020_01_13/222245.html" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:5px 12px;border-radius:2px;text-decoration:none;background:#e8f1fb">TRM TV ↗</a>
        </div>
      </div>

      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #1a7a4a">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📺 Tele Lazio Nord — Drive In</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">Ospite fisso — analisi dati e sondaggi</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">Più stagioni · Commenti in diretta su ricerche di attualità</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="https://www.youtube.com/watch?v=qa3CJBMLXIY&list=PLOoGJz564GrV21MMzOLhiUlpEdW3Xbu8T" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#fff;background:#cc0000;padding:5px 12px;border-radius:2px;text-decoration:none">▶ Playlist YouTube</a>
        </div>
      </div>

    </div>

    <!-- RADIO -->
    <div class="sh"><div class="sl"></div><div class="se">Radio &amp; Podcast</div></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px">
      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #0066cc">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">📻 Controradio Bari</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">«Il dato è tratto» — Conduttore</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:6px">Settimanale · Più stagioni</div>
        <div style="font-size:13px;color:#1a1a2e;line-height:1.6">Statistica, sondaggi e dati raccontati al pubblico barese. Analisi di ricerche sociali e politiche pubbliche.</div>
      </div>
      <div style="background:#f5f6fa;border:1px solid #d9e0ed;border-radius:4px;padding:20px;border-left:3px solid #7b2d8b">
        <div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#5a6a85;margin-bottom:6px">🎙️ VoiceInHub — Podcast</div>
        <div style="font-size:15px;font-weight:700;color:#00264d;margin-bottom:4px">Il podcast di Troisi Ricerche</div>
        <div style="font-size:11.5px;color:#5a6a85;margin-bottom:10px">Customer satisfaction · governance pubblica · ricerca statistica</div>
        <div style="display:flex;gap:8px">
          <a href="https://voiceinhub.it" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:5px 12px;border-radius:2px;text-decoration:none;background:#e8f1fb">voiceinhub.it ↗</a>
        </div>
      </div>
    </div>

    <!-- ONLINE -->
    <div class="sh"><div class="sl"></div><div class="se">Citazioni Web &amp; Stampa Online</div></div>
    <div style="display:flex;flex-direction:column;gap:10px">
      <div style="background:#fff;border:1px solid #d9e0ed;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><div style="font-size:13px;font-weight:700;color:#00264d">Comune di Bari — Food Policy</div><div style="font-size:12px;color:#5a6a85">«L'indagine, affidata all'Istituto Troisi Ricerche, ha coinvolto 1.090 residenti»</div></div>
        <a href="https://www.comune.bari.it/-/cosa-mangiano-i-baresi-il-comune-di-bari-nell-ambito-della-food-policy-indaga-i-consumi-e-i-comportamenti-alimentari-in-citta" target="_blank" rel="noopener" style="font-size:11px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:4px 10px;border-radius:2px;text-decoration:none;white-space:nowrap;background:#e8f1fb">Leggi ↗</a>
      </div>
      <div style="background:#fff;border:1px solid #d9e0ed;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><div style="font-size:13px;font-weight:700;color:#00264d">AbruzzoNews — Progetto SUMMA Interreg</div><div style="font-size:12px;color:#5a6a85">«è stato presentato lo studio, affidato a CLES srl e TROISI RICERCHE srl» · Marzo 2026</div></div>
        <a href="https://www.abruzzonews.eu/summa-concluse-attivita-meeting-progetto-pescara-671170.html" target="_blank" rel="noopener" style="font-size:11px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:4px 10px;border-radius:2px;text-decoration:none;white-space:nowrap;background:#e8f1fb">Leggi ↗</a>
      </div>
      <div style="background:#fff;border:1px solid #d9e0ed;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><div style="font-size:13px;font-weight:700;color:#00264d">BariViva / BariToday — DUC Bari</div><div style="font-size:12px;color:#5a6a85">Indagine sul commercio nel centro storico di Bari · Confcommercio · Gennaio 2020</div></div>
        <a href="https://www.bariviva.it/notizie/dove-si-compra-meglio-a-bari-ecco-il-sondaggio-di-confcommercio/" target="_blank" rel="noopener" style="font-size:11px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:4px 10px;border-radius:2px;text-decoration:none;white-space:nowrap;background:#e8f1fb">Leggi ↗</a>
      </div>
      <div style="background:#fff;border:1px solid #d9e0ed;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><div style="font-size:13px;font-weight:700;color:#00264d">Buonasera24 — CiBari 2025</div><div style="font-size:12px;color:#5a6a85">Festival CiBari 2025 · Citazione diretta Andrea Troisi · Ottobre 2025</div></div>
        <a href="https://buonasera24.it/gallery/cronaca/905200/il-cibo-come-cura-bari-capitale-della-salute-alimentare-e-della-ricerca-scientifica.html" target="_blank" rel="noopener" style="font-size:11px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:4px 10px;border-radius:2px;text-decoration:none;white-space:nowrap;background:#e8f1fb">Leggi ↗</a>
      </div>
      <div style="background:#fff;border:1px solid #d9e0ed;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><div style="font-size:13px;font-weight:700;color:#00264d">la Repubblica (eccellenze lazio)</div><div style="font-size:12px;color:#5a6a85">«Troisi Ricerche: i dati, analizzarli e interpretarli per prendere le decisioni» · 15 novembre 2021</div></div>
        <a href="https://roma.repubblica.it/dossier-adv/eccellenze-lazio/2021/11/15/news/troisi_ricerche_i_dati_analizzarli_e_interpretarli_per_prendere_le_decisioni-326423272/" target="_blank" rel="noopener" style="font-size:11px;font-weight:700;color:#0066cc;border:1px solid #c5d9f0;padding:4px 10px;border-radius:2px;text-decoration:none;white-space:nowrap;background:#e8f1fb">Leggi ↗</a>
      </div>
    </div>

  </div>
</div>

<!-- LIGHTBOX OVERLAY -->
<div class="lightbox-overlay" id="lightbox-overlay">
  <div class="lightbox-inner">
    <button class="lightbox-close" id="lightbox-close" aria-label="Chiudi">×</button>
    <img id="lightbox-img" src="" alt="">
    <div class="lightbox-caption" id="lightbox-caption"></div>
  </div>
</div>
<script>
(function(){
  // Lightbox per tutte le img.img-zoom
  document.querySelectorAll('.img-zoom').forEach(function(img){
    img.addEventListener('click', function(){
      var overlay = document.getElementById('lightbox-overlay');
      var lbImg = document.getElementById('lightbox-img');
      var lbCap = document.getElementById('lightbox-caption');
      // Carica la versione fullsize (stessa src)
      lbImg.src = img.src;
      lbImg.alt = img.alt;
      lbCap.textContent = img.getAttribute('data-caption') || img.alt;
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });
  // Chiudi lightbox
  function closeLB(){
    document.getElementById('lightbox-overlay').classList.remove('open');
    document.body.style.overflow = '';
  }
  document.getElementById('lightbox-close').addEventListener('click', closeLB);
  document.getElementById('lightbox-overlay').addEventListener('click', function(e){
    if(e.target === this) closeLB();
  });
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeLB();
  });
})();
</script>

<?php include(get_template_directory() . '/troisi-footer.php'); ?>

