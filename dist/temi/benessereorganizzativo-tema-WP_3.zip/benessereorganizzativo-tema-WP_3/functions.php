<?php
// Tema BenessereOrganizzativo - Troisi Ricerche

add_action('template_redirect', function() {
  $uri = rtrim(strtok($_SERVER['REQUEST_URI'], '?'), '/');

  // v1.1.1 – articoli sui giovani spostati su benesseredigitalegiovani.it: 301 verso la nuova sede
  $bo_spostati = [
    '/ai-adolescenti-chatbot-supporto-emotivo',
    '/tempo-schermo-benessere-giovani-ricerca-2026',
    '/ai-act-minori-regolamento-europeo-protezione-giovani',
  ];
  if (in_array($uri, $bo_spostati, true)) {
    wp_redirect('https://www.benesseredigitalegiovani.it' . $uri . '/', 301);
    exit;
  }

  // v1.1.1 – le pagine servite dal tema rispondono 200 (prima uscivano con stato 404)
  $bo_pagine = [
    '/sei-in-regola-bo'                             => 'page-sei-in-regola-bo.php',
    '/approfondimenti'                              => 'page-approfondimenti.php',
    '/ispettorato-lavoro-benessere-organizzativo'   => 'page-ispettorato-lavoro-benessere-organizzativo.php',
  ];
  if (isset($bo_pagine[$uri])) {
    global $wp_query;
    if ($wp_query) { $wp_query->is_404 = false; }
    status_header(200);
    include(get_template_directory() . '/' . $bo_pagine[$uri]);
    exit;
  }

  // /sei-in-regola-bo — Checker BO
  if ($uri === '/sei-in-regola-bo') {
    include(get_template_directory() . '/page-sei-in-regola-bo.php');
    exit;
  }

  // /approfondimenti — Blog lista articoli
  if ($uri === '/approfondimenti') {
    include(get_template_directory() . '/page-approfondimenti.php');
    exit;
  }

  // /ispettorato-lavoro-benessere-organizzativo — Articolo 1
  if ($uri === '/ispettorato-lavoro-benessere-organizzativo') {
    include(get_template_directory() . '/page-ispettorato-lavoro-benessere-organizzativo.php');
    exit;
  }
});


// ============================================================
// ARTICOLI SETTIMANALI — Troisi Ricerche (v1.1)
// ============================================================
add_action('after_setup_theme', function () {
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
});

function bo_articoli($n = 3, $offset = 0) {
    return new WP_Query(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => $n, 'offset' => $offset,
                         'post_name__not_in' => ['ciao-mondo', 'hello-world'], 'ignore_sticky_posts' => true]);
}

function bo_minuti_lettura($post = null) {
    $parole = str_word_count(wp_strip_all_tags(preg_replace('#<(style|svg)\b.*?</\1>#s', ' ', get_post_field('post_content', $post))));
    return max(2, (int) round($parole / 200));
}

// Tema dell'articolo = prima categoria diversa da "Analisi"
function bo_tema($post = null) {
    foreach ((array) get_the_category($post ? get_post($post)->ID : 0) as $c) {
        if (!in_array($c->slug, ['analisi', 'senza-categoria', 'uncategorized'], true)) return $c->name;
    }
    return 'Analisi';
}

function bo_url_archivio() {
    $c = get_category_by_slug('analisi');
    return $c ? get_category_link($c) : home_url('/');
}

// Titolo delle pagine interne (la homepage mantiene il proprio <title>)
add_filter('pre_get_document_title', function ($t) {
    if (is_singular()) return wp_strip_all_tags(get_the_title()) . ' — BenessereOrganizzativo';
    if (is_category('analisi')) return 'Analisi — BenessereOrganizzativo';
    if (is_category() || is_tag()) return single_term_title('', false) . ' — Analisi — BenessereOrganizzativo';
    if (is_404()) return 'Pagina non trovata — BenessereOrganizzativo';
    if (is_home() || is_archive() || is_search()) return 'Analisi — BenessereOrganizzativo';
    return $t;
});
add_action('wp_head', function () {
    if (!is_front_page()) echo '<title>' . esc_html(wp_get_document_title()) . "</title>\n";
}, 1);

// SEO articoli: description, Open Graph, JSON-LD NewsArticle
add_action('wp_head', function () {
    if (!is_singular('post')) return;
    $p = get_queried_object();
    $desc = wp_strip_all_tags(has_excerpt($p) ? get_the_excerpt($p) : wp_trim_words($p->post_content, 32, '…'));
    $url = get_permalink($p);
    echo '<meta name="description" content="' . esc_attr($desc) . "\">\n";
    echo '<meta property="og:type" content="article">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr(get_the_title($p)) . "\">\n";
    echo '<meta property="og:description" content="' . esc_attr($desc) . "\">\n";
    echo '<meta property="og:url" content="' . esc_url($url) . "\">\n";
    echo '<meta property="og:site_name" content="BenessereOrganizzativo">' . "\n";
    $ld = [
        '@context' => 'https://schema.org', '@type' => 'NewsArticle',
        'headline' => get_the_title($p), 'description' => $desc,
        'datePublished' => get_the_date('c', $p), 'dateModified' => get_the_modified_date('c', $p),
        'mainEntityOfPage' => $url, 'inLanguage' => 'it-IT', 'articleSection' => bo_tema($p),
        'keywords' => implode(', ', wp_list_pluck((array) get_the_tags($p->ID), 'name')),
        'author' => ['@type' => 'Person', 'name' => 'Andrea Troisi', 'url' => 'https://andreatroisi.it'],
        'publisher' => ['@type' => 'Organization', 'name' => 'Troisi Ricerche S.r.l. Unipersonale', 'url' => 'https://www.troisiricerche.net'],
    ];
    echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
}, 5);

// Il "Ciao mondo" di WordPress non compare in archivi e feed
add_action('pre_get_posts', function ($q) {
    if (!is_admin() && $q->is_main_query() && ($q->is_home() || $q->is_archive() || $q->is_feed())) {
        $q->set('post_name__not_in', ['ciao-mondo', 'hello-world']);
    }
});

