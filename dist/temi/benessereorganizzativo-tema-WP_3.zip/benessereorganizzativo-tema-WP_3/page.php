<?php get_template_part('inc/tr-head'); ?>
<?php while (have_posts()) : the_post(); ?>
<main class="tr-single">
  <article class="tr-post">
    <header class="tr-post-header"><h1><?php the_title(); ?></h1></header>
    <div class="tr-post-body"><?php the_content(); ?></div>
  </article>
</main>
<?php endwhile; ?>
<?php get_template_part('inc/tr-footer'); ?>
