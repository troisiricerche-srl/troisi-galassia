<?php get_header(); ?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Benessere Organizzativo: obbligo normativo, stress lavoro correlato e DVR | Metodo Troisi</title>
<meta name="description" content="Il benessere organizzativo è un obbligo normativo (D.Lgs. 81/2008 e D.Lgs. 150/2009). Scopri obblighi DVR, stress lavoro-correlato, sanzioni e come verificare la compliance. Metodo Troisi — metodologia conforme ANAC, difendibile davanti all'Ispettorato del Lavoro.">
<meta name="keywords" content="benessere organizzativo, benessere organizzativo aziendale, benessere organizzativo pubblica amministrazione, benessere organizzativo aziende, organizational wellbeing, workplace wellbeing, employee wellbeing, benessere nei luoghi di lavoro, qualità della vita lavorativa, clima organizzativo, analisi clima aziendale, survey clima aziendale, misurazione clima organizzativo, stress lavoro correlato, valutazione stress lavoro correlato, rischio psicosociale lavoro, employee survey, employee satisfaction survey, employee engagement survey, indagine dipendenti, questionario benessere organizzativo, performance organizzativa, organizational performance, efficienza organizzativa, employee engagement, employee experience, motivazione dipendenti, organizational analytics, HR analytics, workplace analytics, organizational wellbeing index, organizational climate index, indicatori benessere organizzativo, benchmark clima aziendale, benessere organizzativo Italia, benessere organizzativo aziende italiane, benessere organizzativo enti pubblici, benessere organizzativo comuni, benessere organizzativo università, smart working benessere organizzativo, digital workplace, come misurare il benessere organizzativo, come migliorare il clima aziendale, strumenti per misurare il clima organizzativo, consulenza benessere organizzativo, organizational consulting, Andrea Troisi, Troisi Ricerche, Metodo Troisi, Troisi Organizational Wellbeing Model, mappatura delle competenze, registro delle competenze, CustomerPA, TR-Index, TroisiInsight, Mappatura delle Competenze, Registro delle Competenze, how to measure organizational wellbeing, how to measure employee wellbeing, organizational wellbeing indicators, leadership organizzativa, cultura organizzativa, governance organizzativa, benessere organizzativo digitalizzazione PA, benessere organizzativo trasformazione digitale, performance pubblica amministrazione, valutazione enti pubblici, troisi ricerche benessere organizzativo, andrea troisi organizational wellbeing, rischio ispettivo benessere organizzativo, ispettorato lavoro benessere organizzativo, DVR stress lavoro correlato PA, ANAC questionario benessere organizzativo, D.Lgs. 81/2008 benessere organizzativo, D.Lgs. 150/2009 indagine BO, OIV validazione benessere organizzativo, PIAO benessere organizzativo, diagnosi rischio ispettivo BO, audit benessere organizzativo PA, compliance benessere organizzativo enti pubblici, piano miglioramento benessere organizzativo, comunicazione dipendenti risultati BO, periodicità indagine benessere organizzativo, valutazione approfondita stress SLC, responsabilità datore lavoro benessere organizzativo, sanzioni mancata valutazione stress lavoro correlato, Corte dei Conti benessere organizzativo PA, RSPP benessere organizzativo, medico competente stress lavoro correlato, Accordo Europeo 2004 stress lavoro, INAIL linee guida stress lavoro correlato, benessere organizzativo Comune, benessere organizzativo ASL, benessere organizzativo scuola, benessere organizzativo società in-house, Score BO diagnosi istituzionale, piattaforma TIP benessere organizzativo, tiplive.it survey BO, approfondimenti normativa benessere organizzativo, blog benessere organizzativo PA, cosa controlla ispettorato benessere organizzativo, ispezione benessere organizzativo cosa succede, relazione performance benessere organizzativo, premi personale PA benessere organizzativo">
<link rel="canonical" href="https://www.benessereorganizzativo.it/">
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
<meta name="language" content="Italian">

<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/apple-touch-icon.png">

<!-- Schema.org -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "BenessereOrganizzativo.it — Metodo Troisi",
  "url": "https://www.benessereorganizzativo.it",
  "description": "Il riferimento nazionale per la normativa sul Benessere Organizzativo: D.Lgs. 81/2008, D.Lgs. 150/2009, ANAC, INAIL. Metodo Troisi — Troisi Ricerche S.r.l.",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://www.benessereorganizzativo.it/?s={search_term_string}",
    "query-input": "required name=search_term_string"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Troisi Ricerche S.r.l.",
    "url": "https://www.troisiricerche.net",
    "logo": { "@type": "ImageObject", "url": "https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/favicon.png" },
    "sameAs": [
      "https://www.linkedin.com/company/troisi-ricerche",
      "https://andreatroisi.it"
    ]
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Il benessere organizzativo è obbligatorio?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sì. Per la Pubblica Amministrazione è un obbligo di legge ai sensi del D.Lgs. 150/2009, art. 14 c.5: l'OIV deve curare annualmente indagini sul benessere organizzativo. Per tutte le organizzazioni (PA e privati) il D.Lgs. 81/2008, art. 28, obbliga alla valutazione dello stress lavoro-correlato nel DVR."
      }
    },
    {
      "@type": "Question",
      "name": "Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "L'Ispettorato del Lavoro verifica: la presenza della valutazione dello stress lavoro-correlato nel DVR (D.Lgs. 81/2008 art. 28), l'adeguatezza metodologica dell'indagine, il coinvolgimento del RSPP e del medico competente, l'esistenza di un piano di miglioramento documentato."
      }
    },
    {
      "@type": "Question",
      "name": "Il DVR deve includere lo stress lavoro correlato?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sì. Il DVR deve includere obbligatoriamente la valutazione del rischio da stress lavoro-correlato (SLC) ai sensi del D.Lgs. 81/2008, art. 28. Un DVR senza questa sezione è considerato incompleto e espone il datore di lavoro a sanzioni amministrative e penali."
      }
    },
    {
      "@type": "Question",
      "name": "Quali sono le sanzioni per DVR incompleto?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Un DVR incompleto per assenza della valutazione stress lavoro-correlato comporta: sanzioni amministrative da 1.000 a 3.000 euro, possibile responsabilità penale del datore di lavoro, per la PA possibile rilievo OIV e intervento della Corte dei Conti."
      }
    },
    {
      "@type": "Question",
      "name": "ANAC richiede il questionario benessere organizzativo?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sì. L'ANAC (ora Dipartimento della Funzione Pubblica) ha definito il modello di questionario in 17 sezioni e 85 domande come riferimento metodologico per le indagini sul benessere organizzativo nella PA. Un'indagine condotta con strumenti non validati non soddisfa il requisito normativo."
      }
    },
    {
      "@type": "Question",
      "name": "Ogni quanto va fatta l'indagine benessere organizzativo nella PA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "L'indagine sul benessere organizzativo nella PA deve essere effettuata annualmente, ai sensi del D.Lgs. 150/2009 art. 14 c.5. I risultati devono essere integrati nella Relazione sulla Performance e validati dall'OIV."
      }
    }
  ]
}
</script>

<style>
/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --teal:       #3dbfab;
  --teal-dark:  #2a9d8a;
  --teal-deep:  #1a7a6b;
  --teal-light: #e8f7f4;
  --teal-mid:   #b2e8e0;
  --blu:        #1a3a5c;
  --accento:    #e8a020;
  --testo:      #1a2e2a;
  --grigio:     #6b7280;
  --grigio-bg:  #f8fafa;
  --bordo:      #d1ece8;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --rosso:      #dc2626;
  --arancio:    #ea580c;
}
body { font-family: 'Segoe UI', system-ui, sans-serif; color: var(--testo); background: var(--bianco); line-height: 1.6; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; height: auto; }

/* =============================================
   TOPBAR
   ============================================= */
.topbar { background: var(--teal-deep); padding: 6px 0; font-size: 0.72rem; }
.topbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; gap: 14px; flex-wrap: wrap; align-items: center; }
.topbar a { color: rgba(255,255,255,.65); transition: color .2s; }
.topbar a:hover { color: var(--accento); }
.topbar a.topbar-personal { color: var(--accento); font-weight: 700; }
.topbar a.topbar-active { color: var(--bianco); font-weight: 700; }

/* =============================================
   NAVBAR
   ============================================= */
.navbar { background: var(--bianco); border-bottom: 3px solid var(--teal); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.07); }
.navbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.navbar-brand { display: flex; align-items: center; gap: 10px; }
.brand-logo { font-size: 1.05rem; font-weight: 900; color: var(--teal-deep); line-height: 1.1; }
.brand-logo span { color: var(--teal); }
.brand-sub { font-size: 0.65rem; color: var(--grigio); display: block; }
.navbar-links { display: flex; gap: 4px; align-items: center; }
.navbar-links a { padding: 6px 10px; border-radius: 6px; font-size: 0.82rem; color: var(--testo); font-weight: 500; transition: all .2s; }
.navbar-links a:hover { background: var(--teal-light); color: var(--teal-deep); }
.navbar-links .btn-contatti { border: 1.5px solid var(--bordo); color: var(--teal-deep); font-weight: 600; }
.navbar-links .btn-demo { background: var(--teal); color: var(--bianco) !important; font-weight: 700; padding: 7px 16px; }
.navbar-links .btn-demo:hover { background: var(--teal-dark); }
.hamburger { display: none; flex-direction: column; justify-content: center; gap: 5px; cursor: pointer; padding: 8px; border: none; background: none; }
.hamburger span { display: block; width: 24px; height: 2px; background: var(--teal); border-radius: 2px; transition: all .3s; }
.hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.mobile-menu { display: none; position: fixed; top: 64px; left: 0; right: 0; bottom: 0; background: var(--bianco); z-index: 99; padding: 20px; flex-direction: column; gap: 4px; overflow-y: auto; }
.mobile-menu.open { display: flex; }
.mobile-menu a { padding: 14px 16px; border-radius: 8px; font-size: 1rem; color: var(--testo); font-weight: 500; border-bottom: 1px solid var(--bordo); }
.mobile-menu .btn-demo { background: var(--teal); color: var(--bianco) !important; text-align: center; margin-top: 8px; border-bottom: none; }

/* =============================================
   HERO
   ============================================= */
.hero { background: linear-gradient(135deg, var(--teal-deep) 0%, var(--teal-dark) 50%, var(--teal) 100%); color: var(--bianco); padding: 72px 20px 56px; position: relative; overflow: hidden; }
.hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 80% 20%, rgba(255,255,255,.06) 0%, transparent 60%); }
.hero .inner { max-width: 1100px; margin: 0 auto; position: relative; display: grid; grid-template-columns: 1fr 340px; gap: 48px; align-items: center; }
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.9); font-size: 0.7rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; padding: 5px 14px; border-radius: 20px; margin-bottom: 16px; }
.hero h1 { font-size: clamp(1.9rem, 4vw, 2.8rem); font-weight: 900; line-height: 1.15; margin-bottom: 10px; }
.hero h1 em { color: #a7f3d0; font-style: normal; }
.hero-sub { font-size: 0.88rem; color: rgba(255,255,255,.6); margin-bottom: 14px; }
.hero-desc { font-size: 0.95rem; color: rgba(255,255,255,.82); margin-bottom: 28px; line-height: 1.7; max-width: 520px; }
.hero-cta { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }
.btn-hero-primary { background: var(--bianco); color: var(--teal-deep); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-hero-primary:hover { background: #a7f3d0; }
.btn-hero-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.35); transition: all .2s; display: inline-block; }
.btn-hero-outline:hover { border-color: rgba(255,255,255,.7); }
.hero-badges { display: flex; gap: 8px; flex-wrap: wrap; }
.hb { font-size: 0.68rem; font-weight: 700; padding: 5px 12px; border-radius: 6px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.85); }

/* Hero card */
.hero-card { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); border-radius: 16px; padding: 22px; backdrop-filter: blur(8px); }
.hc-title { font-size: 0.68rem; text-transform: uppercase; letter-spacing: .08em; color: rgba(255,255,255,.5); margin-bottom: 16px; font-weight: 700; }
.bo-score { font-size: 3.5rem; font-weight: 900; color: #a7f3d0; line-height: 1; margin-bottom: 4px; }
.bo-label { font-size: 0.75rem; color: rgba(255,255,255,.6); margin-bottom: 16px; }
.bo-dims { display: flex; flex-direction: column; gap: 8px; }
.bo-dim { display: flex; align-items: center; gap: 8px; }
.bo-dim .bd-label { font-size: 0.65rem; color: rgba(255,255,255,.6); flex: 1; }
.bo-dim .bd-bar { flex: 1; height: 4px; background: rgba(255,255,255,.12); border-radius: 2px; }
.bo-dim .bd-fill { height: 100%; border-radius: 2px; background: #a7f3d0; }
.bo-dim .bd-val { font-size: 0.7rem; color: rgba(255,255,255,.8); font-weight: 700; width: 28px; text-align: right; }
.hc-anac { margin-top: 14px; font-size: 0.65rem; color: rgba(255,255,255,.4); border-top: 1px solid rgba(255,255,255,.1); padding-top: 10px; }
.hc-anac strong { color: #a7f3d0; }

/* =============================================
   SEZIONI GENERALI
   ============================================= */
section { padding: 64px 20px; }
.section-inner { max-width: 1100px; margin: 0 auto; }
.section-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .1em; color: var(--teal-dark); font-weight: 700; margin-bottom: 8px; }
.section-title { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; color: var(--blu); margin-bottom: 12px; line-height: 1.2; }
.section-title em { color: var(--teal-dark); font-style: normal; }
.section-desc { color: var(--grigio); max-width: 680px; margin-bottom: 36px; line-height: 1.7; }

/* =============================================
   NORMATIVA — TIMELINE
   ============================================= */
#normativa { background: var(--grigio-bg); }
.timeline { position: relative; max-width: 860px; }
.timeline::before { content: ''; position: absolute; left: 110px; top: 0; bottom: 0; width: 2px; background: var(--teal-mid); }
.timeline-item { display: grid; grid-template-columns: 100px 1fr; gap: 24px; margin-bottom: 28px; position: relative; }
.tl-anno { text-align: right; padding-top: 14px; position: relative; }
.tl-anno .anno { font-size: 1rem; font-weight: 900; color: var(--teal-dark); line-height: 1; }
.tl-anno .tipo { font-size: 0.6rem; text-transform: uppercase; letter-spacing: .06em; color: var(--grigio); margin-top: 2px; }
.tl-dot { position: absolute; right: -28px; top: 18px; width: 14px; height: 14px; background: var(--teal); border-radius: 50%; border: 3px solid var(--bianco); box-shadow: 0 0 0 2px var(--teal); z-index: 1; }
.tl-content { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px 18px; margin-left: 18px; border-left: 3px solid var(--teal); }
.tl-content .tc-decreto { font-size: 0.68rem; font-weight: 700; color: var(--teal-dark); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 4px; }
.tl-content .tc-titolo { font-size: 0.9rem; font-weight: 700; color: var(--blu); margin-bottom: 6px; }
.tl-content .tc-desc { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; }
.tl-content .tc-tag { display: inline-block; margin-top: 8px; font-size: 0.65rem; font-weight: 700; padding: 3px 10px; border-radius: 4px; }
.tc-tag.obbligatorio { background: #dcfce7; color: #166534; }
.tc-tag.modificato { background: #fef9c3; color: #854d0e; }
.tc-tag.abrogato { background: #fee2e2; color: #991b1b; }
.tc-tag.vigente { background: #e0f2fe; color: #0c4a6e; }
.tc-tag.stress { background: var(--teal-light); color: var(--teal-deep); }

.normativa-riepilogo { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px 24px; margin-top: 32px; border-left: 4px solid var(--teal); max-width: 860px; }
.nr-title { font-size: 0.85rem; font-weight: 800; color: var(--blu); margin-bottom: 10px; }
.nr-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.nr-item { text-align: center; padding: 12px; background: var(--grigio-bg); border-radius: 8px; }
.nr-item .ni-val { font-size: 1.4rem; font-weight: 900; color: var(--teal-dark); }
.nr-item .ni-lbl { font-size: 0.68rem; color: var(--grigio); }

/* =============================================
   CIRCOLO VIRTUOSO
   ============================================= */
#circolo { background: var(--bianco); }
.circolo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.circolo-steps { display: flex; flex-direction: column; gap: 0; }
.cs-step { display: flex; gap: 16px; position: relative; padding-bottom: 24px; }
.cs-step:last-child { padding-bottom: 0; }
.cs-step::after { content: ''; position: absolute; left: 19px; top: 40px; bottom: 0; width: 2px; background: var(--teal-mid); }
.cs-step:last-child::after { display: none; }
.cs-num { width: 40px; height: 40px; background: var(--teal); color: var(--bianco); border-radius: 10px; display: grid; place-items: center; font-weight: 900; font-size: 0.85rem; flex-shrink: 0; position: relative; z-index: 1; }
.cs-body { flex: 1; }
.cs-title { font-size: 0.92rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.cs-desc { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; }
.cs-tools { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 6px; }
.cs-tool { font-size: 0.65rem; background: var(--teal-light); color: var(--teal-deep); border: 1px solid var(--bordo); padding: 2px 8px; border-radius: 4px; font-weight: 600; }

.circolo-schema { background: var(--teal-light); border-radius: 16px; padding: 28px; }
.schema-title { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .08em; color: var(--teal-dark); font-weight: 700; margin-bottom: 20px; }
.schema-circle { display: flex; flex-direction: column; gap: 8px; }
.sc-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: var(--bianco); border-radius: 10px; border: 1px solid var(--bordo); transition: all .2s; }
.sc-item:hover { border-color: var(--teal); box-shadow: 0 2px 12px rgba(61,191,171,.15); }
.sc-icon { font-size: 1.3rem; flex-shrink: 0; }
.sc-info { flex: 1; }
.sc-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); }
.sc-sub { font-size: 0.7rem; color: var(--grigio); }
.sc-arrow { color: var(--teal); font-size: 1.2rem; flex-shrink: 0; }

/* =============================================
   METODOLOGIA
   ============================================= */
#metodo { background: var(--grigio-bg); }
.metodo-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 28px; }
.area-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; border-top: 3px solid var(--teal); transition: box-shadow .2s; }
.area-card:hover { box-shadow: 0 4px 20px rgba(61,191,171,.12); }
.ac-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: .08em; color: var(--teal-dark); font-weight: 700; margin-bottom: 6px; }
.ac-title { font-size: 0.95rem; font-weight: 800; color: var(--blu); margin-bottom: 10px; }
.ac-items { display: flex; flex-direction: column; gap: 4px; }
.ac-item { font-size: 0.78rem; color: var(--grigio); display: flex; align-items: center; gap: 6px; }
.ac-item::before { content: ''; width: 6px; height: 6px; background: var(--teal); border-radius: 50%; flex-shrink: 0; }

/* Indici statistici */
.indici-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.indice-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px; text-align: center; }
.ic-sigla { font-size: 1.4rem; font-weight: 900; color: var(--teal-dark); line-height: 1; margin-bottom: 6px; }
.ic-nome { font-size: 0.8rem; font-weight: 700; color: var(--blu); margin-bottom: 4px; }
.ic-desc { font-size: 0.7rem; color: var(--grigio); line-height: 1.5; }

/* =============================================
   QUESTIONARIO INTERATTIVO ANAC
   ============================================= */
#questionario { background: var(--bianco); }
.q-intro { background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 12px; padding: 20px 24px; margin-bottom: 28px; display: flex; gap: 16px; align-items: flex-start; border-left: 4px solid var(--teal); }
.q-intro-icon { font-size: 1.8rem; flex-shrink: 0; }
.q-intro-text h4 { font-size: 0.9rem; font-weight: 800; color: var(--teal-deep); margin-bottom: 4px; }
.q-intro-text p { font-size: 0.8rem; color: var(--testo); line-height: 1.6; }
.q-intro-text a { color: var(--teal-dark); font-weight: 600; }

.q-tabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px; }
.q-tab { padding: 7px 14px; border-radius: 6px; font-size: 0.78rem; font-weight: 600; cursor: pointer; border: 1.5px solid var(--bordo); color: var(--grigio); background: var(--bianco); transition: all .2s; }
.q-tab:hover { border-color: var(--teal); color: var(--teal-dark); }
.q-tab.active { background: var(--teal); color: var(--bianco); border-color: var(--teal); }

.q-panel { display: none; }
.q-panel.active { display: block; }

.q-sezione { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 12px; overflow: hidden; margin-bottom: 12px; }
.qs-header { padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: background .2s; }
.qs-header:hover { background: var(--teal-light); }
.qs-header.open { background: var(--teal-light); }
.qs-left { display: flex; align-items: center; gap: 10px; }
.qs-letter { width: 32px; height: 32px; background: var(--teal); color: var(--bianco); border-radius: 8px; display: grid; place-items: center; font-weight: 900; font-size: 0.85rem; flex-shrink: 0; }
.qs-name { font-size: 0.88rem; font-weight: 700; color: var(--blu); }
.qs-count { font-size: 0.68rem; color: var(--grigio); background: var(--bianco); padding: 2px 8px; border-radius: 4px; border: 1px solid var(--bordo); }
.qs-icon { color: var(--teal); font-size: 1rem; transition: transform .3s; }
.qs-header.open .qs-icon { transform: rotate(180deg); }
.qs-domande { display: none; padding: 0 18px 16px; }
.qs-header.open + .qs-domande { display: block; }
.domanda { padding: 10px 0; border-bottom: 1px solid var(--bordo); font-size: 0.82rem; color: var(--testo); display: flex; gap: 10px; align-items: flex-start; }
.domanda:last-child { border-bottom: none; }
.d-num { font-size: 0.72rem; font-weight: 700; color: var(--teal-dark); min-width: 28px; flex-shrink: 0; padding-top: 1px; }
.d-scala { margin-top: 6px; display: flex; gap: 4px; }
.d-scala span { width: 22px; height: 22px; border-radius: 4px; border: 1.5px solid var(--bordo); display: grid; place-items: center; font-size: 0.65rem; color: var(--grigio); cursor: pointer; transition: all .2s; }
.d-scala span:hover { background: var(--teal); color: var(--bianco); border-color: var(--teal); }
.d-scala span.negativo { border-color: #fca5a5; color: #ef4444; }
.d-scala span.negativo:hover { background: #ef4444; color: var(--bianco); }
.d-polarita { font-size: 0.62rem; color: #ef4444; font-weight: 600; margin-top: 4px; }

.q-footer { background: var(--teal-light); border: 1px solid var(--bordo); border-radius: 8px; padding: 14px 18px; margin-top: 16px; font-size: 0.78rem; color: var(--grigio); }
.q-footer strong { color: var(--teal-deep); }

/* =============================================
   OUTPUT / DELIVERABLE
   ============================================= */
#output { background: var(--grigio-bg); }
.output-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 28px; }
.output-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; text-align: center; transition: all .2s; }
.output-card:hover { box-shadow: 0 4px 20px rgba(61,191,171,.12); border-color: var(--teal); }
.oc-icon { font-size: 2rem; margin-bottom: 10px; }
.oc-title { font-size: 0.9rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.oc-desc { font-size: 0.78rem; color: var(--grigio); line-height: 1.6; }

/* Matrice interventi preview */
.matrice-preview { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; overflow-x: auto; }
.mp-title { font-size: 0.85rem; font-weight: 800; color: var(--blu); margin-bottom: 14px; }
.matrice-table { width: 100%; border-collapse: collapse; font-size: 0.72rem; }
.matrice-table th { padding: 6px 10px; text-align: center; font-weight: 700; font-size: 0.65rem; }
.matrice-table td { padding: 6px 10px; border: 1px solid var(--bordo); font-size: 0.72rem; }
.m-rosso { background: #fee2e2; }
.m-arancio { background: #fef3c7; }
.m-giallo { background: #fef9c3; }
.m-verde-chiaro { background: #d1fae5; }
.m-verde { background: #a7f3d0; }

/* =============================================
   CLIENTI
   ============================================= */
#clienti { background: var(--bianco); }
.clienti-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.cliente-card { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 10px; padding: 18px 14px; text-align: center; transition: all .2s; }
.cliente-card:hover { border-color: var(--teal); background: var(--teal-light); transform: translateY(-2px); box-shadow: 0 4px 16px rgba(61,191,171,.12); }
.cc-logo { display: inline-flex; align-items: center; justify-content: center; width: 56px; height: 56px; border-radius: 12px; color: #fff; font-size: 0.72rem; font-weight: 900; letter-spacing: .02em; margin: 0 auto 10px; line-height: 1.2; text-align: center; padding: 4px; }
.cc-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); margin-bottom: 4px; line-height: 1.3; }
.cc-tipo { font-size: 0.68rem; color: var(--grigio); line-height: 1.4; }

/* =============================================
   ECOSISTEMA
   ============================================= */
#ecosistema { background: var(--grigio-bg); }
.eco-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 12px; }
.eco-grid-2 { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; }
.eco-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; }
.eco-card:hover { border-color: var(--teal); box-shadow: 0 2px 12px rgba(61,191,171,.1); }
.eco-card.active { border-color: var(--accento); background: #fffbeb; }
.ec-icon { font-size: 1.3rem; margin-bottom: 6px; }
.ec-name { font-size: 0.8rem; font-weight: 700; color: var(--blu); margin-bottom: 3px; }
.ec-desc { font-size: 0.65rem; color: var(--grigio); }

/* =============================================
   CHI SIAMO
   ============================================= */
#chi-siamo { background: var(--bianco); }
.chi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
.at-card { background: var(--grigio-bg); border-radius: 12px; padding: 22px; border: 1px solid var(--bordo); }
.at-avatar { width: 44px; height: 44px; background: var(--teal); border-radius: 10px; display: grid; place-items: center; font-weight: 900; color: var(--bianco); margin-bottom: 12px; font-size: 0.9rem; }
.at-name { font-size: 0.95rem; font-weight: 800; color: var(--blu); margin-bottom: 3px; }
.at-ruolo { font-size: 0.72rem; color: var(--grigio); margin-bottom: 10px; }
.at-desc { font-size: 0.8rem; color: var(--testo); line-height: 1.7; margin-bottom: 12px; }
.at-links { display: flex; gap: 8px; flex-wrap: wrap; }
.at-links a { font-size: 0.72rem; color: var(--teal-dark); font-weight: 600; border: 1px solid var(--bordo); padding: 4px 10px; border-radius: 6px; transition: all .2s; }
.at-links a:hover { background: var(--teal); color: var(--bianco); border-color: var(--teal); }
.anac-box { background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 12px; padding: 20px; }
.anac-box h4 { font-size: 0.85rem; font-weight: 800; color: var(--teal-deep); margin-bottom: 8px; }
.anac-box p { font-size: 0.8rem; color: var(--testo); line-height: 1.6; margin-bottom: 10px; }
.anac-link { font-size: 0.78rem; color: var(--teal-dark); font-weight: 700; border: 1.5px solid var(--teal); padding: 8px 16px; border-radius: 8px; display: inline-block; transition: all .2s; }
.anac-link:hover { background: var(--teal); color: var(--bianco); }

/* =============================================
   CTA FINALE
   ============================================= */
.cta-finale { background: linear-gradient(135deg, var(--teal-deep) 0%, var(--teal-dark) 100%); color: var(--bianco); padding: 64px 20px; text-align: center; }
.cta-finale h2 { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; margin-bottom: 10px; }
.cta-finale p { color: rgba(255,255,255,.7); margin-bottom: 28px; max-width: 500px; margin-left: auto; margin-right: auto; }
.cta-btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.btn-cta-white { background: var(--bianco); color: var(--teal-deep); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; display: inline-block; transition: all .2s; }
.btn-cta-white:hover { background: #a7f3d0; }
.btn-cta-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.3); display: inline-block; transition: all .2s; }
.btn-cta-outline:hover { border-color: rgba(255,255,255,.7); }

/* =============================================
   FOOTER
   ============================================= */
.site-footer { background: #0d2420; color: rgba(255,255,255,.7); padding: 48px 20px 24px; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 32px; }
.footer-brand .brand-name { font-size: 1rem; font-weight: 800; color: var(--bianco); margin-bottom: 8px; }
.footer-brand p { font-size: 0.78rem; line-height: 1.6; margin-bottom: 8px; }
.footer-brand .brand-legal { font-size: 0.68rem; color: rgba(255,255,255,.3); }
.footer-col h4 { font-size: 0.72rem; font-weight: 700; color: var(--bianco); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 7px; }
.footer-col ul li a { font-size: 0.8rem; color: rgba(255,255,255,.55); transition: color .2s; }
.footer-col ul li a:hover { color: var(--teal); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,.1); padding-top: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
.footer-bottom .copy { font-size: 0.7rem; color: rgba(255,255,255,.3); }
.footer-legal { display: flex; gap: 16px; }
.footer-legal a { font-size: 0.7rem; color: rgba(255,255,255,.3); transition: color .2s; }
.footer-legal a:hover { color: rgba(255,255,255,.7); }

/* =============================================
   RESPONSIVE
   ============================================= */
@media (max-width: 960px) {
  .hero .inner { grid-template-columns: 1fr; }
  .hero-card { display: none; }
  .circolo-grid { grid-template-columns: 1fr; }
  .metodo-grid { grid-template-columns: 1fr; }
  .indici-grid { grid-template-columns: 1fr 1fr; }
  .output-grid { grid-template-columns: 1fr 1fr; }
  .eco-grid { grid-template-columns: repeat(3, 1fr); }
  .eco-grid-2 { grid-template-columns: repeat(2, 1fr); }
  .chi-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .navbar-links { display: none !important; }
  .hamburger { display: flex; }
  .topbar { display: none; }
  .timeline::before { left: 80px; }
  .timeline-item { grid-template-columns: 70px 1fr; }
  .clienti-grid { grid-template-columns: repeat(3, 1fr); }
  .footer-grid { grid-template-columns: 1fr 1fr; gap: 24px; }
  .output-grid { grid-template-columns: 1fr; }
  .nr-grid { grid-template-columns: 1fr; }
}
@media (max-width: 480px) {
  .eco-grid { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr; }
  .clienti-grid { grid-template-columns: 1fr 1fr; }
  .indici-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<!-- TOPBAR -->
<div class="topbar">
  <div class="inner">
    <a href="https://andreatroisi.it" class="topbar-personal">andreatroisi.it</a>
    <a href="https://www.troisiricerche.net">troisiricerche.net</a>
    <a href="https://www.t-index.it">TR-Index</a>
    <a href="https://www.mappaturadellecompetenze.it">Mappatura delle Competenze</a>
    <a href="https://www.registrodellecompetenze.it">Registro delle Competenze</a>
    <a href="https://www.customerpa.it">CustomerPA</a>
    <a href="https://www.benessereorganizzativo.it" class="topbar-active">BenessereOrg.</a>
    <a href="https://www.troisiformazione.it">Formazione</a>
    <a href="https://www.tiplive.it">TIP</a>
    <a href="https://www.troisiinsight.it">TroisiInsight</a>
    <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
    <a href="https://www.dibattito-pubblico.it">Dibattito Pubblico</a>
    <a href="https://www.voiceinhub.it">VoiceInHub</a>
    <a href="https://www.governancefinanziaria.it">Governance Fin.</a>
    <a href="https://www.consulenzainternazionalizzazione.it">Internazionalizzazione</a>
    <a href="https://www.benesseredigitalegiovani.it">BDG</a>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="#" class="navbar-brand">
      <div>
        <div class="brand-logo">Benessere<span>Organizzativo</span></div>
        <span class="brand-sub">Metodo ANAC · PA e Aziende · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="#normativa">Normativa</a>
      <a href="#circolo">Metodo</a>
      <a href="#questionario">Questionario ANAC</a>
      <a href="#output">Output</a>
      <a href="#clienti">Clienti</a>
      <a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a>
      <a href="#chi-siamo">Chi siamo</a>
      <a href="mailto:benessere@troisiricerche.it" class="btn-contatti">Scrivici</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi preventivo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
<div class="mobile-menu" id="mobile-menu">
  <a href="#normativa" onclick="closeMobileMenu()">Normativa</a>
  <a href="#circolo" onclick="closeMobileMenu()">Metodo</a>
  <a href="#questionario" onclick="closeMobileMenu()">Questionario ANAC</a>
  <a href="#output" onclick="closeMobileMenu()">Output</a>
  <a href="#clienti" onclick="closeMobileMenu()">Clienti</a>
  <a href="<?php echo home_url('/approfondimenti'); ?>" onclick="closeMobileMenu()">Approfondimenti</a>
  <a href="#chi-siamo" onclick="closeMobileMenu()">Chi siamo</a>
  <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo" onclick="closeMobileMenu()">Richiedi preventivo ↗</a>
</div>

<!-- HERO -->
<section class="hero">
  <div class="inner">
    <div>
      <div class="hero-badge">🏛️ Per la PA è un obbligo di legge · Per le aziende è una leva strategica</div>
      <h1>Benessere Organizzativo: <em>obbligo normativo</em>,<br>stress lavoro correlato e DVR.</h1>
      <p class="hero-sub">Metodo Troisi Ricerche · Metodologia conforme alle linee guida ANAC · Difendibile davanti all'Ispettorato del Lavoro · Integrabile nel DVR</p>
      <p class="hero-desc">Misuriamo il <strong>benessere organizzativo</strong>, lo <strong>stress lavoro-correlato</strong> e l'<strong>employee wellbeing</strong> nella PA e nelle aziende private. La <strong>valutazione SLC è obbligatoria</strong> ai sensi del D.Lgs. 81/2008. Per la PA il D.Lgs. 150/2009 impone indagini annuali con metodo validato. Il Metodo Troisi è <strong>coerente con le indicazioni ANAC</strong>, integrabile nel DVR e valido ai fini della Relazione sulla Performance.</p>
      <div class="hero-cta">
        <a href="#questionario" class="btn-hero-primary">📋 Esplora il questionario ANAC</a>
        <a href="#circolo" class="btn-hero-outline">Scopri il metodo →</a>
      </div>
      <div class="hero-badges">
        <span class="hb">D.Lgs. 150/2009 · PA</span>
        <span class="hb">D.Lgs. 81/2008 · Tutti</span>
        <span class="hb">Stress lavoro-correlato</span>
        <span class="hb">Employee Wellbeing</span>
        <span class="hb">Clima organizzativo</span>
        <span class="hb">ISO 9001 TÜV</span>
      </div>
    </div>
    <div class="hero-card">
      <div class="hc-title">Dashboard B.O. · Esempio Azienda</div>
      <div class="bo-score">7.4</div>
      <div class="bo-label">Indice di Benessere Organizzativo · scala 1–10</div>
      <div class="bo-dims">
        <div class="bo-dim"><span class="bd-label">Stress lavoro-correlato</span><div class="bd-bar"><div class="bd-fill" style="width:78%"></div></div><span class="bd-val">7.8</span></div>
        <div class="bo-dim"><span class="bd-label">Area strutturale</span><div class="bd-bar"><div class="bd-fill" style="width:72%"></div></div><span class="bd-val">7.2</span></div>
        <div class="bo-dim"><span class="bd-label">Area interpersonale</span><div class="bd-bar"><div class="bd-fill" style="width:80%"></div></div><span class="bd-val">8.0</span></div>
        <div class="bo-dim"><span class="bd-label">Area individuale</span><div class="bd-bar"><div class="bd-fill" style="width:68%"></div></div><span class="bd-val">6.8</span></div>
      </div>
      <div class="hc-anac">Elaborazione Troisi Ricerche · <strong>Modello ANAC</strong> · 17 sezioni · 85 domande</div>
    </div>
  </div>
</section>


<?php get_template_part('inc/tr-ultime'); ?>

<!-- RIQUADRO CHECKER SEI IN REGOLA BO -->
<section style="padding: 0 20px; max-width: 1100px; margin: -24px auto 0;">
  <a href="/sei-in-regola-bo" style="
    display: flex; gap: 16px; align-items: center;
    background: linear-gradient(135deg, #e8f7f4, #f0fdf4);
    border: 2px solid #3dbfab; border-radius: 14px;
    padding: 20px 24px; text-decoration: none; cursor: pointer;
    transition: all .2s; box-shadow: 0 4px 16px rgba(61,191,171,.15);
    margin-bottom: 16px;
  ">
    <div style="font-size: 2rem; flex-shrink: 0;">🔍</div>
    <div style="flex: 1;">
      <div style="font-size: .7rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: #2a9d8a; margin-bottom: 4px;">⚠️ Strumento gratuito · PA e Aziende Private</div>
      <div style="font-size: 1.05rem; font-weight: 800; color: #1a7a6b; margin-bottom: 4px;">Il tuo ente è in regola con il Benessere Organizzativo?</div>
      <div style="font-size: .84rem; color: #6b7280; line-height: 1.5;">Scoprilo in 8 domande — D.Lgs. 81/2008 · D.Lgs. 150/2009 · Modello ANAC. Report gratuito con il livello di compliance e le raccomandazioni operative.</div>
    </div>
    <div style="flex-shrink: 0; background: #1a7a6b; color: #fff; font-weight: 700; font-size: .85rem; padding: 10px 18px; border-radius: 8px; white-space: nowrap;">
      Verifica ora →
    </div>
  </a>
</section>
<!-- FINE RIQUADRO CHECKER -->

<!-- NORMATIVA -->
<section id="normativa">
  <div class="section-inner">
    <div class="section-label">Quadro normativo</div>
    <div class="section-title">Benessere organizzativo: <em>obbligo normativo</em> o scelta?</div>
    <p class="section-desc"><strong style="color:var(--teal-deep);">Per la PA è un obbligo di legge.</strong> Il D.Lgs. 150/2009, art. 14 c.5, impone indagini annuali sul benessere organizzativo con metodologia validata. <strong style="color:var(--teal-deep);">Per tutte le organizzazioni (PA e privati), il D.Lgs. 81/2008, art. 28, rende obbligatoria la valutazione dello stress lavoro-correlato nel DVR.</strong> Un DVR senza la sezione SLC è incompleto e non difendibile davanti all'Ispettorato del Lavoro. Il Metodo Troisi è <strong>metodologia conforme alle linee guida INAIL</strong>, coerente con le indicazioni ANAC e valido ai fini della Relazione sulla Performance e del PIAO.</p>
    <div class="timeline">
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2008</div><div class="tipo">Sicurezza</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.Lgs. 9 aprile 2008 n. 81 — Testo Unico Sicurezza</div>
          <div class="tc-titolo">Obbligo di valutazione dello stress lavoro-correlato</div>
          <div class="tc-desc">Introduce l'obbligo per tutti i datori di lavoro (pubblici e privati) di valutare il rischio da stress lavoro-correlato nell'ambito della valutazione dei rischi (DVR). L'art. 28 prevede che la valutazione riguardi tutti i rischi, incluso lo stress. Recepisce la direttiva quadro europea 89/391/CEE.</div>
          <span class="tc-tag stress">Stress lavoro-correlato</span>
          <span class="tc-tag obbligatorio">Pubblico e privato</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2009</div><div class="tipo">PA · Riforma</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.Lgs. 27 ottobre 2009 n. 150 — Riforma Brunetta</div>
          <div class="tc-titolo">Obbligo indagini annuali sul Benessere Organizzativo nella PA</div>
          <div class="tc-desc">Art. 14, comma 5: gli Organismi Indipendenti di Valutazione (OIV) devono curare annualmente indagini sul personale dipendente per rilevare: il livello di benessere organizzativo, il grado di condivisione del sistema di valutazione e la valutazione del superiore gerarchico. I modelli vengono predisposti da ANAC (allora CiVIT).</div>
          <span class="tc-tag obbligatorio">Obbligo PA · Art. 14 c.5</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2010</div><div class="tipo">Accordo</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">Accordo Europeo 8 ottobre 2004 — Recepimento Italia 2010</div>
          <div class="tc-titolo">Accordo sullo stress lavoro-correlato nelle organizzazioni</div>
          <div class="tc-desc">Recepito in Italia con accordo interconfederale del 9 giugno 2008 e successivamente operativo. Fornisce il quadro definitorio e metodologico per la valutazione dello stress lavoro-correlato, che deve essere inclusa nel DVR entro il 31 dicembre 2010 (circolare del Ministero del Lavoro).</div>
          <span class="tc-tag vigente">Privato · Accordo quadro</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2013</div><div class="tipo">Trasparenza</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.Lgs. 14 marzo 2013 n. 33 — Trasparenza PA</div>
          <div class="tc-titolo">Obbligo di pubblicazione dei risultati sul sito istituzionale</div>
          <div class="tc-desc">Art. 20, comma 3 (poi abrogato): le amministrazioni dovevano pubblicare i risultati delle indagini sul benessere organizzativo sui propri siti istituzionali e trasmetterli ad ANAC. In questo anno viene anche approvato il modello ANAC di questionario in 17 sezioni e 85 domande, tuttora il riferimento nazionale.</div>
          <span class="tc-tag modificato">Pubblicazione poi abrogata</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2016</div><div class="tipo">Modifica</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.Lgs. 25 maggio 2016 n. 97 — Riforma FOIA</div>
          <div class="tc-titolo">Abrogazione dell'obbligo di pubblicazione dei risultati</div>
          <div class="tc-desc">Abroga l'art. 20 c.3 del D.Lgs. 33/2013: le PA non sono più obbligate a pubblicare online i risultati delle indagini BO. L'obbligo di effettuare le indagini rimane intatto. I dati rimangono a uso interno e vengono trasmessi agli OIV per la valutazione della performance. La riservatezza favorisce una maggiore sincerità nelle risposte.</div>
          <span class="tc-tag abrogato">Pubblicazione abrogata</span>
          <span class="tc-tag vigente">Indagine ancora obbligatoria</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2016</div><div class="tipo">OIV</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.P.R. 9 maggio 2016 n. 105 — Regolamento OIV</div>
          <div class="tc-titolo">Riforma degli Organismi Indipendenti di Valutazione</div>
          <div class="tc-desc">Ridefinisce il ruolo degli OIV e riorganizza le funzioni in materia di performance. Contestualmente, le funzioni di ANAC in materia di benessere organizzativo vengono trasferite al Dipartimento della Funzione Pubblica, che diventa il nuovo referente istituzionale per i modelli di indagine.</div>
          <span class="tc-tag modificato">Trasferimento al DFP</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2017</div><div class="tipo">Performance</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.Lgs. 25 maggio 2017 n. 74 — Riforma performance PA</div>
          <div class="tc-titolo">Benessere organizzativo come fattore abilitante della performance</div>
          <div class="tc-desc">Modifica il D.Lgs. 150/2009 integrando il benessere organizzativo nel sistema di misurazione e valutazione della performance. La rilevazione del BO diventa un input essenziale per la valutazione partecipativa. Il BO è riconosciuto come leva per l'incremento dell'efficienza e della qualità dei servizi pubblici.</div>
          <span class="tc-tag vigente">Performance e BO integrati</span>
        </div>
      </div>
      <div class="timeline-item">
        <div class="tl-anno"><div class="anno">2022</div><div class="tipo">PIAO</div><div class="tl-dot"></div></div>
        <div class="tl-content">
          <div class="tc-decreto">D.P.R. 24 giugno 2022 n. 81 — Piano Integrato PIAO</div>
          <div class="tc-titolo">Il BO entra nel Piano Integrato di Attività e Organizzazione</div>
          <div class="tc-desc">Il Piano Integrato di Attività e Organizzazione (PIAO) unifica in un unico documento strategico diversi piani della PA, inclusi performance, anticorruzione e gestione del personale. La rilevazione del benessere organizzativo deve essere coerente con gli obiettivi del PIAO e rendicontata agli OIV. Tutte le PA con più di 50 dipendenti sono soggette all'obbligo.</div>
          <span class="tc-tag obbligatorio">PIAO · PA > 50 dipendenti</span>
        </div>
      </div>
    </div>
    <div class="normativa-riepilogo">
      <div class="nr-title">Il quadro in sintesi · Stato attuale dell'obbligo</div>
      <div class="nr-grid">
        <div class="nr-item"><div class="ni-val">PA</div><div class="ni-lbl">Obbligo D.Lgs. 150/2009 · Art. 14 c.5 · OIV · PIAO</div></div>
        <div class="nr-item"><div class="ni-val">Privato</div><div class="ni-lbl">Stress SLC · D.Lgs. 81/2008 · Art. 28 DVR</div></div>
        <div class="nr-item"><div class="ni-val">Modello</div><div class="ni-lbl">ANAC · 17 sezioni · 85 domande · Dipartimento Funzione Pubblica</div></div>
      </div>
    </div>
  </div>
</section>

<!-- CIRCOLO VIRTUOSO -->
<section id="circolo">
  <div class="section-inner">
    <div class="section-label">Metodo Troisi Ricerche</div>
    <div class="section-title">Il <em>circolo virtuoso</em> per il capitale umano</div>
    <p class="section-desc">Non una semplice indagine, ma un percorso integrato in 5 fasi che trasforma i dati del benessere organizzativo in azioni concrete di miglioramento.</p>
    <div class="circolo-grid">
      <div class="circolo-steps">
        <div class="cs-step">
          <div class="cs-num">01</div>
          <div class="cs-body">
            <div class="cs-title">Misurazione del Benessere Organizzativo</div>
            <p class="cs-desc">Questionario anonimo CAWI/CATI strutturato sulle 17 sezioni ANAC. Approccio multidisciplinare centrato sulla persona. Scala 1–6, analisi percezioni e attese, sistema di controllo delle risposte.</p>
            <div class="cs-tools"><span class="cs-tool">CAWI</span><span class="cs-tool">CATI</span><span class="cs-tool">Modello ANAC</span><span class="cs-tool">85 domande</span></div>
          </div>
        </div>
        <div class="cs-step">
          <div class="cs-num">02</div>
          <div class="cs-body">
            <div class="cs-title">Mappatura delle competenze</div>
            <p class="cs-desc">Interviste CAPI a tutto il personale per mappare conoscenze, competenze e capacità. Autovalutazione + valutazione oggettiva. Identificazione dei fabbisogni formativi.</p>
            <div class="cs-tools"><span class="cs-tool">CAPI</span><span class="cs-tool">Mappatura delle Competenze</span><span class="cs-tool">Fabbisogni formativi</span></div>
          </div>
        </div>
        <div class="cs-step">
          <div class="cs-num">03</div>
          <div class="cs-body">
            <div class="cs-title">Piano degli interventi formativi</div>
            <p class="cs-desc">Piano strutturato per formazione continua, formazione orientata al benessere e formazione manageriale comportamentale. Dettaglio per destinatari, obiettivi, tempistiche e risultati attesi.</p>
            <div class="cs-tools"><span class="cs-tool">Formazione continua</span><span class="cs-tool">Manageriale</span></div>
          </div>
        </div>
        <div class="cs-step">
          <div class="cs-num">04</div>
          <div class="cs-body">
            <div class="cs-title">Registro Digitale delle Competenze</div>
            <p class="cs-desc">Portale responsive per archiviazione, validazione e certificazione degli apprendimenti. Datawarehouse a disposizione di dipendenti e azienda. Conforme agli standard europei EQF.</p>
            <div class="cs-tools"><span class="cs-tool">Registro delle Competenze</span><span class="cs-tool">EQF</span><span class="cs-tool">D.Lgs. 13/2013</span></div>
          </div>
        </div>
        <div class="cs-step">
          <div class="cs-num">05</div>
          <div class="cs-body">
            <div class="cs-title">Performance Management</div>
            <p class="cs-desc">Integrazione della formazione e del BO nel sistema di valutazione della performance individuale. MBO, obiettivi comportamentali, CRM e indicatori di servizio. Chiude il circolo virtuoso.</p>
            <div class="cs-tools"><span class="cs-tool">MBO</span><span class="cs-tool">OIV</span><span class="cs-tool">PIAO</span></div>
          </div>
        </div>
      </div>
      <div class="circolo-schema">
        <div class="schema-title">Il percorso integrato</div>
        <div class="schema-circle">
          <div class="sc-item"><span class="sc-icon">🔍</span><div class="sc-info"><div class="sc-name">Misurazione BO</div><div class="sc-sub">Questionario ANAC · 17 sezioni</div></div><span class="sc-arrow">↓</span></div>
          <div class="sc-item"><span class="sc-icon">🗺️</span><div class="sc-info"><div class="sc-name">Mappatura competenze</div><div class="sc-sub">Mappatura delle Competenze · CAPI</div></div><span class="sc-arrow">↓</span></div>
          <div class="sc-item"><span class="sc-icon">📚</span><div class="sc-info"><div class="sc-name">Piano formativo</div><div class="sc-sub">Continuo · Benessere · Manageriale</div></div><span class="sc-arrow">↓</span></div>
          <div class="sc-item"><span class="sc-icon">📜</span><div class="sc-info"><div class="sc-name">Registro digitale</div><div class="sc-sub">Registro delle Competenze · EQF · D.Lgs. 13/2013</div></div><span class="sc-arrow">↓</span></div>
          <div class="sc-item"><span class="sc-icon">🏆</span><div class="sc-info"><div class="sc-name">Performance Management</div><div class="sc-sub">MBO · OIV · PIAO</div></div><span class="sc-arrow">↺</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- METODOLOGIA -->
<section id="metodo">
  <div class="section-inner">
    <div class="section-label">Aree di indagine</div>
    <div class="section-title">La struttura del <em>questionario</em></div>
    <p class="section-desc">Il questionario si articola in 4 macro-aree, ognuna con dimensioni e item specifici. L'analisi per percezioni e attese (scala 1–6) consente di identificare i gap tra ciò che è percepito e ciò che è atteso.</p>
    <div class="metodo-grid">
      <div class="area-card">
        <div class="ac-label">Macro-area A · Stress lavoro-correlato</div>
        <div class="ac-title">Benessere al lavoro</div>
        <div class="ac-items">
          <div class="ac-item">Carico lavorativo e work-life balance</div>
          <div class="ac-item">Responsabilità e autonomia decisionale</div>
          <div class="ac-item">Discriminazioni di genere, età, etnia</div>
          <div class="ac-item">Equità organizzativa percepita</div>
          <div class="ac-item">Contesto e condizioni di lavoro</div>
          <div class="ac-item">Gestione del cambiamento organizzativo</div>
        </div>
      </div>
      <div class="area-card">
        <div class="ac-label">Macro-area B · Strutturale</div>
        <div class="ac-title">Area strutturale</div>
        <div class="ac-items">
          <div class="ac-item">Ambiente fisico (salubrità ed ergonomia)</div>
          <div class="ac-item">Applicazione normativa sulla sicurezza</div>
          <div class="ac-item">Disponibilità e fluidità delle informazioni</div>
          <div class="ac-item">Chiarezza delle funzioni e dei ruoli</div>
          <div class="ac-item">Sistema di riconoscimenti e incentivi</div>
          <div class="ac-item">Progressioni di carriera e sviluppo professionale</div>
        </div>
      </div>
      <div class="area-card">
        <div class="ac-label">Macro-area C · Interpersonale</div>
        <div class="ac-title">Area interpersonale</div>
        <div class="ac-items">
          <div class="ac-item">Qualità del rapporto con il management</div>
          <div class="ac-item">Qualità dei rapporti con il superiore gerarchico</div>
          <div class="ac-item">Qualità dei rapporti con i colleghi</div>
          <div class="ac-item">Coesione del gruppo di lavoro</div>
          <div class="ac-item">Collaborazione e dinamiche comunicative</div>
          <div class="ac-item">Stili di leadership e soddisfazione relazionale</div>
        </div>
      </div>
      <div class="area-card">
        <div class="ac-label">Macro-area D · Individuale</div>
        <div class="ac-title">Area individuale</div>
        <div class="ac-items">
          <div class="ac-item">Senso di appartenenza all'organizzazione</div>
          <div class="ac-item">Soddisfazione relativa alla propria funzione</div>
          <div class="ac-item">Motivazione intrinseca ed estrinseca</div>
          <div class="ac-item">Valori dichiarati, commitment e percezione</div>
        </div>
      </div>
    </div>
    <div class="section-label" style="margin-top:32px;">Gli indici elaborati</div>
    <div class="indici-grid">
      <div class="indice-card"><div class="ic-sigla">PM</div><div class="ic-nome">Punteggio Medio</div><div class="ic-desc">Percezione complessiva delle condizioni di lavoro in azienda</div></div>
      <div class="indice-card"><div class="ic-sigla">ESI</div><div class="ic-nome">Employee Satisfaction Index</div><div class="ic-desc">Come le percezioni agiscono sul BO in funzione dell'importanza relativa di ogni dimensione</div></div>
      <div class="indice-card"><div class="ic-sigla">OVR</div><div class="ic-nome">Overall</div><div class="ic-desc">Percentuale di chi ha espresso parere negativo vs positivo per ogni dimensione monitorata</div></div>
      <div class="indice-card"><div class="ic-sigla">NPS</div><div class="ic-nome">Net Promoter Score</div><div class="ic-desc">Capacità attrattiva di nuovi talenti: propensione a consigliare l'azienda a familiari/amici</div></div>
    </div>
  </div>
</section>

<!-- QUESTIONARIO INTERATTIVO ANAC -->
<section id="questionario">
  <div class="section-inner">
    <div class="section-label">Strumento interattivo</div>
    <div class="section-title">Il questionario <em>ANAC</em> — 17 sezioni · 85 domande</div>
    <p class="section-desc">Esplora il questionario strutturato sul modello ANAC, utilizzato da Troisi Ricerche per le indagini di Benessere Organizzativo. Scala di risposta 1–6 (1–3 = disagio, 4–6 = benessere). Le domande con ⚠ hanno polarità negativa.</p>

    <div class="q-intro">
      <div class="q-intro-icon">🏛️</div>
      <div class="q-intro-text">
        <h4>Metodologia validata come conforme agli standard del Dipartimento della Funzione Pubblica</h4>
        <p>Il questionario e la metodologia di Troisi Ricerche sono stati riconosciuti come conformi agli standard per le indagini sul Benessere Organizzativo nella PA, ai sensi dell'art. 14, c.5 del D.Lgs. 150/2009. Le funzioni di indirizzo sono oggi in capo al Dipartimento della Funzione Pubblica, che ha recepito i modelli originariamente sviluppati da ANAC (allora CiVIT). Il nostro approccio è strutturato in coerenza con questi standard e applicato con piena efficacia nelle indagini di <strong>climate survey</strong>, <strong>employee wellbeing</strong> e <strong>performance organizzativa</strong>. <a href="https://www.anticorruzione.it" target="_blank">Riferimento normativo ↗</a></p>
      </div>
    </div>

    <div class="q-tabs">
      <div class="q-tab active" onclick="switchTab('bo')">Benessere Organizzativo (A–I)</div>
      <div class="q-tab" onclick="switchTab('condivisione')">Condivisione sistema (L–N)</div>
      <div class="q-tab" onclick="switchTab('superiore')">Valutazione superiore (O–P)</div>
    </div>

    <!-- PANEL 1: Benessere Organizzativo -->
    <div class="q-panel active" id="panel-bo">
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">A</div><div class="qs-name">Sicurezza, salute e stress lavoro-correlato</div><span class="qs-count">10 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">A.01</span><div>Nel mio lavoro mi sento fisicamente sicuro/a e protetto/a dai rischi per la salute.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">A.02</span><div>L'organizzazione adotta misure efficaci per prevenire gli infortuni e le malattie professionali.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">A.03</span><div>Il mio carico di lavoro è gestibile e sostenibile nel tempo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">A.04</span><div>⚠ Spesso mi sento esaurito/a emotivamente a causa del lavoro.<div class="d-scala"><span class="negativo">1</span><span class="negativo">2</span><span class="negativo">3</span><span>4</span><span>5</span><span>6</span></div><div class="d-polarita">⚠ Polarità negativa: punteggio basso = benessere</div></div></div>
          <div class="domanda"><span class="d-num">A.05</span><div>⚠ Il ritmo di lavoro richiesto è così elevato da rendere difficile il recupero tra un'attività e l'altra.<div class="d-scala"><span class="negativo">1</span><span class="negativo">2</span><span class="negativo">3</span><span>4</span><span>5</span><span>6</span></div><div class="d-polarita">⚠ Polarità negativa</div></div></div>
          <div class="domanda"><span class="d-num">A.06</span><div>Riesco a conciliare adeguatamente le esigenze lavorative con quelle personali e familiari.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">A.07</span><div>Ho chiarezza sui miei compiti e sulle responsabilità che mi sono state assegnate.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">A.08</span><div>Dispongo dell'autonomia necessaria per svolgere il mio lavoro in modo efficace.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">A.09</span><div>⚠ Nei momenti di difficoltà mi sento solo/a e senza supporto da parte dell'organizzazione.<div class="d-scala"><span class="negativo">1</span><span class="negativo">2</span><span class="negativo">3</span><span>4</span><span>5</span><span>6</span></div><div class="d-polarita">⚠ Polarità negativa</div></div></div>
          <div class="domanda"><span class="d-num">A.10</span><div>L'introduzione del lavoro agile/smart-working ha migliorato il mio equilibrio vita-lavoro.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">B</div><div class="qs-name">Le discriminazioni</div><span class="qs-count">7 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">B.01</span><div>Nella mia organizzazione tutti i lavoratori sono trattati con uguale rispetto, a prescindere dal genere.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">B.02</span><div>Non vi sono differenze di trattamento basate sull'età dei lavoratori.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">B.03</span><div>L'organizzazione garantisce pari opportunità di sviluppo professionale indipendentemente dall'origine etnica o dalla nazionalità.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">B.04</span><div>⚠ Ho assistito o sono stato/a vittima di episodi di mobbing o di comportamenti discriminatori.<div class="d-scala"><span class="negativo">1</span><span class="negativo">2</span><span class="negativo">3</span><span>4</span><span>5</span><span>6</span></div><div class="d-polarita">⚠ Polarità negativa</div></div></div>
          <div class="domanda"><span class="d-num">B.05</span><div>Le opportunità di formazione sono distribuite equamente tra tutti i lavoratori.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">B.06</span><div>I criteri di valutazione della performance sono applicati in modo equo e trasparente.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">B.07</span><div>⚠ Chi segnala problemi o disagi in questa organizzazione rischia conseguenze negative.<div class="d-scala"><span class="negativo">1</span><span class="negativo">2</span><span class="negativo">3</span><span>4</span><span>5</span><span>6</span></div><div class="d-polarita">⚠ Polarità negativa</div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">C</div><div class="qs-name">L'equità nella mia organizzazione</div><span class="qs-count">6 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">C.01</span><div>I criteri per l'attribuzione degli incarichi e delle responsabilità sono chiari e trasparenti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">C.02</span><div>Le retribuzioni e i premi sono distribuiti in modo equo rispetto al contributo effettivo di ciascuno.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">C.03</span><div>Le promozioni e gli avanzamenti di carriera avvengono sulla base del merito.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">C.04</span><div>Sento che il mio impegno e i miei risultati vengono adeguatamente riconosciuti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">C.05</span><div>Le regole organizzative sono applicate in modo coerente e uniforme a tutti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">C.06</span><div>Percepisco un clima di sostanziale equità nei processi decisionali che mi riguardano.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">D</div><div class="qs-name">Carriera e sviluppo professionale</div><span class="qs-count">6 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">D.01</span><div>Ho chiaro quali sono le possibilità di crescita professionale nella mia organizzazione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">D.02</span><div>La formazione offerta dall'organizzazione è adeguata alle mie esigenze di sviluppo professionale.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">D.03</span><div>Ho avuto concrete opportunità di miglioramento professionale negli ultimi 2 anni.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">D.04</span><div>I percorsi di carriera sono definiti in modo chiaro e accessibile a tutti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">D.05</span><div>L'organizzazione investe effettivamente nello sviluppo delle competenze del personale.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">D.06</span><div>Mi sento supportato/a nel raggiungimento dei miei obiettivi di crescita professionale.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">E</div><div class="qs-name">Il mio lavoro</div><span class="qs-count">6 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">E.01</span><div>Il mio lavoro mi permette di esprimere le mie competenze e capacità.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">E.02</span><div>Trovo significato e utilità nelle attività che svolgo quotidianamente.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">E.03</span><div>Posso proporre idee e miglioramenti nel mio ambito di lavoro.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">E.04</span><div>Dispongo degli strumenti e delle risorse necessarie per svolgere bene il mio lavoro.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">E.05</span><div>Il mio lavoro mi consente di raggiungere un buon equilibrio tra vita professionale e personale.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">E.06</span><div>Sono soddisfatto/a complessivamente del lavoro che svolgo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">F</div><div class="qs-name">I miei colleghi</div><span class="qs-count">5 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">F.01</span><div>I rapporti con i colleghi sono caratterizzati da rispetto e collaborazione reciproca.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">F.02</span><div>Posso contare sul supporto dei colleghi quando ne ho bisogno.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">F.03</span><div>Nel mio gruppo di lavoro esiste un clima di fiducia e coesione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">F.04</span><div>Le comunicazioni interne tra colleghi sono efficaci e tempestive.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">F.05</span><div>I conflitti tra colleghi vengono gestiti in modo costruttivo dall'organizzazione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">G</div><div class="qs-name">Il contesto del mio lavoro</div><span class="qs-count">6 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">G.01</span><div>L'ambiente fisico in cui lavoro è confortevole, pulito e adeguatamente attrezzato.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">G.02</span><div>Le norme sulla sicurezza sul lavoro sono rispettate e applicate efficacemente.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">G.03</span><div>Le informazioni necessarie per svolgere il lavoro circolano in modo adeguato e tempestivo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">G.04</span><div>I processi organizzativi sono efficienti e non generano inutili ostacoli burocratici.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">G.05</span><div>Le innovazioni tecnologiche vengono introdotte in modo graduale e supportato.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">G.06</span><div>L'organizzazione gestisce i cambiamenti in modo trasparente e partecipativo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">H</div><div class="qs-name">Il senso di appartenenza</div><span class="qs-count">5 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">H.01</span><div>Mi sento parte integrante di questa organizzazione e ne condivido i valori fondamentali.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">H.02</span><div>Sono orgoglioso/a di lavorare in questa organizzazione e di rappresentarla.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">H.03</span><div>Gli obiettivi strategici dell'organizzazione mi sembrano condivisibili e motivanti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">H.04</span><div>Mi identifico con la missione e i valori dichiarati della mia organizzazione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">H.05</span><div>⚠ Se potessi, cercherei attivamente un altro impiego presso una diversa organizzazione.<div class="d-scala"><span class="negativo">1</span><span class="negativo">2</span><span class="negativo">3</span><span>4</span><span>5</span><span>6</span></div><div class="d-polarita">⚠ Polarità negativa</div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">I</div><div class="qs-name">L'immagine della mia organizzazione</div><span class="qs-count">5 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">I.01</span><div>Ritengo che la mia organizzazione sia percepita positivamente dall'esterno.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">I.02</span><div>I servizi erogati dalla mia organizzazione sono di qualità elevata rispetto agli standard di settore.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">I.03</span><div>L'organizzazione comunica efficacemente la propria missione e i propri risultati ai cittadini/clienti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">I.04</span><div>Sono soddisfatto/a della reputazione pubblica della mia organizzazione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">I.05</span><div>Consiglierei ad amici e familiari di rivolgersi ai servizi offerti dalla mia organizzazione (NPS).<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-footer">
        <strong>Importanza degli ambiti:</strong> Al termine del questionario, si chiede ai rispondenti di indicare il grado di importanza attribuita a ciascuna delle sezioni A–I, su scala 1–4. Questo consente di calcolare l'<strong>Employee Satisfaction Index (ESI)</strong> ponderato per le attese.
      </div>
    </div>

    <!-- PANEL 2: Condivisione sistema di valutazione -->
    <div class="q-panel" id="panel-condivisione">
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">L</div><div class="qs-name">La mia organizzazione — sistema di valutazione</div><span class="qs-count">6 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">L.01</span><div>Conosco gli obiettivi strategici della mia organizzazione per il prossimo anno.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">L.02</span><div>Gli obiettivi assegnati alla mia unità organizzativa mi sembrano chiari e raggiungibili.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">L.03</span><div>Comprendo il legame tra i miei obiettivi individuali e quelli dell'organizzazione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">L.04</span><div>Le risorse messe a disposizione per raggiungere gli obiettivi sono adeguate.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">L.05</span><div>Il Piano della Performance (o PIAO) viene comunicato e condiviso con il personale.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">L.06</span><div>Partecipo attivamente alla definizione degli obiettivi del mio ambito lavorativo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">M</div><div class="qs-name">Le mie performance</div><span class="qs-count">5 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">M.01</span><div>Gli obiettivi che mi vengono assegnati sono misurabili e verificabili.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">M.02</span><div>Ricevo feedback regolari sull'andamento delle mie performance.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">M.03</span><div>Il sistema di valutazione tiene conto del reale contributo di ciascun lavoratore.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">M.04</span><div>La valutazione della performance è collegata a concrete opportunità di crescita e sviluppo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">M.05</span><div>Sono soddisfatto/a del processo di valutazione delle mie performance individuali.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">N</div><div class="qs-name">Il funzionamento del sistema di valutazione</div><span class="qs-count">5 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">N.01</span><div>Il sistema di misurazione della performance è chiaro e comprensibile a tutti i dipendenti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">N.02</span><div>I criteri di valutazione sono applicati in modo coerente da tutti i valutatori.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">N.03</span><div>Il sistema di incentivazione valorizza effettivamente i risultati di eccellenza.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">N.04</span><div>È possibile contestare o discutere la propria valutazione in modo trasparente.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">N.05</span><div>Il sistema di valutazione contribuisce complessivamente al miglioramento organizzativo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
    </div>

    <!-- PANEL 3: Valutazione superiore gerarchico -->
    <div class="q-panel" id="panel-superiore">
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">O</div><div class="qs-name">Il mio capo e la mia crescita</div><span class="qs-count">7 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">O.01</span><div>Il mio superiore gerarchico mi assegna obiettivi chiari e raggiungibili.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">O.02</span><div>Il mio capo mi fornisce indicazioni utili e tempestive per migliorare il mio lavoro.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">O.03</span><div>Il mio superiore sostiene la mia crescita professionale e mi supporta nelle sfide lavorative.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">O.04</span><div>Il mio capo riconosce e valorizza il contributo che porto all'organizzazione.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">O.05</span><div>Mi sento incoraggiato/a ad esprimere idee innovative e suggerimenti di miglioramento.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">O.06</span><div>Il mio superiore gestisce le situazioni critiche con competenza e serenità.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">O.07</span><div>Il mio capo è disponibile al dialogo e all'ascolto delle esigenze dei collaboratori.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-sezione">
        <div class="qs-header" onclick="toggleSezione(this)">
          <div class="qs-left"><div class="qs-letter">P</div><div class="qs-name">Il mio capo e l'equità</div><span class="qs-count">7 domande</span></div>
          <span class="qs-icon">▾</span>
        </div>
        <div class="qs-domande">
          <div class="domanda"><span class="d-num">P.01</span><div>Il mio superiore tratta tutti i collaboratori con uguale rispetto, senza preferenze o discriminazioni.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">P.02</span><div>I criteri con cui il mio capo valuta le performance dei collaboratori sono trasparenti e coerenti.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">P.03</span><div>Il mio superiore distribuisce equamente i carichi di lavoro tra i componenti del team.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">P.04</span><div>Il mio capo assegna incarichi e opportunità sulla base delle competenze reali, non di favoritismi.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">P.05</span><div>Il mio superiore garantisce pari opportunità di sviluppo a tutti i componenti del gruppo.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">P.06</span><div>Il mio capo gestisce i conflitti all'interno del team in modo equo e imparziale.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
          <div class="domanda"><span class="d-num">P.07</span><div>Sono complessivamente soddisfatto/a della leadership del mio superiore gerarchico.<div class="d-scala"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span></div></div></div>
        </div>
      </div>
      <div class="q-footer">
        <strong>Nota metodologica:</strong> Il superiore gerarchico va individuato nel responsabile che assegna gli obiettivi e valuta la performance individuale del dipendente (precisazione ANAC, seduta 29 maggio 2013). Per i dirigenti apicali, il superiore è l'organo di vertice politico-amministrativo.
      </div>
    </div>

  </div>
</section>

<!-- OUTPUT -->
<section id="output">
  <div class="section-inner">
    <div class="section-label">Cosa produciamo</div>
    <div class="section-title">Gli <em>output</em> dell'indagine</div>
    <p class="section-desc">Al termine del processo di rilevazione e analisi, Troisi Ricerche consegna all'organizzazione un set completo di strumenti per l'azione.</p>
    <div class="output-grid">
      <div class="output-card"><div class="oc-icon">📊</div><div class="oc-title">Rapporto di ricerca</div><div class="oc-desc">Analisi completa con tecniche monovariate e bivariate, infografiche, tabelle a doppia entrata. Presentato al management e al personale.</div></div>
      <div class="output-card"><div class="oc-icon">📈</div><div class="oc-title">Indici statistici</div><div class="oc-desc">PM, ESI, Overall e NPS elaborati per ogni dimensione. Confronto con benchmark di settore e trend temporale.</div></div>
      <div class="output-card"><div class="oc-icon">🗂️</div><div class="oc-title">Matrice degli interventi</div><div class="oc-desc">Cruscotto con sistema di emoticon e colori (rosso → verde). Priorità di intervento per area critica e grado di urgenza.</div></div>
      <div class="output-card"><div class="oc-icon">👥</div><div class="oc-title">Incontro con il management</div><div class="oc-desc">Sessione strategica per discutere le risultanze e pianificare le tappe successive del percorso di valorizzazione del capitale umano.</div></div>
      <div class="output-card"><div class="oc-icon">🎤</div><div class="oc-title">Presentazione al personale</div><div class="oc-desc">Momento partecipativo di confronto e dialogo per aumentare la trasparenza informativa e favorire la condivisione dei risultati.</div></div>
      <div class="output-card"><div class="oc-icon">🔄</div><div class="oc-title">Piano di miglioramento</div><div class="oc-desc">Proposta operativa articolata per priorità di intervento, compatibile con il PIAO e rendicontabile agli OIV.</div></div>
    </div>
    <div class="matrice-preview">
      <div class="mp-title">Esempio · Matrice degli interventi</div>
      <div style="overflow-x:auto;">
        <table class="matrice-table">
          <thead>
            <tr>
              <th style="text-align:left; padding: 6px 10px; background:var(--grigio-bg);">Dimensione / Item</th>
              <th style="background:#fee2e2; color:#991b1b; font-size:0.6rem;">Alta priorità<br>1–2</th>
              <th style="background:#fee2e2; color:#991b1b; font-size:0.6rem;">Alta priorità<br>2–2.5</th>
              <th style="background:#fef9c3; color:#854d0e; font-size:0.6rem;">Media priorità<br>2.5–3</th>
              <th style="background:#fef9c3; color:#854d0e; font-size:0.6rem;">Azione correttiva<br>3–3.5</th>
              <th style="background:#d1fae5; color:#065f46; font-size:0.6rem;">Sviluppo<br>3.5–4.5</th>
              <th style="background:#a7f3d0; color:#064e3b; font-size:0.6rem;">Punti di forza<br>4.5–6</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style="font-size:0.75rem; font-weight:600; color:var(--blu); padding:6px 10px;">A · Stress lavoro-correlato</td><td class="m-rosso"></td><td class="m-rosso"></td><td class="m-arancio"></td><td class="m-giallo"></td><td class="m-verde-chiaro" style="text-align:center; color:#065f46;">✓</td><td class="m-verde"></td></tr>
            <tr><td style="font-size:0.75rem; font-weight:600; color:var(--blu); padding:6px 10px;">B · Discriminazioni</td><td class="m-rosso"></td><td class="m-rosso"></td><td class="m-arancio"></td><td class="m-giallo" style="text-align:center; color:#854d0e;">✓</td><td class="m-verde-chiaro"></td><td class="m-verde"></td></tr>
            <tr><td style="font-size:0.75rem; font-weight:600; color:var(--blu); padding:6px 10px;">C · Equità organizzativa</td><td class="m-rosso"></td><td class="m-rosso" style="text-align:center; color:#991b1b;">✓</td><td class="m-arancio"></td><td class="m-giallo"></td><td class="m-verde-chiaro"></td><td class="m-verde"></td></tr>
            <tr><td style="font-size:0.75rem; font-weight:600; color:var(--blu); padding:6px 10px;">H · Senso di appartenenza</td><td class="m-rosso"></td><td class="m-rosso"></td><td class="m-arancio"></td><td class="m-giallo"></td><td class="m-verde-chiaro"></td><td class="m-verde" style="text-align:center; color:#064e3b;">✓</td></tr>
          </tbody>
        </table>
      </div>
      <p style="font-size:0.68rem; color:var(--grigio); margin-top:10px;">Scala: rosso = intervento urgente · giallo = azione correttiva · verde = punto di forza · Troisi Ricerche © 2026</p>
    </div>
  </div>
</section>

<!-- DATI E GRAFICI -->
<section id="dati" style="background: var(--grigio-bg);">
  <div class="section-inner">
    <div class="section-label">Dati · Fonti istituzionali verificabili</div>
    <div class="section-title">Lo stato del <em>benessere organizzativo</em> in Italia</div>
    <p class="section-desc">Dati da fonti istituzionali pubbliche: ISTAT (Rapporto BES 2024, Indagine Aspetti della Vita Quotidiana 2024), INAIL (Relazione annuale 2024), EU-OSHA (OSH Pulse 2022), INAPP (Indagine BO 2022). Elaborazione Troisi Ricerche 2026.</p>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 28px; margin-bottom: 36px;">
      <div style="background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 22px;">
        <div class="section-label" style="margin-bottom: 4px;">Benessere organizzativo nelle PA italiane</div>
        <p style="font-size: 0.72rem; color: var(--grigio); margin-bottom: 14px; line-height: 1.5;">Punteggi medi per dimensione (scala 1–6) · Indagine INAPP-CUG 2022 e indagini PA pubbliche 2023-2024<br><span style="color: var(--accento); font-weight: 600;">— soglia minima benessere = 4.0</span><br><span style="color: var(--grigio); font-size: 0.65rem;">Fonti: INAPP, AgID 2023, Università Good Practice 2024, performance.gov.it</span></p>
        <div style="position: relative; width: 100%; height: 260px;">
          <svg viewBox="0 0 540 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
            <line x1="50" y1="20" x2="530" y2="20" stroke="#e5e7eb" stroke-width="1"/>
            <line x1="50" y1="60" x2="530" y2="60" stroke="#e5e7eb" stroke-width="1"/>
            <line x1="50" y1="100" x2="530" y2="100" stroke="#e5e7eb" stroke-width="1"/>
            <line x1="50" y1="140" x2="530" y2="140" stroke="#e5e7eb" stroke-width="1"/>
            <line x1="50" y1="180" x2="530" y2="180" stroke="#e5e7eb" stroke-width="1"/>
            <text x="44" y="24" text-anchor="end" font-size="10" fill="#9ca3af">6</text>
            <text x="44" y="64" text-anchor="end" font-size="10" fill="#9ca3af">5</text>
            <text x="44" y="104" text-anchor="end" font-size="10" fill="#9ca3af">4</text>
            <text x="44" y="144" text-anchor="end" font-size="10" fill="#9ca3af">3</text>
            <text x="44" y="184" text-anchor="end" font-size="10" fill="#9ca3af">2</text>
            <line x1="50" y1="100" x2="530" y2="100" stroke="#e8a020" stroke-width="2" stroke-dasharray="6,4"/>
            <text x="532" y="104" font-size="9" fill="#e8a020" font-weight="600">4.0</text>
            <rect x="58"  y="77"  width="42" height="103" rx="2" fill="#3dbfab"/>
            <rect x="116" y="65"  width="42" height="115" rx="2" fill="#3dbfab"/>
            <rect x="174" y="90"  width="42" height="90"  rx="2" fill="#3dbfab"/>
            <rect x="232" y="100" width="42" height="80"  rx="2" fill="#3dbfab"/>
            <rect x="290" y="74"  width="42" height="106" rx="2" fill="#3dbfab"/>
            <rect x="348" y="62"  width="42" height="118" rx="2" fill="#3dbfab"/>
            <rect x="406" y="87"  width="42" height="93"  rx="2" fill="#3dbfab"/>
            <rect x="464" y="81"  width="42" height="99"  rx="2" fill="#3dbfab"/>
            <text x="79"  y="72"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">4.2</text>
            <text x="137" y="60"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">4.6</text>
            <text x="195" y="85"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">3.8</text>
            <text x="253" y="95"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">3.5</text>
            <text x="311" y="69"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">4.3</text>
            <text x="369" y="57"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">4.7</text>
            <text x="427" y="82"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">3.9</text>
            <text x="485" y="76"  text-anchor="middle" font-size="9" fill="#0f766e" font-weight="700">4.1</text>
            <text x="79"  y="198" text-anchor="middle" font-size="8" fill="#6b7280">Benessere</text>
            <text x="79"  y="208" text-anchor="middle" font-size="8" fill="#6b7280">al lavoro</text>
            <text x="137" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Discrimi-</text>
            <text x="137" y="208" text-anchor="middle" font-size="8" fill="#6b7280">nazioni</text>
            <text x="195" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Equità</text>
            <text x="195" y="208" text-anchor="middle" font-size="8" fill="#6b7280">org.</text>
            <text x="253" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Carriera</text>
            <text x="253" y="208" text-anchor="middle" font-size="8" fill="#6b7280">sviluppo</text>
            <text x="311" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Il mio</text>
            <text x="311" y="208" text-anchor="middle" font-size="8" fill="#6b7280">lavoro</text>
            <text x="369" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Colleghi</text>
            <text x="427" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Contesto</text>
            <text x="427" y="208" text-anchor="middle" font-size="8" fill="#6b7280">lavoro</text>
            <text x="485" y="198" text-anchor="middle" font-size="8" fill="#6b7280">Apparte-</text>
            <text x="485" y="208" text-anchor="middle" font-size="8" fill="#6b7280">nenza</text>
            <rect x="50" y="220" width="12" height="10" rx="2" fill="#3dbfab"/>
            <text x="66" y="229" font-size="9" fill="#6b7280">Punteggio medio PA (scala 1–6)</text>
            <line x1="240" y1="225" x2="260" y2="225" stroke="#e8a020" stroke-width="2" stroke-dasharray="4,3"/>
            <text x="264" y="229" font-size="9" fill="#e8a020" font-weight="600">soglia 4.0</text>
          </svg>
        </div>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-top: 14px;">
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--teal-dark);">4.1 / 6</div><div style="font-size: 0.62rem; color: var(--grigio);">Media BO atenei italiani · Good Practice 2024</div></div>
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--arancio);">36%</div><div style="font-size: 0.62rem; color: var(--grigio);">Impegno non riconosciuto · performance.gov.it 2024</div></div>
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--teal-dark);">74%</div><div style="font-size: 0.62rem; color: var(--grigio);">Non sviluppa capacità individuali · INAPP 2022</div></div>
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--teal-dark);">57%</div><div style="font-size: 0.62rem; color: var(--grigio);">Insoddisfatti del proprio sviluppo · INAPP 2022</div></div>
        </div>
      </div>
      <div style="background: var(--bianco); border: 1px solid var(--bordo); border-radius: 14px; padding: 22px;">
        <div class="section-label" style="margin-bottom: 4px;">Qualità della vita lavorativa in Italia e in Europa</div>
        <p style="font-size: 0.72rem; color: var(--grigio); margin-bottom: 14px; line-height: 1.5;">Indicatori selezionati da fonti istituzionali · %<br><span style="color: var(--rosso); font-weight: 600;">rosso = criticità · verde = aspetto positivo</span><br><span style="color: var(--grigio); font-size: 0.65rem;">Fonti: ISTAT Aspetti Vita Quotidiana 2024, INAIL 2024, EU-OSHA OSH Pulse 2022</span></p>
        <div style="position: relative; width: 100%; height: 260px;">
          <svg viewBox="0 0 540 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
            <line x1="60" y1="20"  x2="530" y2="20"  stroke="#e5e7eb" stroke-width="1"/>
            <line x1="60" y1="57"  x2="530" y2="57"  stroke="#e5e7eb" stroke-width="1"/>
            <line x1="60" y1="94"  x2="530" y2="94"  stroke="#e5e7eb" stroke-width="1"/>
            <line x1="60" y1="131" x2="530" y2="131" stroke="#e5e7eb" stroke-width="1"/>
            <line x1="60" y1="168" x2="530" y2="168" stroke="#e5e7eb" stroke-width="1"/>
            <text x="54" y="24"  text-anchor="end" font-size="10" fill="#9ca3af">100%</text>
            <text x="54" y="61"  text-anchor="end" font-size="10" fill="#9ca3af">75%</text>
            <text x="54" y="98"  text-anchor="end" font-size="10" fill="#9ca3af">50%</text>
            <text x="54" y="135" text-anchor="end" font-size="10" fill="#9ca3af">25%</text>
            <text x="54" y="172" text-anchor="end" font-size="10" fill="#9ca3af">0%</text>
            <rect x="72"  y="53"  width="52" height="115" rx="2" fill="#e76f51"/>
            <rect x="148" y="50"  width="52" height="118" rx="2" fill="#3dbfab"/>
            <rect x="224" y="100" width="52" height="68"  rx="2" fill="#e76f51"/>
            <rect x="300" y="103" width="52" height="65"  rx="2" fill="#e76f51"/>
            <rect x="376" y="124" width="52" height="44"  rx="2" fill="#e76f51"/>
            <rect x="452" y="107" width="52" height="61"  rx="2" fill="#e76f51"/>
            <text x="98"  y="48"  text-anchor="middle" font-size="10" fill="#c2410c" font-weight="700">77.6%</text>
            <text x="174" y="45"  text-anchor="middle" font-size="10" fill="#0f766e" font-weight="700">80%</text>
            <text x="250" y="95"  text-anchor="middle" font-size="10" fill="#c2410c" font-weight="700">46%</text>
            <text x="326" y="98"  text-anchor="middle" font-size="10" fill="#c2410c" font-weight="700">44%</text>
            <text x="402" y="119" text-anchor="middle" font-size="10" fill="#c2410c" font-weight="700">30%</text>
            <text x="478" y="102" text-anchor="middle" font-size="10" fill="#c2410c" font-weight="700">41%</text>
            <text x="98"  y="185" text-anchor="middle" font-size="7.5" fill="#6b7280">Soddisfatti</text>
            <text x="98"  y="194" text-anchor="middle" font-size="7.5" fill="#6b7280">lavoro</text>
            <text x="98"  y="203" text-anchor="middle" font-size="7.5" fill="#9ca3af">ISTAT 2024</text>
            <text x="174" y="185" text-anchor="middle" font-size="7.5" fill="#6b7280">Soddisfatti</text>
            <text x="174" y="194" text-anchor="middle" font-size="7.5" fill="#6b7280">vita lav.</text>
            <text x="174" y="203" text-anchor="middle" font-size="7.5" fill="#9ca3af">ISTAT 2023</text>
            <text x="250" y="185" text-anchor="middle" font-size="7.5" fill="#6b7280">Pressione</text>
            <text x="250" y="194" text-anchor="middle" font-size="7.5" fill="#6b7280">eccessiva</text>
            <text x="250" y="203" text-anchor="middle" font-size="7.5" fill="#9ca3af">EU-OSHA</text>
            <text x="326" y="185" text-anchor="middle" font-size="7.5" fill="#6b7280">Stress</text>
            <text x="326" y="194" text-anchor="middle" font-size="7.5" fill="#6b7280">post-covid</text>
            <text x="326" y="203" text-anchor="middle" font-size="7.5" fill="#9ca3af">EU-OSHA</text>
            <text x="402" y="185" text-anchor="middle" font-size="7.5" fill="#6b7280">Problemi</text>
            <text x="402" y="194" text-anchor="middle" font-size="7.5" fill="#6b7280">salute lav.</text>
            <text x="402" y="203" text-anchor="middle" font-size="7.5" fill="#9ca3af">EU-OSHA</text>
            <text x="478" y="185" text-anchor="middle" font-size="7.5" fill="#6b7280">Soddisfatti</text>
            <text x="478" y="194" text-anchor="middle" font-size="7.5" fill="#6b7280">valutaz. PA</text>
            <text x="478" y="203" text-anchor="middle" font-size="7.5" fill="#9ca3af">DFP 2024</text>
            <rect x="60"  y="218" width="10" height="10" rx="2" fill="#e76f51"/>
            <text x="74"  y="227" font-size="9" fill="#6b7280">criticità</text>
            <rect x="130" y="218" width="10" height="10" rx="2" fill="#3dbfab"/>
            <text x="144" y="227" font-size="9" fill="#6b7280">aspetto positivo</text>
          </svg>
        </div>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 14px;">
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--rosso);">77.6%</div><div style="font-size: 0.62rem; color: var(--grigio);">Soddisfatti del lavoro · ISTAT 2024 (in calo -2.4pp)</div></div>
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--rosso);">+17.9%</div><div style="font-size: 0.62rem; color: var(--grigio);">Denunce malattie psichiche · INAIL Q1 2024</div></div>
          <div style="background: var(--grigio-bg); border-radius: 7px; padding: 9px; text-align: center;"><div style="font-size: 1.2rem; font-weight: 800; color: var(--rosso);">9 mln</div><div style="font-size: 0.62rem; color: var(--grigio);">Lavoratori con stress SLC · INAIL</div></div>
        </div>
      </div>
    </div>
    <div style="background: var(--bianco); border: 1px solid var(--bordo); border-radius: 8px; padding: 14px 18px; margin-bottom: 28px; font-size: 0.75rem; color: var(--grigio); line-height: 1.7;">
      <strong style="color: var(--blu);">Fonti istituzionali utilizzate:</strong>
      <a href="https://www.istat.it" target="_blank" style="color: var(--teal-dark); font-weight: 600;">ISTAT</a> — Rapporto BES 2024 · Indagine Aspetti della Vita Quotidiana 2024 &nbsp;|&nbsp;
      <a href="https://www.inail.it" target="_blank" style="color: var(--teal-dark); font-weight: 600;">INAIL</a> — Relazione annuale 2024 &nbsp;|&nbsp;
      <a href="https://osha.europa.eu" target="_blank" style="color: var(--teal-dark); font-weight: 600;">EU-OSHA</a> — OSH Pulse 2022 &nbsp;|&nbsp;
      <a href="https://www.inapp.gov.it" target="_blank" style="color: var(--teal-dark); font-weight: 600;">INAPP</a> — Indagine Benessere Organizzativo 2022 &nbsp;|&nbsp;
      <a href="https://performance.gov.it" target="_blank" style="color: var(--teal-dark); font-weight: 600;">Dip. Funzione Pubblica</a> — Relazione performance PA 2024
    </div>
    <div style="background: var(--bianco); border: 1px solid var(--bordo); border-left: 4px solid var(--teal); border-radius: 12px; padding: 24px 28px;">
      <div class="section-label" style="margin-bottom: 8px;">Il benessere organizzativo dentro il Metodo Troisi</div>
      <p style="font-size: 0.88rem; color: var(--testo); line-height: 1.7; margin-bottom: 18px;">Il Benessere Organizzativo non è un'indagine isolata. Nel <strong>Metodo Troisi</strong>, è il punto di partenza di un circolo virtuoso che porta a misurare le competenze (<a href="https://www.mappaturadellecompetenze.it" target="_blank" style="color:var(--teal-dark); font-weight:600;">Mappatura delle Competenze</a>), certificarle (<a href="https://www.registrodellecompetenze.it" target="_blank" style="color:var(--teal-dark); font-weight:600;">Registro delle Competenze</a>), e misurare la soddisfazione dei cittadini/clienti (<a href="https://www.customerpa.it" target="_blank" style="color:var(--teal-dark); font-weight:600;">CustomerPA</a>). I dati del BO alimentano direttamente gli <strong>indicatori di performance</strong> richiesti da PIAO e OIV — trasformando un adempimento normativo in un motore di miglioramento continuo.</p>
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;">
        <a href="https://www.mappaturadellecompetenze.it" target="_blank" style="background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; display: block;"><div style="font-size: 1.3rem; margin-bottom: 6px;">🗺️</div><div style="font-size: 0.8rem; font-weight: 700; color: var(--teal-deep);">Mappatura delle Competenze</div><div style="font-size: 0.68rem; color: var(--grigio);">Mappatura competenze</div><div style="font-size: 0.65rem; color: var(--teal-dark); margin-top: 4px; font-weight: 600;">Fase 2 →</div></a>
        <a href="https://www.registrodellecompetenze.it" target="_blank" style="background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; display: block;"><div style="font-size: 1.3rem; margin-bottom: 6px;">📜</div><div style="font-size: 0.8rem; font-weight: 700; color: var(--teal-deep);">Registro delle Competenze</div><div style="font-size: 0.68rem; color: var(--grigio);">Registro digitale EQF</div><div style="font-size: 0.65rem; color: var(--teal-dark); margin-top: 4px; font-weight: 600;">Fase 3 →</div></a>
        <a href="https://www.customerpa.it" target="_blank" style="background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; display: block;"><div style="font-size: 1.3rem; margin-bottom: 6px;">😊</div><div style="font-size: 0.8rem; font-weight: 700; color: var(--teal-deep);">CustomerPA</div><div style="font-size: 0.68rem; color: var(--grigio);">CS cittadini · CPA Index</div><div style="font-size: 0.65rem; color: var(--teal-dark); margin-top: 4px; font-weight: 600;">Fase 4 →</div></a>
        <a href="https://www.troisiinsight.it" target="_blank" style="background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; display: block;"><div style="font-size: 1.3rem; margin-bottom: 6px;">📊</div><div style="font-size: 0.8rem; font-weight: 700; color: var(--teal-deep);">TroisiInsight</div><div style="font-size: 0.68rem; color: var(--grigio);">Report · Dashboard · KPI</div><div style="font-size: 0.65rem; color: var(--teal-dark); margin-top: 4px; font-weight: 600;">Dati pubblici ↗</div></a>
      </div>
    </div>
  </div>
</section>

<!-- CLIENTI -->
<section id="clienti">
  <div class="section-inner">
    <div class="section-label">Chi ha scelto Troisi Ricerche</div>
    <div class="section-title">Alcune delle organizzazioni che hanno misurato il loro <em>benessere</em></div>
    <p class="section-desc">Una selezione dei nostri clienti, in diversi settori e territori.</p>
    <div class="clienti-grid">
      <div class="cliente-card"><div class="cc-logo" style="background:#004f9e;">AQP</div><div class="cc-name">Acquedotto Pugliese</div><div class="cc-tipo">Utility idrica pubblica · Puglia</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#2e7d32;">ERSAF</div><div class="cc-name">ERSAF</div><div class="cc-tipo">Ente Reg. Servizi Agricoltura · Lombardia</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#1a3a5c;">AIDP</div><div class="cc-name">AIDP Puglia</div><div class="cc-tipo">Assoc. Italiana Dir. Personale</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#7b1fa2;">ESU</div><div class="cc-name">ESU Padova</div><div class="cc-tipo">Ente Reg. Diritto allo Studio · Veneto</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#1565c0;">AdP</div><div class="cc-name">Aeroporti di Puglia</div><div class="cc-tipo">Infrastrutture aeroportuali · Puglia</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#00695c;">TT</div><div class="cc-name">Trieste Trasporti</div><div class="cc-tipo">Trasporto pubblico locale · Friuli V.G.</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#e65100;">SVT</div><div class="cc-name">SVT Vicenza</div><div class="cc-tipo">Società Vicentina Trasporti · Veneto</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#880e4f;">BPPB</div><div class="cc-name">Banca Popolare di Puglia e Basilicata</div><div class="cc-tipo">Istituto bancario · Puglia e Basilicata</div></div>
      <div class="cliente-card"><div class="cc-logo" style="background:#c17b00;">ORP</div><div class="cc-name">Oropan SpA</div><div class="cc-tipo">Prodotti da forno · Altamura (BA) · dal 1956</div></div>
    </div>
  </div>
</section>

<!-- ECOSISTEMA -->
<section id="ecosistema">
  <div class="section-inner">
    <div class="section-label">La galassia Troisi Ricerche</div>
    <div class="section-title">Un <em>ecosistema</em> integrato</div>
    <div class="eco-grid">
      <a href="https://www.t-index.it" target="_blank" class="eco-card"><div class="ec-icon">📐</div><div class="ec-name">TR-Index</div><div class="ec-desc">Performance territoriale</div></a>
      <a href="https://www.mappaturadellecompetenze.it" target="_blank" class="eco-card"><div class="ec-icon">🗺️</div><div class="ec-name">Mappatura delle Competenze</div><div class="ec-desc">Mappatura competenze</div></a>
      <a href="https://www.registrodellecompetenze.it" target="_blank" class="eco-card"><div class="ec-icon">📜</div><div class="ec-name">Registro delle Competenze</div><div class="ec-desc">Registro digitale</div></a>
      <a href="https://www.customerpa.it" target="_blank" class="eco-card"><div class="ec-icon">😊</div><div class="ec-name">CustomerPA</div><div class="ec-desc">Customer satisfaction PA</div></a>
      <a href="#" class="eco-card active"><div class="ec-icon">🧠</div><div class="ec-name">BenessereOrg.</div><div class="ec-desc">Sei qui ◉</div></a>
    </div>
    <div class="eco-grid-2" style="margin-top:12px;">
      <a href="https://www.troisiinsight.it" target="_blank" class="eco-card"><div class="ec-icon">📊</div><div class="ec-name">TroisiInsight</div><div class="ec-desc">Report e dashboard</div></a>
      <a href="https://www.digitalizzazionenellapa.it" target="_blank" class="eco-card"><div class="ec-icon">🏛️</div><div class="ec-name">DigitalizzazionePA</div><div class="ec-desc">PA digitale</div></a>
      <a href="https://www.voiceinhub.it" target="_blank" class="eco-card"><div class="ec-icon">🎙️</div><div class="ec-name">VoiceInHub</div><div class="ec-desc">Podcast innovazione</div></a>
      <a href="https://tip.troisiricerche.it" target="_blank" class="eco-card"><div class="ec-icon">⚡</div><div class="ec-name">TIP Platform</div><div class="ec-desc">Piattaforma sondaggi</div></a>
      <a href="https://www.troisiricerche.net" target="_blank" class="eco-card"><div class="ec-icon">🏢</div><div class="ec-name">Troisi Ricerche</div><div class="ec-desc">Hub principale</div></a>
    </div>
  </div>
</section>

<!-- CHI SIAMO -->

<!-- ============================================================
     SEZIONE SEO: RISCHI, SANZIONI, FAQ AI
     Ottimizzata per Google + AI (ChatGPT, Gemini, Perplexity)
     ============================================================ -->
<section id="rischi-sanzioni" style="background:#fff;padding:64px 20px">
  <div class="section-inner">
    <div class="section-label">Compliance · Normativa lavoro</div>
    <div class="section-title">Rischi, sanzioni e <em>cosa verifica l'Ispettorato</em></div>
    <p class="section-desc">Il benessere organizzativo non è solo un tema di clima interno: è un obbligo normativo con conseguenze concrete in caso di inadempimento. Ecco cosa verifica l'Ispettorato del Lavoro e quali sono le responsabilità.</p>

    <!-- GRIGLIA RISCHI -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin:28px 0">

      <!-- DVR -->
      <div style="background:#fef2f2;border:1.5px solid #fecaca;border-radius:12px;padding:18px 20px">
        <div style="font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#dc2626;margin-bottom:8px">⚠️ Rischio 1 — DVR</div>
        <h3 style="font-size:.97rem;font-weight:800;color:#1a2e2a;margin-bottom:8px">DVR incompleto — stress lavoro correlato</h3>
        <p style="font-size:.83rem;color:#6b7280;line-height:1.6;margin-bottom:10px">Il D.Lgs. 81/2008, art. 28, obbliga tutti i datori di lavoro a valutare lo stress lavoro-correlato nel DVR. Un DVR senza questa sezione è incompleto.</p>
        <div style="font-size:.78rem;color:#dc2626;font-weight:600">Sanzioni: da €1.000 a €3.000 · Responsabilità penale</div>
      </div>

      <!-- PA INDAGINE -->
      <div style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;padding:18px 20px">
        <div style="font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#d97706;margin-bottom:8px">⚠️ Rischio 2 — PA</div>
        <h3 style="font-size:.97rem;font-weight:800;color:#1a2e2a;margin-bottom:8px">Indagine BO mancante o non validata</h3>
        <p style="font-size:.83rem;color:#6b7280;line-height:1.6;margin-bottom:10px">Il D.Lgs. 150/2009, art. 14 c.5, impone indagini annuali con metodo ANAC validato. Un'indagine non strutturata è giuridicamente irrilevante.</p>
        <div style="font-size:.78rem;color:#d97706;font-weight:600">Conseguenze: Relazione Performance non valida · Premi bloccati</div>
      </div>

      <!-- CORTE DEI CONTI -->
      <div style="background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:12px;padding:18px 20px">
        <div style="font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#1d4ed8;margin-bottom:8px">⚠️ Rischio 3 — Corte dei Conti</div>
        <h3 style="font-size:.97rem;font-weight:800;color:#1a2e2a;margin-bottom:8px">Responsabilità degli amministratori PA</h3>
        <p style="font-size:.83rem;color:#6b7280;line-height:1.6;margin-bottom:10px">In caso di inadempimento grave, la Corte dei Conti può irrogare sanzioni personali agli amministratori responsabili della PA, fino a 20 volte la retribuzione mensile lorda.</p>
        <div style="font-size:.78rem;color:#1d4ed8;font-weight:600">Responsabilità: fino a 20x la retribuzione mensile</div>
      </div>

    </div>

    <!-- COSA VERIFICA L'ISPETTORATO -->
    <div style="background:linear-gradient(135deg,#e8f7f4,#f0fdf4);border:1.5px solid #b2e8e0;border-radius:14px;padding:24px 28px;margin:24px 0">
      <h2 style="font-size:1.1rem;font-weight:800;color:#1a7a6b;margin-bottom:14px">Cosa verifica l'Ispettorato del Lavoro sul benessere organizzativo</h2>
      <p style="font-size:.88rem;color:#1a2e2a;margin-bottom:12px">Durante un'ispezione, l'<strong>Ispettorato Nazionale del Lavoro</strong> non valuta percezioni: verifica documenti, processi e conformità normativa. Gli elementi controllati sono:</p>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
        <div style="display:flex;gap:8px;font-size:.84rem;color:#1a2e2a;line-height:1.5"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>DVR aggiornato</strong> con sezione stress lavoro-correlato</span></div>
        <div style="display:flex;gap:8px;font-size:.84rem;color:#1a2e2a;line-height:1.5"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Metodo di rilevazione</strong> validato (ANAC, INAIL)</span></div>
        <div style="display:flex;gap:8px;font-size:.84rem;color:#1a2e2a;line-height:1.5"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Coinvolgimento RSPP</strong> e medico competente</span></div>
        <div style="display:flex;gap:8px;font-size:.84rem;color:#1a2e2a;line-height:1.5"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Piano di miglioramento</strong> documentato</span></div>
        <div style="display:flex;gap:8px;font-size:.84rem;color:#1a2e2a;line-height:1.5"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>OIV coinvolto</strong> nella validazione (PA)</span></div>
        <div style="display:flex;gap:8px;font-size:.84rem;color:#1a2e2a;line-height:1.5"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Comunicazione ai dipendenti</strong> dei risultati</span></div>
      </div>
      <div style="margin-top:16px">
        <a href="/approfondimenti/ispettorato-lavoro-benessere-organizzativo" style="font-size:.84rem;font-weight:700;color:#1a7a6b;text-decoration:underline">→ Leggi la guida completa: Cosa controlla l'Ispettorato del Lavoro</a>
      </div>
    </div>

    <!-- FAQ AI-READY -->
    <div style="margin-top:32px" id="faq-bo">
      <h2 style="font-size:1.15rem;font-weight:800;color:#1a3a5c;margin-bottom:18px">Domande frequenti sul benessere organizzativo</h2>

      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #d1ece8;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:6px">Il benessere organizzativo è obbligatorio?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.6">Sì. Il benessere organizzativo è obbligatorio per legge. <strong>Per la PA</strong>: il D.Lgs. 150/2009, art. 14 c.5, impone indagini annuali con metodo ANAC. <strong>Per tutti</strong>: il D.Lgs. 81/2008, art. 28, obbliga alla valutazione dello stress lavoro-correlato nel DVR. Un DVR senza questa sezione è incompleto.</p>
        </div>
      </div>

      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #d1ece8;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:6px">Cosa dice la legge sul benessere organizzativo?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.6">Le norme principali sono: il <strong>D.Lgs. 81/2008</strong> (valutazione stress SLC nel DVR, obbligatoria per tutti), il <strong>D.Lgs. 150/2009</strong> (indagine annuale BO nella PA), le <strong>Linee guida INAIL</strong> sulla valutazione dello stress lavoro-correlato, e il modello <strong>ANAC</strong> a 17 sezioni come standard metodologico per la PA.</p>
        </div>
      </div>

      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #d1ece8;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:6px">Quando è obbligatoria l'indagine benessere organizzativo nella PA?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.6">L'indagine sul benessere organizzativo nella PA è obbligatoria ogni anno, ai sensi del D.Lgs. 150/2009, art. 14 c.5. I risultati devono essere integrati nella Relazione sulla Performance e validati dall'OIV (Organismo Indipendente di Valutazione). Il mancato rispetto invalida la Relazione e può bloccare i premi al personale.</p>
        </div>
      </div>

      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #d1ece8;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:6px">Cosa deve contenere il DVR per lo stress lavoro-correlato?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.6">Il DVR deve includere: la valutazione preliminare del rischio da stress lavoro-correlato (SLC), eventualmente la valutazione approfondita (se emergono indicatori di rischio), il coinvolgimento del RSPP e del medico competente, e un piano di miglioramento con azioni correttive documentate. Tutto questo è richiesto dal D.Lgs. 81/2008, art. 28, e dalle Linee guida INAIL.</p>
        </div>
      </div>

      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #d1ece8;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:6px">Il benessere organizzativo è obbligatorio per i Comuni?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.6">Sì. I Comuni, come tutte le PA, sono soggetti all'obbligo di indagine annuale sul benessere organizzativo ai sensi del D.Lgs. 150/2009. I Comuni con più di 50 dipendenti sono inoltre soggetti al PIAO (Piano Integrato di Attività e Organizzazione), che integra la rilevazione BO negli obiettivi strategici dell'ente.</p>
        </div>
      </div>

      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:6px">Cosa chiede l'INAIL sullo stress lavoro-correlato?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.6">Le Linee guida INAIL sullo stress lavoro-correlato prevedono una valutazione in due fasi: una <strong>valutazione preliminare</strong> (sempre obbligatoria) e una <strong>valutazione approfondita</strong> (obbligatoria quando emergono indicatori di rischio). La metodologia deve essere documentata, coinvolgere il medico competente e produrre un piano di miglioramento verificabile.</p>
        </div>
      </div>

    </div>

    <!-- CTA -->
    <div style="background:linear-gradient(135deg,#1a7a6b,#1e3a8a);border-radius:14px;padding:24px 28px;text-align:center;margin-top:28px">
      <div style="font-size:.68rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.5);margin-bottom:8px">⚖️ Verifica la compliance del tuo ente</div>
      <h3 style="font-size:1.1rem;font-weight:900;color:#fff;margin-bottom:8px">Scopri in 8 domande il rischio ispettivo del tuo ente</h3>
      <p style="font-size:.87rem;color:rgba(255,255,255,.78);margin-bottom:14px">Diagnosi gratuita — Score BO immediato — Metodologia conforme alle linee guida INAIL e coerente con le indicazioni ANAC</p>
      <a href="/sei-in-regola-bo" style="display:inline-flex;align-items:center;gap:8px;background:#e8a020;color:#1a2e2a;font-weight:800;font-size:.92rem;padding:12px 24px;border-radius:10px;text-decoration:none">⚖️ Avvia la diagnosi gratuita →</a>
    </div>

  </div>
</section>
<!-- FINE SEZIONE RISCHI/SANZIONI/FAQ -->

<section id="chi-siamo">
  <div class="section-inner">
    <div class="section-label">Chi siamo</div>
    <div class="section-title">Andrea Troisi e <em>Troisi Ricerche</em></div>
    <div class="chi-grid">
      <div class="at-card">
        <div class="at-avatar">AT</div>
        <div class="at-name">Andrea Troisi</div>
        <div class="at-ruolo">Ricercatore · Statistico · Fondatore Troisi Ricerche · Professore Univ. Foggia e Bari</div>
        <p class="at-desc">Andrea Troisi ha sviluppato il metodo per la misurazione del Benessere Organizzativo che è stato riconosciuto da ANAC come modello di riferimento nazionale. In oltre 20 anni ha applicato questo metodo in decine di organizzazioni pubbliche e private, costruendo il circolo virtuoso che integra BO, competenze, formazione e performance.</p>
        <div class="at-links">
          <a href="https://andreatroisi.it" target="_blank">andreatroisi.it ↗</a>
          <a href="https://www.linkedin.com/in/andreatroisi/" target="_blank">LinkedIn ↗</a>
          <a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota ↗</a>
        </div>
      </div>
      <div class="anac-box">
        <h4>Metodologia conforme agli standard istituzionali</h4>
        <p>La metodologia Troisi Ricerche è strutturata in conformità agli standard per le indagini sul Benessere Organizzativo definiti dal Dipartimento della Funzione Pubblica, che ha recepito i modelli originariamente elaborati da ANAC (CiVIT) ai sensi del D.Lgs. 150/2009, art. 14 c.5.</p>
        <p>Questo ci consente di garantire alle organizzazioni clienti — PA e aziende private — uno strumento scientificamente fondato, rendicontabile agli OIV, compatibile con il PIAO e coerente con gli obiettivi di <strong>performance organizzativa</strong>, <strong>employee engagement</strong> e <strong>organizational wellbeing</strong>.</p>
        <a href="https://www.troisiricerche.net/chi-siamo/" target="_blank" class="anac-link">Scopri il team Troisi Ricerche ↗</a>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<div class="cta-finale">
  <div style="max-width:560px; margin:0 auto;">
    <h2>Misura il benessere della tua organizzazione</h2>
    <p>Prenota una sessione con Andrea Troisi e il team di Troisi Ricerche. Risposta entro 24 ore lavorative.</p>
    <div class="cta-btns">
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-cta-white">📅 Prenota una call gratuita</a>
      <a href="mailto:benessere@troisiricerche.it" class="btn-cta-outline">✉️ Scrivici</a>
    </div>
  </div>
</div>

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">BenessereOrganizzativo.it</div>
        <p>Piattaforma per la misurazione del Benessere Organizzativo nella PA e nelle aziende. Metodo Troisi Ricerche · Riconosciuto da ANAC.</p>
        <p class="brand-legal">Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari · P.IVA 07216100722</p>
      </div>
      <div class="footer-col">
        <h4>Il sito</h4>
        <ul>
          <li><a href="#normativa">Normativa e timeline</a></li>
          <li><a href="#circolo">Il circolo virtuoso</a></li>
          <li><a href="#metodo">Metodologia</a></li>
          <li><a href="#questionario">Questionario ANAC</a></li>
          <li><a href="#output">Output</a></li>
          <li><a href="#clienti">Clienti</a></li>
          <li><a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Galassia Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">troisiricerche.net</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.mappaturadellecompetenze.it" target="_blank">Mappatura delle Competenze</a></li>
          <li><a href="https://www.registrodellecompetenze.it" target="_blank">Registro delle Competenze</a></li>
          <li><a href="https://www.customerpa.it" target="_blank">CustomerPA</a></li>
          <li><a href="https://tip.troisiricerche.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una call</a></li>
          <li><a href="mailto:benessere@troisiricerche.it">benessere@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a></li>
          <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a></li>
          <li><a href="tel:800644046">800 644 046</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 BenessereOrganizzativo.it · Troisi Ricerche S.r.l. Unipersonale</div>
      <div class="footer-legal" id="iubenda-footer-links"></div>
      <script type="text/javascript" src="https://embeds.iubenda.com/widgets/946ac756-6db6-11ee-8bfc-5ad8d8c564c0.js"></script>
    </div>
  </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
function toggleSezione(header) {
  header.classList.toggle('open');
}
function switchTab(tab) {
  document.querySelectorAll('.q-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.q-panel').forEach(p => p.classList.remove('active'));
  const tabs = { 'bo': 0, 'condivisione': 1, 'superiore': 2 };
  document.querySelectorAll('.q-tab')[tabs[tab]].classList.add('active');
  document.getElementById('panel-' + tab).classList.add('active');
}
</script>

<div style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true">
benessere organizzativo normativa stress lavoro correlato normativa DVR stress lavoro correlato obbligo ispettorato del lavoro stress lavoro correlato compliance enti pubblici il benessere organizzativo è obbligatorio cosa controlla l'ispettorato del lavoro il DVR deve includere lo stress lavoro correlato ogni quanto va fatta l'indagine benessere organizzativo cosa succede se non faccio l'indagine BO benessere organizzativo è obbligatorio per i comuni cosa chiede l'INAIL sullo stress lavoro correlato verifica benessere organizzativo audit benessere organizzativo valutazione SLC obbligatoria responsabilità datore di lavoro stress lavoro corte dei conti responsabilità amministratori PA ANAC benessere organizzativo linee guida INAIL stress lavoro correlato linee guida sanzioni ispettorato lavoro DVR cosa succede se DVR non è aggiornato benessere organizzativo pubblica amministrazione stress lavoro correlato normativa DVR stress lavoro correlato obbligo ispettorato del lavoro stress lavoro correlato compliance enti pubblici audit benessere organizzativo benessere organizzativo normativa pubblica amministrazione benessere organizzativo aziendale benessere organizzativo aziende organizational wellbeing workplace wellbeing employee wellbeing benessere nei luoghi di lavoro qualità della vita lavorativa clima organizzativo analisi clima aziendale survey clima aziendale misurazione clima organizzativo stress lavoro correlato valutazione stress lavoro correlato rischio psicosociale lavoro employee survey employee satisfaction survey employee engagement survey indagine dipendenti questionario benessere organizzativo performance organizzativa organizational performance efficienza organizzativa employee engagement employee experience motivazione dipendenti organizational analytics HR analytics workplace analytics organizational wellbeing index organizational climate index indicatori benessere organizzativo benchmark clima aziendale benessere organizzativo Italia benessere organizzativo aziende italiane benessere organizzativo enti pubblici benessere organizzativo comuni benessere organizzativo università smart working benessere organizzativo digital workplace come misurare il benessere organizzativo come migliorare il clima aziendale strumenti per misurare il clima organizzativo consulenza benessere organizzativo organizational consulting Andrea Troisi Troisi Ricerche Metodo Troisi Troisi Organizational Wellbeing Model mappatura delle competenze registro delle competenze CustomerPA TR-Index TroisiInsight Mappatura delle Competenze Registro delle Competenze how to measure organizational wellbeing how to measure employee wellbeing organizational wellbeing indicators leadership organizzativa cultura organizzativa governance organizzativa benessere organizzativo digitalizzazione PA benessere organizzativo trasformazione digitale performance pubblica amministrazione valutazione enti pubblici troisi ricerche benessere organizzativo andrea troisi organizational wellbeing
</div>

<?php get_footer(); ?>
</body>
</html>