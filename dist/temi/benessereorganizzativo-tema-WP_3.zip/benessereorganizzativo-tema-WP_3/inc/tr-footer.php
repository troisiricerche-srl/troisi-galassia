<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">BenessereOrganizzativo.it</div>
        <p>Piattaforma per la misurazione del Benessere Organizzativo nella PA e nelle aziende. Metodo Troisi Ricerche · Riconosciuto da ANAC.</p>
        <p class="brand-legal">Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari · P.IVA 07216100722</p>
      </div>
      <div class="footer-col">
        <h4>Il sito</h4>
        <ul>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#normativa">Normativa e timeline</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#circolo">Il circolo virtuoso</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#metodo">Metodologia</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#questionario">Questionario ANAC</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#output">Output</a></li>
          <li><a href="<?php echo esc_url(home_url('/')); ?>#clienti">Clienti</a></li>
          <li><a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Galassia Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">troisiricerche.net</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.mappaturadellecompetenze.it" target="_blank">Mappatura delle Competenze</a></li>
          <li><a href="https://www.registrodellecompetenze.it" target="_blank">Registro delle Competenze</a></li>
          <li><a href="https://www.customerpa.it" target="_blank">CustomerPA</a></li>
          <li><a href="https://tip.troisiricerche.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una call</a></li>
          <li><a href="mailto:benessere@troisiricerche.it">benessere@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a></li>
          <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a></li>
          <li><a href="tel:800644046">800 644 046</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 BenessereOrganizzativo.it · Troisi Ricerche S.r.l. Unipersonale</div>
      <div class="footer-legal" id="iubenda-footer-links"></div>
      <script type="text/javascript" src="https://embeds.iubenda.com/widgets/946ac756-6db6-11ee-8bfc-5ad8d8c564c0.js"></script>
    </div>
  </div>
</footer>
<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
</script>
<?php wp_footer(); ?>
</body>
</html>
