<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="language" content="Italian">

<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/apple-touch-icon.png">

<!-- Schema.org -->
<style>
/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --teal:       #3dbfab;
  --teal-dark:  #2a9d8a;
  --teal-deep:  #1a7a6b;
  --teal-light: #e8f7f4;
  --teal-mid:   #b2e8e0;
  --blu:        #1a3a5c;
  --accento:    #e8a020;
  --testo:      #1a2e2a;
  --grigio:     #6b7280;
  --grigio-bg:  #f8fafa;
  --bordo:      #d1ece8;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --rosso:      #dc2626;
  --arancio:    #ea580c;
}
body { font-family: 'Segoe UI', system-ui, sans-serif; color: var(--testo); background: var(--bianco); line-height: 1.6; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; height: auto; }

/* =============================================
   TOPBAR
   ============================================= */
.topbar { background: var(--teal-deep); padding: 6px 0; font-size: 0.72rem; }
.topbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; gap: 14px; flex-wrap: wrap; align-items: center; }
.topbar a { color: rgba(255,255,255,.65); transition: color .2s; }
.topbar a:hover { color: var(--accento); }
.topbar a.topbar-personal { color: var(--accento); font-weight: 700; }
.topbar a.topbar-active { color: var(--bianco); font-weight: 700; }

/* =============================================
   NAVBAR
   ============================================= */
.navbar { background: var(--bianco); border-bottom: 3px solid var(--teal); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.07); }
.navbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.navbar-brand { display: flex; align-items: center; gap: 10px; }
.brand-logo { font-size: 1.05rem; font-weight: 900; color: var(--teal-deep); line-height: 1.1; }
.brand-logo span { color: var(--teal); }
.brand-sub { font-size: 0.65rem; color: var(--grigio); display: block; }
.navbar-links { display: flex; gap: 4px; align-items: center; }
.navbar-links a { padding: 6px 10px; border-radius: 6px; font-size: 0.82rem; color: var(--testo); font-weight: 500; transition: all .2s; }
.navbar-links a:hover { background: var(--teal-light); color: var(--teal-deep); }
.navbar-links .btn-contatti { border: 1.5px solid var(--bordo); color: var(--teal-deep); font-weight: 600; }
.navbar-links .btn-demo { background: var(--teal); color: var(--bianco) !important; font-weight: 700; padding: 7px 16px; }
.navbar-links .btn-demo:hover { background: var(--teal-dark); }
.hamburger { display: none; flex-direction: column; justify-content: center; gap: 5px; cursor: pointer; padding: 8px; border: none; background: none; }
.hamburger span { display: block; width: 24px; height: 2px; background: var(--teal); border-radius: 2px; transition: all .3s; }
.hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.mobile-menu { display: none; position: fixed; top: 64px; left: 0; right: 0; bottom: 0; background: var(--bianco); z-index: 99; padding: 20px; flex-direction: column; gap: 4px; overflow-y: auto; }
.mobile-menu.open { display: flex; }
.mobile-menu a { padding: 14px 16px; border-radius: 8px; font-size: 1rem; color: var(--testo); font-weight: 500; border-bottom: 1px solid var(--bordo); }
.mobile-menu .btn-demo { background: var(--teal); color: var(--bianco) !important; text-align: center; margin-top: 8px; border-bottom: none; }

/* =============================================
   HERO
   ============================================= */
.hero { background: linear-gradient(135deg, var(--teal-deep) 0%, var(--teal-dark) 50%, var(--teal) 100%); color: var(--bianco); padding: 72px 20px 56px; position: relative; overflow: hidden; }
.hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 80% 20%, rgba(255,255,255,.06) 0%, transparent 60%); }
.hero .inner { max-width: 1100px; margin: 0 auto; position: relative; display: grid; grid-template-columns: 1fr 340px; gap: 48px; align-items: center; }
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.9); font-size: 0.7rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; padding: 5px 14px; border-radius: 20px; margin-bottom: 16px; }
.hero h1 { font-size: clamp(1.9rem, 4vw, 2.8rem); font-weight: 900; line-height: 1.15; margin-bottom: 10px; }
.hero h1 em { color: #a7f3d0; font-style: normal; }
.hero-sub { font-size: 0.88rem; color: rgba(255,255,255,.6); margin-bottom: 14px; }
.hero-desc { font-size: 0.95rem; color: rgba(255,255,255,.82); margin-bottom: 28px; line-height: 1.7; max-width: 520px; }
.hero-cta { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }
.btn-hero-primary { background: var(--bianco); color: var(--teal-deep); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; transition: all .2s; display: inline-block; }
.btn-hero-primary:hover { background: #a7f3d0; }
.btn-hero-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.35); transition: all .2s; display: inline-block; }
.btn-hero-outline:hover { border-color: rgba(255,255,255,.7); }
.hero-badges { display: flex; gap: 8px; flex-wrap: wrap; }
.hb { font-size: 0.68rem; font-weight: 700; padding: 5px 12px; border-radius: 6px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2); color: rgba(255,255,255,.85); }

/* Hero card */
.hero-card { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); border-radius: 16px; padding: 22px; backdrop-filter: blur(8px); }
.hc-title { font-size: 0.68rem; text-transform: uppercase; letter-spacing: .08em; color: rgba(255,255,255,.5); margin-bottom: 16px; font-weight: 700; }
.bo-score { font-size: 3.5rem; font-weight: 900; color: #a7f3d0; line-height: 1; margin-bottom: 4px; }
.bo-label { font-size: 0.75rem; color: rgba(255,255,255,.6); margin-bottom: 16px; }
.bo-dims { display: flex; flex-direction: column; gap: 8px; }
.bo-dim { display: flex; align-items: center; gap: 8px; }
.bo-dim .bd-label { font-size: 0.65rem; color: rgba(255,255,255,.6); flex: 1; }
.bo-dim .bd-bar { flex: 1; height: 4px; background: rgba(255,255,255,.12); border-radius: 2px; }
.bo-dim .bd-fill { height: 100%; border-radius: 2px; background: #a7f3d0; }
.bo-dim .bd-val { font-size: 0.7rem; color: rgba(255,255,255,.8); font-weight: 700; width: 28px; text-align: right; }
.hc-anac { margin-top: 14px; font-size: 0.65rem; color: rgba(255,255,255,.4); border-top: 1px solid rgba(255,255,255,.1); padding-top: 10px; }
.hc-anac strong { color: #a7f3d0; }

/* =============================================
   SEZIONI GENERALI
   ============================================= */
section { padding: 64px 20px; }
.section-inner { max-width: 1100px; margin: 0 auto; }
.section-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .1em; color: var(--teal-dark); font-weight: 700; margin-bottom: 8px; }
.section-title { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; color: var(--blu); margin-bottom: 12px; line-height: 1.2; }
.section-title em { color: var(--teal-dark); font-style: normal; }
.section-desc { color: var(--grigio); max-width: 680px; margin-bottom: 36px; line-height: 1.7; }

/* =============================================
   NORMATIVA — TIMELINE
   ============================================= */
#normativa { background: var(--grigio-bg); }
.timeline { position: relative; max-width: 860px; }
.timeline::before { content: ''; position: absolute; left: 110px; top: 0; bottom: 0; width: 2px; background: var(--teal-mid); }
.timeline-item { display: grid; grid-template-columns: 100px 1fr; gap: 24px; margin-bottom: 28px; position: relative; }
.tl-anno { text-align: right; padding-top: 14px; position: relative; }
.tl-anno .anno { font-size: 1rem; font-weight: 900; color: var(--teal-dark); line-height: 1; }
.tl-anno .tipo { font-size: 0.6rem; text-transform: uppercase; letter-spacing: .06em; color: var(--grigio); margin-top: 2px; }
.tl-dot { position: absolute; right: -28px; top: 18px; width: 14px; height: 14px; background: var(--teal); border-radius: 50%; border: 3px solid var(--bianco); box-shadow: 0 0 0 2px var(--teal); z-index: 1; }
.tl-content { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px 18px; margin-left: 18px; border-left: 3px solid var(--teal); }
.tl-content .tc-decreto { font-size: 0.68rem; font-weight: 700; color: var(--teal-dark); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 4px; }
.tl-content .tc-titolo { font-size: 0.9rem; font-weight: 700; color: var(--blu); margin-bottom: 6px; }
.tl-content .tc-desc { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; }
.tl-content .tc-tag { display: inline-block; margin-top: 8px; font-size: 0.65rem; font-weight: 700; padding: 3px 10px; border-radius: 4px; }
.tc-tag.obbligatorio { background: #dcfce7; color: #166534; }
.tc-tag.modificato { background: #fef9c3; color: #854d0e; }
.tc-tag.abrogato { background: #fee2e2; color: #991b1b; }
.tc-tag.vigente { background: #e0f2fe; color: #0c4a6e; }
.tc-tag.stress { background: var(--teal-light); color: var(--teal-deep); }

.normativa-riepilogo { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px 24px; margin-top: 32px; border-left: 4px solid var(--teal); max-width: 860px; }
.nr-title { font-size: 0.85rem; font-weight: 800; color: var(--blu); margin-bottom: 10px; }
.nr-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.nr-item { text-align: center; padding: 12px; background: var(--grigio-bg); border-radius: 8px; }
.nr-item .ni-val { font-size: 1.4rem; font-weight: 900; color: var(--teal-dark); }
.nr-item .ni-lbl { font-size: 0.68rem; color: var(--grigio); }

/* =============================================
   CIRCOLO VIRTUOSO
   ============================================= */
#circolo { background: var(--bianco); }
.circolo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; }
.circolo-steps { display: flex; flex-direction: column; gap: 0; }
.cs-step { display: flex; gap: 16px; position: relative; padding-bottom: 24px; }
.cs-step:last-child { padding-bottom: 0; }
.cs-step::after { content: ''; position: absolute; left: 19px; top: 40px; bottom: 0; width: 2px; background: var(--teal-mid); }
.cs-step:last-child::after { display: none; }
.cs-num { width: 40px; height: 40px; background: var(--teal); color: var(--bianco); border-radius: 10px; display: grid; place-items: center; font-weight: 900; font-size: 0.85rem; flex-shrink: 0; position: relative; z-index: 1; }
.cs-body { flex: 1; }
.cs-title { font-size: 0.92rem; font-weight: 800; color: var(--blu); margin-bottom: 4px; }
.cs-desc { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; }
.cs-tools { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 6px; }
.cs-tool { font-size: 0.65rem; background: var(--teal-light); color: var(--teal-deep); border: 1px solid var(--bordo); padding: 2px 8px; border-radius: 4px; font-weight: 600; }

.circolo-schema { background: var(--teal-light); border-radius: 16px; padding: 28px; }
.schema-title { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .08em; color: var(--teal-dark); font-weight: 700; margin-bottom: 20px; }
.schema-circle { display: flex; flex-direction: column; gap: 8px; }
.sc-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: var(--bianco); border-radius: 10px; border: 1px solid var(--bordo); transition: all .2s; }
.sc-item:hover { border-color: var(--teal); box-shadow: 0 2px 12px rgba(61,191,171,.15); }
.sc-icon { font-size: 1.3rem; flex-shrink: 0; }
.sc-info { flex: 1; }
.sc-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); }
.sc-sub { font-size: 0.7rem; color: var(--grigio); }
.sc-arrow { color: var(--teal); font-size: 1.2rem; flex-shrink: 0; }

/* =============================================
   METODOLOGIA
   ============================================= */
#metodo { background: var(--grigio-bg); }
.metodo-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 28px; }
.area-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; border-top: 3px solid var(--teal); transition: box-shadow .2s; }
.area-card:hover { box-shadow: 0 4px 20px rgba(61,191,171,.12); }
.ac-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: .08em; color: var(--teal-dark); font-weight: 700; margin-bottom: 6px; }
.ac-title { font-size: 0.95rem; font-weight: 800; color: var(--blu); margin-bottom: 10px; }
.ac-items { display: flex; flex-direction: column; gap: 4px; }
.ac-item { font-size: 0.78rem; color: var(--grigio); display: flex; align-items: center; gap: 6px; }
.ac-item::before { content: ''; width: 6px; height: 6px; background: var(--teal); border-radius: 50%; flex-shrink: 0; }

/* Indici statistici */
.indici-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.indice-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px; text-align: center; }
.ic-sigla { font-size: 1.4rem; font-weight: 900; color: var(--teal-dark); line-height: 1; margin-bottom: 6px; }
.ic-nome { font-size: 0.8rem; font-weight: 700; color: var(--blu); margin-bottom: 4px; }
.ic-desc { font-size: 0.7rem; color: var(--grigio); line-height: 1.5; }

/* =============================================
   QUESTIONARIO INTERATTIVO ANAC
   ============================================= */
#questionario { background: var(--bianco); }
.q-intro { background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 12px; padding: 20px 24px; margin-bottom: 28px; display: flex; gap: 16px; align-items: flex-start; border-left: 4px solid var(--teal); }
.q-intro-icon { font-size: 1.8rem; flex-shrink: 0; }
.q-intro-text h4 { font-size: 0.9rem; font-weight: 800; color: var(--teal-deep); margin-bottom: 4px; }
.q-intro-text p { font-size: 0.8rem; color: var(--testo); line-height: 1.6; }
.q-intro-text a { color: var(--teal-dark); font-weight: 600; }

.q-tabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px; }
.q-tab { padding: 7px 14px; border-radius: 6px; font-size: 0.78rem; font-weight: 600; cursor: pointer; border: 1.5px solid var(--bordo); color: var(--grigio); background: var(--bianco); transition: all .2s; }
.q-tab:hover { border-color: var(--teal); color: var(--teal-dark); }
.q-tab.active { background: var(--teal); color: var(--bianco); border-color: var(--teal); }

.q-panel { display: none; }
.q-panel.active { display: block; }

.q-sezione { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 12px; overflow: hidden; margin-bottom: 12px; }
.qs-header { padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: background .2s; }
.qs-header:hover { background: var(--teal-light); }
.qs-header.open { background: var(--teal-light); }
.qs-left { display: flex; align-items: center; gap: 10px; }
.qs-letter { width: 32px; height: 32px; background: var(--teal); color: var(--bianco); border-radius: 8px; display: grid; place-items: center; font-weight: 900; font-size: 0.85rem; flex-shrink: 0; }
.qs-name { font-size: 0.88rem; font-weight: 700; color: var(--blu); }
.qs-count { font-size: 0.68rem; color: var(--grigio); background: var(--bianco); padding: 2px 8px; border-radius: 4px; border: 1px solid var(--bordo); }
.qs-icon { color: var(--teal); font-size: 1rem; transition: transform .3s; }
.qs-header.open .qs-icon { transform: rotate(180deg); }
.qs-domande { display: none; padding: 0 18px 16px; }
.qs-header.open + .qs-domande { display: block; }
.domanda { padding: 10px 0; border-bottom: 1px solid var(--bordo); font-size: 0.82rem; color: var(--testo); display: flex; gap: 10px; align-items: flex-start; }
.domanda:last-child { border-bottom: none; }
.d-num { font-size: 0.72rem; font-weight: 700; color: var(--teal-dark); min-width: 28px; flex-shrink: 0; padding-top: 1px; }
.d-scala { margin-top: 6px; display: flex; gap: 4px; }
.d-scala span { width: 22px; height: 22px; border-radius: 4px; border: 1.5px solid var(--bordo); display: grid; place-items: center; font-size: 0.65rem; color: var(--grigio); cursor: pointer; transition: all .2s; }
.d-scala span:hover { background: var(--teal); color: var(--bianco); border-color: var(--teal); }
.d-scala span.negativo { border-color: #fca5a5; color: #ef4444; }
.d-scala span.negativo:hover { background: #ef4444; color: var(--bianco); }
.d-polarita { font-size: 0.62rem; color: #ef4444; font-weight: 600; margin-top: 4px; }

.q-footer { background: var(--teal-light); border: 1px solid var(--bordo); border-radius: 8px; padding: 14px 18px; margin-top: 16px; font-size: 0.78rem; color: var(--grigio); }
.q-footer strong { color: var(--teal-deep); }

/* =============================================
   OUTPUT / DELIVERABLE
   ============================================= */
#output { background: var(--grigio-bg); }
.output-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 28px; }
.output-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; text-align: center; transition: all .2s; }
.output-card:hover { box-shadow: 0 4px 20px rgba(61,191,171,.12); border-color: var(--teal); }
.oc-icon { font-size: 2rem; margin-bottom: 10px; }
.oc-title { font-size: 0.9rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.oc-desc { font-size: 0.78rem; color: var(--grigio); line-height: 1.6; }

/* Matrice interventi preview */
.matrice-preview { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; overflow-x: auto; }
.mp-title { font-size: 0.85rem; font-weight: 800; color: var(--blu); margin-bottom: 14px; }
.matrice-table { width: 100%; border-collapse: collapse; font-size: 0.72rem; }
.matrice-table th { padding: 6px 10px; text-align: center; font-weight: 700; font-size: 0.65rem; }
.matrice-table td { padding: 6px 10px; border: 1px solid var(--bordo); font-size: 0.72rem; }
.m-rosso { background: #fee2e2; }
.m-arancio { background: #fef3c7; }
.m-giallo { background: #fef9c3; }
.m-verde-chiaro { background: #d1fae5; }
.m-verde { background: #a7f3d0; }

/* =============================================
   CLIENTI
   ============================================= */
#clienti { background: var(--bianco); }
.clienti-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.cliente-card { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 10px; padding: 18px 14px; text-align: center; transition: all .2s; }
.cliente-card:hover { border-color: var(--teal); background: var(--teal-light); transform: translateY(-2px); box-shadow: 0 4px 16px rgba(61,191,171,.12); }
.cc-logo { display: inline-flex; align-items: center; justify-content: center; width: 56px; height: 56px; border-radius: 12px; color: #fff; font-size: 0.72rem; font-weight: 900; letter-spacing: .02em; margin: 0 auto 10px; line-height: 1.2; text-align: center; padding: 4px; }
.cc-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); margin-bottom: 4px; line-height: 1.3; }
.cc-tipo { font-size: 0.68rem; color: var(--grigio); line-height: 1.4; }

/* =============================================
   ECOSISTEMA
   ============================================= */
#ecosistema { background: var(--grigio-bg); }
.eco-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 12px; }
.eco-grid-2 { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; }
.eco-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; }
.eco-card:hover { border-color: var(--teal); box-shadow: 0 2px 12px rgba(61,191,171,.1); }
.eco-card.active { border-color: var(--accento); background: #fffbeb; }
.ec-icon { font-size: 1.3rem; margin-bottom: 6px; }
.ec-name { font-size: 0.8rem; font-weight: 700; color: var(--blu); margin-bottom: 3px; }
.ec-desc { font-size: 0.65rem; color: var(--grigio); }

/* =============================================
   CHI SIAMO
   ============================================= */
#chi-siamo { background: var(--bianco); }
.chi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
.at-card { background: var(--grigio-bg); border-radius: 12px; padding: 22px; border: 1px solid var(--bordo); }
.at-avatar { width: 44px; height: 44px; background: var(--teal); border-radius: 10px; display: grid; place-items: center; font-weight: 900; color: var(--bianco); margin-bottom: 12px; font-size: 0.9rem; }
.at-name { font-size: 0.95rem; font-weight: 800; color: var(--blu); margin-bottom: 3px; }
.at-ruolo { font-size: 0.72rem; color: var(--grigio); margin-bottom: 10px; }
.at-desc { font-size: 0.8rem; color: var(--testo); line-height: 1.7; margin-bottom: 12px; }
.at-links { display: flex; gap: 8px; flex-wrap: wrap; }
.at-links a { font-size: 0.72rem; color: var(--teal-dark); font-weight: 600; border: 1px solid var(--bordo); padding: 4px 10px; border-radius: 6px; transition: all .2s; }
.at-links a:hover { background: var(--teal); color: var(--bianco); border-color: var(--teal); }
.anac-box { background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 12px; padding: 20px; }
.anac-box h4 { font-size: 0.85rem; font-weight: 800; color: var(--teal-deep); margin-bottom: 8px; }
.anac-box p { font-size: 0.8rem; color: var(--testo); line-height: 1.6; margin-bottom: 10px; }
.anac-link { font-size: 0.78rem; color: var(--teal-dark); font-weight: 700; border: 1.5px solid var(--teal); padding: 8px 16px; border-radius: 8px; display: inline-block; transition: all .2s; }
.anac-link:hover { background: var(--teal); color: var(--bianco); }

/* =============================================
   CTA FINALE
   ============================================= */
.cta-finale { background: linear-gradient(135deg, var(--teal-deep) 0%, var(--teal-dark) 100%); color: var(--bianco); padding: 64px 20px; text-align: center; }
.cta-finale h2 { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; margin-bottom: 10px; }
.cta-finale p { color: rgba(255,255,255,.7); margin-bottom: 28px; max-width: 500px; margin-left: auto; margin-right: auto; }
.cta-btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.btn-cta-white { background: var(--bianco); color: var(--teal-deep); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; display: inline-block; transition: all .2s; }
.btn-cta-white:hover { background: #a7f3d0; }
.btn-cta-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.3); display: inline-block; transition: all .2s; }
.btn-cta-outline:hover { border-color: rgba(255,255,255,.7); }

/* =============================================
   FOOTER
   ============================================= */
.site-footer { background: #0d2420; color: rgba(255,255,255,.7); padding: 48px 20px 24px; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 32px; }
.footer-brand .brand-name { font-size: 1rem; font-weight: 800; color: var(--bianco); margin-bottom: 8px; }
.footer-brand p { font-size: 0.78rem; line-height: 1.6; margin-bottom: 8px; }
.footer-brand .brand-legal { font-size: 0.68rem; color: rgba(255,255,255,.3); }
.footer-col h4 { font-size: 0.72rem; font-weight: 700; color: var(--bianco); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 7px; }
.footer-col ul li a { font-size: 0.8rem; color: rgba(255,255,255,.55); transition: color .2s; }
.footer-col ul li a:hover { color: var(--teal); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,.1); padding-top: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
.footer-bottom .copy { font-size: 0.7rem; color: rgba(255,255,255,.3); }
.footer-legal { display: flex; gap: 16px; }
.footer-legal a { font-size: 0.7rem; color: rgba(255,255,255,.3); transition: color .2s; }
.footer-legal a:hover { color: rgba(255,255,255,.7); }

/* =============================================
   RESPONSIVE
   ============================================= */
@media (max-width: 960px) {
  .hero .inner { grid-template-columns: 1fr; }
  .hero-card { display: none; }
  .circolo-grid { grid-template-columns: 1fr; }
  .metodo-grid { grid-template-columns: 1fr; }
  .indici-grid { grid-template-columns: 1fr 1fr; }
  .output-grid { grid-template-columns: 1fr 1fr; }
  .eco-grid { grid-template-columns: repeat(3, 1fr); }
  .eco-grid-2 { grid-template-columns: repeat(2, 1fr); }
  .chi-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .navbar-links { display: none !important; }
  .hamburger { display: flex; }
  .topbar { display: none; }
  .timeline::before { left: 80px; }
  .timeline-item { grid-template-columns: 70px 1fr; }
  .clienti-grid { grid-template-columns: repeat(3, 1fr); }
  .footer-grid { grid-template-columns: 1fr 1fr; gap: 24px; }
  .output-grid { grid-template-columns: 1fr; }
  .nr-grid { grid-template-columns: 1fr; }
}
@media (max-width: 480px) {
  .eco-grid { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr; }
  .clienti-grid { grid-template-columns: 1fr 1fr; }
  .indici-grid { grid-template-columns: 1fr; }
}
</style>
<link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/tr-articoli.css?ver=1.1">
<?php wp_head(); ?>
</head>
<body <?php body_class('tr-pagina'); ?>>
<?php get_template_part('inc/tr-nav'); ?>
