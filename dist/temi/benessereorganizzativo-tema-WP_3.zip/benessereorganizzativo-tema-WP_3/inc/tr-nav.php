<!-- TOPBAR -->
<div class="topbar">
  <div class="inner">
    <a href="https://andreatroisi.it" class="topbar-personal">andreatroisi.it</a>
    <a href="https://www.troisiricerche.net">troisiricerche.net</a>
    <a href="https://www.t-index.it">TR-Index</a>
    <a href="https://www.mappaturadellecompetenze.it">Mappatura delle Competenze</a>
    <a href="https://www.registrodellecompetenze.it">Registro delle Competenze</a>
    <a href="https://www.customerpa.it">CustomerPA</a>
    <a href="https://www.benessereorganizzativo.it" class="topbar-active">BenessereOrg.</a>
    <a href="https://www.troisiformazione.it">Formazione</a>
    <a href="https://www.tiplive.it">TIP</a>
    <a href="https://www.troisiinsight.it">TroisiInsight</a>
    <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
    <a href="https://www.dibattito-pubblico.it">Dibattito Pubblico</a>
    <a href="https://www.voiceinhub.it">VoiceInHub</a>
    <a href="https://www.governancefinanziaria.it">Governance Fin.</a>
    <a href="https://www.consulenzainternazionalizzazione.it">Internazionalizzazione</a>
    <a href="https://www.benesseredigitalegiovani.it">BDG</a>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="navbar-brand">
      <div>
        <div class="brand-logo">Benessere<span>Organizzativo</span></div>
        <span class="brand-sub">Metodo ANAC · PA e Aziende · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="<?php echo esc_url(home_url('/')); ?>#normativa">Normativa</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#circolo">Metodo</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#questionario">Questionario ANAC</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#output">Output</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#clienti">Clienti</a>
      <a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a>
      <a href="<?php echo esc_url(home_url('/')); ?>#chi-siamo">Chi siamo</a>
      <a href="mailto:benessere@troisiricerche.it" class="btn-contatti">Scrivici</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi preventivo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
<div class="mobile-menu" id="mobile-menu">
  <a href="<?php echo esc_url(home_url('/')); ?>#normativa" onclick="closeMobileMenu()">Normativa</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#circolo" onclick="closeMobileMenu()">Metodo</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#questionario" onclick="closeMobileMenu()">Questionario ANAC</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#output" onclick="closeMobileMenu()">Output</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#clienti" onclick="closeMobileMenu()">Clienti</a>
  <a href="<?php echo home_url('/approfondimenti'); ?>" onclick="closeMobileMenu()">Approfondimenti</a>
  <a href="<?php echo esc_url(home_url('/')); ?>#chi-siamo" onclick="closeMobileMenu()">Chi siamo</a>
  <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo" onclick="closeMobileMenu()">Richiedi preventivo ↗</a>
</div>

<!-- HERO -->
