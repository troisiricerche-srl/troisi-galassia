<?php $q = bo_articoli(3); if ($q->have_posts()) : ?>
<link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/tr-articoli.css?ver=1.1">
<section class="tr-ultime" id="ultime-analisi">
  <div class="tr-ultime-inner">
    <div class="tr-ultime-head">
      <div>
        <div class="tr-ultime-label">Analisi e dati · un approfondimento ogni mercoledì</div>
        <h2 class="tr-ultime-title">Le ultime analisi sul benessere al lavoro</h2>
      </div>
      <a class="tr-ultime-tutte" href="<?php echo esc_url(bo_url_archivio()); ?>">Tutte le analisi →</a>
    </div>
    <div class="tr-ultime-grid">
      <?php while ($q->have_posts()) : $q->the_post(); ?>
      <a class="tr-card" href="<?php the_permalink(); ?>">
        <div class="tr-card-meta"><span class="tr-card-tag"><?php echo esc_html(bo_tema()); ?></span> <?php echo esc_html(get_the_date('j F Y')); ?></div>
        <h3><?php the_title(); ?></h3>
        <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 28, '…')); ?></p>
        <span class="tr-card-more">Leggi l'analisi →</span>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
<?php endif; ?>
