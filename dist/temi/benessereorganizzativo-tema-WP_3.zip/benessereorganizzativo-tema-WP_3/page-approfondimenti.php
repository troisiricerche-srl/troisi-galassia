<?php /* Template Name: Approfondimenti — Normativa e Benessere Organizzativo */ ?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Normativa Benessere Organizzativo: DVR, stress lavoro correlato, ANAC | Approfondimenti Troisi</title>
<meta name="description" content="Approfondimenti su normativa benessere organizzativo, DVR stress lavoro correlato obbligo, compliance enti pubblici e audit benessere organizzativo. Scopri cosa verifica l'Ispettorato del Lavoro. Metodo Troisi.">
<meta name="keywords" content="benessere organizzativo normativa, benessere organizzativo pubblica amministrazione, stress lavoro correlato normativa, compliance lavoro enti pubblici, verifica benessere organizzativo, audit benessere organizzativo, normativa INAIL stress lavoro correlato, ANAC benessere organizzativo, DVR stress lavoro correlato obbligo, rischio ispettorato lavoro, cosa controlla ispettorato del lavoro, il benessere organizzativo è obbligatorio, DVR stress lavoro correlato, indagine benessere organizzativo obbligatoria, sanzioni DVR incompleto, D.Lgs. 81/2008 stress lavoro correlato, D.Lgs. 150/2009 benessere organizzativo, linee guida INAIL stress lavoro, Corte dei Conti responsabilità amministratori, valutazione SLC obbligatoria, OIV validazione benessere organizzativo, PIAO benessere organizzativo, Metodo Troisi, Troisi Ricerche, piattaforma TIP, benessere organizzativo Comune, benessere organizzativo ASL, benessere organizzativo scuola">
<link rel="canonical" href="https://www.benessereorganizzativo.it/approfondimenti">
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large">
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">

<!-- Open Graph -->
<meta property="og:type" content="website">
<meta property="og:title" content="Approfondimenti — Normativa e Benessere Organizzativo | Troisi Ricerche">
<meta property="og:description" content="Guide, articoli e analisi su DVR, stress lavoro-correlato, ANAC e rischio ispettivo. Il riferimento nazionale sul Benessere Organizzativo — Metodo Troisi.">
<meta property="og:url" content="https://www.benessereorganizzativo.it/approfondimenti">
<meta property="og:site_name" content="BenessereOrganizzativo.it">
<meta property="og:image" content="https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/blog-ispettorato-lavoro-bo.png">

<!-- Twitter/X Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Approfondimenti — Normativa e Benessere Organizzativo">
<meta name="twitter:description" content="Guide e articoli su DVR, stress lavoro-correlato, ANAC e rischio ispettivo. Metodo Troisi — Troisi Ricerche.">

<!-- JSON-LD -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Blog",
  "name": "Approfondimenti — Normativa Benessere Organizzativo",
  "url": "https://www.benessereorganizzativo.it/approfondimenti",
  "description": "Guide e articoli su benessere organizzativo normativa, DVR stress lavoro correlato obbligo, compliance enti pubblici e audit benessere organizzativo. Metodo Troisi — Troisi Ricerche S.r.l.",
  "inLanguage": "it-IT",
  "publisher": {
    "@type": "Organization",
    "name": "Troisi Ricerche S.r.l.",
    "url": "https://www.benessereorganizzativo.it",
    "logo": { "@type": "ImageObject", "url": "https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/favicon.png" }
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Il benessere organizzativo è obbligatorio?",
      "acceptedAnswer": { "@type": "Answer", "text": "Sì. Per la PA è obbligatorio ai sensi del D.Lgs. 150/2009 (indagine annuale con metodo ANAC). Per tutti è obbligatorio il D.Lgs. 81/2008 che impone la valutazione dello stress lavoro-correlato nel DVR." }
    },
    {
      "@type": "Question",
      "name": "Cosa dice la legge sul benessere organizzativo?",
      "acceptedAnswer": { "@type": "Answer", "text": "Le norme principali sono: D.Lgs. 81/2008 art. 28 (DVR e stress SLC), D.Lgs. 150/2009 art. 14 (indagine annuale PA), linee guida INAIL sulla valutazione SLC, modello ANAC a 17 sezioni come standard metodologico." }
    },
    {
      "@type": "Question",
      "name": "Quando è obbligatoria l'indagine benessere organizzativo?",
      "acceptedAnswer": { "@type": "Answer", "text": "Per la PA: ogni anno, con integrazione nella Relazione sulla Performance e validazione OIV. Per tutti: la valutazione SLC nel DVR deve essere aggiornata periodicamente o al variare delle condizioni di rischio." }
    },
    {
      "@type": "Question",
      "name": "Cosa controlla l'ispettorato del lavoro sul benessere organizzativo?",
      "acceptedAnswer": { "@type": "Answer", "text": "L'Ispettorato verifica: DVR con sezione SLC aggiornata, metodo di rilevazione validato (ANAC/INAIL), coinvolgimento RSPP e medico competente, piano di miglioramento documentato, comunicazione ai dipendenti." }
    },
    {
      "@type": "Question",
      "name": "Cosa deve contenere il DVR per essere completo?",
      "acceptedAnswer": { "@type": "Answer", "text": "Il DVR deve includere la valutazione dello stress lavoro-correlato (SLC) ai sensi del D.Lgs. 81/2008 art. 28. Deve indicare il metodo usato, il coinvolgimento di RSPP e medico competente, e il piano di azioni correttive. Un DVR senza SLC è incompleto e sanzionabile." }
    }
  ]
}
</script>

<style>
:root {
  --teal:#3dbfab; --teal-dark:#2a9d8a; --teal-deep:#1a7a6b;
  --teal-light:#e8f7f4; --teal-mid:#b2e8e0;
  --blu:#1a3a5c; --accento:#e8a020; --viola:#7c3aed;
  --testo:#1a2e2a; --grigio:#6b7280;
  --grigio-bg:#f8fafa; --bordo:#d1ece8;
  --bianco:#ffffff; --verde:#16a34a;
  --rosso:#dc2626;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;overflow-x:hidden;font-family:'Segoe UI',system-ui,sans-serif;color:var(--testo);background:var(--grigio-bg);line-height:1.6}
a{text-decoration:none;color:inherit}
img{max-width:100%}

/* NAVBAR */
.navbar{background:var(--bianco);border-bottom:3px solid var(--teal);position:sticky;top:0;z-index:100;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.navbar .inner{max-width:1200px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;height:64px}
.navbar-brand{display:flex;align-items:center;gap:10px;text-decoration:none}
.brand-logo{font-size:1.05rem;font-weight:800;color:var(--teal-deep)}
.brand-logo span{color:var(--teal)}
.brand-sub{font-size:.62rem;color:var(--grigio);letter-spacing:.04em;display:block;margin-top:1px}
.navbar-links{display:flex;gap:4px;align-items:center}
.navbar-links a{padding:6px 10px;border-radius:6px;font-size:.82rem;color:var(--testo);font-weight:500;transition:all .2s}
.navbar-links a:hover{background:var(--teal-light);color:var(--teal-deep)}
.navbar-links .nav-active{background:var(--teal-light);color:var(--teal-deep);font-weight:700}
.navbar-links .btn-contatti{border:1.5px solid var(--bordo);color:var(--teal-deep);font-weight:600}
.navbar-links .btn-demo{background:var(--teal);color:var(--bianco)!important;font-weight:700;padding:7px 16px}
.navbar-links .btn-demo:hover{background:var(--teal-dark)}
.hamburger{display:none;flex-direction:column;gap:5px;background:none;border:none;cursor:pointer;padding:6px}
.hamburger span{display:block;width:22px;height:2px;background:var(--testo);border-radius:2px;transition:.3s}
.mobile-menu{display:none;position:fixed;top:64px;left:0;right:0;bottom:0;background:var(--bianco);z-index:99;padding:20px;flex-direction:column;gap:4px;overflow-y:auto}
.mobile-menu.open{display:flex}
.mobile-menu a{padding:14px 16px;border-radius:8px;font-size:1rem;color:var(--testo);font-weight:500;border-bottom:1px solid var(--bordo)}
.mobile-menu .nav-active{background:var(--teal-light);color:var(--teal-deep);font-weight:700}
.mobile-menu .btn-demo{background:var(--teal);color:var(--bianco)!important;text-align:center;margin-top:8px;border-bottom:none}
@media(max-width:900px){.navbar-links{display:none!important}.hamburger{display:flex}}

/* BREADCRUMB */
.breadcrumb{max-width:1100px;margin:0 auto;padding:12px 20px;font-size:.78rem;color:var(--grigio);display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.breadcrumb a{color:var(--teal-deep);font-weight:500}
.breadcrumb a:hover{text-decoration:underline}
.breadcrumb-sep{color:var(--bordo)}

/* HERO */
.blog-hero{background:linear-gradient(135deg,#1a7a6b 0%,#1e3a8a 60%,#7c3aed 100%);color:#fff;padding:52px 20px 44px;text-align:center;position:relative;overflow:hidden}
.blog-hero::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 40px,rgba(255,255,255,.015) 40px,rgba(255,255,255,.015) 41px)}
.bh-eyebrow{display:inline-block;background:rgba(232,160,32,.2);border:1px solid rgba(232,160,32,.4);color:#e8a020;font-size:.68rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:5px 16px;border-radius:20px;margin-bottom:14px;position:relative}
.bh-title{font-size:clamp(1.6rem,3.5vw,2.4rem);font-weight:900;line-height:1.2;margin-bottom:10px;position:relative}
.bh-title em{color:#e8a020;font-style:normal}
.bh-sub{font-size:.92rem;color:rgba(255,255,255,.78);max-width:560px;margin:0 auto 18px;line-height:1.7;position:relative}
.bh-pills{display:flex;gap:7px;justify-content:center;flex-wrap:wrap;position:relative}
.bh-pill{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.22);color:rgba(255,255,255,.85);font-size:.68rem;font-weight:600;padding:4px 12px;border-radius:20px}

/* MAIN LAYOUT */
.blog-main{max-width:1100px;margin:0 auto;padding:36px 20px 64px;display:grid;grid-template-columns:1fr 300px;gap:32px}
@media(max-width:860px){.blog-main{grid-template-columns:1fr;padding:24px 16px 48px}}

/* ARTICLES LIST */
.articles-grid{display:flex;flex-direction:column;gap:28px}
.blog-card{background:var(--bianco);border:1.5px solid var(--bordo);border-radius:14px;overflow:hidden;box-shadow:0 2px 16px rgba(26,122,107,.06);transition:transform .2s,box-shadow .2s;display:flex;flex-direction:column}
.blog-card:hover{transform:translateY(-3px);box-shadow:0 8px 28px rgba(26,122,107,.12)}
.bc-img{width:100%;height:220px;overflow:hidden;background:linear-gradient(135deg,#1a7a6b,#1e3a8a);flex-shrink:0;position:relative}
.bc-img img,.bc-img svg{width:100%;height:100%;object-fit:cover}
.bc-img-placeholder{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:3rem}
.bc-body{padding:22px 24px 20px;flex:1;display:flex;flex-direction:column}
.bc-meta{display:flex;gap:10px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
.bc-tag{font-size:.65rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;background:var(--teal-light);color:var(--teal-deep);border:1px solid var(--teal-mid);padding:3px 10px;border-radius:20px}
.bc-date{font-size:.72rem;color:var(--grigio)}
.bc-title{font-size:1.15rem;font-weight:800;color:var(--testo);line-height:1.3;margin-bottom:8px}
.bc-title:hover{color:var(--teal-deep)}
.bc-desc{font-size:.87rem;color:var(--grigio);line-height:1.65;flex:1;margin-bottom:16px}
.bc-footer{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
.bc-norm{font-size:.67rem;color:var(--grigio);font-style:italic}
.bc-cta{display:inline-flex;align-items:center;gap:6px;background:var(--teal-dark);color:#fff;font-size:.82rem;font-weight:700;padding:9px 18px;border-radius:8px;transition:all .2s}
.bc-cta:hover{background:var(--teal-deep);transform:translateX(2px)}

/* COMING SOON CARD */
.bc-soon{background:var(--grigio-bg);border:1.5px dashed var(--bordo);border-radius:14px;padding:28px 24px;display:flex;align-items:center;gap:14px}
.bc-soon-icon{font-size:1.8rem;flex-shrink:0}
.bc-soon h3{font-size:.92rem;font-weight:700;color:var(--grigio);margin-bottom:3px}
.bc-soon p{font-size:.8rem;color:var(--grigio);line-height:1.5}

/* SIDEBAR */
.blog-sidebar{display:flex;flex-direction:column;gap:20px}
.sb-card{background:var(--bianco);border:1.5px solid var(--bordo);border-radius:12px;padding:18px;box-shadow:0 2px 10px rgba(0,0,0,.04)}
.sb-title{font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--teal-deep);margin-bottom:12px;display:flex;align-items:center;gap:6px}
.sb-tool{background:linear-gradient(135deg,#1a7a6b,#1e3a8a);border-radius:12px;padding:18px;color:#fff}
.sb-tool .sb-title{color:rgba(255,255,255,.6)}
.sb-tool p{font-size:.82rem;color:rgba(255,255,255,.8);line-height:1.55;margin-bottom:12px}
.sb-tool-cta{display:block;background:#e8a020;color:var(--testo)!important;font-weight:800;font-size:.85rem;padding:11px 16px;border-radius:8px;text-align:center;transition:all .2s}
.sb-tool-cta:hover{background:#f5c842}
.sb-links ul{list-style:none;display:flex;flex-direction:column;gap:6px}
.sb-links li a{font-size:.83rem;color:var(--teal-deep);font-weight:500;display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid var(--teal-light);transition:color .15s}
.sb-links li a:hover{color:var(--teal-dark)}
.sb-norm li{font-size:.79rem;color:var(--grigio);padding:5px 0;border-bottom:1px solid var(--teal-light);line-height:1.4;display:flex;gap:8px;align-items:flex-start}
.sb-norm li:last-child{border-bottom:none}
.sb-brand{background:var(--teal-light);border:1.5px solid var(--teal-mid);border-radius:12px;padding:16px}
.sb-brand h4{font-size:.88rem;font-weight:800;color:var(--teal-deep);margin-bottom:6px}
.sb-brand p{font-size:.78rem;color:var(--grigio);line-height:1.5;margin-bottom:8px}
.sb-brand a{font-size:.78rem;color:var(--teal-deep);font-weight:600;text-decoration:underline}

/* FOOTER */
.site-footer{background:#0d2420;color:rgba(255,255,255,.7);padding:48px 20px 24px}
.footer-inner{max-width:1100px;margin:0 auto}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:32px;margin-bottom:32px}
.footer-brand .brand-name{font-size:1rem;font-weight:800;color:#fff;margin-bottom:8px}
.footer-brand p{font-size:.78rem;line-height:1.6;margin-bottom:8px}
.brand-legal{font-size:.72rem;color:rgba(255,255,255,.4)}
.footer-col h4{font-size:.72rem;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px}
.footer-col ul{list-style:none;display:flex;flex-direction:column;gap:7px}
.footer-col ul a{font-size:.8rem;color:rgba(255,255,255,.6);transition:color .2s}
.footer-col ul a:hover{color:var(--teal)}
.footer-bottom{border-top:1px solid rgba(255,255,255,.1);padding-top:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;font-size:.75rem}
.footer-legal{display:flex;gap:14px}
.footer-legal a{color:rgba(255,255,255,.4);transition:color .2s}
.footer-legal a:hover{color:var(--teal)}
@media(max-width:768px){
  .footer-grid{grid-template-columns:1fr 1fr;gap:20px}
  .footer-bottom{flex-direction:column;text-align:center}
}
@media(max-width:480px){
  .footer-grid{grid-template-columns:1fr}
  .bc-body{padding:16px}
  .bc-footer{flex-direction:column;align-items:flex-start}
  .bc-cta{width:100%;justify-content:center}
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="https://www.benessereorganizzativo.it" class="navbar-brand">
      <div>
        <div class="brand-logo">Benessere<span>Organizzativo</span></div>
        <span class="brand-sub">Metodo ANAC · PA e Aziende · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="https://www.benessereorganizzativo.it/#normativa">Normativa</a>
      <a href="https://www.benessereorganizzativo.it/#circolo">Metodo</a>
      <a href="https://www.benessereorganizzativo.it/#questionario">Questionario ANAC</a>
      <a href="https://www.benessereorganizzativo.it/#output">Output</a>
      <a href="https://www.benessereorganizzativo.it/#clienti">Clienti</a>
      <a href="https://www.benessereorganizzativo.it/#chi-siamo">Chi siamo</a>
      <a href="<?php echo home_url('/approfondimenti'); ?>" class="nav-active">Approfondimenti</a>
      <a href="mailto:benessere@troisiricerche.it" class="btn-contatti">Scrivici</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi preventivo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
<div class="mobile-menu" id="mobile-menu">
  <a href="https://www.benessereorganizzativo.it/#normativa" onclick="closeMobileMenu()">Normativa</a>
  <a href="https://www.benessereorganizzativo.it/#circolo" onclick="closeMobileMenu()">Metodo</a>
  <a href="https://www.benessereorganizzativo.it/#questionario" onclick="closeMobileMenu()">Questionario ANAC</a>
  <a href="https://www.benessereorganizzativo.it/#output" onclick="closeMobileMenu()">Output</a>
  <a href="https://www.benessereorganizzativo.it/#clienti" onclick="closeMobileMenu()">Clienti</a>
  <a href="https://www.benessereorganizzativo.it/#chi-siamo" onclick="closeMobileMenu()">Chi siamo</a>
  <a href="<?php echo home_url('/approfondimenti'); ?>" class="nav-active" onclick="closeMobileMenu()">Approfondimenti</a>
  <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo" onclick="closeMobileMenu()">Richiedi preventivo ↗</a>
</div>

<!-- HERO -->
<div class="blog-hero">
  <div class="bh-eyebrow">📚 Normativa · Compliance · Benessere Organizzativo</div>
  <h1 class="bh-title">Benessere Organizzativo: <em>normativa, DVR</em><br>e stress lavoro correlato</h1>
  <p class="bh-sub">Il benessere organizzativo è un obbligo normativo (D.Lgs. 81/2008 e D.Lgs. 150/2009). Guide su DVR, stress lavoro correlato, compliance enti pubblici, audit benessere organizzativo e rischio ispettorato lavoro. Il riferimento nazionale — <strong style="color:#fff">Metodo Troisi</strong>.</p>
  <div class="bh-pills">
    <span class="bh-pill">D.Lgs. 81/2008</span>
    <span class="bh-pill">D.Lgs. 150/2009</span>
    <span class="bh-pill">ANAC · DVR</span>
    <span class="bh-pill">Ispettorato del Lavoro</span>
    <span class="bh-pill">OIV · RSPP</span>
    <span class="bh-pill">Corte dei Conti</span>
  </div>
</div>


<!-- SEZIONE DOMANDE AI UNDER HERO — SEO / AI citability -->
<div style="background:#fff;border-bottom:1px solid #d1ece8;padding:16px 20px">
  <div style="max-width:1100px;margin:0 auto">
    <div style="font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#1a7a6b;margin-bottom:10px">📋 Risposte rapide — domande frequenti</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a href="#il-bo-e-obbligatorio" style="font-size:.8rem;background:#e8f7f4;border:1px solid #b2e8e0;color:#1a7a6b;padding:5px 12px;border-radius:20px;font-weight:600;text-decoration:none">Il BO è obbligatorio?</a>
      <a href="#cosa-dice-la-legge" style="font-size:.8rem;background:#e8f7f4;border:1px solid #b2e8e0;color:#1a7a6b;padding:5px 12px;border-radius:20px;font-weight:600;text-decoration:none">Cosa dice la legge?</a>
      <a href="#quando-obbligatoria" style="font-size:.8rem;background:#e8f7f4;border:1px solid #b2e8e0;color:#1a7a6b;padding:5px 12px;border-radius:20px;font-weight:600;text-decoration:none">Quando è obbligatoria l'indagine?</a>
      <a href="#cosa-controlla-ispettorato" style="font-size:.8rem;background:#e8f7f4;border:1px solid #b2e8e0;color:#1a7a6b;padding:5px 12px;border-radius:20px;font-weight:600;text-decoration:none">Cosa controlla l'Ispettorato?</a>
      <a href="#cosa-deve-contenere-dvr" style="font-size:.8rem;background:#e8f7f4;border:1px solid #b2e8e0;color:#1a7a6b;padding:5px 12px;border-radius:20px;font-weight:600;text-decoration:none">Cosa deve contenere il DVR?</a>
    </div>
  </div>
</div>
<!-- BREADCRUMB -->
<div class="breadcrumb">
  <a href="https://www.benessereorganizzativo.it">Home</a>
  <span class="breadcrumb-sep">›</span>
  <span>Approfondimenti</span>
</div>

<!-- MAIN CONTENT -->
<div class="blog-main">

  <!-- ARTICLES -->
  <div class="articles-grid">

    <!-- ARTICOLO 1 — ISPETTORATO DEL LAVORO -->
    <article class="blog-card">
      <div class="bc-img">
        <img src="https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/blog-ispettorato-lavoro-bo.png"
             alt="Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo — illustrazione normativa"
             width="700" height="220" loading="eager">
      </div>
      <div class="bc-body">
        <div class="bc-meta">
          <span class="bc-tag">Normativa · Ispezione</span>
          <span class="bc-date">📅 Marzo 2026</span>
          <span class="bc-tag" style="background:#fef2f2;color:#dc2626;border-color:#fecaca">⚠️ Rischio Ispettivo</span>
        </div>
        <h2 class="bc-title">
          <a href="<?php echo home_url('/ispettorato-lavoro-benessere-organizzativo'); ?>">
            Cosa controlla davvero l'Ispettorato del Lavoro sul benessere organizzativo
          </a>
        </h2>
        <p class="bc-desc">DVR, stress lavoro-correlato, indagini obbligatorie e responsabilità del datore di lavoro: cosa viene verificato durante un'ispezione sul Benessere Organizzativo nella PA e nelle aziende private. Cosa rischi se non sei in regola con il D.Lgs. 81/2008 e il D.Lgs. 150/2009.</p>
        <div class="bc-footer">
          <span class="bc-norm">D.Lgs. 81/2008 · D.Lgs. 150/2009 · ANAC · INAIL</span>
          <a href="<?php echo home_url('/ispettorato-lavoro-benessere-organizzativo'); ?>" class="bc-cta">Leggi l'articolo →</a>
        </div>
      </div>
    </article>

    <!-- ARTICOLO 2 — Coming soon -->
    <div class="bc-soon">
      <div class="bc-soon-icon">📝</div>
      <div>
        <h3>In arrivo: DVR e stress lavoro-correlato — guida completa per la PA</h3>
        <p>Come integrare correttamente la valutazione SLC nel DVR, cosa richiedono le linee guida INAIL e come strutturare la documentazione difendibile davanti all'Ispettorato del Lavoro.</p>
      </div>
    </div>

    <!-- ARTICOLO 3 — Coming soon -->
    <div class="bc-soon">
      <div class="bc-soon-icon">📝</div>
      <div>
        <h3>In arrivo: Questionario ANAC — 17 sezioni, campionamento e tracciabilità</h3>
        <p>Guida metodologica al questionario ANAC per il Benessere Organizzativo: come si struttura, chi deve condurlo, come si valida il campione con la formula di Cochran e come si presentano i risultati all'OIV.</p>
      </div>
    </div>

    <!-- ARTICOLO 4 — Coming soon -->
    <div class="bc-soon">
      <div class="bc-soon-icon">📝</div>
      <div>
        <h3>In arrivo: OIV e Relazione sulla Performance — il ruolo del BO</h3>
        <p>Come l'indagine sul Benessere Organizzativo si integra nel ciclo della performance della PA, cosa deve validare l'OIV e come evitare il blocco dei premi al personale.</p>
      </div>
    </div>


    <!-- FAQ AI-READY — Benessere Organizzativo Normativa -->
    <div style="background:#fff;border:1.5px solid #d1ece8;border-radius:14px;padding:24px;margin-top:8px" id="faq-blog">
      <h2 style="font-size:1rem;font-weight:800;color:#1a3a5c;margin-bottom:16px">📋 Domande frequenti — Normativa benessere organizzativo</h2>

      <div id="il-bo-e-obbligatorio" style="border-bottom:1px solid #e8f7f4;padding:12px 0">
        <h3 style="font-size:.92rem;font-weight:700;color:#1a2e2a;margin-bottom:5px">Il benessere organizzativo è obbligatorio?</h3>
        <p style="font-size:.84rem;color:#6b7280;line-height:1.6">Sì. <strong>Per la PA</strong>: il D.Lgs. 150/2009, art. 14 c.5, impone indagini annuali. <strong>Per tutti</strong>: il D.Lgs. 81/2008, art. 28, richiede la valutazione dello stress lavoro-correlato nel DVR. Un DVR senza questa sezione è incompleto e sanzionabile.</p>
      </div>

      <div id="cosa-dice-la-legge" style="border-bottom:1px solid #e8f7f4;padding:12px 0">
        <h3 style="font-size:.92rem;font-weight:700;color:#1a2e2a;margin-bottom:5px">Cosa dice la legge sul benessere organizzativo?</h3>
        <p style="font-size:.84rem;color:#6b7280;line-height:1.6">Le principali norme sono: <strong>D.Lgs. 81/2008</strong> (art. 28 — DVR e stress SLC, obbligatorio per tutti), <strong>D.Lgs. 150/2009</strong> (art. 14 c.5 — indagine annuale per PA), <strong>linee guida INAIL</strong> sulla valutazione SLC, <strong>modello ANAC</strong> a 17 sezioni come standard metodologico, <strong>PIAO 2022</strong> per le PA con più di 50 dipendenti.</p>
      </div>

      <div id="quando-obbligatoria" style="border-bottom:1px solid #e8f7f4;padding:12px 0">
        <h3 style="font-size:.92rem;font-weight:700;color:#1a2e2a;margin-bottom:5px">Quando è obbligatoria l'indagine benessere organizzativo?</h3>
        <p style="font-size:.84rem;color:#6b7280;line-height:1.6">Per la PA: <strong>ogni anno</strong>, con integrazione nella Relazione sulla Performance e validazione da parte dell'OIV. In assenza di indagine, la Relazione non è valida e i premi al personale possono essere bloccati. Per i privati: la valutazione SLC deve essere aggiornata periodicamente o al variare delle condizioni di rischio.</p>
      </div>

      <div id="cosa-controlla-ispettorato" style="border-bottom:1px solid #e8f7f4;padding:12px 0">
        <h3 style="font-size:.92rem;font-weight:700;color:#1a2e2a;margin-bottom:5px">Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo?</h3>
        <p style="font-size:.84rem;color:#6b7280;line-height:1.6">L'Ispettorato Nazionale del Lavoro verifica: <strong>DVR con sezione SLC aggiornata</strong>, metodo di rilevazione validato (ANAC/INAIL), coinvolgimento formale di RSPP e medico competente, piano di miglioramento documentato, coinvolgimento OIV (PA), comunicazione ai dipendenti dei risultati.</p>
      </div>

      <div id="cosa-deve-contenere-dvr" style="padding:12px 0">
        <h3 style="font-size:.92rem;font-weight:700;color:#1a2e2a;margin-bottom:5px">Cosa deve contenere il DVR per essere completo?</h3>
        <p style="font-size:.84rem;color:#6b7280;line-height:1.6">Il DVR deve includere la <strong>valutazione dello stress lavoro-correlato</strong> (D.Lgs. 81/2008, art. 28), il metodo usato, il coinvolgimento di RSPP e medico competente, e un piano di azioni correttive documentato. La valutazione può essere preliminare o approfondita (se emergono indicatori di rischio). Un DVR senza SLC è sanzionabile da €1.000 a €3.000.</p>
      </div>

    </div>

  </div><!-- /articles-grid -->

  <!-- SIDEBAR -->
  <aside class="blog-sidebar">

    <!-- TOOL CTA -->
    <div class="sb-tool">
      <div class="sb-title">🔬 Diagnosi gratuita</div>
      <p><strong style="color:#fff">Il tuo ente è esposto al rischio ispettivo?</strong> Scoprilo in 8 punti con la Diagnosi BO — Metodo Troisi. Score immediato e report con azioni correttive.</p>
      <a href="<?php echo home_url('/sei-in-regola-bo'); ?>" class="sb-tool-cta">⚖️ Avvia la diagnosi →</a>
    </div>

    <!-- LINK ARTICOLI -->
    <div class="sb-card sb-links">
      <div class="sb-title">📚 Articoli disponibili</div>
      <ul>
        <li><a href="<?php echo home_url('/ispettorato-lavoro-benessere-organizzativo'); ?>">→ Cosa controlla l'Ispettorato del Lavoro sul BO</a></li>
        <li><a href="#" style="color:var(--grigio);cursor:default">→ DVR e stress SLC — guida PA <em style="font-size:.7rem">(presto)</em></a></li>
        <li><a href="#" style="color:var(--grigio);cursor:default">→ Questionario ANAC — 17 sezioni <em style="font-size:.7rem">(presto)</em></a></li>
        <li><a href="#" style="color:var(--grigio);cursor:default">→ OIV e Relazione Performance <em style="font-size:.7rem">(presto)</em></a></li>
      </ul>
    </div>

    <!-- NORMATIVA QUICK REF -->
    <div class="sb-card">
      <div class="sb-title">⚖️ Riferimenti normativi</div>
      <ul class="sb-norm">
        <li><span>📋</span><span><strong>D.Lgs. 81/2008 art. 28</strong> — Valutazione stress lavoro-correlato nel DVR</span></li>
        <li><span>📋</span><span><strong>D.Lgs. 150/2009 art. 14</strong> — Indagine BO annuale nella PA</span></li>
        <li><span>📋</span><span><strong>Linee guida DFP · ANAC</strong> — Questionario 17 sezioni</span></li>
        <li><span>📋</span><span><strong>Accordo Europeo 2004</strong> — Stress lavoro-correlato</span></li>
        <li><span>📋</span><span><strong>Linee guida INAIL</strong> — Valutazione preliminare + approfondita</span></li>
        <li><span>📋</span><span><strong>PIAO 2022</strong> — Integrazione BO nel Piano</span></li>
      </ul>
    </div>

    <!-- BRAND BOX -->
    <div class="sb-brand">
      <h4>Metodo Troisi · Troisi Ricerche</h4>
      <p>Oltre 20 anni di ricerca sul Benessere Organizzativo nella PA e nelle aziende. Accreditati MIUR. Piattaforma TIP per survey e dashboard BO.</p>
      <p style="margin-top:6px"><a href="https://tiplive.it" target="_blank">→ tiplive.it — Piattaforma TIP</a></p>
      <p><a href="https://www.troisiricerche.net" target="_blank">→ troisiricerche.net</a></p>
    </div>

  </aside>

</div><!-- /blog-main -->

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">BenessereOrganizzativo.it</div>
        <p>Piattaforma per la misurazione del Benessere Organizzativo nella PA e nelle aziende. Metodo Troisi Ricerche · Riconosciuto da ANAC.</p>
        <p class="brand-legal">Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari · P.IVA 07216100722</p>
      </div>
      <div class="footer-col">
        <h4>Il sito</h4>
        <ul>
          <li><a href="https://www.benessereorganizzativo.it/#normativa">Normativa e timeline</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#circolo">Il circolo virtuoso</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#metodo">Metodologia</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#questionario">Questionario ANAC</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#output">Output</a></li>
          <li><a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Galassia Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">troisiricerche.net</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.customerpa.it" target="_blank">CustomerPA</a></li>
          <li><a href="https://tiplive.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una call</a></li>
          <li><a href="mailto:benessere@troisiricerche.it">benessere@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a></li>
          <li><a href="tel:800644046">800 644 046</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 BenessereOrganizzativo.it · Troisi Ricerche S.r.l. Unipersonale</div>
      <div class="footer-legal" id="iubenda-footer-links"></div>
      <script type="text/javascript" src="https://embeds.iubenda.com/widgets/946ac756-6db6-11ee-8bfc-5ad8d8c564c0.js"></script>
    </div>
  </div>
</footer>

<script>
function toggleMobileMenu(){
  const m=document.getElementById('mobile-menu');
  const b=document.getElementById('hamburger-btn');
  m.classList.toggle('open');
  b.classList.toggle('open');
  document.body.style.overflow=m.classList.contains('open')?'hidden':'';
}
function closeMobileMenu(){
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow='';
}
</script>

<!-- SEO hidden keywords -->
<div style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true">
benessere organizzativo benessere organizzativo aziendale benessere organizzativo pubblica amministrazione benessere organizzativo aziende organizational wellbeing workplace wellbeing employee wellbeing benessere nei luoghi di lavoro qualità della vita lavorativa clima organizzativo analisi clima aziendale survey clima aziendale misurazione clima organizzativo stress lavoro correlato valutazione stress lavoro correlato rischio psicosociale lavoro employee survey employee satisfaction survey employee engagement survey indagine dipendenti questionario benessere organizzativo performance organizzativa organizational performance efficienza organizzativa employee engagement employee experience motivazione dipendenti organizational analytics HR analytics workplace analytics organizational wellbeing index organizational climate index indicatori benessere organizzativo benchmark clima aziendale benessere organizzativo Italia benessere organizzativo aziende italiane benessere organizzativo enti pubblici benessere organizzativo comuni benessere organizzativo università smart working benessere organizzativo digital workplace come misurare il benessere organizzativo come migliorare il clima aziendale strumenti per misurare il clima organizzativo consulenza benessere organizzativo organizational consulting Andrea Troisi Troisi Ricerche Metodo Troisi Troisi Organizational Wellbeing Model mappatura delle competenze registro delle competenze CustomerPA TR-Index TroisiInsight Mappatura delle Competenze Registro delle Competenze how to measure organizational wellbeing how to measure employee wellbeing organizational wellbeing indicators leadership organizzativa cultura organizzativa governance organizzativa benessere organizzativo digitalizzazione PA benessere organizzativo trasformazione digitale performance pubblica amministrazione valutazione enti pubblici troisi ricerche benessere organizzativo andrea troisi organizational wellbeing rischio ispettivo benessere organizzativo ispettorato lavoro benessere organizzativo DVR stress lavoro correlato PA ANAC questionario benessere organizzativo D.Lgs. 81/2008 benessere organizzativo D.Lgs. 150/2009 indagine BO OIV validazione benessere organizzativo PIAO benessere organizzativo diagnosi rischio ispettivo BO audit benessere organizzativo PA compliance benessere organizzativo enti pubblici piano miglioramento benessere organizzativo comunicazione dipendenti risultati BO periodicità indagine benessere organizzativo valutazione approfondita stress SLC responsabilità datore lavoro benessere organizzativo sanzioni mancata valutazione stress lavoro correlato Corte dei Conti benessere organizzativo PA RSPP benessere organizzativo medico competente stress lavoro correlato Accordo Europeo 2004 stress lavoro INAIL linee guida stress lavoro correlato benessere organizzativo Comune benessere organizzativo ASL benessere organizzativo scuola benessere organizzativo società in-house Score BO diagnosi istituzionale piattaforma TIP benessere organizzativo tiplive.it survey BO approfondimenti normativa benessere organizzativo blog benessere organizzativo PA cosa controlla ispettorato benessere organizzativo ispezione benessere organizzativo cosa succede relazione performance benessere organizzativo premi personale PA benessere organizzativo
</div>

<?php get_footer(); ?>
</body>
</html>
