<?php // /sei-in-regola-bo v6 — Troisi Ricerche ?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Diagnosi Rischio Ispettivo — Benessere Organizzativo · Metodo Troisi · Troisi Ricerche</title>
<meta name="description" content="Diagnosi ufficiale del rischio ispettivo sul Benessere Organizzativo. Verifica in 8 punti la conformità al D.Lgs. 81/2008, D.Lgs. 150/2009 e ANAC. Score BO gratuito. Metodo Troisi — Troisi Ricerche.">
<meta name="keywords" content="benessere organizzativo PA, rischio ispettorato lavoro, DVR stress lavoro correlato, compliance enti pubblici, ANAC benessere organizzativo, D.Lgs. 81/2008 PA, stress lavoro correlato comuni, audit benessere organizzativo, Metodo Troisi BO, Troisi Ricerche benessere organizzativo">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "Diagnosi Rischio Ispettivo — Benessere Organizzativo",
  "url": "https://www.benessereorganizzativo.it/sei-in-regola-bo",
  "description": "Diagnosi ufficiale del rischio ispettivo sul Benessere Organizzativo nella PA italiana. Score BO gratuito basato su D.Lgs. 81/2008, D.Lgs. 150/2009 e linee guida ANAC. Metodo Troisi — Troisi Ricerche S.r.l.",
  "applicationCategory": "GovernmentApplication",
  "operatingSystem": "Web",
  "offers": {"@type": "Offer", "price": "0", "priceCurrency": "EUR"},
  "provider": {"@type": "Organization", "name": "Troisi Ricerche S.r.l.", "url": "https://www.benessereorganizzativo.it"}
}
</script>
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
<style>

/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --teal:       #3dbfab;
  --teal-dark:  #2a9d8a;
  --teal-deep:  #1a7a6b;
  --teal-light: #e8f7f4;
  --teal-mid:   #b2e8e0;
  --blu:        #1a3a5c;
  --accento:    #e8a020;
  --testo:      #1a2e2a;
  --grigio:     #6b7280;
  --grigio-bg:  #f8fafa;
  --bordo:      #d1ece8;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --rosso:      #dc2626;
  --arancio:    #ea580c;
}


/* =============================================
   RESET & BASE
   ============================================= */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --teal:       #3dbfab;
  --teal-dark:  #2a9d8a;
  --teal-deep:  #1a7a6b;
  --teal-light: #e8f7f4;
  --teal-mid:   #b2e8e0;
  --blu:        #1a3a5c;
  --accento:    #e8a020;
  --testo:      #1a2e2a;
  --grigio:     #6b7280;
  --grigio-bg:  #f8fafa;
  --bordo:      #d1ece8;
  --bianco:     #ffffff;
  --verde:      #16a34a;
  --rosso:      #dc2626;
  --arancio:    #ea580c;
}
body { font-family: 'Segoe UI', system-ui, sans-serif; color: var(--testo); background: var(--bianco); line-height: 1.6; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; height: auto; }

/* =============================================
   TOPBAR
   ============================================= */
.topbar { background: var(--teal-deep); padding: 6px 0; font-size: 0.72rem; }
.topbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; gap: 14px; flex-wrap: wrap; align-items: center; }
.topbar a { color: rgba(255,255,255,.65); transition: color .2s; }
.topbar a:hover { color: var(--accento); }
.topbar a.topbar-personal { color: var(--accento); font-weight: 700; }
.topbar a.topbar-active { color: var(--bianco); font-weight: 700; }

/* =============================================
   NAVBAR
   ============================================= */
.navbar { background: var(--bianco); border-bottom: 3px solid var(--teal); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.07); }
.navbar .inner { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.navbar-brand { display: flex; align-items: center; gap: 10px; }
.brand-logo { font-size: 1.05rem; font-weight: 900; color: var(--teal-deep); line-height: 1.1; }
.brand-logo span { color: var(--teal); }
.brand-sub { font-size: 0.65rem; color: var(--grigio); display: block; }
.navbar-links { display: flex; gap: 4px; align-items: center; }
.navbar-links a { padding: 6px 10px; border-radius: 6px; font-size: 0.82rem; color: var(--testo); font-weight: 500; transition: all .2s; }
.navbar-links a:hover { background: var(--teal-light); color: var(--teal-deep); }
.navbar-links .btn-contatti { border: 1.5px solid var(--bordo); color: var(--teal-deep); font-weight: 600; }
.navbar-links .btn-demo { background: var(--teal); color: var(--bianco) !important; font-weight: 700; padding: 7px 16px; }
.navbar-links .btn-demo:hover { background: var(--teal-dark); }
.hamburger { display: none; flex-direction: column; justify-content: center; gap: 5px; cursor: pointer; padding: 8px; border: none; background: none; }
.hamburger span { display: block; width: 24px; height: 2px; background: var(--teal); border-radius: 2px; transition: all .3s; }
.hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.mobile-menu { display: none; position: fixed; top: 64px; left: 0; right: 0; bottom: 0; background: var(--bianco); z-index: 99; padding: 20px; flex-direction: column; gap: 4px; overflow-y: auto; }
.mobile-menu.open { display: flex; }
.mobile-menu a { padding: 14px 16px; border-radius: 8px; font-size: 1rem; color: var(--testo); font-weight: 500; border-bottom: 1px solid var(--bordo); }
.mobile-menu .btn-demo { background: var(--teal); color: var(--bianco) !important; text-align: center; margin-top: 8px; border-bottom: none; }

/* =============================================
   HERO
   ============================================= */
.hero { background: linear-gradient(135deg, var(--teal-deep) 0%, var(--teal-dark) 50%, var(--teal) 100%); color: var(--bianco); padding: 72px 20px 56px; position: relative; overflow: hidden; }
.hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 80% 20%, rgba(255,255,255,.06) 0%, transparent 60%); }
.btn-hero-primary:hover { background: #a7f3d0; }
.btn-hero-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.35); transition: all .2s; display: inline-block; }
.btn-hero-outline:hover { border-color: rgba(255,255,255,.7); }

/* Hero card */
.bo-score { font-size: 3.5rem; font-weight: 900; color: #a7f3d0; line-height: 1; margin-bottom: 4px; }
.bo-label { font-size: 0.75rem; color: rgba(255,255,255,.6); margin-bottom: 16px; }
.bo-dims { display: flex; flex-direction: column; gap: 8px; }
.bo-dim { display: flex; align-items: center; gap: 8px; }
.bo-dim .bd-label { font-size: 0.65rem; color: rgba(255,255,255,.6); flex: 1; }
.bo-dim .bd-bar { flex: 1; height: 4px; background: rgba(255,255,255,.12); border-radius: 2px; }
.bo-dim .bd-fill { height: 100%; border-radius: 2px; background: #a7f3d0; }
.bo-dim .bd-val { font-size: 0.7rem; color: rgba(255,255,255,.8); font-weight: 700; width: 28px; text-align: right; }
.hc-anac { margin-top: 14px; font-size: 0.65rem; color: rgba(255,255,255,.4); border-top: 1px solid rgba(255,255,255,.1); padding-top: 10px; }
.hc-anac strong { color: #a7f3d0; }

/* =============================================
   SEZIONI GENERALI
   ============================================= */
section { padding: 64px 20px; }
.section-inner { max-width: 1100px; margin: 0 auto; }
.section-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .1em; color: var(--teal-dark); font-weight: 700; margin-bottom: 8px; }
.section-title { font-size: clamp(1.4rem, 3vw, 2rem); font-weight: 800; color: var(--blu); margin-bottom: 12px; line-height: 1.2; }
.section-title em { color: var(--teal-dark); font-style: normal; }
.section-desc { color: var(--grigio); max-width: 680px; margin-bottom: 36px; line-height: 1.7; }

/* =============================================
   NORMATIVA — TIMELINE
   ============================================= */
#normativa { background: var(--grigio-bg); }
.tl-anno .anno { font-size: 1rem; font-weight: 900; color: var(--teal-dark); line-height: 1; }
.tl-anno .tipo { font-size: 0.6rem; text-transform: uppercase; letter-spacing: .06em; color: var(--grigio); margin-top: 2px; }
.tl-dot { position: absolute; right: -28px; top: 18px; width: 14px; height: 14px; background: var(--teal); border-radius: 50%; border: 3px solid var(--bianco); box-shadow: 0 0 0 2px var(--teal); z-index: 1; }
.tl-content { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px 18px; margin-left: 18px; border-left: 3px solid var(--teal); }
.tl-content .tc-decreto { font-size: 0.68rem; font-weight: 700; color: var(--teal-dark); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 4px; }
.tl-content .tc-titolo { font-size: 0.9rem; font-weight: 700; color: var(--blu); margin-bottom: 6px; }
.tl-content .tc-desc { font-size: 0.8rem; color: var(--grigio); line-height: 1.6; }
.tl-content .tc-tag { display: inline-block; margin-top: 8px; font-size: 0.65rem; font-weight: 700; padding: 3px 10px; border-radius: 4px; }
.tc-tag.obbligatorio { background: #dcfce7; color: #166534; }
.tc-tag.modificato { background: #fef9c3; color: #854d0e; }
.tc-tag.abrogato { background: #fee2e2; color: #991b1b; }
.tc-tag.vigente { background: #e0f2fe; color: #0c4a6e; }
.tc-tag.stress { background: var(--teal-light); color: var(--teal-deep); }

.normativa-riepilogo { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px 24px; margin-top: 32px; border-left: 4px solid var(--teal); max-width: 860px; }
.nr-title { font-size: 0.85rem; font-weight: 800; color: var(--blu); margin-bottom: 10px; }
.nr-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.nr-item { text-align: center; padding: 12px; background: var(--grigio-bg); border-radius: 8px; }
.nr-item .ni-val { font-size: 1.4rem; font-weight: 900; color: var(--teal-dark); }
.nr-item .ni-lbl { font-size: 0.68rem; color: var(--grigio); }

/* =============================================
   CIRCOLO VIRTUOSO
   ============================================= */
#circolo { background: var(--bianco); }

.schema-circle { display: flex; flex-direction: column; gap: 8px; }
.sc-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: var(--bianco); border-radius: 10px; border: 1px solid var(--bordo); transition: all .2s; }
.sc-item:hover { border-color: var(--teal); box-shadow: 0 2px 12px rgba(61,191,171,.15); }
.sc-icon { font-size: 1.3rem; flex-shrink: 0; }
.sc-info { flex: 1; }
.sc-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); }
.sc-sub { font-size: 0.7rem; color: var(--grigio); }
.sc-arrow { color: var(--teal); font-size: 1.2rem; flex-shrink: 0; }

/* =============================================
   METODOLOGIA
   ============================================= */
#metodo { background: var(--grigio-bg); }
.metodo-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 28px; }
.area-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; border-top: 3px solid var(--teal); transition: box-shadow .2s; }
.area-card:hover { box-shadow: 0 4px 20px rgba(61,191,171,.12); }
.ac-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: .08em; color: var(--teal-dark); font-weight: 700; margin-bottom: 6px; }
.ac-title { font-size: 0.95rem; font-weight: 800; color: var(--blu); margin-bottom: 10px; }
.ac-items { display: flex; flex-direction: column; gap: 4px; }
.ac-item { font-size: 0.78rem; color: var(--grigio); display: flex; align-items: center; gap: 6px; }
.ac-item::before { content: ''; width: 6px; height: 6px; background: var(--teal); border-radius: 50%; flex-shrink: 0; }

/* Indici statistici */
.indici-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.indice-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 16px; text-align: center; }
.ic-sigla { font-size: 1.4rem; font-weight: 900; color: var(--teal-dark); line-height: 1; margin-bottom: 6px; }
.ic-nome { font-size: 0.8rem; font-weight: 700; color: var(--blu); margin-bottom: 4px; }
.ic-desc { font-size: 0.7rem; color: var(--grigio); line-height: 1.5; }

/* =============================================
   QUESTIONARIO INTERATTIVO ANAC
   ============================================= */
#questionario { background: var(--bianco); }
.q-intro { background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 12px; padding: 20px 24px; margin-bottom: 28px; display: flex; gap: 16px; align-items: flex-start; border-left: 4px solid var(--teal); }
.q-intro-icon { font-size: 1.8rem; flex-shrink: 0; }
.q-intro-text h4 { font-size: 0.9rem; font-weight: 800; color: var(--teal-deep); margin-bottom: 4px; }
.q-intro-text p { font-size: 0.8rem; color: var(--testo); line-height: 1.6; }
.q-intro-text a { color: var(--teal-dark); font-weight: 600; }

.q-tabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px; }
.q-tab { padding: 7px 14px; border-radius: 6px; font-size: 0.78rem; font-weight: 600; cursor: pointer; border: 1.5px solid var(--bordo); color: var(--grigio); background: var(--bianco); transition: all .2s; }
.q-tab:hover { border-color: var(--teal); color: var(--teal-dark); }
.q-tab.active { background: var(--teal); color: var(--bianco); border-color: var(--teal); }

.q-panel { display: none; }
.q-panel.active { display: block; }

.q-sezione { background: var(--grigio-bg); border: 1px solid var(--bordo); border-radius: 12px; overflow: hidden; margin-bottom: 12px; }
.qs-header { padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: background .2s; }
.qs-header:hover { background: var(--teal-light); }
.qs-header.open { background: var(--teal-light); }
.qs-left { display: flex; align-items: center; gap: 10px; }
.qs-letter { width: 32px; height: 32px; background: var(--teal); color: var(--bianco); border-radius: 8px; display: grid; place-items: center; font-weight: 900; font-size: 0.85rem; flex-shrink: 0; }
.qs-name { font-size: 0.88rem; font-weight: 700; color: var(--blu); }
.qs-count { font-size: 0.68rem; color: var(--grigio); background: var(--bianco); padding: 2px 8px; border-radius: 4px; border: 1px solid var(--bordo); }
.qs-icon { color: var(--teal); font-size: 1rem; transition: transform .3s; }
.qs-header.open .qs-icon { transform: rotate(180deg); }
.qs-domande { display: none; padding: 0 18px 16px; }
.qs-header.open + .qs-domande { display: block; }
.domanda { padding: 10px 0; border-bottom: 1px solid var(--bordo); font-size: 0.82rem; color: var(--testo); display: flex; gap: 10px; align-items: flex-start; }
.domanda:last-child { border-bottom: none; }
.d-num { font-size: 0.72rem; font-weight: 700; color: var(--teal-dark); min-width: 28px; flex-shrink: 0; padding-top: 1px; }
.d-scala { margin-top: 6px; display: flex; gap: 4px; }
.d-scala span { width: 22px; height: 22px; border-radius: 4px; border: 1.5px solid var(--bordo); display: grid; place-items: center; font-size: 0.65rem; color: var(--grigio); cursor: pointer; transition: all .2s; }
.d-scala span:hover { background: var(--teal); color: var(--bianco); border-color: var(--teal); }
.d-scala span.negativo { border-color: #fca5a5; color: #ef4444; }
.d-scala span.negativo:hover { background: #ef4444; color: var(--bianco); }
.d-polarita { font-size: 0.62rem; color: #ef4444; font-weight: 600; margin-top: 4px; }

.q-footer { background: var(--teal-light); border: 1px solid var(--bordo); border-radius: 8px; padding: 14px 18px; margin-top: 16px; font-size: 0.78rem; color: var(--grigio); }
.q-footer strong { color: var(--teal-deep); }

/* =============================================
   OUTPUT / DELIVERABLE
   ============================================= */
#output { background: var(--grigio-bg); }
.oc-title { font-size: 0.9rem; font-weight: 800; color: var(--blu); margin-bottom: 6px; }
.oc-desc { font-size: 0.78rem; color: var(--grigio); line-height: 1.6; }

/* Matrice interventi preview */
.matrice-preview { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 12px; padding: 22px; overflow-x: auto; }
.mp-title { font-size: 0.85rem; font-weight: 800; color: var(--blu); margin-bottom: 14px; }
.matrice-table { width: 100%; border-collapse: collapse; font-size: 0.72rem; }
.matrice-table th { padding: 6px 10px; text-align: center; font-weight: 700; font-size: 0.65rem; }
.matrice-table td { padding: 6px 10px; border: 1px solid var(--bordo); font-size: 0.72rem; }
.m-rosso { background: #fee2e2; }
.m-arancio { background: #fef3c7; }
.m-giallo { background: #fef9c3; }
.m-verde-chiaro { background: #d1fae5; }
.m-verde { background: #a7f3d0; }

/* =============================================
   CLIENTI
   ============================================= */
#clienti { background: var(--bianco); }
.cliente-card:hover { border-color: var(--teal); background: var(--teal-light); transform: translateY(-2px); box-shadow: 0 4px 16px rgba(61,191,171,.12); }
.cc-logo { display: inline-flex; align-items: center; justify-content: center; width: 56px; height: 56px; border-radius: 12px; color: #fff; font-size: 0.72rem; font-weight: 900; letter-spacing: .02em; margin: 0 auto 10px; line-height: 1.2; text-align: center; padding: 4px; }
.cc-name { font-size: 0.85rem; font-weight: 700; color: var(--blu); margin-bottom: 4px; line-height: 1.3; }
.cc-tipo { font-size: 0.68rem; color: var(--grigio); line-height: 1.4; }

/* =============================================
   ECOSISTEMA
   ============================================= */
#ecosistema { background: var(--grigio-bg); }
.eco-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 12px; }
.eco-grid-2 { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; }
.eco-card { background: var(--bianco); border: 1px solid var(--bordo); border-radius: 10px; padding: 14px; text-align: center; transition: all .2s; }
.eco-card:hover { border-color: var(--teal); box-shadow: 0 2px 12px rgba(61,191,171,.1); }
.eco-card.active { border-color: var(--accento); background: #fffbeb; }
.ec-icon { font-size: 1.3rem; margin-bottom: 6px; }
.ec-name { font-size: 0.8rem; font-weight: 700; color: var(--blu); margin-bottom: 3px; }
.ec-desc { font-size: 0.65rem; color: var(--grigio); }

/* =============================================
   CHI SIAMO
   ============================================= */
#chi-siamo { background: var(--bianco); }
.chi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
.at-card { background: var(--grigio-bg); border-radius: 12px; padding: 22px; border: 1px solid var(--bordo); }
.at-avatar { width: 44px; height: 44px; background: var(--teal); border-radius: 10px; display: grid; place-items: center; font-weight: 900; color: var(--bianco); margin-bottom: 12px; font-size: 0.9rem; }
.at-name { font-size: 0.95rem; font-weight: 800; color: var(--blu); margin-bottom: 3px; }
.at-ruolo { font-size: 0.72rem; color: var(--grigio); margin-bottom: 10px; }
.at-desc { font-size: 0.8rem; color: var(--testo); line-height: 1.7; margin-bottom: 12px; }
.at-links { display: flex; gap: 8px; flex-wrap: wrap; }
.at-links a { font-size: 0.72rem; color: var(--teal-dark); font-weight: 600; border: 1px solid var(--bordo); padding: 4px 10px; border-radius: 6px; transition: all .2s; }
.at-links a:hover { background: var(--teal); color: var(--bianco); border-color: var(--teal); }
.anac-box { background: var(--teal-light); border: 1px solid var(--teal-mid); border-radius: 12px; padding: 20px; }
.anac-box h4 { font-size: 0.85rem; font-weight: 800; color: var(--teal-deep); margin-bottom: 8px; }
.anac-box p { font-size: 0.8rem; color: var(--testo); line-height: 1.6; margin-bottom: 10px; }
.anac-link { font-size: 0.78rem; color: var(--teal-dark); font-weight: 700; border: 1.5px solid var(--teal); padding: 8px 16px; border-radius: 8px; display: inline-block; transition: all .2s; }
.anac-link:hover { background: var(--teal); color: var(--bianco); }

/* =============================================
   CTA FINALE
   ============================================= */
.btn-cta-white { background: var(--bianco); color: var(--teal-deep); padding: 12px 28px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; display: inline-block; transition: all .2s; }
.btn-cta-white:hover { background: #a7f3d0; }
.btn-cta-outline { background: transparent; color: var(--bianco); padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; border: 2px solid rgba(255,255,255,.3); display: inline-block; transition: all .2s; }
.btn-cta-outline:hover { border-color: rgba(255,255,255,.7); }

/* =============================================
   FOOTER
   ============================================= */
.site-footer { background: #0d2420; color: rgba(255,255,255,.7); padding: 48px 20px 24px; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 32px; }
.footer-brand .brand-name { font-size: 1rem; font-weight: 800; color: var(--bianco); margin-bottom: 8px; }
.footer-brand p { font-size: 0.78rem; line-height: 1.6; margin-bottom: 8px; }
.footer-brand .brand-legal { font-size: 0.68rem; color: rgba(255,255,255,.3); }
.footer-col h4 { font-size: 0.72rem; font-weight: 700; color: var(--bianco); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 7px; }
.footer-col ul li a { font-size: 0.8rem; color: rgba(255,255,255,.55); transition: color .2s; }
.footer-col ul li a:hover { color: var(--teal); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,.1); padding-top: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
.footer-bottom .copy { font-size: 0.7rem; color: rgba(255,255,255,.3); }
.footer-legal { display: flex; gap: 16px; }
.footer-legal a { font-size: 0.7rem; color: rgba(255,255,255,.3); transition: color .2s; }
.footer-legal a:hover { color: rgba(255,255,255,.7); }

/* =============================================
   RESPONSIVE
   ============================================= */
@media (max-width: 960px) {
  .indici-grid { grid-template-columns: 1fr 1fr; }
  .eco-grid-2 { grid-template-columns: repeat(2, 1fr); }
  .chi-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .navbar-links { display: none !important; }
  .hamburger { display: flex; }
  .topbar { display: none; }
}
@media (max-width: 480px) {
  .eco-grid { grid-template-columns: 1fr 1fr; }
  .footer-grid { grid-template-columns: 1fr; }
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;overflow-x:hidden;font-family:'Segoe UI',system-ui,sans-serif;color:#1a2e2a;background:#fff;line-height:1.6}
img{max-width:100%}
.bo-hero{background:linear-gradient(135deg,#1a7a6b 0%,#1e3a8a 60%,#7c3aed 100%);color:#fff;padding:48px 20px 36px;text-align:center}
.bo-eyebrow{display:inline-block;background:rgba(232,160,32,.2);border:1px solid rgba(232,160,32,.4);color:#e8a020;font-size:.68rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:4px 14px;border-radius:20px;margin-bottom:12px}
.bo-hero h1{font-size:clamp(1.5rem,3.5vw,2.2rem);font-weight:900;margin-bottom:10px;line-height:1.2}
.bo-hero h1 em{color:#e8a020;font-style:normal}
.bo-hero h2{font-size:clamp(1.4rem,3vw,2rem);font-weight:900;margin-bottom:10px;line-height:1.25}
.bo-hero h2 em{color:#e8a020;font-style:normal}
.bo-hero p{font-size:.88rem;color:rgba(255,255,255,.8);max-width:540px;margin:0 auto 14px;line-height:1.6}
.bo-hero-sub{font-size:.9rem;color:rgba(255,255,255,.8);line-height:1.7;margin-bottom:18px;max-width:580px;margin-left:auto;margin-right:auto}
.bo-risk-row{display:flex;flex-direction:column;gap:7px;margin-bottom:18px;max-width:560px;margin-left:auto;margin-right:auto;text-align:left}
.bo-risk-item{display:flex;gap:9px;align-items:flex-start;font-size:.83rem;color:rgba(255,255,255,.85);line-height:1.4}
.bri-icon{color:#f87171;font-size:.9rem;flex-shrink:0;margin-top:1px}
.bo-hero-disclaimer{font-size:.68rem;color:rgba(255,255,255,.35);margin-top:14px;border-top:1px solid rgba(255,255,255,.1);padding-top:10px}
.bo-pills{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin:5px 0}
/* === PRE-OUTPUT SCREEN === */
.bo-preout{display:none;text-align:center;padding:48px 20px}
.bo-preout.active{display:block;animation:fadeIn .3s}
.bo-ai-spinner{width:72px;height:72px;border-radius:50%;border:3px solid rgba(61,191,171,.2);border-top-color:#3dbfab;animation:spin 1.2s linear infinite;margin:0 auto 16px}
@keyframes spin{to{transform:rotate(360deg)}}
.bo-ai-pulse{display:flex;justify-content:center;gap:6px;margin-bottom:20px}
.bo-ai-pulse span{width:8px;height:8px;border-radius:50%;background:#3dbfab;animation:bopulse 1.4s ease-in-out infinite}
.bo-ai-pulse span:nth-child(2){animation-delay:.2s}
.bo-ai-pulse span:nth-child(3){animation-delay:.4s}
@keyframes bopulse{0%,80%,100%{opacity:.2;transform:scale(.8)}40%{opacity:1;transform:scale(1)}}
.bo-ai-label{font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#1a7a6b;margin-bottom:8px}
.bo-ai-step{font-size:.85rem;color:#6b7280;margin-bottom:6px;min-height:20px}
.bo-ai-norm{display:inline-block;font-size:.72rem;color:#6b7280;background:#e8f7f4;border:1px solid #b2e8e0;padding:4px 12px;border-radius:20px;margin-top:8px}
.bo-poitems{max-width:420px;margin:16px auto 0;background:#fff;border:1.5px solid #d1ece8;border-radius:10px;padding:14px 16px;text-align:left}
.bo-poi{display:flex;gap:9px;align-items:flex-start;font-size:.79rem;color:#1a2e2a;padding:5px 0;border-bottom:1px solid #d1ece8;line-height:1.5;opacity:.3;transition:opacity .5s}
.bo-poi:last-child{border-bottom:none}
.bo-poi.done{opacity:1}
.bo-poi-dot{width:8px;height:8px;border-radius:50%;background:#d1ece8;flex-shrink:0;margin-top:4px;transition:background .4s}
.bo-poi.done .bo-poi-dot{background:#16a34a}
/* === PREVIEW + LOCK === */
.bo-preview-wrap{background:#fff;border:1.5px solid #d1ece8;border-radius:12px;overflow:hidden;margin-bottom:14px;box-shadow:0 4px 20px rgba(0,0,0,.06)}
.bo-preview-header{background:linear-gradient(135deg,#0f2027,#1a7a6b);padding:18px 20px;text-align:center}
.bo-preview-eyebrow{font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:8px}
.bo-preview-score-wrap{display:flex;align-items:center;justify-content:center;gap:16px;margin:12px 0;flex-wrap:wrap}
.bo-score-circle{width:100px;height:100px;border-radius:50%;border:5px solid;display:flex;flex-direction:column;align-items:center;justify-content:center;flex-shrink:0}
.bo-score-pct{font-size:1.8rem;font-weight:900;line-height:1}
.bo-score-lbl{font-size:.6rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;margin-top:2px}
.sc-verde{border-color:#16a34a;color:#16a34a;background:#f0fdf4}
.sc-giallo{border-color:#d97706;color:#d97706;background:#fffbeb}
.sc-rosso{border-color:#dc2626;color:#dc2626;background:#fef2f2}
.bo-preview-badge{font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:4px 14px;border-radius:20px;margin-top:4px;display:inline-block}
.pb-verde{background:#dcfce7;color:#16a34a}
.pb-giallo{background:#fef9c3;color:#d97706}
.pb-rosso{background:#fee2e2;color:#dc2626}
.bo-preview-items{padding:14px 16px}
.bo-preview-item{display:flex;gap:9px;align-items:flex-start;padding:7px 0;border-bottom:1px solid #e5e7eb;font-size:.82rem;line-height:1.4}
.bo-preview-item:last-child{border-bottom:none}
/* === LOCK BOX === */
.bo-lock-box{background:#f8fafa;border:1.5px solid #d1ece8;border-top:3px solid #3dbfab;border-radius:0 0 12px 12px;padding:20px;margin-bottom:14px;text-align:center}
.bo-lock-icon{font-size:2.5rem;margin-bottom:8px}
.bo-lock-title{font-size:1rem;font-weight:800;color:#1a7a6b;margin-bottom:5px}
.bo-lock-sub{font-size:.84rem;color:#6b7280;line-height:1.6;max-width:460px;margin:0 auto}
/* === LEVA FORTE === */
.bo-danger-box{background:linear-gradient(135deg,#fff1f2,#fef2f2);border:1.5px solid #fecaca;border-radius:10px;padding:14px 16px;margin:14px 0}
.bo-danger-header{display:flex;align-items:center;gap:8px;font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#dc2626;margin-bottom:10px}
.bo-danger-item{display:flex;gap:9px;align-items:flex-start;font-size:.82rem;color:#1a2e2a;line-height:1.5;margin-bottom:6px}
/* === COSA CONTIENE === */
.bo-what-box{background:linear-gradient(135deg,#e8f7f4,#f0fdf4);border:1.5px solid #b2e8e0;border-radius:10px;padding:14px 16px;margin:14px 0}
.bo-what-header{font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#1a7a6b;margin-bottom:10px}
.bo-what-item{display:flex;gap:9px;align-items:flex-start;font-size:.82rem;color:#1a2e2a;line-height:1.5;margin-bottom:6px}
/* === URGENZA === */
.bo-urgenza{background:linear-gradient(135deg,#1e3a8a,#0f2027);border-radius:10px;padding:14px 18px;margin-bottom:14px;display:flex;gap:12px;align-items:center}
.bo-urgenza-icon{font-size:1.3rem;flex-shrink:0}
.bo-urgenza-text h4{color:#e8a020;font-size:.88rem;font-weight:800;margin-bottom:3px}
.bo-urgenza-text p{color:rgba(255,255,255,.8);font-size:.78rem;line-height:1.5;margin:0}
.bo-urgenza-badge{margin-left:auto;text-align:center;flex-shrink:0;background:rgba(232,160,32,.15);border:1px solid rgba(232,160,32,.4);border-radius:8px;padding:8px 12px}
.bo-urgenza-badge b{display:block;color:#e8a020;font-size:.85rem;font-weight:800}
.bo-urgenza-badge small{color:rgba(255,255,255,.6);font-size:.65rem}
/* === MEDICO POTENZIATO === */
.bo-medico-box{background:linear-gradient(135deg,#1a7a6b,#0f4a40);border-radius:10px;padding:16px 18px;margin:14px 0;text-align:center}
.bo-medico-box h3{font-size:1.1rem;font-weight:900;color:#fff;line-height:1.3;margin-bottom:6px}
.bo-medico-box h3 em{color:#99f6e4;font-style:normal}
.bo-medico-box p{font-size:.84rem;color:rgba(255,255,255,.8);line-height:1.6;margin:0}
/* === PERSONALIZZAZIONE === */
.bo-personal-box{background:linear-gradient(135deg,#ede9fe,#fdf4ff);border:1.5px solid #c4b5fd;border-radius:10px;padding:12px 14px;margin:10px 0;display:flex;gap:10px;align-items:flex-start}
.bo-personal-text h4{font-size:.9rem;font-weight:800;color:#4c1d95;margin-bottom:4px}
.bo-personal-text p{font-size:.8rem;color:#6b7280;line-height:1.5;margin:0}
/* === CROSS === */
.bo-cross-box{background:linear-gradient(135deg,#eff6ff,#f0f5ff);border:1.5px solid #bfdbfe;border-radius:10px;padding:14px 16px;margin:14px 0;display:flex;gap:12px;align-items:flex-start}
.bo-cross-text h4{font-size:.9rem;font-weight:800;color:#1e3a8a;margin-bottom:5px}
.bo-cross-text p{font-size:.8rem;color:#6b7280;line-height:1.5;margin-bottom:7px}
.bo-cross-link{display:inline-flex;align-items:center;gap:6px;font-size:.77rem;font-weight:700;color:#1d4ed8;background:#dbeafe;padding:4px 12px;border-radius:20px;text-decoration:none;border:1px solid #bfdbfe}
/* === CTA DOPPIA === */
.bo-cta-doppia{background:#fff;border:1.5px solid #d1ece8;border-radius:12px;overflow:hidden;margin:14px 0;box-shadow:0 4px 20px rgba(0,0,0,.06)}
.bo-cta-d-head{background:linear-gradient(135deg,#064e3b,#16a34a);padding:16px 20px;text-align:center}
.bo-cta-d-eyebrow{font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.55);margin-bottom:6px}
.bo-cta-d-head h3{color:#fff;font-size:1.05rem;font-weight:800;margin-bottom:5px;line-height:1.3}
.bo-cta-d-head h3 em{color:#6ee7b7;font-style:normal}
.bo-cta-d-head p{color:rgba(255,255,255,.8);font-size:.82rem;line-height:1.5;margin:0}
.bo-cta-d-body{padding:16px 18px}
@media(max-width:768px){
  .bo-hero h1{font-size:1.4rem}
  .bo-preview-score-wrap{flex-direction:column;gap:10px}
  .bo-urgenza{flex-wrap:wrap}
  .bo-urgenza-badge{margin-left:0;width:100%}
}
@media(max-width:480px){
  .bo-hero h1{font-size:1.25rem}
  .bo-svc-grid{grid-template-columns:1fr!important}
}
.bo-pill{font-size:.67rem;font-weight:600;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.85);padding:3px 10px;border-radius:20px}
.bo-wrap{max-width:700px;margin:0 auto;padding:0 20px 60px}
.bo-prog-row{display:flex;justify-content:space-between;font-size:.73rem;color:#6b7280;margin:24px 0 6px}
.bo-prog-track{background:#e5e7eb;border-radius:99px;height:6px;margin-bottom:20px;overflow:hidden}
.bo-prog-fill{height:100%;background:linear-gradient(90deg,#3dbfab,#e8a020);border-radius:99px;width:0%;transition:width .4s ease}
.bo-step{display:none}
.bo-step.active{display:block;animation:fi .3s ease}
@keyframes fi{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.bo-card{background:#fff;border:1.5px solid #d1ece8;border-radius:14px;padding:20px;margin-bottom:12px}
.bo-num{font-size:.68rem;font-weight:700;color:#2a9d8a;letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px;display:flex;align-items:center;gap:8px}
.bo-num span{background:#3dbfab;color:#fff;width:20px;height:20px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:.68rem;flex-shrink:0}
.bo-who{display:inline-block;font-size:.68rem;font-weight:600;background:#e8f7f4;color:#1a7a6b;padding:2px 10px;border-radius:20px;margin-bottom:8px}
.bo-q{font-size:.98rem;font-weight:700;color:#1a2e2a;margin:6px 0 4px;line-height:1.4}
.bo-sub{font-size:.79rem;color:#6b7280;margin-bottom:14px;line-height:1.5}
.bo-opts{display:flex;flex-direction:column;gap:8px}
.bo-opt{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border:1.5px solid #d1ece8;border-radius:10px;background:#fff;cursor:pointer;transition:border-color .15s,background .15s;width:100%}
.bo-opt:hover{border-color:#3dbfab;background:#e8f7f4}
.bo-opt input[type=radio]{width:18px;height:18px;min-width:18px;margin-top:2px;cursor:pointer;accent-color:#3dbfab;flex-shrink:0}
.bo-icon{font-size:.95rem;flex-shrink:0;margin-top:1px}
.bo-lbl{font-size:.85rem;font-weight:500;line-height:1.4}
.bo-desc{display:block;font-size:.72rem;color:#6b7280;margin-top:2px;font-weight:400}
.btn-row{display:flex;gap:10px;justify-content:flex-end;margin-top:12px}
.btn-b{padding:10px 18px;border:1.5px solid #d1ece8;border-radius:8px;background:#fff;color:#6b7280;font-size:.85rem;font-family:inherit;cursor:pointer}
.btn-n{padding:11px 22px;border:none;border-radius:8px;background:#3dbfab;color:#fff;font-size:.86rem;font-weight:700;font-family:inherit;cursor:pointer}
.btn-n:disabled{opacity:.35;cursor:not-allowed}
.btn-n:not(:disabled):hover{background:#2a9d8a}
.bo-reg{background:#e8f7f4;border:1.5px solid #b2e8e0;border-radius:10px;padding:14px 16px;margin-bottom:14px;font-size:.82rem;color:#1a7a6b;line-height:1.5}
.bo-reg strong{display:block;font-size:.86rem;margin-bottom:3px}
.bo-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px}
.bo-field{display:flex;flex-direction:column;gap:4px}
.bo-field label{font-size:.72rem;font-weight:600;color:#1a2e2a}
.bo-field input,.bo-field select{padding:9px 12px;border:1.5px solid #d1ece8;border-radius:8px;font-size:.85rem;font-family:inherit;color:#1a2e2a;background:#fff;width:100%;-webkit-appearance:none}
.bo-field input:focus,.bo-field select:focus{border-color:#3dbfab;outline:none}
.bo-priv{display:flex;gap:8px;align-items:flex-start;font-size:.74rem;color:#6b7280;margin-top:10px;line-height:1.5}
.bo-priv input{margin-top:3px;flex-shrink:0;min-width:16px;height:16px;accent-color:#3dbfab}
.bo-res-top{text-align:center;padding:20px 0 14px}
.bo-gauge{width:110px;height:110px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:800;border:5px solid;margin-bottom:8px}
.g-v{border-color:#16a34a;color:#16a34a;background:#f0fdf4}.g-g{border-color:#d97706;color:#d97706;background:#fffbeb}.g-r{border-color:#dc2626;color:#dc2626;background:#fef2f2}
.bo-lv{display:inline-block;font-size:.73rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:4px 14px;border-radius:20px;margin-bottom:10px}
.lv-v{background:#dcfce7;color:#16a34a}.lv-g{background:#fef9c3;color:#d97706}.lv-r{background:#fee2e2;color:#dc2626}
.bo-res-title{font-size:1.2rem;font-weight:800;color:#1a3a5c;margin-bottom:6px}
.bo-res-sub{font-size:.85rem;color:#6b7280;max-width:480px;margin:0 auto;line-height:1.6}
.bo-ri-list{display:flex;flex-direction:column;gap:8px;margin:16px 0}
.bo-ri{display:flex;gap:10px;align-items:flex-start;padding:10px 14px;border-radius:10px;border:1.5px solid}
.ri-v{background:#f0fdf4;border-color:#bbf7d0}.ri-g{background:#fffbeb;border-color:#fde68a}.ri-r{background:#fef2f2;border-color:#fecaca}
.bo-ri-t{font-size:.82rem;line-height:1.5}
.bo-ri-t strong{display:block;font-size:.86rem;margin-bottom:2px}
.bo-cta{margin-top:16px;background:#fff;border:1.5px solid #d1ece8;border-radius:16px;overflow:hidden}
.bo-cta-h{background:linear-gradient(135deg,#1a7a6b,#1e3a8a);padding:22px;text-align:center}
.bo-cta-h h3{color:#fff;font-size:1.1rem;font-weight:800;margin-bottom:6px}
.bo-cta-h h3 em{color:#99f6e4;font-style:normal}
.bo-cta-h p{color:rgba(255,255,255,.8);font-size:.82rem;line-height:1.6;margin:0}
.bo-cta-b{padding:18px 20px}
.bo-svc-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
.bo-svc{display:flex;gap:8px;align-items:flex-start;padding:10px;background:#e8f7f4;border-radius:8px;border:1px solid #b2e8e0}
.bo-svc h4{font-size:.78rem;font-weight:700;color:#1a7a6b;margin-bottom:2px}
.bo-svc p{font-size:.71rem;color:#6b7280;line-height:1.4;margin:0}
.tip-b{display:inline-flex;background:#1e3a8a;color:#fff;font-size:.67rem;font-weight:700;padding:1px 6px;border-radius:4px;vertical-align:middle}
.bo-out{background:linear-gradient(135deg,#e8f7f4,#f0fdf4);border:1.5px solid #b2e8e0;border-radius:10px;padding:14px;margin-bottom:14px;display:flex;gap:12px}
.bo-out h4{font-size:.86rem;font-weight:700;color:#1a7a6b;margin-bottom:5px}
.bo-out p{font-size:.78rem;color:#6b7280;line-height:1.6;margin-bottom:8px}
.bo-out-pills{display:flex;gap:5px;flex-wrap:wrap}
.bo-out-pill{font-size:.68rem;font-weight:600;background:#b2e8e0;color:#1a7a6b;padding:3px 8px;border-radius:20px}
.bo-proof{background:#1a3a5c;border-radius:10px;padding:12px 14px;display:flex;gap:12px;align-items:center;margin-bottom:14px;flex-wrap:wrap}
.bo-ps-wrap{display:flex;gap:16px;flex:1;flex-wrap:wrap}
.bo-ps{text-align:center}
.bo-ps b{display:block;font-size:1.1rem;font-weight:700;color:#e8a020}
.bo-ps small{font-size:.66rem;color:rgba(255,255,255,.65);line-height:1.3}
.bo-btns{display:flex;flex-direction:column;gap:8px}
.bo-btn-g{display:flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#1a7a6b,#3dbfab);color:#fff;font-weight:700;font-size:.88rem;padding:13px;border-radius:10px;text-decoration:none;border:none;font-family:inherit;cursor:pointer}
.bo-btn-o{display:flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:#1a7a6b;font-weight:600;font-size:.85rem;padding:11px;border-radius:10px;text-decoration:none;border:1.5px solid #3dbfab}
.bo-btn-p{display:flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:#6b7280;font-size:.8rem;padding:9px;border-radius:10px;border:1px solid #e5e7eb;cursor:pointer;font-family:inherit;width:100%}
.bo-cta-f{background:#f8fafa;border-top:1px solid #d1ece8;padding:10px 20px;font-size:.72rem;color:#6b7280;line-height:1.4;display:flex;gap:8px}
@media(max-width:600px){.bo-grid{grid-template-columns:1fr}.bo-svc-grid{grid-template-columns:1fr}.btn-row{flex-direction:column-reverse}.btn-b,.btn-n{width:100%;text-align:center}.bo-proof{flex-direction:column}}
</style>
</head>
<body>
<div class="topbar">
  <div class="inner">
    <a href="https://andreatroisi.it" class="topbar-personal">andreatroisi.it</a>
    <a href="https://www.troisiricerche.net">troisiricerche.net</a>
    <a href="https://www.t-index.it">TR-Index</a>
    <a href="https://www.mappaturadellecompetenze.it">Mappatura delle Competenze</a>
    <a href="https://www.registrodellecompetenze.it">Registro delle Competenze</a>
    <a href="https://www.customerpa.it">CustomerPA</a>
    <a href="https://www.benessereorganizzativo.it" class="topbar-active">BenessereOrg.</a>
    <a href="https://www.troisiformazione.it">Formazione</a>
    <a href="https://www.tiplive.it">TIP</a>
    <a href="https://www.troisiinsight.it">TroisiInsight</a>
    <a href="https://www.digitalizzazionenellapa.it">DigitalizzazionePA</a>
    <a href="https://www.dibattito-pubblico.it">Dibattito Pubblico</a>
    <a href="https://www.voiceinhub.it">VoiceInHub</a>
    <a href="https://www.governancefinanziaria.it">Governance Fin.</a>
    <a href="https://www.consulenzainternazionalizzazione.it">Internazionalizzazione</a>
    <a href="https://www.benesseredigitalegiovani.it">BDG</a>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="https://www.benessereorganizzativo.it" class="navbar-brand">
      <div>
        <div class="brand-logo">Benessere<span>Organizzativo</span></div>
        <span class="brand-sub">Metodo ANAC · PA e Aziende · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="https://www.benessereorganizzativo.it/#normativa">Normativa</a>
      <a href="https://www.benessereorganizzativo.it/#circolo">Metodo</a>
      <a href="https://www.benessereorganizzativo.it/#questionario">Questionario ANAC</a>
      <a href="https://www.benessereorganizzativo.it/#output">Output</a>
      <a href="https://www.benessereorganizzativo.it/#clienti">Clienti</a>
      <a href="https://www.benessereorganizzativo.it/#chi-siamo">Chi siamo</a>
      <a href="mailto:benessere@troisiricerche.it" class="btn-contatti">Scrivici</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi preventivo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<div class="bo-hero">
  <div class="bo-eyebrow">⚠️ Verifica gratuita · PA e Aziende Private · Troisi Ricerche</div>
  <h2>Il tuo ente è in regola con il<br><em>Benessere Organizzativo?</em></h2>
  <p>8 domande per scoprire il livello di compliance e il rischio sanzioni dell'Ispettorato del Lavoro.</p>
  <div class="bo-pills"><span class="bo-pill">D.Lgs. 81/2008</span><span class="bo-pill">D.Lgs. 150/2009</span><span class="bo-pill">Modello ANAC</span><span class="bo-pill">PIAO 2022</span></div>
  <div class="bo-pills"><span class="bo-pill">🏛 PA</span><span class="bo-pill">🏥 Sanità</span><span class="bo-pill">🏢 Aziende private</span><span class="bo-pill">🎓 Scuole</span></div>
</div>

<div class="bo-wrap">
  <div class="bo-prog-row"><span id="pt">Domanda 1 di 8</span><span id="pp">0%</span></div>
  <div class="bo-prog-track"><div class="bo-prog-fill" id="pf"></div></div>

<div class="bo-step active" id="s1">
<div class="bo-card">
<div class="bo-num"><span>1</span>DVR — Stress lavoro-correlato</div>
<span class="bo-who">🏛 PA + 🏢 Privati</span>
<div class="bo-q">Il DVR include la valutazione del rischio da stress lavoro-correlato?</div>
<div class="bo-sub">Obbligo per tutti i datori di lavoro ai sensi del D.Lgs. 81/2008 art. 28. Sanzioni da €1.000 a €3.000 e sospensione attività.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q1" value="2" onchange="sel(1,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, valutazione completa e aggiornata<span class="bo-desc">Preliminare + approfondita se necessario</span></span></label>
<label class="bo-opt"><input type="radio" name="q1" value="1" onchange="sel(1,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Presente ma non aggiornata<span class="bo-desc">DVR vecchio o solo valutazione preliminare</span></span></label>
<label class="bo-opt"><input type="radio" name="q1" value="0" onchange="sel(1,0)"><span class="bo-icon">❌</span><span class="bo-lbl">No, non è nel DVR</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-n" id="b1" disabled onclick="vai(1)">Avanti →</button></div>
</div>

<div class="bo-step" id="s2">
<div class="bo-card">
<div class="bo-num"><span>2</span>Indagine Benessere Organizzativo</div>
<span class="bo-who">🏛 PA (obbligo) · 🏢 Privati (raccomandato)</span>
<div class="bo-q">Nell'ultimo anno è stata condotta un'indagine sul benessere organizzativo?</div>
<div class="bo-sub">Per la PA: obbligo annuale D.Lgs. 150/2009 art. 14 c.5. Per i privati: chi misura il BO riduce l'assenteismo del 25-40%.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q2" value="2" onchange="sel(2,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, con metodo strutturato e validato<span class="bo-desc">Questionario ANAC o equivalente</span></span></label>
<label class="bo-opt"><input type="radio" name="q2" value="1" onchange="sel(2,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Sì, ma in modo informale<span class="bo-desc">Box suggerimenti, form generico</span></span></label>
<label class="bo-opt"><input type="radio" name="q2" value="0" onchange="sel(2,0)"><span class="bo-icon">❌</span><span class="bo-lbl">No, non è stata condotta</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(1)">← Indietro</button><button class="btn-n" id="b2" disabled onclick="vai(2)">Avanti →</button></div>
</div>

<div class="bo-step" id="s3">
<div class="bo-card">
<div class="bo-num"><span>3</span>Questionario ANAC / Metodo validato</div>
<span class="bo-who">🏛 PA (obbligo) · 🏢 Privati (raccomandato)</span>
<div class="bo-q">L'indagine utilizza il questionario ANAC (17 sezioni, 85 domande)?</div>
<div class="bo-sub">Un questionario non validato non soddisfa i requisiti normativi.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q3" value="2" onchange="sel(3,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, questionario ANAC o metodo validato<span class="bo-desc">17 sezioni, scala validata, campionamento corretto</span></span></label>
<label class="bo-opt"><input type="radio" name="q3" value="1" onchange="sel(3,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Questionario personalizzato non validato</span></label>
<label class="bo-opt"><input type="radio" name="q3" value="0" onchange="sel(3,0)"><span class="bo-icon">❌</span><span class="bo-lbl">Nessun questionario strutturato</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(2)">← Indietro</button><button class="btn-n" id="b3" disabled onclick="vai(3)">Avanti →</button></div>
</div>

<div class="bo-step" id="s4">
<div class="bo-card">
<div class="bo-num"><span>4</span>OIV / RSPP coinvolto</div>
<span class="bo-who">🏛 PA → OIV · 🏢 Privati → RSPP</span>
<div class="bo-q">I risultati sono stati trasmessi all'OIV (PA) o al RSPP (privati)?</div>
<div class="bo-sub">L'OIV integra il BO nella valutazione della performance. Il RSPP aggiorna il DVR.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q4" value="2" onchange="sel(4,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, trasmessi e integrati formalmente</span></label>
<label class="bo-opt"><input type="radio" name="q4" value="1" onchange="sel(4,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Trasmessi ma non formalmente integrati</span></label>
<label class="bo-opt"><input type="radio" name="q4" value="0" onchange="sel(4,0)"><span class="bo-icon">❌</span><span class="bo-lbl">No, non trasmessi</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(3)">← Indietro</button><button class="btn-n" id="b4" disabled onclick="vai(4)">Avanti →</button></div>
</div>

<div class="bo-step" id="s5">
<div class="bo-card">
<div class="bo-num"><span>5</span>Piano di miglioramento</div>
<span class="bo-who">🏛 PA + 🏢 Privati</span>
<div class="bo-q">A seguito dell'indagine sono stati adottati piani di miglioramento documentati?</div>
<div class="bo-sub">Senza azioni correttive tracciabili la rilevazione è priva di valore normativo.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q5" value="2" onchange="sel(5,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, piano formale approvato e monitorato</span></label>
<label class="bo-opt"><input type="radio" name="q5" value="1" onchange="sel(5,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Alcune azioni informali, non documentate</span></label>
<label class="bo-opt"><input type="radio" name="q5" value="0" onchange="sel(5,0)"><span class="bo-icon">❌</span><span class="bo-lbl">No, i dati non hanno generato azioni</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(4)">← Indietro</button><button class="btn-n" id="b5" disabled onclick="vai(5)">Avanti →</button></div>
</div>

<div class="bo-step" id="s6">
<div class="bo-card">
<div class="bo-num"><span>6</span>Comunicazione ai dipendenti</div>
<span class="bo-who">🏛 PA + 🏢 Privati</span>
<div class="bo-q">I risultati sono stati comunicati ai dipendenti in modo trasparente?</div>
<div class="bo-sub">Un'indagine i cui risultati non vengono condivisi genera sfiducia.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q6" value="2" onchange="sel(6,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, comunicati a tutti i dipendenti<span class="bo-desc">Report, riunioni, intranet</span></span></label>
<label class="bo-opt"><input type="radio" name="q6" value="1" onchange="sel(6,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Comunicati solo ai dirigenti</span></label>
<label class="bo-opt"><input type="radio" name="q6" value="0" onchange="sel(6,0)"><span class="bo-icon">❌</span><span class="bo-lbl">No, non comunicati</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(5)">← Indietro</button><button class="btn-n" id="b6" disabled onclick="vai(6)">Avanti →</button></div>
</div>

<div class="bo-step" id="s7">
<div class="bo-card">
<div class="bo-num"><span>7</span>Periodicità e continuità</div>
<span class="bo-who">🏛 PA (annuale) · 🏢 Privati (periodica)</span>
<div class="bo-q">Le indagini vengono condotte con cadenza regolare?</div>
<div class="bo-sub">La PA è tenuta all'indagine ogni anno. La continuità permette di difendersi in caso di ispezione.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q7" value="2" onchange="sel(7,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, cadenza regolare con serie storica<span class="bo-desc">Dati confrontabili anno su anno</span></span></label>
<label class="bo-opt"><input type="radio" name="q7" value="1" onchange="sel(7,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Condotta una sola volta o discontinua</span></label>
<label class="bo-opt"><input type="radio" name="q7" value="0" onchange="sel(7,0)"><span class="bo-icon">❌</span><span class="bo-lbl">Mai condotta</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(6)">← Indietro</button><button class="btn-n" id="b7" disabled onclick="vai(7)">Avanti →</button></div>
</div>

<div class="bo-step" id="s8">
<div class="bo-card">
<div class="bo-num"><span>8</span>Valutazione approfondita stress SLC</div>
<span class="bo-who">🏛 PA + 🏢 Privati</span>
<div class="bo-q">È stata condotta anche la valutazione approfondita dello stress lavoro-correlato?</div>
<div class="bo-sub">Le Linee guida INAIL prevedono due livelli. Fermarsi alla sola preliminare non è sufficiente.</div>
<div class="bo-opts">
<label class="bo-opt"><input type="radio" name="q8" value="2" onchange="sel(8,2)"><span class="bo-icon">✅</span><span class="bo-lbl">Sì, entrambe le fasi completate<span class="bo-desc">Preliminare + approfondita</span></span></label>
<label class="bo-opt"><input type="radio" name="q8" value="1" onchange="sel(8,1)"><span class="bo-icon">⚠️</span><span class="bo-lbl">Solo valutazione preliminare</span></label>
<label class="bo-opt"><input type="radio" name="q8" value="0" onchange="sel(8,0)"><span class="bo-icon">❌</span><span class="bo-lbl">Nessuna valutazione specifica</span></label>
</div>
</div>
<div class="btn-row"><button class="btn-b" onclick="torna(7)">← Indietro</button><button class="btn-n" id="b8" disabled onclick="vai(8)">Avanti →</button></div>
</div>



  <div class="bo-step" id="sreg">
    <div class="bo-card">
      <div class="bo-num"><span>9</span>Quasi fatto!</div>
      <div class="bo-reg">📋 <strong>Il tuo report è pronto</strong>Inserisci i dati per riceverlo. Gratuito e senza impegno.</div>
      <div class="bo-grid">
        <div class="bo-field"><label>Nome *</label><input type="text" id="fn" oninput="ck()"></div>
        <div class="bo-field"><label>Cognome *</label><input type="text" id="fc" oninput="ck()"></div>
      </div>
      <div class="bo-grid">
        <div class="bo-field"><label>Email *</label><input type="email" id="fe" oninput="ck()"></div>
        <div class="bo-field"><label>Ruolo</label><select id="fr"><option value="">Seleziona...</option><optgroup label="Enti Pubblici"><option>Segretario Generale / DG</option><option>Responsabile HR / Personale</option><option>RSPP</option><option>OIV / Nucleo Valutazione</option><option>Dirigente / Funzionario</option></optgroup><optgroup label="Aziende Private"><option>Titolare / Amministratore</option><option>Direttore HR</option><option>RSPP Aziendale</option><option>Medico Competente</option></optgroup></select></div>
      </div>
      <div class="bo-grid">
        <div class="bo-field"><label>Ente / Azienda *</label><input type="text" id="fente" oninput="ck()"></div>
        <div class="bo-field"><label>Tipologia</label><select id="ft"><option value="">Seleziona...</option><optgroup label="Pubblica Amministrazione"><option>Comune fino a 5.000 ab.</option><option>Comune 5.001-15.000 ab.</option><option>Comune 15.001-50.000 ab.</option><option>Comune oltre 50.000 ab.</option><option>Provincia / Regione</option><option>ASL / AO / IRCCS</option><option>Societa in-house</option></optgroup><optgroup label="Aziende Private"><option>Micro impresa (fino a 10 dip.)</option><option>Piccola impresa (11-50 dip.)</option><option>Media impresa (51-250 dip.)</option><option>Grande impresa (oltre 250 dip.)</option></optgroup></select></div>
      </div>
      <div class="bo-priv"><input type="checkbox" id="fp" onchange="ck()"><label for="fp">Acconsento al trattamento dei dati da parte di <strong>Troisi Ricerche S.r.l.</strong> ai sensi del GDPR. <a href="javascript:void(0)" onclick="window.open('https://www.iubenda.com/privacy-policy/47773457','_blank')" target="_blank" style="color:#3dbfab">Privacy Policy</a> *</label></div>
    </div>
    <div class="btn-row">
      <button class="btn-b" onclick="torna(8)">← Indietro</button>
      <button class="btn-n" id="breg" disabled onclick="mostra()">📊 Vedi il report →</button>
    </div>
  </div>

  <!-- PRE-OUTPUT SCREEN -->
  <div class="bo-preout" id="bo-preout">
    <div class="bo-ai-spinner"></div>
    <div class="bo-ai-label">Sistema di Diagnosi BO — Metodo Troisi</div>
    <div class="bo-ai-pulse"><span></span><span></span><span></span></div>
    <div class="bo-ai-step" id="bo-ai-step">Acquisizione dati organizzativi...</div>
    <div class="bo-ai-norm" id="bo-ai-norm">Verifica D.Lgs. 81/2008 art. 28...</div>
    <div class="bo-poitems">
      <div style="font-size:.67rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#1a7a6b;margin-bottom:8px">Dimensioni di analisi in elaborazione</div>
      <div class="bo-poi" id="bpoi-1"><span class="bo-poi-dot"></span><span><strong>Conformità normativa</strong> — D.Lgs. 81/2008, D.Lgs. 150/2009, ANAC</span></div>
      <div class="bo-poi" id="bpoi-2"><span class="bo-poi-dot"></span><span><strong>Adeguatezza metodologica</strong> — DVR, campionamento, scale validate</span></div>
      <div class="bo-poi" id="bpoi-3"><span class="bo-poi-dot"></span><span><strong>Rischio ispettivo</strong> — esposizione Ispettorato del Lavoro</span></div>
      <div class="bo-poi" id="bpoi-4"><span class="bo-poi-dot"></span><span><strong>Scoring pesato</strong> — ponderazione criteri critici/alti/standard</span></div>
      <div class="bo-poi" id="bpoi-5"><span class="bo-poi-dot"></span><span><strong>Benchmark nazionale</strong> — confronto con PA e aziende monitorate</span></div>
    </div>
    <p style="font-size:.73rem;color:#6b7280;margin-top:14px;max-width:400px;margin-left:auto;margin-right:auto;line-height:1.6;">Il sistema sta elaborando la diagnosi del rischio ispettivo e confrontando il profilo del tuo ente con le casistiche monitorate da Troisi Ricerche.</p>
  </div>

  <!-- RISULTATO -->
  <div class="bo-step" id="sres">

    <!-- PREVIEW: score + 3 punti principali -->
    <div class="bo-preview-wrap">
      <div class="bo-preview-header">
        <div class="bo-preview-eyebrow" id="bo-prev-eyebrow">Diagnosi BO — Anteprima</div>
        <div class="bo-preview-score-wrap">
          <div class="bo-score-circle" id="bo-score-circle">
            <div class="bo-score-pct" id="bo-score-pct"></div>
            <div class="bo-score-lbl">Score BO</div>
          </div>
          <div style="text-align:left">
            <div class="bo-preview-badge" id="bo-prev-badge"></div>
            <div style="font-size:.85rem;font-weight:700;color:#fff;margin:6px 0 3px" id="bo-prev-title"></div>
            <div style="font-size:.78rem;color:rgba(255,255,255,.7);line-height:1.5;max-width:300px" id="bo-prev-sub"></div>
          </div>
        </div>
      </div>
      <div class="bo-preview-items">
        <div style="font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#6b7280;margin-bottom:8px">📋 Anteprima diagnosi — 3 punti principali</div>
        <div id="bo-prev-items"></div>
        <div style="margin-top:10px;padding:10px;background:linear-gradient(135deg,rgba(61,191,171,.08),rgba(30,58,138,.05));border:1px solid rgba(61,191,171,.2);border-radius:8px;font-size:.76rem;color:#6b7280;text-align:center;">
          🔒 <strong style="color:#1a7a6b">Continua sotto per accedere al report completo</strong> con tutti gli 8 punti, scenario di rischio e percorso operativo
        </div>
      </div>
    </div>

    <!-- PERSONALIZZAZIONE -->
    <div class="bo-personal-box" id="bo-personal-box">
      <div style="font-size:1.5rem;flex-shrink:0">🏛</div>
      <div class="bo-personal-text">
        <h4 id="bo-personal-title">Per un ente come il tuo...</h4>
        <p id="bo-personal-text">Il percorso di conformità sul Benessere Organizzativo ha caratteristiche specifiche che dipendono dalla tipologia e dalla dimensione della tua organizzazione.</p>
      </div>
    </div>

    <!-- LOCK BOX -->
    <div class="bo-lock-box">
      <div class="bo-lock-icon">🔒</div>
      <div class="bo-lock-title">Report completo disponibile</div>
      <div class="bo-lock-sub">Per accedere al report completo, con l'analisi dettagliata di tutti gli 8 punti, le indicazioni operative e le azioni correttive specifiche per il tuo ente, scegli una delle opzioni qui sotto.</div>
    </div>

    <!-- LEVA FORTE -->
    <div class="bo-danger-box">
      <div class="bo-danger-header">⚠️ Senza report completo — cosa rischi</div>
      <div class="bo-danger-item"><span style="color:#dc2626;flex-shrink:0">→</span><span><strong>Non sei difendibile in caso di ispezione</strong> dell'Ispettorato del Lavoro o verifica del RSPP</span></div>
      <div class="bo-danger-item"><span style="color:#dc2626;flex-shrink:0">→</span><span><strong>Non puoi dimostrare la conformità</strong> al D.Lgs. 81/2008 e alle linee guida ANAC</span></div>
      <div class="bo-danger-item"><span style="color:#dc2626;flex-shrink:0">→</span><span><strong>Il DVR potrebbe risultare incompleto</strong> per assenza della valutazione stress lavoro-correlato documentata</span></div>
      <div class="bo-danger-item"><span style="color:#dc2626;flex-shrink:0">→</span><span><strong>Per la PA:</strong> Corte dei Conti può irrogare sanzioni personali fino a 20x la retribuzione mensile lorda agli amministratori responsabili</span></div>
    </div>

    <!-- COSA CONTIENE IL REPORT COMPLETO -->
    <div class="bo-what-box">
      <div class="bo-what-header">📋 Cosa contiene il report completo — Metodo Troisi</div>
      <div class="bo-what-item"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Analisi normativa dettagliata</strong> punto per punto su tutti gli 8 criteri (D.Lgs. 81/2008, D.Lgs. 150/2009, ANAC)</span></div>
      <div class="bo-what-item"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Gap puntuali</strong> con riferimento normativo e livello di criticità (critico / alto / standard)</span></div>
      <div class="bo-what-item"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Azioni correttive operative</strong> con priorità, tempi stimati e responsabili indicati</span></div>
      <div class="bo-what-item"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Struttura difendibile davanti all'Ispettorato</strong> — documentazione utilizzabile in caso di ispezione</span></div>
      <div class="bo-what-item"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Piano di integrazione nel DVR</strong> — il report è integrabile nel Documento di Valutazione dei Rischi</span></div>
      <div class="bo-what-item"><span style="color:#16a34a;flex-shrink:0">✓</span><span><strong>Benchmark nazionale</strong> — posizionamento rispetto ad enti simili nel database Troisi Ricerche</span></div>
    </div>

    <!-- EFFETTO MEDICO POTENZIATO -->
    <div class="bo-medico-box">
      <div style="font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:8px">⚕️ Il passaggio necessario</div>
      <h3>Hai la diagnosi.<br>Ora serve la <em>soluzione</em>.</h3>
      <p>Troisi Ricerche trasforma il tuo risultato in conformità reale, documentata e difendibile davanti all'Ispettorato del Lavoro, all'OIV e alla Corte dei Conti. Dal 2006, per oltre 200 enti pubblici e aziende private.</p>
    </div>

    <!-- DOPPIA CONVERSIONE -->
    <div class="bo-cta-doppia">
      <div class="bo-cta-d-head">
        <div class="bo-cta-d-eyebrow">⚖️ Non una consulenza — un adempimento necessario</div>
        <h3>Avvia il percorso di conformità<br><em>prima della prossima ispezione</em></h3>
        <p>Troisi Ricerche analizza i gap specifici del tuo ente e propone un piano operativo documentato, integrabile nel DVR e difendibile in ogni sede istituzionale.</p>
      </div>
      <div class="bo-cta-d-body">

        <!-- Urgenza dinamica -->
        <div class="bo-urgenza">
          <div class="bo-urgenza-icon">⏳</div>
          <div class="bo-urgenza-text">
            <h4 id="bo-urg-title">Il momento di agire è adesso</h4>
            <p id="bo-urg-body">L'Ispettorato del Lavoro può avviare ispezioni senza preavviso. Chi non ha un sistema BO documentato e metodologicamente corretto non è in grado di dimostrare la conformità.</p>
          </div>
          <div class="bo-urgenza-badge">
            <b>24h</b>
            <small>Risposta<br>garantita</small>
          </div>
        </div>

        <!-- CTA 1 — principale -->
        <a href="https://calendly.com/andreatroisi/30min?month=2026-01" target="_blank" style="display:flex;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,#1a7a6b,#2a9d8a);color:#fff;font-weight:800;font-size:.95rem;padding:14px 20px;border-radius:10px;text-decoration:none;box-shadow:0 4px 16px rgba(26,122,107,.3);margin-bottom:10px;">
          📅 Prenota la consulenza gratuita con Andrea Troisi
        </a>

        <!-- CTA 2 -->
        <a href="mailto:benessere@troisiricerche.it?subject=Richiesta%20report%20completo%20BO%20—%20[Nome%20Ente]" style="display:flex;align-items:center;justify-content:center;gap:10px;background:#fff;color:#1a7a6b;font-weight:700;font-size:.9rem;padding:12px 20px;border-radius:10px;text-decoration:none;border:1.5px solid #3dbfab;margin-bottom:8px;">
          ✉️ Ricevi il report completo via email
        </a>
        <div style="text-align:center;font-size:.72rem;color:#6b7280;margin-bottom:14px;">📋 Report utilizzabile in caso di ispezione · Conforme D.Lgs. 81/2008 · Gratuito</div>

        <!-- Servizi -->
        <div style="font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#1a7a6b;margin-bottom:10px">🔧 Come lo facciamo concretamente — Metodo Troisi</div>
        <div class="bo-svc-grid">
          <div class="bo-svc"><span style="font-size:1.1rem;flex-shrink:0">📋</span><div><h4>Questionario ANAC validato</h4><p>17 sezioni, 85 domande. Modello ufficiale DFP</p></div></div>
          <div class="bo-svc"><span style="font-size:1.1rem;flex-shrink:0">💻</span><div><h4>Survey su <span class="tip-b">TIP</span></h4><p>Piattaforma proprietaria anonima GDPR. Real-time su <a href="https://tiplive.it" target="_blank" style="color:#1a7a6b;font-weight:600">tiplive.it</a></p></div></div>
          <div class="bo-svc"><span style="font-size:1.1rem;flex-shrink:0">⚖️</span><div><h4>DVR integrato</h4><p>Il report è integrabile nel DVR esistente. Difendibile davanti all'Ispettorato</p></div></div>
          <div class="bo-svc"><span style="font-size:1.1rem;flex-shrink:0">📊</span><div><h4>Metodo Troisi — Cochran</h4><p>Campionamento statistico validato, benchmark nazionale. Accreditati MIUR</p></div></div>
          <div class="bo-svc"><span style="font-size:1.1rem;flex-shrink:0">🎓</span><div><h4>Formazione RSPP/HR</h4><p>Formiamo il personale sulla gestione del BO e sulla prevenzione SLC</p></div></div>
          <div class="bo-svc"><span style="font-size:1.1rem;flex-shrink:0">🤖</span><div><h4>Dashboard AI su <span class="tip-b">TIP</span></h4><p>Analisi AI, trend e piano di miglioramento in tempo reale</p></div></div>
        </div>

        <!-- Output box -->
        <div class="bo-out">
          <span style="font-size:1.5rem;flex-shrink:0">📋</span>
          <div>
            <h4>Il risultato: un report che vale davanti all'Ispettorato</h4>
            <p>Conforme al D.Lgs. 81/2008 e D.Lgs. 150/2009, integrabile nel DVR, allegabile alla Relazione Performance, presentabile al CdA o Giunta.</p>
            <div class="bo-out-pills">
              <span class="bo-out-pill">✅ Conforme D.Lgs. 81/2008</span>
              <span class="bo-out-pill">✅ Conforme D.Lgs. 150/2009</span>
              <span class="bo-out-pill">✅ Integrabile nel DVR</span>
              <span class="bo-out-pill">✅ Allegabile Relazione Performance</span>
              <span class="bo-out-pill">✅ Accreditato MIUR</span>
              <span class="bo-out-pill">✅ Survey su TIP</span>
            </div>
          </div>
        </div>

        <!-- Proof bar con MIUR -->
        <div class="bo-proof">
          <div class="bo-ps-wrap">
            <div class="bo-ps"><b>20+</b><small>anni sul<br>mercato</small></div>
            <div class="bo-ps"><b>500+</b><small>ricerche<br>realizzate</small></div>
            <div class="bo-ps"><b>200+</b><small>enti<br>serviti</small></div>
            <div class="bo-ps"><b>TIP</b><small>Piattaforma<br>proprietaria</small></div>
          </div>
          <div style="border-left:1px solid rgba(255,255,255,.15);padding-left:12px;text-align:center">
            <img src="<?php echo get_template_directory_uri(); ?>/miur.png" alt="MIUR" style="width:50px;display:block;margin:0 auto 4px;filter:brightness(0) invert(1)">
            <b style="display:block;font-size:.68rem;color:#e8a020">Accreditato MIUR</b>
            <small style="font-size:.65rem;color:rgba(255,255,255,.6)">Ente di Ricerca</small>
          </div>
        </div>

        <!-- Bottone PDF -->
        <button onclick="stampa()" class="bo-btn-p" style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;background:#fff;color:#6b7280;font-size:.82rem;padding:9px;border-radius:8px;border:1px solid #d1ece8;cursor:pointer;font-family:inherit;margin-top:4px;">📄 Scarica il Report BO in PDF</button>

      </div>
      <div class="bo-cta-f">🛡️ <span><strong style="color:#1a2e2a">Colloquio operativo gratuito — nessun impegno.</strong> Analizziamo i gap specifici del tuo ente in 30 minuti e proponiamo un piano con tempi, costi e output documentati. Risposta entro 24 ore lavorative. Troisi Ricerche S.r.l. · P.IVA 07216100722 · Accreditato MIUR come Ente di Ricerca · Piattaforma TIP · Dal 2006.</span></div>
    </div>

    <!-- CROSS-SYSTEM CUSTOMERPA -->
    <div class="bo-cross-box">
      <div style="font-size:1.8rem;flex-shrink:0">🏛</div>
      <div class="bo-cross-text">
        <h4>Hai verificato il Benessere Organizzativo. E la Customer Satisfaction?</h4>
        <p>Il D.Lgs. 150/2009 obbliga ogni PA a rilevare annualmente la soddisfazione dei cittadini. Il mancato adempimento espone l'ente a rilievi OIV, ANAC e Corte dei Conti. CustomerPA — Metodo Troisi è il sistema nazionale per la verifica della conformità CS.</p>
        <a href="https://www.customerpa.it/sei-in-regola" target="_blank" class="bo-cross-link">🏛 Verifica la conformità CS del tuo ente →</a>
      </div>
    </div>

    <!-- DETTAGLIO COMPLETO (nascosto, visibile dopo click) -->
    <div id="bo-detail-full" style="display:none">
      <div style="margin:16px 0 8px;font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#6b7280">Dettaglio verifica per punto</div>
      <div class="bo-ri-list" id="ri"></div>
    </div>

  </div><!-- /sres -->

</div>

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">BenessereOrganizzativo.it</div>
        <p>Piattaforma per la misurazione del Benessere Organizzativo nella PA e nelle aziende. Metodo Troisi Ricerche · Riconosciuto da ANAC.</p>
        <p class="brand-legal">Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari · P.IVA 07216100722</p>
      </div>
      <div class="footer-col">
        <h4>Il sito</h4>
        <ul>
          <li><a href="https://www.benessereorganizzativo.it/#normativa">Normativa e timeline</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#circolo">Il circolo virtuoso</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#metodo">Metodologia</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#questionario">Questionario ANAC</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#output">Output</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#clienti">Clienti</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Galassia Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">troisiricerche.net</a></li>
          <li><a href="https://www.t-index.it" target="_blank">TR-Index</a></li>
          <li><a href="https://www.mappaturadellecompetenze.it" target="_blank">Mappatura delle Competenze</a></li>
          <li><a href="https://www.registrodellecompetenze.it" target="_blank">Registro delle Competenze</a></li>
          <li><a href="https://www.customerpa.it" target="_blank">CustomerPA</a></li>
          <li><a href="https://tip.troisiricerche.it" target="_blank">TIP Platform</a></li>
          <li><a href="https://www.troisiinsight.it" target="_blank">TroisiInsight</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una call</a></li>
          <li><a href="mailto:benessere@troisiricerche.it">benessere@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a></li>
          <li><a href="https://www.youtube.com/@Troisiricerche" target="_blank">YouTube</a></li>
          <li><a href="tel:800644046">800 644 046</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 BenessereOrganizzativo.it · Troisi Ricerche S.r.l. Unipersonale</div>
      <div class="footer-legal" id="iubenda-footer-links"></div>
      <script type="text/javascript" src="https://embeds.iubenda.com/widgets/946ac756-6db6-11ee-8bfc-5ad8d8c564c0.js"></script>
    </div>
  </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
function toggleSezione(header) {
  header.classList.toggle('open');
}
function switchTab(tab) {
  document.querySelectorAll('.q-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.q-panel').forEach(p => p.classList.remove('active'));
  const tabs = { 'bo': 0, 'condivisione': 1, 'superiore': 2 };
  document.querySelectorAll('.q-tab')[tabs[tab]].classList.add('active');
  document.getElementById('panel-' + tab).classList.add('active');
}
</script>

<div style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true">
benessere organizzativo benessere organizzativo aziendale benessere organizzativo pubblica amministrazione benessere organizzativo aziende organizational wellbeing workplace wellbeing employee wellbeing benessere nei luoghi di lavoro qualità della vita lavorativa clima organizzativo analisi clima aziendale survey clima aziendale misurazione clima organizzativo stress lavoro correlato valutazione stress lavoro correlato rischio psicosociale lavoro employee survey employee satisfaction survey employee engagement survey indagine dipendenti questionario benessere organizzativo performance organizzativa organizational performance efficienza organizzativa employee engagement employee experience motivazione dipendenti organizational analytics HR analytics workplace analytics organizational wellbeing index organizational climate index indicatori benessere organizzativo benchmark clima aziendale benessere organizzativo Italia benessere organizzativo aziende italiane benessere organizzativo enti pubblici benessere organizzativo comuni benessere organizzativo università smart working benessere organizzativo digital workplace come misurare il benessere organizzativo come migliorare il clima aziendale strumenti per misurare il clima organizzativo consulenza benessere organizzativo organizational consulting Andrea Troisi Troisi Ricerche Metodo Troisi Troisi Organizational Wellbeing Model mappatura delle competenze registro delle competenze CustomerPA TR-Index TroisiInsight Mappatura delle Competenze Registro delle Competenze how to measure organizational wellbeing how to measure employee wellbeing organizational wellbeing indicators leadership organizzativa cultura organizzativa governance organizzativa benessere organizzativo digitalizzazione PA benessere organizzativo trasformazione digitale performance pubblica amministrazione valutazione enti pubblici troisi ricerche benessere organizzativo andrea troisi organizational wellbeing
</div>

<?php get_footer(); ?>


<script>
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger-btn');
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow = '';
}
function toggleSezione(header) {
  header.classList.toggle('open');
}
function switchTab(tab) {
  document.querySelectorAll('.q-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.q-panel').forEach(p => p.classList.remove('active'));
  const tabs = { 'bo': 0, 'condivisione': 1, 'superiore': 2 };
  document.querySelectorAll('.q-tab')[tabs[tab]].classList.add('active');
  document.getElementById('panel-' + tab).classList.add('active');
}
</script>
<script>
var ans={};
var LB=["DVR con stress lavoro-correlato", "Indagine Benessere Organizzativo", "Questionario ANAC validato", "OIV / RSPP coinvolto", "Piano di miglioramento", "Comunicazione ai dipendenti", "Periodicit\u00e0 e continuit\u00e0", "Valutazione approfondita stress SLC"];
var NM=["D.Lgs. 81/2008 art. 28", "D.Lgs. 150/2009 art. 14 c.5", "Linee guida DFP \u00b7 ANAC", "D.Lgs. 150/2009 \u00b7 D.Lgs. 81/2008", "D.Lgs. 81/2008 \u00b7 D.Lgs. 150/2009", "Accordo Europeo 2004 \u00b7 INAIL", "D.Lgs. 150/2009 \u00b7 annualit\u00e0 PA", "Accordo Europeo 2004 \u00b7 INAIL"];
function sel(s,v){ans[s]=v;var b=document.getElementById('b'+s);if(b)b.disabled=false;}
function vai(n){document.querySelectorAll('.bo-step').forEach(function(e){e.classList.remove('active');});var d=n>=8?'sreg':'s'+(n+1);document.getElementById(d).classList.add('active');var p=Math.round((n/8)*100);document.getElementById('pf').style.width=p+'%';document.getElementById('pp').textContent=p+'%';document.getElementById('pt').textContent=n<8?'Domanda '+(n+1)+' di 8':'Registrazione';window.scrollTo({top:0,behavior:'smooth'});}
function torna(n){document.querySelectorAll('.bo-step').forEach(function(e){e.classList.remove('active');});document.getElementById('s'+n).classList.add('active');var p=Math.round(((n-1)/8)*100);document.getElementById('pf').style.width=p+'%';document.getElementById('pp').textContent=p+'%';document.getElementById('pt').textContent='Domanda '+n+' di 8';window.scrollTo({top:0,behavior:'smooth'});}
function ck(){var ok=document.getElementById('fn').value.trim()&&document.getElementById('fc').value.trim()&&document.getElementById('fe').value.indexOf('@')>0&&document.getElementById('fente').value.trim()&&document.getElementById('fp').checked;document.getElementById('breg').disabled=!ok;}
function mostra(){
  var tot=0; for(var k in ans) tot+=ans[k];
  var pct=Math.round((tot/16)*100);
  var nome=document.getElementById('fn').value;
  var cognome=document.getElementById('fc').value||'';
  var email=document.getElementById('fe').value;
  var ente=document.getElementById('fente').value;
  var tipo=document.getElementById('ft').value||'';
  var ruolo=document.getElementById('fr').value||'';
  var lk=pct>=70?'verde':pct>=40?'giallo':'rosso';
  var lt=pct>=70?'VERDE — Buona compliance':pct>=40?'GIALLO — Compliance parziale':'ROSSO — Rischio elevato';

  // Invia lead
  fetch('https://formspree.io/f/mdawbgbw',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    _to:'benessere@troisiricerche.it',_replyto:email,
    _subject:'🧠 Diagnosi BO — '+ente+' — '+lt+' ('+pct+'%)',
    strumento:'BO Checker v2 — Metodo Troisi',
    nome:nome+' '+cognome,email:email,ruolo:ruolo,ente:ente,tipo:tipo,
    punteggio:pct+'%',livello:lt,risposte:JSON.stringify(ans),
    data:new Date().toLocaleDateString('it-IT')
  })}).catch(function(){});

  // Email conferma immediata (Email 1)
  fetch('https://formspree.io/f/mdawbgbw',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    _to:email,_replyto:'benessere@troisiricerche.it',
    _subject:'La tua Diagnosi BO — '+ente+' — Troisi Ricerche',
    messaggio:'Gentile '+nome+', la diagnosi del Benessere Organizzativo per '+ente+' ha rilevato un livello '+lt+' (score: '+pct+'%). Il team di Troisi Ricerche ha ricevuto il tuo report e ti contatterà entro 24 ore lavorative per illustrare il percorso di conformità. Per fissare subito un colloquio: https://calendly.com/andreatroisi/30min — benessere@troisiricerche.it — Troisi Ricerche S.r.l. · Accreditato MIUR come Ente di Ricerca · Piattaforma TIP · Dal 2006.'
  })}).catch(function(){});

  // Nascondi form, mostra pre-output
  document.querySelectorAll('.bo-step').forEach(function(e){e.classList.remove('active');});
  document.getElementById('bo-preout').classList.add('active');
  document.getElementById('pf').style.width='100%';
  document.getElementById('pp').textContent='100%';
  document.getElementById('pt').textContent='Elaborazione in corso...';
  window.scrollTo({top:0,behavior:'smooth'});

  // Animazione bullet pre-output
  var preSteps=[
    ['Acquisizione dati organizzativi...','Verifica D.Lgs. 81/2008 art. 28...',1],
    ['Analisi adempimenti normativi...','Confronto linee guida ANAC 2017...',2],
    ['Calcolo scoring pesato...','Ponderazione criteri critici × 3...',3],
    ['Generazione diagnosi BO...','Benchmark su enti e aziende monitorate...',4],
    ['Elaborazione scenario di rischio...','Identificazione gap prioritari...',5],
    ['Diagnosi BO pronta.','Trasmissione sicura in corso...',null],
  ];
  var pi=0;
  var pint=setInterval(function(){
    if(pi>=preSteps.length){clearInterval(pint);setTimeout(mostraResult,400);return;}
    document.getElementById('bo-ai-step').textContent=preSteps[pi][0];
    document.getElementById('bo-ai-norm').textContent=preSteps[pi][1];
    if(preSteps[pi][2]){var bp=document.getElementById('bpoi-'+preSteps[pi][2]);if(bp)bp.classList.add('done');}
    pi++;
  },750);

  function mostraResult(){
    document.getElementById('bo-preout').classList.remove('active');
    document.getElementById('sres').classList.add('active');
    document.getElementById('pt').textContent='Diagnosi BO completata';
    window.scrollTo({top:0,behavior:'smooth'});

    // Gauge
    var circle=document.getElementById('bo-score-circle');
    circle.className='bo-score-circle sc-'+lk;
    document.getElementById('bo-score-pct').textContent=pct+'%';

    // Eyebrow + badge + titolo + sub
    document.getElementById('bo-prev-eyebrow').textContent='Diagnosi BO — '+ente;
    var badge=document.getElementById('bo-prev-badge');
    badge.textContent=lk==='verde'?'🟢 VERDE — Buona compliance':lk==='giallo'?'🟡 GIALLO — Compliance parziale':'🔴 ROSSO — Rischio elevato';
    badge.className='bo-preview-badge pb-'+lk;
    document.getElementById('bo-prev-title').textContent=
      lk==='verde'?ente+' — conformità sostanziale verificata':
      lk==='giallo'?ente+' — gap normativi da colmare urgentemente':
      ente+' — rischio ispettivo elevato e documentabile';
    document.getElementById('bo-prev-sub').textContent=
      lk==='verde'?'Il sistema BO è impostato correttamente. Alcune ottimizzazioni per raggiungere la piena conformità e difendibilità ispezione.':
      lk==='giallo'?'Adempimenti mancanti che espongono l\'ente a rilievi dell\'Ispettorato del Lavoro. Ogni ciclo senza intervento consolida il gap.':
      'Carenze significative e documentabili. Esposizione crescente al rischio ispettivo. La responsabilità degli amministratori è personale.';

    // Preview 3 punti principali
    var prevItems=document.getElementById('bo-prev-items');
    prevItems.innerHTML='';
    var shown=0;
    for(var i=1;i<=8&&shown<3;i++){
      var v=ans[i]!==undefined?ans[i]:0;
      if(v<2){
        var cls=v===1?'item-warn':'item-ko';
        var icon=v===1?'⚠️':'❌';
        var msg=v===1?'Gap rilevato — intervento raccomandato':'Non conforme — intervento necessario';
        var bg=v===1?'#fffbeb':'#fef2f2';
        var bc=v===1?'#fde68a':'#fecaca';
        prevItems.innerHTML+='<div class="bo-preview-item" style="background:'+bg+';border-radius:7px;border:1px solid '+bc+';margin-bottom:5px;"><div style="font-size:.9rem;flex-shrink:0">'+icon+'</div><div style="flex:1"><strong style="font-size:.8rem">'+LB[i-1]+'</strong><div style="font-size:.73rem;color:#6b7280">'+msg+' · '+NM[i-1]+'</div></div></div>';
        shown++;
      }
    }
    if(shown===0){
      prevItems.innerHTML='<div style="text-align:center;padding:10px;color:#16a34a;font-size:.82rem">✅ Tutti i punti verificati mostrano conformità soddisfacente</div>';
    }

    // PERSONALIZZAZIONE per tipo ente
    var personalTitle='Per un ente come il tuo...';
    var personalText='Il percorso di conformità sul Benessere Organizzativo ha caratteristiche specifiche per la tua tipologia organizzativa.';
    if(tipo.indexOf('Comune')>=0||tipo.indexOf('Provincia')>=0||tipo.indexOf('Regione')>=0){
      personalTitle='Per un '+tipo+'...';
      personalText='Il D.Lgs. 150/2009 impone un\'indagine BO annuale con questionario ANAC (17 sezioni). L\'OIV deve validare il processo nella Relazione sulla Performance. Il mancato adempimento blocca i premi al personale e può generare rilievi Corte dei Conti.';
    } else if(tipo.indexOf('ASL')>=0||tipo.indexOf('IRCCS')>=0){
      personalTitle='Per una '+tipo+'...';
      personalText='Le strutture sanitarie pubbliche sono soggette sia al D.Lgs. 81/2008 (DVR stress SLC) sia al D.Lgs. 150/2009 (indagine BO annuale). Il doppio obbligo richiede un sistema integrato che Troisi Ricerche sviluppa con il Metodo Troisi.';
    } else if(tipo.indexOf('Scuola')>=0||tipo.indexOf('scolastica')>=0){
      personalTitle='Per un\'istituzione scolastica...';
      personalText='Le scuole sono soggette al D.Lgs. 81/2008 per la valutazione dello stress lavoro-correlato. Il MIUR raccomanda l\'adozione del questionario ANAC per il monitoraggio del BO. Un sistema documentato è difendibile davanti all\'Ispettorato del Lavoro.';
    } else if(tipo.indexOf('impresa')>=0||tipo.indexOf('azien')>=0){
      personalTitle='Per un\'azienda privata...';
      personalText='Il D.Lgs. 81/2008 obbliga tutte le aziende a valutare il rischio da stress lavoro-correlato nel DVR. Un sistema BO documentato è difendibile in caso di ispezione e riduce l\'esposizione a sanzioni da €1.000 a €3.000.';
    }
    if(ruolo) personalTitle=ruolo+' — percorso personalizzato';
    document.getElementById('bo-personal-title').textContent=personalTitle;
    document.getElementById('bo-personal-text').textContent=personalText;

    // URGENZA dinamica
    var urgTitle, urgBody;
    if(lk==='verde'){
      urgTitle='Sei vicino alla piena conformità — consolida ora';
      urgBody='Il tuo ente ha un buon sistema BO. Il passo successivo è documentarlo formalmente in modo difendibile davanti all\'Ispettorato del Lavoro e integrarlo correttamente nel DVR.';
    } else if(lk==='giallo'){
      urgTitle='Finestra operativa limitata — agisci prima della prossima ispezione';
      urgBody='L\'Ispettorato del Lavoro può avviare ispezioni senza preavviso. Chi non ha un sistema BO documentato e metodologicamente corretto non è in grado di dimostrare la conformità. Ogni mese senza intervento consolida il gap.';
    } else {
      urgTitle='Ogni ciclo che passa aumenta il rischio ispettivo';
      urgBody='Carenze documentabili nel sistema BO. Un\'ispezione dell\'Ispettorato del Lavoro in questa situazione troverebbe inadempimenti concreti. La responsabilità del datore di lavoro e degli amministratori è personale e crescente.';
    }
    document.getElementById('bo-urg-title').textContent=urgTitle;
    document.getElementById('bo-urg-body').textContent=urgBody;

    // Dettaglio completo (nascosto inizialmente)
    var c=document.getElementById('ri');
    if(c){
      c.innerHTML='';
      for(var i=1;i<=8;i++){
        var v=ans[i]!==undefined?ans[i]:0;
        var cls2=v===2?'ri-v':v===1?'ri-g':'ri-r';
        var icon2=v===2?'✅':v===1?'⚠️':'❌';
        var msg2=v===2?'Conforme':v===1?'Parzialmente conforme — intervento raccomandato':'Non conforme — intervento necessario';
        c.innerHTML+='<div class="bo-ri '+cls2+'"><div style="font-size:1rem;flex-shrink:0;margin-top:1px">'+icon2+'</div><div class="bo-ri-t"><strong>'+LB[i-1]+'</strong>'+msg2+' · <em style="font-size:.74rem;color:#6b7280">'+NM[i-1]+'</em></div></div>';
      }
      document.getElementById('bo-detail-full').style.display='block';
    }
  }
}
function stampa(){var r=document.getElementById('sres').innerHTML;var w=window.open('','_blank','width=820,height=900');w.document.write('<html><head><title>BO Report — Troisi Ricerche<\/title><style>');w.document.write('@page{size:A4;margin:1.2cm}');w.document.write('*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;box-sizing:border-box}');w.document.write('body{font-family:Segoe UI,sans-serif;font-size:8.5pt;color:#1a1a2e;margin:0;padding:0}');w.document.write('.hr{text-align:center;border-bottom:2px solid #3dbfab;padding-bottom:10px;margin-bottom:12px}.hr h1{color:#1a7a6b;font-size:12pt;margin:0 0 2px}.hr p{color:#6b7280;font-size:7pt;margin:0}');w.document.write('.bo-res-top{text-align:center;padding:8px 0 6px}');w.document.write('.bo-gauge{width:65px;height:65px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:1.1rem;font-weight:800;border:4px solid;margin-bottom:4px}');w.document.write('.g-v{border-color:#16a34a;color:#16a34a;background:#f0fdf4}.g-g{border-color:#d97706;color:#d97706;background:#fffbeb}.g-r{border-color:#dc2626;color:#dc2626;background:#fef2f2}');w.document.write('.bo-lv{display:inline-block;font-size:6.5pt;font-weight:700;text-transform:uppercase;padding:2px 10px;border-radius:20px;margin-bottom:5px}');w.document.write('.lv-v{background:#dcfce7;color:#16a34a}.lv-g{background:#fef9c3;color:#d97706}.lv-r{background:#fee2e2;color:#dc2626}');w.document.write('.bo-res-title{font-size:10pt;font-weight:800;color:#1a3a5c;margin-bottom:3px}.bo-res-sub{font-size:7.5pt;color:#6b7280;line-height:1.4;margin-bottom:6px}');w.document.write('.bo-ri-list{display:flex;flex-direction:column;gap:3px;margin:6px 0}');w.document.write('.bo-ri{display:flex;gap:6px;align-items:flex-start;padding:5px 8px;border-radius:5px;border:1pt solid}');w.document.write('.ri-v{background:#f0fdf4;border-color:#bbf7d0}.ri-g{background:#fffbeb;border-color:#fde68a}.ri-r{background:#fef2f2;border-color:#fecaca}');w.document.write('.bo-ri-t{font-size:7pt;line-height:1.3}.bo-ri-t strong{display:block;font-size:7.5pt;margin-bottom:1px}');w.document.write('.bo-cta{page-break-before:always}');w.document.write('.bo-cta-h{background:#1a7a6b!important;padding:12px;text-align:center;border-radius:6px 6px 0 0}');w.document.write('.bo-cta-h h3{color:#fff;font-size:10pt;font-weight:800;margin:0 0 3px}.bo-cta-h h3 em{color:#99f6e4;font-style:normal}');w.document.write('.bo-cta-h p{color:rgba(255,255,255,.85);font-size:7pt;line-height:1.4;margin:0}');w.document.write('.bo-cta-b{padding:10px 12px}');w.document.write('.bo-svc-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:8px}');w.document.write('.bo-svc{display:flex;gap:5px;align-items:flex-start;padding:6px;background:#e8f7f4!important;border-radius:5px;border:1pt solid #b2e8e0}');w.document.write('.bo-svc h4{font-size:7pt;font-weight:700;color:#1a7a6b;margin:0 0 1px}.bo-svc p{font-size:6.5pt;color:#6b7280;line-height:1.3;margin:0}');w.document.write('.tip-b{background:#1e3a8a!important;color:#fff;font-size:6pt;padding:1px 4px;border-radius:3px}');w.document.write('.bo-out{background:#e8f7f4!important;border:1pt solid #b2e8e0;border-radius:5px;padding:7px 8px;margin-bottom:7px;display:flex;gap:7px}');w.document.write('.bo-out h4{font-size:7.5pt;font-weight:700;color:#1a7a6b;margin:0 0 3px}.bo-out p{font-size:7pt;color:#6b7280;line-height:1.4;margin:0 0 4px}');w.document.write('.bo-out-pills{display:flex;gap:3px;flex-wrap:wrap}');w.document.write('.bo-out-pill{font-size:6pt;font-weight:600;background:#b2e8e0!important;color:#1a7a6b;padding:2px 5px;border-radius:8px}');w.document.write('.bo-proof{background:#1a3a5c!important;border-radius:5px;padding:7px 9px;display:flex;gap:8px;align-items:center;margin-bottom:7px}');w.document.write('.bo-ps-wrap{display:flex;gap:10px;flex:1}.bo-ps{text-align:center}');w.document.write('.bo-ps b{display:block;font-size:9pt;font-weight:700;color:#e8a020}.bo-ps small{font-size:5.5pt;color:rgba(255,255,255,.7);line-height:1.2}');w.document.write('.bo-btns{display:flex;gap:5px;margin-bottom:5px}');w.document.write('.bo-btn-g{flex:1;background:#1a7a6b!important;color:#fff;font-weight:700;font-size:7pt;padding:6px;border-radius:5px;text-align:center;text-decoration:none;display:block}');w.document.write('.bo-btn-o{flex:1;color:#1a7a6b;font-weight:600;font-size:7pt;padding:6px;border-radius:5px;text-align:center;text-decoration:none;border:1pt solid #3dbfab;display:block}');w.document.write('.bo-btn-p{display:none!important}');w.document.write('.bo-cta-f{background:#f8fafa;border-top:1pt solid #d1ece8;padding:5px 8px;font-size:6pt;color:#6b7280;line-height:1.3;display:flex;gap:5px}');w.document.write('<\/style><\/head><body>');w.document.write('<div class="hr"><h1>Benessere Organizzativo — Report Compliance<\/h1><p>Troisi Ricerche S.r.l. · benessereorganizzativo.it · '+new Date().toLocaleDateString('it-IT')+'<\/p><\/div>');w.document.write(r);w.document.write('<\/body><\/html>');w.document.close();setTimeout(function(){w.print();},600);}
</script>
</body>
</html>