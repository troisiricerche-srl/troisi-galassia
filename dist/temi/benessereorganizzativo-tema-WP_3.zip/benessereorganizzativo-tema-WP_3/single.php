<?php get_template_part('inc/tr-head'); ?>
<?php while (have_posts()) : the_post(); ?>
<main class="tr-single">
  <article class="tr-post">
    <header class="tr-post-header">
      <div class="tr-post-kicker"><a class="tr-post-tag" href="<?php echo esc_url(bo_url_archivio()); ?>"><?php echo esc_html(bo_tema()); ?></a> <span><?php echo esc_html(get_the_date('j F Y')); ?></span></div>
      <h1><?php the_title(); ?></h1>
      <?php if (has_excerpt()) : ?><p class="tr-post-sommario"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
      <p class="tr-post-byline">di <strong>Andrea Troisi</strong> · BenessereOrganizzativo · <?php echo (int) bo_minuti_lettura(); ?> min di lettura</p>
    </header>
    <div class="tr-post-body">
      <?php the_content(); ?>
    </div>
    <footer class="tr-post-footer">
      <div class="tr-autore">
        <div class="tr-autore-badge">AT</div>
        <div><strong>Andrea Troisi</strong><br>Statistico, fondatore di Troisi Ricerche (2006), docente di Economia del turismo all'Università di Bari. Giornalista.</div>
      </div>
      <div class="tr-share">
        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo rawurlencode(get_permalink()); ?>" target="_blank" rel="noopener">Condividi su LinkedIn ↗</a>
        <a href="<?php echo esc_url(bo_url_archivio()); ?>">Tutte le analisi →</a>
        <a href="<?php echo esc_url(home_url('/')); ?>">Torna a BenessereOrganizzativo</a>
      </div>
      <nav class="tr-post-nav">
        <div><?php previous_post_link('%link', '← %title'); ?></div>
        <div><?php next_post_link('%link', '%title →'); ?></div>
      </nav>
    </footer>
  </article>
</main>
<?php endwhile; ?>
<?php get_template_part('inc/tr-footer'); ?>
