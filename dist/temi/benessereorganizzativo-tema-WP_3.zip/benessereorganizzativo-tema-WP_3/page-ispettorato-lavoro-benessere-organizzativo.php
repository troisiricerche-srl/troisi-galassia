<?php /* Template Name: Articolo — Ispettorato Lavoro Benessere Organizzativo */ ?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo (DVR e SLC) | Troisi Ricerche</title>
<meta name="description" content="Scopri cosa verifica l'Ispettorato del Lavoro su DVR, stress lavoro correlato e benessere organizzativo. Evita sanzioni e non conformità. Normativa D.Lgs. 81/2008, D.Lgs. 150/2009, ANAC. Metodo Troisi.">
<meta name="keywords" content="ispettorato del lavoro benessere organizzativo, cosa controlla ispettorato del lavoro, controlli ispettorato lavoro DVR, stress lavoro correlato ispettorato, verifica DVR ispettorato lavoro, ispezione lavoro cosa controllano, sanzioni ispettorato lavoro DVR, cosa controlla ispettorato lavoro stress lavoro correlato, cosa succede se DVR non è aggiornato, obbligo benessere organizzativo PA ispettorato, verifica benessere organizzativo enti pubblici, controlli ANAC benessere organizzativo, D.Lgs. 81/2008 stress lavoro correlato, D.Lgs. 150/2009 benessere organizzativo, linee guida INAIL stress lavoro, ANAC questionario benessere organizzativo, Corte dei Conti responsabilità amministratori, DVR stress lavoro correlato obbligo, sanzioni DVR incompleto, valutazione SLC obbligatoria, compliance enti pubblici lavoro, audit benessere organizzativo, Metodo Troisi, Troisi Ricerche, piattaforma TIP">
<link rel="canonical" href="https://www.benessereorganizzativo.it/ispettorato-lavoro-benessere-organizzativo">
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large">
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">

<!-- Open Graph — Facebook, LinkedIn -->
<meta property="og:type" content="article">
<meta property="og:title" content="Cosa controlla davvero l'Ispettorato del Lavoro sul benessere organizzativo">
<meta property="og:description" content="DVR, stress lavoro-correlato, indagini obbligatorie e responsabilità: cosa viene verificato durante un'ispezione. Guida completa — Metodo Troisi · Troisi Ricerche.">
<meta property="og:url" content="https://www.benessereorganizzativo.it/ispettorato-lavoro-benessere-organizzativo">
<meta name="image" property="og:image" content="https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/blog-ispettorato-lavoro-bo.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:site_name" content="BenessereOrganizzativo.it — Metodo Troisi">
<meta property="article:published_time" content="2026-03-20T09:00:00+01:00">
<meta property="article:author" content="Andrea Troisi">
<meta property="article:section" content="Normativa">
<meta property="article:tag" content="benessere organizzativo, ispettorato del lavoro, DVR, stress lavoro-correlato, D.Lgs. 81/2008">

<!-- Twitter/X Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@troisiricerche">
<meta name="twitter:title" content="Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo">
<meta name="twitter:description" content="DVR, stress lavoro-correlato, ANAC e responsabilità: guida completa — Metodo Troisi · Troisi Ricerche.">
<meta name="twitter:image" content="https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/blog-ispettorato-lavoro-bo.png">

<!-- LinkedIn specific -->
<meta name="author" content="Andrea Troisi — Troisi Ricerche S.r.l.">

<!-- JSON-LD Article -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Cosa controlla davvero l'Ispettorato del Lavoro sul benessere organizzativo",
  "description": "DVR, stress lavoro-correlato, indagini obbligatorie e responsabilità: cosa viene verificato durante un'ispezione sul Benessere Organizzativo nella PA e nelle aziende.",
  "image": "https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/blog-ispettorato-lavoro-bo.png",
  "datePublished": "2026-03-20",
  "dateModified": "2026-03-20",
  "author": {
    "@type": "Person",
    "name": "Andrea Troisi",
    "url": "https://andreatroisi.it",
    "jobTitle": "Ricercatore e Statistico — Fondatore Troisi Ricerche"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Troisi Ricerche S.r.l.",
    "url": "https://www.benessereorganizzativo.it",
    "logo": { "@type": "ImageObject", "url": "<?php echo get_template_directory_uri(); ?>/favicon.png" }
  },
  "mainEntityOfPage": { "@type": "WebPage", "@id": "https://www.benessereorganizzativo.it/ispettorato-lavoro-benessere-organizzativo" },
  "articleSection": "Normativa",
  "keywords": "ispettorato lavoro, benessere organizzativo, DVR, stress lavoro correlato, D.Lgs. 81/2008, ANAC, OIV, PA"
}
</script>

<!-- JSON-LD BreadcrumbList -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.benessereorganizzativo.it" },
    { "@type": "ListItem", "position": 2, "name": "Approfondimenti", "item": "https://www.benessereorganizzativo.it/approfondimenti" },
    { "@type": "ListItem", "position": 3, "name": "Ispettorato del Lavoro e Benessere Organizzativo", "item": "https://www.benessereorganizzativo.it/ispettorato-lavoro-benessere-organizzativo" }
  ]
}
</script>

<style>
:root {
  --teal:#3dbfab; --teal-dark:#2a9d8a; --teal-deep:#1a7a6b;
  --teal-light:#e8f7f4; --teal-mid:#b2e8e0;
  --blu:#1a3a5c; --accento:#e8a020; --viola:#7c3aed;
  --testo:#1a2e2a; --grigio:#6b7280;
  --grigio-bg:#f8fafa; --bordo:#d1ece8;
  --bianco:#ffffff; --verde:#16a34a;
  --rosso:#dc2626; --warn:#d97706;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;overflow-x:hidden;font-family:'Segoe UI',system-ui,sans-serif;color:var(--testo);background:var(--grigio-bg);line-height:1.6}
a{text-decoration:none;color:inherit}
img,svg{max-width:100%}

/* NAVBAR */
.navbar{background:var(--bianco);border-bottom:3px solid var(--teal);position:sticky;top:0;z-index:100;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.navbar .inner{max-width:1200px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;height:64px}
.navbar-brand{display:flex;align-items:center;gap:10px;text-decoration:none}
.brand-logo{font-size:1.05rem;font-weight:800;color:var(--teal-deep)}
.brand-logo span{color:var(--teal)}
.brand-sub{font-size:.62rem;color:var(--grigio);letter-spacing:.04em;display:block;margin-top:1px}
.navbar-links{display:flex;gap:4px;align-items:center}
.navbar-links a{padding:6px 10px;border-radius:6px;font-size:.82rem;color:var(--testo);font-weight:500;transition:all .2s}
.navbar-links a:hover{background:var(--teal-light);color:var(--teal-deep)}
.navbar-links .nav-active{background:var(--teal-light);color:var(--teal-deep);font-weight:700}
.navbar-links .btn-contatti{border:1.5px solid var(--bordo);color:var(--teal-deep);font-weight:600}
.navbar-links .btn-demo{background:var(--teal);color:var(--bianco)!important;font-weight:700;padding:7px 16px}
.navbar-links .btn-demo:hover{background:var(--teal-dark)}
.hamburger{display:none;flex-direction:column;gap:5px;background:none;border:none;cursor:pointer;padding:6px}
.hamburger span{display:block;width:22px;height:2px;background:var(--testo);border-radius:2px}
.mobile-menu{display:none;position:fixed;top:64px;left:0;right:0;bottom:0;background:var(--bianco);z-index:99;padding:20px;flex-direction:column;gap:4px;overflow-y:auto}
.mobile-menu.open{display:flex}
.mobile-menu a{padding:14px 16px;border-radius:8px;font-size:1rem;color:var(--testo);font-weight:500;border-bottom:1px solid var(--bordo)}
.mobile-menu .nav-active{background:var(--teal-light);color:var(--teal-deep);font-weight:700}
.mobile-menu .btn-demo{background:var(--teal);color:var(--bianco)!important;text-align:center;margin-top:8px;border-bottom:none}
@media(max-width:900px){.navbar-links{display:none!important}.hamburger{display:flex}}

/* BREADCRUMB */
.breadcrumb{max-width:1100px;margin:0 auto;padding:12px 20px;font-size:.78rem;color:var(--grigio);display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.breadcrumb a{color:var(--teal-deep);font-weight:500}
.breadcrumb a:hover{text-decoration:underline}
.breadcrumb-sep{color:var(--bordo)}

/* LAYOUT */
.art-layout{max-width:1100px;margin:0 auto;padding:32px 20px 64px;display:grid;grid-template-columns:1fr 300px;gap:36px}
@media(max-width:860px){.art-layout{grid-template-columns:1fr;padding:20px 16px 48px}}

/* ARTICLE */
article.art-body{min-width:0}

/* HERO IMG */
.art-hero-img{width:100%;max-height:400px;overflow:hidden;border-radius:14px;margin-bottom:24px;box-shadow:0 4px 24px rgba(0,0,0,.1)}
.art-hero-img img,.art-hero-img svg{width:100%;height:100%;object-fit:cover;display:block}

/* ARTICLE META */
.art-meta{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:14px}
.art-tag{font-size:.65rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;background:var(--teal-light);color:var(--teal-deep);border:1px solid var(--teal-mid);padding:3px 10px;border-radius:20px}
.art-tag-red{background:#fef2f2;color:var(--rosso);border-color:#fecaca}
.art-date{font-size:.75rem;color:var(--grigio)}
.art-author{font-size:.75rem;color:var(--grigio)}

/* ARTICLE TYPOGRAPHY */
.art-h1{font-size:clamp(1.6rem,3vw,2.2rem);font-weight:900;line-height:1.2;color:var(--testo);margin-bottom:10px}
.art-subtitle{font-size:1rem;color:var(--grigio);line-height:1.65;margin-bottom:20px;border-left:3px solid var(--teal);padding-left:14px;font-style:italic}
.art-content{font-size:.95rem;line-height:1.75;color:var(--testo)}
.art-content p{margin-bottom:14px}
.art-content h2{font-size:1.2rem;font-weight:800;color:var(--teal-deep);margin:28px 0 10px;padding-bottom:6px;border-bottom:2px solid var(--teal-light)}
.art-content h3{font-size:1rem;font-weight:700;color:var(--testo);margin:20px 0 8px}
.art-content ul{margin:8px 0 14px 0;padding-left:0;list-style:none;display:flex;flex-direction:column;gap:5px}
.art-content ul li{display:flex;gap:9px;align-items:flex-start;font-size:.92rem;line-height:1.55;padding:5px 8px;background:var(--grigio-bg);border-radius:7px;border-left:3px solid var(--teal-mid)}
.art-content ul li::before{content:'';flex-shrink:0}
.art-content ul.ul-red li{border-left-color:#fecaca;background:#fff5f5}
.art-content ul.ul-green li{border-left-color:#bbf7d0;background:#f0fdf4}
.art-content strong{color:var(--testo)}

/* CALLOUT BOXES */
.art-callout{border-radius:10px;padding:14px 16px;margin:16px 0;display:flex;gap:12px;align-items:flex-start}
.art-callout-teal{background:var(--teal-light);border:1.5px solid var(--teal-mid)}
.art-callout-red{background:#fef2f2;border:1.5px solid #fecaca}
.art-callout-warn{background:#fffbeb;border:1.5px solid #fde68a}
.art-callout-blu{background:#eff6ff;border:1.5px solid #bfdbfe}
.ac-icon{font-size:1.2rem;flex-shrink:0;margin-top:1px}
.ac-text{font-size:.88rem;line-height:1.6}
.ac-text strong{font-size:.9rem}

/* NORM BADGE */
.art-norm{display:inline-flex;align-items:center;gap:6px;font-size:.73rem;font-weight:700;color:var(--teal-deep);background:var(--teal-light);border:1px solid var(--teal-mid);padding:4px 12px;border-radius:20px;margin:4px 0}

/* TABLE OF CONTENTS */
.art-toc{background:var(--bianco);border:1.5px solid var(--bordo);border-radius:12px;padding:18px 20px;margin-bottom:24px}
.art-toc h4{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--teal-deep);margin-bottom:10px}
.art-toc ol{padding-left:18px;display:flex;flex-direction:column;gap:6px}
.art-toc li{font-size:.86rem;color:var(--grigio)}
.art-toc li a{color:var(--teal-deep);font-weight:500;transition:color .15s}
.art-toc li a:hover{color:var(--teal-dark);text-decoration:underline}

/* SOCIAL SHARING */
.art-share{background:var(--bianco);border:1.5px solid var(--bordo);border-radius:12px;padding:18px 20px;margin:28px 0}
.art-share h4{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--grigio);margin-bottom:12px}
.share-btns{display:flex;gap:9px;flex-wrap:wrap}
.share-btn{display:inline-flex;align-items:center;gap:7px;font-size:.82rem;font-weight:700;padding:9px 16px;border-radius:8px;text-decoration:none;transition:all .15s;border:none;cursor:pointer;font-family:inherit}
.share-btn:hover{transform:translateY(-1px);opacity:.9}
.share-linkedin{background:#0A66C2;color:#fff}
.share-facebook{background:#1877F2;color:#fff}
.share-twitter{background:#000;color:#fff}
.share-whatsapp{background:#25D366;color:#fff}
.share-copy{background:var(--grigio-bg);color:var(--testo);border:1.5px solid var(--bordo)}
.share-copy.copied{background:var(--verde);color:#fff;border-color:var(--verde)}

/* CTA FINALE */
.art-cta-final{background:linear-gradient(135deg,#1a7a6b,#1e3a8a);border-radius:14px;padding:28px 24px;margin:32px 0;text-align:center;color:#fff}
.art-cta-final .cta-eyebrow{font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.5);margin-bottom:10px}
.art-cta-final h3{font-size:1.3rem;font-weight:900;line-height:1.3;margin-bottom:8px}
.art-cta-final h3 em{color:#e8a020;font-style:normal}
.art-cta-final p{font-size:.9rem;color:rgba(255,255,255,.8);line-height:1.6;margin-bottom:16px}
.art-cta-btn{display:inline-flex;align-items:center;gap:8px;background:#e8a020;color:var(--testo)!important;font-weight:800;font-size:.95rem;padding:13px 24px;border-radius:10px;text-decoration:none;transition:all .2s}
.art-cta-btn:hover{background:#f5c842;transform:translateY(-2px)}
.art-cta-micro{font-size:.72rem;color:rgba(255,255,255,.45);margin-top:10px}

/* TAG ARTICOLO */
.art-tags{display:flex;gap:7px;flex-wrap:wrap;margin:20px 0}
.art-tag-item{font-size:.72rem;background:var(--grigio-bg);border:1px solid var(--bordo);color:var(--grigio);padding:3px 10px;border-radius:20px}

/* AUTHOR BOX */
.art-author-box{background:var(--bianco);border:1.5px solid var(--bordo);border-radius:12px;padding:18px 20px;display:flex;gap:14px;align-items:flex-start;margin:24px 0}
.auth-avatar{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--teal-dark),var(--blu));display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;color:#fff;flex-shrink:0}
.auth-name{font-size:.9rem;font-weight:800;color:var(--testo);margin-bottom:2px}
.auth-role{font-size:.75rem;color:var(--grigio);margin-bottom:5px}
.auth-bio{font-size:.8rem;color:var(--grigio);line-height:1.5}

/* RELATED */
.art-related{margin:24px 0}
.art-related h4{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--grigio);margin-bottom:12px}
.rel-item{display:flex;gap:10px;align-items:flex-start;padding:10px;background:var(--bianco);border:1px solid var(--bordo);border-radius:9px;margin-bottom:8px}
.rel-icon{font-size:1.1rem;flex-shrink:0}
.rel-title{font-size:.85rem;font-weight:600;color:var(--teal-deep)}
.rel-desc{font-size:.75rem;color:var(--grigio);line-height:1.4}

/* SIDEBAR */
.art-sidebar{display:flex;flex-direction:column;gap:20px}
.sb-card{background:var(--bianco);border:1.5px solid var(--bordo);border-radius:12px;padding:18px;box-shadow:0 2px 10px rgba(0,0,0,.04)}
.sb-title{font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--teal-deep);margin-bottom:12px}
.sb-tool{background:linear-gradient(135deg,#1a7a6b,#1e3a8a);border-radius:12px;padding:18px;color:#fff}
.sb-tool .sb-title{color:rgba(255,255,255,.6)}
.sb-tool p{font-size:.82rem;color:rgba(255,255,255,.8);line-height:1.55;margin-bottom:12px}
.sb-tool-cta{display:block;background:#e8a020;color:var(--testo)!important;font-weight:800;font-size:.85rem;padding:11px 16px;border-radius:8px;text-align:center;transition:all .2s}
.sb-tool-cta:hover{background:#f5c842}
.sb-toc-list{list-style:none;display:flex;flex-direction:column;gap:5px}
.sb-toc-list li a{font-size:.82rem;color:var(--teal-deep);font-weight:500;padding:4px 0;display:flex;gap:6px;border-bottom:1px solid var(--teal-light);transition:color .15s}
.sb-toc-list li a:hover{color:var(--teal-dark)}
.sb-norm-list{list-style:none;display:flex;flex-direction:column;gap:6px}
.sb-norm-list li{font-size:.78rem;color:var(--grigio);padding:5px 0;border-bottom:1px solid var(--teal-light);line-height:1.4;display:flex;gap:7px;align-items:flex-start}
.sb-brand{background:var(--teal-light);border:1.5px solid var(--teal-mid);border-radius:12px;padding:16px}
.sb-brand h4{font-size:.88rem;font-weight:800;color:var(--teal-deep);margin-bottom:6px}
.sb-brand p{font-size:.78rem;color:var(--grigio);line-height:1.5;margin-bottom:8px}
.sb-brand a{font-size:.78rem;color:var(--teal-deep);font-weight:600;text-decoration:underline;display:block;margin-top:3px}

/* FOOTER */
.site-footer{background:#0d2420;color:rgba(255,255,255,.7);padding:48px 20px 24px}
.footer-inner{max-width:1100px;margin:0 auto}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:32px;margin-bottom:32px}
.footer-brand .brand-name{font-size:1rem;font-weight:800;color:#fff;margin-bottom:8px}
.footer-brand p{font-size:.78rem;line-height:1.6;margin-bottom:8px}
.brand-legal{font-size:.72rem;color:rgba(255,255,255,.4)}
.footer-col h4{font-size:.72rem;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px}
.footer-col ul{list-style:none;display:flex;flex-direction:column;gap:7px}
.footer-col ul a{font-size:.8rem;color:rgba(255,255,255,.6);transition:color .2s}
.footer-col ul a:hover{color:var(--teal)}
.footer-bottom{border-top:1px solid rgba(255,255,255,.1);padding-top:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;font-size:.75rem}
.footer-legal{display:flex;gap:14px}
.footer-legal a{color:rgba(255,255,255,.4);transition:color .2s}
.footer-legal a:hover{color:var(--teal)}

/* RESPONSIVE */
@media(max-width:640px){
  .art-h1{font-size:1.5rem}
  .share-btns{gap:7px}
  .share-btn{font-size:.76rem;padding:8px 12px}
  .art-cta-final{padding:20px 16px}
  .art-author-box{flex-direction:column;gap:10px}
}
@media(max-width:480px){
  .footer-grid{grid-template-columns:1fr 1fr}
  .art-cta-btn{width:100%;justify-content:center}
}
@media(max-width:360px){
  .footer-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="inner">
    <a href="https://www.benessereorganizzativo.it" class="navbar-brand">
      <div>
        <div class="brand-logo">Benessere<span>Organizzativo</span></div>
        <span class="brand-sub">Metodo ANAC · PA e Aziende · Powered by Troisi Ricerche</span>
      </div>
    </a>
    <div class="navbar-links">
      <a href="https://www.benessereorganizzativo.it/#normativa">Normativa</a>
      <a href="https://www.benessereorganizzativo.it/#circolo">Metodo</a>
      <a href="https://www.benessereorganizzativo.it/#questionario">Questionario ANAC</a>
      <a href="https://www.benessereorganizzativo.it/#output">Output</a>
      <a href="https://www.benessereorganizzativo.it/#clienti">Clienti</a>
      <a href="https://www.benessereorganizzativo.it/#chi-siamo">Chi siamo</a>
      <a href="<?php echo home_url('/approfondimenti'); ?>" class="nav-active">Approfondimenti</a>
      <a href="mailto:benessere@troisiricerche.it" class="btn-contatti">Scrivici</a>
      <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo">Richiedi preventivo ↗</a>
    </div>
    <button class="hamburger" id="hamburger-btn" onclick="toggleMobileMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
<div class="mobile-menu" id="mobile-menu">
  <a href="https://www.benessereorganizzativo.it/#normativa" onclick="closeMobileMenu()">Normativa</a>
  <a href="https://www.benessereorganizzativo.it/#circolo" onclick="closeMobileMenu()">Metodo</a>
  <a href="https://www.benessereorganizzativo.it/#questionario" onclick="closeMobileMenu()">Questionario ANAC</a>
  <a href="https://www.benessereorganizzativo.it/#output" onclick="closeMobileMenu()">Output</a>
  <a href="https://www.benessereorganizzativo.it/#clienti" onclick="closeMobileMenu()">Clienti</a>
  <a href="https://www.benessereorganizzativo.it/#chi-siamo" onclick="closeMobileMenu()">Chi siamo</a>
  <a href="<?php echo home_url('/approfondimenti'); ?>" class="nav-active" onclick="closeMobileMenu()">Approfondimenti</a>
  <a href="https://calendly.com/andreatroisi/30min" target="_blank" class="btn-demo" onclick="closeMobileMenu()">Richiedi preventivo ↗</a>
</div>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <a href="https://www.benessereorganizzativo.it">Home</a>
  <span class="breadcrumb-sep">›</span>
  <a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a>
  <span class="breadcrumb-sep">›</span>
  <span>Ispettorato del Lavoro e Benessere Organizzativo</span>
</div>

<!-- MAIN LAYOUT -->
<div class="art-layout">

  <!-- ARTICLE CONTENT -->
  <article class="art-body" itemscope itemtype="https://schema.org/Article">

    <!-- Hero image -->
    <div class="art-hero-img">
      <img src="https://www.benessereorganizzativo.it/wp-content/themes/benessereorganizzativo-tema-WP_3/blog-ispettorato-lavoro-bo.png"
           alt="Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo — illustrazione normativa DVR stress SLC"
           width="700" height="400" loading="eager"
           itemprop="image">
    </div>

    <!-- Meta -->
    <div class="art-meta">
      <span class="art-tag">⚖️ Normativa</span>
      <span class="art-tag art-tag-red">⚠️ Rischio Ispettivo</span>
      <span class="art-date">📅 <time itemprop="datePublished" datetime="2026-03-20">Marzo 2026</time></span>
      <span class="art-author">✍️ <span itemprop="author">Andrea Troisi — Troisi Ricerche</span></span>
    </div>

    <!-- H1 -->
    <h1 class="art-h1" itemprop="headline">
      Cosa controlla l'Ispettorato del Lavoro sul benessere organizzativo: DVR, stress lavoro-correlato e sanzioni
    </h1>

    <!-- Sottotitolo -->
    <p class="art-subtitle" itemprop="description">
      DVR, stress lavoro-correlato, indagini obbligatorie e responsabilità: cosa viene verificato durante un'ispezione sul Benessere Organizzativo nella PA e nelle aziende private.
    </p>

    <!-- Indice -->
    <nav class="art-toc" aria-label="Indice dell'articolo">
      <h4>📋 Indice dell'articolo</h4>
      <ol>
        <li><a href="#intro">Introduzione — il BO non è un tema soft</a></li>
        <li><a href="#dvr">Il DVR e lo stress lavoro-correlato (D.Lgs. 81/2008)</a></li>
        <li><a href="#indagine-bo">Indagine BO nella PA (D.Lgs. 150/2009)</a></li>
        <li><a href="#metodo-anac">Metodo ANAC e validità scientifica</a></li>
        <li><a href="#figure">Coinvolgimento delle figure obbligatorie</a></li>
        <li><a href="#piano">Piano di miglioramento</a></li>
        <li><a href="#comunicazione">Comunicazione ai dipendenti</a></li>
        <li><a href="#conseguenze">Cosa succede in caso di non conformità</a></li>
        <li><a href="#conclusione">Conclusione e diagnosi gratuita</a></li>
      </ol>
    </nav>

    <!-- ARTICLE BODY -->
    <div class="art-content" itemprop="articleBody">

      <!-- INTRO -->
      <section id="intro">
        <h2>Benessere organizzativo e ispettorato del lavoro: non è un tema soft</h2>
        <p>Molti enti pubblici e aziende considerano il benessere organizzativo come un argomento legato al clima interno o alla soddisfazione dei dipendenti — qualcosa di utile ma non urgente, non vincolante.</p>
        <p>In realtà, il benessere organizzativo è un <strong>ambito normativo preciso</strong>, direttamente collegato alla sicurezza sul lavoro e alla responsabilità personale del datore di lavoro.</p>

        <div class="art-callout art-callout-teal">
          <span class="ac-icon">⚖️</span>
          <div class="ac-text">
            <strong>L'Ispettorato Nazionale del Lavoro, durante un controllo, non valuta percezioni:</strong> verifica documenti, processi e conformità normativa. Se il sistema BO dell'ente non è in ordine, le conseguenze sono concrete e documentabili. Il DVR deve includere la valutazione dello stress lavoro-correlato ai sensi del D.Lgs. 81/2008. La metodologia deve essere conforme alle linee guida INAIL e coerente con le indicazioni ANAC.
          </div>
        </div>

        <p>Questo articolo descrive punto per punto cosa viene effettivamente controllato durante un'ispezione sul Benessere Organizzativo, quali sono le norme di riferimento e cosa succede in caso di inadempimento.</p>
      </section>

      <!-- DVR -->
      <section id="dvr">
        <h2>1. Controlli ispettorato lavoro: DVR e stress lavoro-correlato</h2>
        <span class="art-norm">⚖️ D.Lgs. 81/2008 art. 28 — Obbligo per tutti i datori di lavoro</span>

        <p>Il primo elemento che viene controllato durante un'ispezione è il <strong>Documento di Valutazione dei Rischi (DVR)</strong>.</p>
        <p>Il DVR deve includere la valutazione dello stress lavoro-correlato. Questo è obbligatorio ai sensi del D.Lgs. 81/2008, art. 28. Secondo questa norma, il DVR deve includere obbligatoriamente:</p>

        <ul>
          <li>✅ la valutazione del rischio da stress lavoro-correlato (SLC)</li>
          <li>✅ una sezione aggiornata e documentata — non generica</li>
          <li>✅ il coinvolgimento formale del RSPP e del medico competente</li>
        </ul>

        <div class="art-callout art-callout-red">
          <span class="ac-icon">❌</span>
          <div class="ac-text">
            <strong>Un DVR senza la sezione stress lavoro-correlato è considerato incompleto.</strong> Questo espone il datore di lavoro a sanzioni personali, indipendentemente dalle dimensioni dell'organizzazione.
          </div>
        </div>

        <h3>Conseguenze di un DVR incompleto: sanzioni e responsabilità datore di lavoro</h3>
        <ul class="ul-red">
          <li>⚠️ Sanzioni amministrative da <strong>€1.000 a €3.000</strong> per il datore di lavoro</li>
          <li>⚠️ Responsabilità penale diretta in caso di infortunio riconducibile allo stress</li>
          <li>⚠️ Impossibilità di dimostrare la conformità in sede ispettiva</li>
        </ul>
      </section>

      <!-- INDAGINE BO -->
      <section id="indagine-bo">
        <h2>2. Obbligo benessere organizzativo PA: indagine annuale e ispezione</h2>
        <span class="art-norm">⚖️ D.Lgs. 150/2009 art. 14 c.5 — Indagine annuale obbligatoria per la PA</span>

        <p>Per la <strong>Pubblica Amministrazione</strong>, entra in gioco il D.Lgs. 150/2009, che introduce un obbligo ulteriore rispetto alla normativa sulla sicurezza.</p>
        <p>Questo decreto prevede:</p>

        <ul>
          <li>📋 indagine annuale sul Benessere Organizzativo</li>
          <li>📋 integrazione nella Relazione sulla Performance</li>
          <li>📋 validazione formale da parte dell'OIV (Organismo Indipendente di Valutazione)</li>
        </ul>

        <div class="art-callout art-callout-warn">
          <span class="ac-icon">⏳</span>
          <div class="ac-text">
            <strong>Attenzione alla periodicità:</strong> non è sufficiente aver condotto un'indagine anni fa. L'obbligo è annuale per la PA. Ogni anno senza rilevazione formale consolida il gap normativo.
          </div>
        </div>

        <h3>Cosa succede se non fai l'indagine BO nella PA (D.Lgs. 150/2009)</h3>
        <ul class="ul-red">
          <li>⚠️ La Relazione sulla Performance non è validabile dall'OIV</li>
          <li>⚠️ I premi al personale possono essere bloccati</li>
          <li>⚠️ Il ciclo di gestione della performance risulta incompleto</li>
          <li>⚠️ Possibile rilievo da parte della Corte dei Conti</li>
        </ul>
      </section>

      <!-- METODO ANAC -->
      <section id="metodo-anac">
        <h2>3. Verifica DVR ispettorato: metodo ANAC e validità scientifica</h2>
        <span class="art-norm">⚖️ Linee guida DFP · ANAC — Metodologia obbligatoria per la PA</span>

        <p>Non basta "fare un questionario". L'ANAC e il Dipartimento della Funzione Pubblica indicano con precisione quali caratteristiche deve avere lo strumento di rilevazione:</p>

        <ul>
          <li>🔬 questionario strutturato con le <strong>17 sezioni</strong> del modello ANAC</li>
          <li>🔬 metodo scientifico di campionamento (es. formula di Cochran)</li>
          <li>🔬 risultati tracciabili, comparabili nel tempo e presentabili all'OIV</li>
          <li>🔬 scala validata scientificamente — non un modulo interno generico</li>
        </ul>

        <div class="art-callout art-callout-red">
          <span class="ac-icon">⚠️</span>
          <div class="ac-text">
            <strong>Un'indagine condotta con strumenti non validati è:</strong>
            <br>— giuridicamente irrilevante per il D.Lgs. 150/2009
            <br>— non difendibile in sede ispettiva
            <br>— non integrabile correttamente nel DVR
          </div>
        </div>

        <p>Un'indagine non condotta con il questionario ANAC a 17 sezioni o metodo equivalente validato è giuridicamente irrilevante ai fini del D.Lgs. 150/2009 e non difendibile davanti all'Ispettorato del Lavoro. Il <strong>Metodo Troisi</strong> adotta il questionario ANAC a 17 sezioni, la formula di Cochran per il campionamento e un sistema di scoring pesato su 8 criteri normativi — erogato tramite la <strong>Piattaforma TIP</strong> (<a href="https://tiplive.it" target="_blank" rel="noopener" style="color:var(--teal-deep);font-weight:600">tiplive.it</a>), anonima e GDPR-compliant.</p>
      </section>

      <!-- FIGURE -->
      <section id="figure">
        <h2>4. Ispezione lavoro: cosa controllano su OIV e RSPP</h2>
        <span class="art-norm">⚖️ D.Lgs. 150/2009 · D.Lgs. 81/2008 — Figure di controllo nel processo</span>

        <p>Durante un controllo, l'Ispettorato verifica anche il <strong>coinvolgimento formale delle figure obbligatorie</strong> nel processo BO:</p>

        <ul>
          <li>👥 <strong>OIV</strong> (nella PA) — deve validare il processo BO nella Relazione sulla Performance</li>
          <li>👥 <strong>RSPP</strong> (nelle aziende e PA) — deve aggiornare il DVR con i risultati della valutazione SLC</li>
          <li>👥 <strong>Medico Competente</strong> — deve essere consultato nella fase di valutazione approfondita</li>
        </ul>

        <div class="art-callout art-callout-teal">
          <span class="ac-icon">📋</span>
          <div class="ac-text">
            <strong>Attenzione:</strong> non è sufficiente che queste figure "sappiano" dell'indagine. Il loro coinvolgimento deve essere <strong>documentato formalmente</strong>. Un processo non formalizzato non è difendibile in sede ispettiva.
          </div>
        </div>

        <h3>Se il processo non è formalizzato</h3>
        <ul class="ul-red">
          <li>⚠️ Il ciclo BO non è considerato valido</li>
          <li>⚠️ La conformità non è dimostrabile davanti all'Ispettorato</li>
          <li>⚠️ DVR e Relazione Performance restano privi di validazione</li>
        </ul>
      </section>

      <!-- PIANO -->
      <section id="piano">
        <h2>5. Sanzioni ispettorato lavoro DVR: il piano di miglioramento</h2>
        <span class="art-norm">⚖️ D.Lgs. 81/2008 · D.Lgs. 150/2009 — Chiusura obbligatoria del ciclo</span>

        <p>Uno degli errori più diffusi è <strong>fermarsi alla rilevazione</strong>: viene condotta l'indagine, si raccolgono i dati, ma non si dà seguito ai risultati.</p>
        <p>In realtà, la normativa richiede che il ciclo si chiuda con:</p>

        <ul class="ul-green">
          <li>✅ azioni correttive specifiche e documentate</li>
          <li>✅ responsabili nominati per ogni azione</li>
          <li>✅ scadenze e monitoraggio nel tempo</li>
          <li>✅ integrazione nel piano della performance o nel DVR</li>
        </ul>

        <div class="art-callout art-callout-warn">
          <span class="ac-icon">⚠️</span>
          <div class="ac-text">
            <strong>Senza un piano di miglioramento:</strong> il ciclo BO resta aperto. L'indagine diventa un adempimento burocratico fine a sé stesso, e il rischio normativo resta invariato.
          </div>
        </div>
      </section>

      <!-- COMUNICAZIONE -->
      <section id="comunicazione">
        <h2>6. Cosa succede se DVR non è aggiornato: comunicazione e responsabilità</h2>
        <span class="art-norm">⚖️ Accordo Europeo 2004 · Linee guida INAIL — Partecipazione dei lavoratori</span>

        <p>Secondo l'Accordo Europeo sullo stress da lavoro (2004) e le linee guida INAIL, il processo BO deve includere la <strong>restituzione dei risultati ai lavoratori</strong>:</p>

        <ul>
          <li>📢 comunicazione formale dei risultati dell'indagine ai dipendenti</li>
          <li>📢 coinvolgimento delle rappresentanze sindacali (RSU/RSA)</li>
          <li>📢 trasparenza interna sul percorso di miglioramento</li>
        </ul>

        <p>In assenza di questa fase, il processo BO viene considerato <strong>incompleto</strong> — con possibili conseguenze in sede di contenzioso sindacale o ispettivo.</p>
      </section>

      <!-- CONSEGUENZE -->
      <section id="conseguenze">
        <h2>Sanzioni ispettorato lavoro DVR: cosa succede in caso di non conformità</h2>

        <p>Durante un'ispezione dell'Ispettorato del Lavoro sul Benessere Organizzativo, le situazioni più frequenti che emergono sono:</p>

        <ul class="ul-red">
          <li>❌ DVR incompleto — mancanza della sezione stress lavoro-correlato</li>
          <li>❌ Assenza di indagine BO formale negli ultimi 12 mesi (PA)</li>
          <li>❌ Metodo di rilevazione non validato o non campionato</li>
          <li>❌ Assenza di documentazione sul piano di miglioramento</li>
          <li>❌ OIV e RSPP non formalmente coinvolti nel processo</li>
        </ul>

        <div class="art-callout art-callout-red">
          <span class="ac-icon">🚨</span>
          <div class="ac-text">
            <strong>Conseguenze per i privati:</strong> sanzioni amministrative da €1.000 a €3.000, eventuale responsabilità penale del datore di lavoro per omessa valutazione del rischio.
          </div>
        </div>

        <div class="art-callout art-callout-red">
          <span class="ac-icon">🏛️</span>
          <div class="ac-text">
            <strong>Conseguenze per la PA:</strong> invalidazione Relazione Performance, blocco premi al personale, rilievi OIV, e — nei casi più gravi — <strong>intervento della Corte dei Conti</strong> con responsabilità personale degli amministratori fino a 20 volte la retribuzione mensile lorda.
          </div>
        </div>
      </section>

      <!-- CONCLUSIONE -->
      <section id="conclusione">
        <h2>Come mettersi in regola: dall'audit benessere organizzativo alla conformità</h2>

        <p>Il benessere organizzativo <strong>non è un'opzione</strong>, né un tema da affrontare solo in sede di audit interno.</p>
        <p>È un obbligo normativo che richiede un sistema:</p>

        <ul class="ul-green">
          <li>✅ <strong>documentato</strong> — con DVR aggiornato, relazioni e verbali</li>
          <li>✅ <strong>strutturato</strong> — con metodo validato, campionamento corretto, figure obbligatorie coinvolte</li>
          <li>✅ <strong>difendibile</strong> — in grado di reggere un'ispezione dell'Ispettorato del Lavoro o un rilievo OIV/Corte dei Conti</li>
        </ul>

        <div class="art-callout art-callout-blu">
          <span class="ac-icon">🏛️</span>
          <div class="ac-text">
            Il <strong>Metodo Troisi</strong>, sviluppato da <strong>Troisi Ricerche S.r.l.</strong> (accreditata MIUR come Ente di Ricerca), integra tutti questi elementi in un unico sistema: questionario ANAC a 17 sezioni, scoring pesato su 8 criteri normativi, report difendibile e piano di miglioramento — erogato tramite la <a href="https://tiplive.it" target="_blank" rel="noopener" style="color:var(--teal-deep);font-weight:600">Piattaforma TIP</a>.
          </div>
        </div>
      </section>

    </div><!-- /art-content -->

    <!-- CTA FINALE -->
    <div class="art-cta-final" id="verifica">
      <div class="cta-eyebrow">🔎 Diagnosi gratuita — Metodo Troisi</div>
      <h3>Verifica ora la situazione<br><em>del tuo ente o azienda</em></h3>
      <p>Vuoi sapere se il tuo ente è in regola con il D.Lgs. 81/2008, il D.Lgs. 150/2009 e le linee guida ANAC? La Diagnosi BO — Metodo Troisi analizza 8 criteri normativi in pochi minuti. Score immediato, gratuito, report con azioni correttive.</p>
      <a href="<?php echo home_url('/sei-in-regola-bo'); ?>" class="art-cta-btn">⚖️ Avvia ora la diagnosi del rischio ispettivo →</a>
      <div class="art-cta-micro">Gratuito · Nessun impegno · Risposta entro 24 ore · Metodo Troisi · Troisi Ricerche S.r.l.</div>
    </div>


    <!-- ====================================================
         FAQ SEO — Ottimizzata per Google e AI
         Fase 4 — Prompt 2 SEO
         ==================================================== -->
    <div style="background:#fff;border:1.5px solid #d1ece8;border-radius:14px;padding:24px 28px;margin:32px 0" itemscope itemtype="https://schema.org/FAQPage">

      <h2 style="font-size:1.05rem;font-weight:800;color:#1a3a5c;margin-bottom:18px;padding-bottom:8px;border-bottom:2px solid #e8f7f4">
        ❓ Domande frequenti — Ispettorato del Lavoro e Benessere Organizzativo
      </h2>

      <!-- Q1 -->
      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #e8f7f4;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:7px">Cosa controlla l'Ispettorato del Lavoro durante un'ispezione sul benessere organizzativo?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.65">L'Ispettorato del Lavoro verifica: (1) che il DVR includa la valutazione dello stress lavoro-correlato (D.Lgs. 81/2008, art. 28); (2) che il metodo di rilevazione sia validato e conforme alle linee guida INAIL e ANAC; (3) il coinvolgimento formale di RSPP e medico competente; (4) l'esistenza di un piano di miglioramento documentato; (5) per la PA: la validazione da parte dell'OIV; (6) la comunicazione dei risultati ai dipendenti. L'assenza di uno di questi elementi espone il datore di lavoro a sanzioni.</p>
        </div>
      </div>

      <!-- Q2 -->
      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #e8f7f4;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:7px">Il DVR deve includere lo stress lavoro-correlato?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.65">Sì. Il DVR deve includere obbligatoriamente la valutazione dello stress lavoro-correlato (SLC) ai sensi del D.Lgs. 81/2008, art. 28. Questa norma si applica a tutti i datori di lavoro, pubblici e privati, indipendentemente dalle dimensioni dell'organizzazione. Un DVR che non include la valutazione SLC è considerato incompleto dall'Ispettorato del Lavoro.</p>
        </div>
      </div>

      <!-- Q3 -->
      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #e8f7f4;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:7px">Quali sono le sanzioni per DVR incompleto sullo stress lavoro-correlato?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.65">Le sanzioni per DVR incompleto ai sensi del D.Lgs. 81/2008 includono: sanzioni amministrative da 1.000 a 3.000 euro, eventuale responsabilità penale del datore di lavoro in caso di infortuni riconducibili allo stress, per la PA: possibile intervento della Corte dei Conti con responsabilità personale degli amministratori fino a 20 volte la retribuzione mensile lorda.</p>
        </div>
      </div>

      <!-- Q4 -->
      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="border-bottom:1px solid #e8f7f4;padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:7px">Il benessere organizzativo è obbligatorio nella PA?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.65">Sì. Per la Pubblica Amministrazione il benessere organizzativo è obbligatorio ai sensi del D.Lgs. 150/2009, art. 14 c.5. L'OIV deve curare annualmente indagini sul benessere organizzativo del personale. I risultati devono essere integrati nella Relazione sulla Performance. Le PA con più di 50 dipendenti devono inserire il BO anche nel PIAO (Piano Integrato di Attività e Organizzazione).</p>
        </div>
      </div>

      <!-- Q5 -->
      <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" style="padding:14px 0">
        <h3 itemprop="name" style="font-size:.95rem;font-weight:700;color:#1a2e2a;margin-bottom:7px">ANAC richiede il questionario benessere organizzativo?</h3>
        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p itemprop="text" style="font-size:.87rem;color:#6b7280;line-height:1.65">Sì. L'ANAC (ora Dipartimento della Funzione Pubblica) ha definito il modello di questionario in 17 sezioni e 85 domande come standard metodologico per le indagini sul benessere organizzativo nella PA. Questo strumento deve essere utilizzato come riferimento per garantire la validità scientifica e la difendibilità dei risultati. Un'indagine condotta con strumenti non validati non soddisfa il requisito del D.Lgs. 150/2009 e non è valida ai fini della Relazione sulla Performance.</p>
        </div>
      </div>

    </div><!-- /FAQ -->
    <!-- SOCIAL SHARING -->
    <div class="art-share">
      <h4>📤 Condividi questo articolo</h4>
      <div class="share-btns">
        <a href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.benessereorganizzativo.it%2Fispettorato-lavoro-benessere-organizzativo"
           target="_blank" rel="noopener" class="share-btn share-linkedin"
           aria-label="Condividi su LinkedIn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          LinkedIn
        </a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.benessereorganizzativo.it%2Fispettorato-lavoro-benessere-organizzativo"
           target="_blank" rel="noopener" class="share-btn share-facebook"
           aria-label="Condividi su Facebook">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
          Facebook
        </a>
        <a href="https://twitter.com/intent/tweet?url=https%3A%2F%2Fwww.benessereorganizzativo.it%2Fispettorato-lavoro-benessere-organizzativo&text=Cosa+controlla+davvero+l%27Ispettorato+del+Lavoro+sul+%23BenessereOrganizzativo+%E2%80%94+Metodo+Troisi"
           target="_blank" rel="noopener" class="share-btn share-twitter"
           aria-label="Condividi su X/Twitter">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
          X / Twitter
        </a>
        <a href="https://wa.me/?text=Cosa+controlla+l%27Ispettorato+del+Lavoro+sul+Benessere+Organizzativo+%F0%9F%94%97+https%3A%2F%2Fwww.benessereorganizzativo.it%2Fispettorato-lavoro-benessere-organizzativo"
           target="_blank" rel="noopener" class="share-btn share-whatsapp"
           aria-label="Condividi su WhatsApp">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/></svg>
          WhatsApp
        </a>
        <button class="share-btn share-copy" onclick="copyLink(this)"
                aria-label="Copia link articolo">
          🔗 Copia link
        </button>
      </div>
    </div>

    <!-- TAG -->
    <div class="art-tags">
      <span class="art-tag-item">benessere organizzativo</span>
      <span class="art-tag-item">ispettorato del lavoro</span>
      <span class="art-tag-item">DVR</span>
      <span class="art-tag-item">stress lavoro-correlato</span>
      <span class="art-tag-item">D.Lgs. 81/2008</span>
      <span class="art-tag-item">D.Lgs. 150/2009</span>
      <span class="art-tag-item">ANAC</span>
      <span class="art-tag-item">OIV</span>
      <span class="art-tag-item">RSPP</span>
      <span class="art-tag-item">PA</span>
      <span class="art-tag-item">Metodo Troisi</span>
    </div>

    <!-- AUTHOR -->
    <div class="art-author-box">
      <div class="auth-avatar">AT</div>
      <div>
        <div class="auth-name">Andrea Troisi</div>
        <div class="auth-role">Ricercatore e Statistico · Fondatore Troisi Ricerche · Professore Univ. Foggia e Bari</div>
        <div class="auth-bio">Andrea Troisi ha sviluppato il Metodo Troisi per la misurazione del Benessere Organizzativo, riconosciuto da ANAC come modello di riferimento nazionale. In oltre 20 anni ha applicato questo metodo in centinaia di organizzazioni pubbliche e private. Fondatore della Piattaforma TIP (tiplive.it) per le survey BO nella PA.</div>
      </div>
    </div>

    <!-- CORRELATI -->
    <div class="art-related">
      <h4>📚 Approfondisci</h4>
      <div class="rel-item">
        <span class="rel-icon">📋</span>
        <div>
          <div class="rel-title"><a href="<?php echo home_url('/sei-in-regola-bo'); ?>">Diagnosi Rischio Ispettivo BO — Score gratuito in 8 domande</a></div>
          <div class="rel-desc">Verifica in 8 punti la conformità del tuo ente al D.Lgs. 81/2008, D.Lgs. 150/2009 e ANAC. Metodo Troisi.</div>
        </div>
      </div>
      <div class="rel-item">
        <span class="rel-icon">📝</span>
        <div>
          <div class="rel-title" style="color:var(--grigio)">DVR e stress lavoro-correlato — guida completa per la PA <em style="font-size:.72rem">(presto)</em></div>
          <div class="rel-desc">Come integrare correttamente la valutazione SLC nel DVR con il Metodo Troisi.</div>
        </div>
      </div>
      <div class="rel-item">
        <span class="rel-icon">📝</span>
        <div>
          <div class="rel-title" style="color:var(--grigio)">Questionario ANAC — 17 sezioni e campionamento Cochran <em style="font-size:.72rem">(presto)</em></div>
          <div class="rel-desc">Guida metodologica al questionario ANAC per il Benessere Organizzativo.</div>
        </div>
      </div>
    </div>

  </article><!-- /article -->

  <!-- SIDEBAR -->
  <aside class="art-sidebar">

    <!-- TOOL CTA -->
    <div class="sb-tool">
      <div class="sb-title">🔬 Diagnosi gratuita</div>
      <p><strong style="color:#fff">Il tuo ente è esposto al rischio ispettivo?</strong> Verifica in 8 punti con la Diagnosi BO — Metodo Troisi.</p>
      <a href="<?php echo home_url('/sei-in-regola-bo'); ?>" class="sb-tool-cta">⚖️ Avvia la diagnosi →</a>
    </div>

    <!-- TOC SIDEBAR -->
    <div class="sb-card">
      <div class="sb-title">📋 In questo articolo</div>
      <ul class="sb-toc-list">
        <li><a href="#intro">→ Il BO non è un tema soft</a></li>
        <li><a href="#dvr">→ DVR e stress SLC</a></li>
        <li><a href="#indagine-bo">→ Indagine BO nella PA</a></li>
        <li><a href="#metodo-anac">→ Metodo ANAC</a></li>
        <li><a href="#figure">→ OIV e RSPP</a></li>
        <li><a href="#piano">→ Piano di miglioramento</a></li>
        <li><a href="#comunicazione">→ Comunicazione ai dipendenti</a></li>
        <li><a href="#conseguenze">→ Conseguenze</a></li>
        <li><a href="#conclusione">→ Conclusione</a></li>
      </ul>
    </div>

    <!-- NORMATIVA -->
    <div class="sb-card">
      <div class="sb-title">⚖️ Norme citate</div>
      <ul class="sb-norm-list">
        <li><span>📋</span><span><strong>D.Lgs. 81/2008 art. 28</strong> — DVR e stress SLC</span></li>
        <li><span>📋</span><span><strong>D.Lgs. 150/2009 art. 14</strong> — Indagine BO annuale PA</span></li>
        <li><span>📋</span><span><strong>Linee guida DFP · ANAC</strong> — 17 sezioni</span></li>
        <li><span>📋</span><span><strong>Accordo Europeo 2004</strong> — Stress SLC</span></li>
        <li><span>📋</span><span><strong>Linee guida INAIL</strong> — Valutazione SLC</span></li>
        <li><span>📋</span><span><strong>PIAO 2022</strong> — Integrazione BO</span></li>
      </ul>
    </div>

    <!-- BRAND -->
    <div class="sb-brand">
      <h4>Metodo Troisi · Piattaforma TIP</h4>
      <p>Sistema integrato per la misurazione del BO: questionario ANAC, campionamento Cochran, scoring pesato, report difendibile.</p>
      <a href="https://tiplive.it" target="_blank" rel="noopener">→ tiplive.it — Piattaforma TIP</a>
      <a href="https://www.troisiricerche.net" target="_blank" rel="noopener">→ troisiricerche.net</a>
    </div>

  </aside>

</div><!-- /art-layout -->

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">BenessereOrganizzativo.it</div>
        <p>Piattaforma per la misurazione del Benessere Organizzativo nella PA e nelle aziende. Metodo Troisi Ricerche · Riconosciuto da ANAC.</p>
        <p class="brand-legal">Powered by Troisi Ricerche S.r.l. Unipersonale<br>Via de Rossi, 57 · 70122 Bari · P.IVA 07216100722</p>
      </div>
      <div class="footer-col">
        <h4>Il sito</h4>
        <ul>
          <li><a href="https://www.benessereorganizzativo.it/#normativa">Normativa e timeline</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#circolo">Il circolo virtuoso</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#metodo">Metodologia</a></li>
          <li><a href="https://www.benessereorganizzativo.it/#questionario">Questionario ANAC</a></li>
          <li><a href="<?php echo home_url('/approfondimenti'); ?>">Approfondimenti</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Galassia Troisi</h4>
        <ul>
          <li><a href="https://andreatroisi.it" target="_blank">andreatroisi.it</a></li>
          <li><a href="https://www.troisiricerche.net" target="_blank">troisiricerche.net</a></li>
          <li><a href="https://www.customerpa.it" target="_blank">CustomerPA</a></li>
          <li><a href="https://tiplive.it" target="_blank">TIP Platform</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contatti</h4>
        <ul>
          <li><a href="https://calendly.com/andreatroisi/30min" target="_blank">Prenota una call</a></li>
          <li><a href="mailto:benessere@troisiricerche.it">benessere@troisiricerche.it</a></li>
          <li><a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank">LinkedIn</a></li>
          <li><a href="tel:800644046">800 644 046</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="copy">© 2026 BenessereOrganizzativo.it · Troisi Ricerche S.r.l. Unipersonale</div>
      <div class="footer-legal" id="iubenda-footer-links"></div>
      <script type="text/javascript" src="https://embeds.iubenda.com/widgets/946ac756-6db6-11ee-8bfc-5ad8d8c564c0.js"></script>
    </div>
  </div>
</footer>

<script>
function toggleMobileMenu(){
  const m=document.getElementById('mobile-menu');
  const b=document.getElementById('hamburger-btn');
  m.classList.toggle('open');
  b.classList.toggle('open');
  document.body.style.overflow=m.classList.contains('open')?'hidden':'';
}
function closeMobileMenu(){
  document.getElementById('mobile-menu').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
  document.body.style.overflow='';
}
function copyLink(btn){
  navigator.clipboard.writeText('https://www.benessereorganizzativo.it/ispettorato-lavoro-benessere-organizzativo').then(function(){
    btn.textContent='✅ Link copiato!';
    btn.classList.add('copied');
    setTimeout(function(){btn.textContent='🔗 Copia link';btn.classList.remove('copied');},2500);
  }).catch(function(){
    btn.textContent='Link: benessereorganizzativo.it/ispettorato-lavoro-benessere-organizzativo';
  });
}
// Smooth scroll per TOC
document.querySelectorAll('a[href^="#"]').forEach(function(a){
  a.addEventListener('click',function(e){
    const id=this.getAttribute('href').slice(1);
    const el=document.getElementById(id);
    if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth',block:'start'});}
  });
});
</script>

<!-- SEO keywords hidden -->
<div style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true">
benessere organizzativo benessere organizzativo aziendale benessere organizzativo pubblica amministrazione benessere organizzativo aziende organizational wellbeing workplace wellbeing employee wellbeing benessere nei luoghi di lavoro qualità della vita lavorativa clima organizzativo analisi clima aziendale survey clima aziendale misurazione clima organizzativo stress lavoro correlato valutazione stress lavoro correlato rischio psicosociale lavoro employee survey employee satisfaction survey employee engagement survey indagine dipendenti questionario benessere organizzativo performance organizzativa organizational performance efficienza organizzativa employee engagement employee experience motivazione dipendenti organizational analytics HR analytics workplace analytics organizational wellbeing index organizational climate index indicatori benessere organizzativo benchmark clima aziendale benessere organizzativo Italia benessere organizzativo aziende italiane benessere organizzativo enti pubblici benessere organizzativo comuni benessere organizzativo università smart working benessere organizzativo digital workplace come misurare il benessere organizzativo come migliorare il clima aziendale strumenti per misurare il clima organizzativo consulenza benessere organizzativo organizational consulting Andrea Troisi Troisi Ricerche Metodo Troisi Troisi Organizational Wellbeing Model mappatura delle competenze registro delle competenze CustomerPA TR-Index TroisiInsight Mappatura delle Competenze Registro delle Competenze how to measure organizational wellbeing how to measure employee wellbeing organizational wellbeing indicators leadership organizzativa cultura organizzativa governance organizzativa benessere organizzativo digitalizzazione PA benessere organizzativo trasformazione digitale performance pubblica amministrazione valutazione enti pubblici troisi ricerche benessere organizzativo andrea troisi organizational wellbeing rischio ispettivo benessere organizzativo ispettorato lavoro benessere organizzativo DVR stress lavoro correlato PA ANAC questionario benessere organizzativo D.Lgs. 81/2008 benessere organizzativo D.Lgs. 150/2009 indagine BO OIV validazione benessere organizzativo PIAO benessere organizzativo diagnosi rischio ispettivo BO audit benessere organizzativo PA compliance benessere organizzativo enti pubblici piano miglioramento benessere organizzativo comunicazione dipendenti risultati BO periodicità indagine benessere organizzativo valutazione approfondita stress SLC responsabilità datore lavoro benessere organizzativo sanzioni mancata valutazione stress lavoro correlato Corte dei Conti benessere organizzativo PA RSPP benessere organizzativo medico competente stress lavoro correlato Accordo Europeo 2004 stress lavoro INAIL linee guida stress lavoro correlato benessere organizzativo Comune benessere organizzativo ASL benessere organizzativo scuola benessere organizzativo società in-house Score BO diagnosi istituzionale piattaforma TIP benessere organizzativo tiplive.it survey BO approfondimenti normativa benessere organizzativo blog benessere organizzativo PA cosa controlla ispettorato benessere organizzativo ispezione benessere organizzativo cosa succede relazione performance benessere organizzativo premi personale PA benessere organizzativo
</div>

<?php get_footer(); ?>
</body>
</html>
