<?php
/**
 * Template Name: Privacy Policy
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1>Privacy Policy</h1>
    <p>Informativa sul trattamento dei dati personali ai sensi del GDPR</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-content" style="margin-top:-1.5rem;">

      <p><strong>Ultimo aggiornamento:</strong> <?php echo date('d/m/Y'); ?></p>

      <h2>1. Titolare del trattamento</h2>
      <p><strong>Troisi Ricerche S.r.l.</strong><br>
      Sede legale: Via de Rossi 57, 70122 Bari (BA)<br>
      CF/P.IVA: 07216100722<br>
      Codice SDI: KRRH6B9<br>
      Email: <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a><br>
      PEC: <a href="mailto:andrea.troisi@pec.it">andrea.troisi@pec.it</a></p>
      <p>Il Titolare gestisce il sito web <strong>benesseredigitalegiovani.it</strong> ("il Sito"), progetto dell'Osservatorio sul Benessere Digitale dei Giovani.</p>

      <h2>2. Dati raccolti</h2>
      <h3>2.1 Dati forniti volontariamente</h3>
      <p>Il Sito raccoglie dati personali solo quando l'utente li fornisce volontariamente attraverso:</p>
      <ul>
        <li><strong>Checker di esposizione digitale:</strong> indirizzo email, risposte al questionario, profilo risultante. Lo scopo è fornire un risultato personalizzato e, con consenso esplicito, inviare aggiornamenti.</li>
        <li><strong>Newsletter:</strong> indirizzo email per ricevere aggiornamenti dall'Osservatorio.</li>
        <li><strong>Modulo contatti:</strong> nome, email e messaggio per rispondere a richieste specifiche.</li>
      </ul>

      <h3>2.2 Dati raccolti automaticamente</h3>
      <p>Con il consenso dell'utente, il Sito può raccogliere dati di navigazione tramite cookie analitici: indirizzo IP (anonimizzato), pagine visitate, durata della visita, dispositivo e browser utilizzato. Questi dati sono trattati in forma aggregata e anonima.</p>

      <h2>3. Finalità e base giuridica</h2>
      <p>I dati personali sono trattati per le seguenti finalità:</p>
      <ul>
        <li><strong>Erogazione del servizio Checker</strong> (base giuridica: esecuzione di un servizio richiesto dall'utente, art. 6.1.b GDPR)</li>
        <li><strong>Invio newsletter e aggiornamenti</strong> (base giuridica: consenso esplicito dell'utente, art. 6.1.a GDPR)</li>
        <li><strong>Risposta a richieste di contatto</strong> (base giuridica: legittimo interesse, art. 6.1.f GDPR)</li>
        <li><strong>Analisi statistica aggregata e anonima</strong> del traffico del Sito (base giuridica: consenso per cookie analitici, art. 6.1.a GDPR)</li>
        <li><strong>Ricerca scientifica</strong> — i dati aggregati e anonimi del Checker possono essere utilizzati per le pubblicazioni dell'Osservatorio (base giuridica: legittimo interesse per ricerca scientifica, art. 89 GDPR)</li>
      </ul>

      <h2>4. Conservazione dei dati</h2>
      <ul>
        <li><strong>Dati Checker:</strong> conservati per massimo 24 mesi dalla raccolta</li>
        <li><strong>Newsletter:</strong> fino a revoca del consenso (cancellazione in ogni email)</li>
        <li><strong>Contatti:</strong> per il tempo necessario a evadere la richiesta, massimo 12 mesi</li>
        <li><strong>Cookie analitici:</strong> massimo 13 mesi</li>
      </ul>

      <h2>5. Destinatari dei dati</h2>
      <p>I dati personali non vengono venduti né ceduti a terzi per finalità di marketing. Possono essere comunicati a:</p>
      <ul>
        <li>Provider di hosting del Sito (responsabile del trattamento nominato)</li>
        <li>Servizio di invio email/newsletter (se attivato)</li>
        <li>Google Analytics (in forma anonimizzata, solo con consenso cookie)</li>
      </ul>
      <p>Tutti i responsabili del trattamento sono vincolati contrattualmente al rispetto del GDPR.</p>

      <h2>6. Trasferimento dati extra-UE</h2>
      <p>In caso di utilizzo di servizi con server extra-UE (es. Google Analytics), il trasferimento avviene sulla base di clausole contrattuali standard approvate dalla Commissione Europea o del Data Privacy Framework UE-USA.</p>

      <h2>7. Diritti dell'interessato</h2>
      <p>L'utente ha diritto di:</p>
      <ul>
        <li><strong>Accesso</strong> — ottenere conferma dell'esistenza dei propri dati e riceverne copia</li>
        <li><strong>Rettifica</strong> — correggere dati inesatti o incompleti</li>
        <li><strong>Cancellazione</strong> ("diritto all'oblio") — richiedere la rimozione dei propri dati</li>
        <li><strong>Limitazione del trattamento</strong> — in determinate circostanze</li>
        <li><strong>Portabilità</strong> — ricevere i dati in formato strutturato e leggibile</li>
        <li><strong>Opposizione</strong> — opporsi al trattamento per motivi legittimi</li>
        <li><strong>Revoca del consenso</strong> — in qualsiasi momento, senza pregiudicare la liceità del trattamento precedente</li>
      </ul>
      <p>Per esercitare i propri diritti: <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a></p>
      <p>L'utente ha inoltre il diritto di proporre reclamo al <strong>Garante per la protezione dei dati personali</strong> (<a href="https://www.garanteprivacy.it" target="_blank" rel="noopener">www.garanteprivacy.it</a>).</p>

      <h2>8. Minori</h2>
      <p>Il Sito non è rivolto direttamente ai minori di 14 anni. Il Checker è destinato ai <strong>genitori</strong> che rispondono riguardo ai propri figli. Non vengono raccolti dati identificativi dei minori.</p>

      <h2>9. Sicurezza</h2>
      <p>Il Sito adotta misure tecniche e organizzative adeguate a proteggere i dati personali: connessione HTTPS, accesso limitato ai dati, backup regolari e aggiornamento costante del software.</p>

      <h2>10. Modifiche alla presente informativa</h2>
      <p>Il Titolare si riserva di aggiornare questa informativa. La data dell'ultimo aggiornamento è indicata in alto. L'utente è invitato a consultare periodicamente questa pagina.</p>

    </div>
  </div>
</section>

<?php get_footer(); ?>
