<?php
/**
 * Template Name: Chi siamo
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1>Chi siamo</h1>
    <p>L'istituto e il ricercatore dietro l'Osservatorio</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-content" style="margin-top:-1.5rem;">

      <h2>L'Osservatorio</h2>
      <p>L'Osservatorio sul Benessere Digitale dei Giovani nasce dalla convinzione che il rapporto tra giovani e tecnologia vada compreso con <strong>dati</strong>, non con opinioni. Non siamo né allarmisti né entusiasti acritici: siamo ricercatori.</p>
      <p>Produciamo ricerca scientifica originale sul rapporto tra dispositivi digitali, piattaforme social e benessere psicofisico dei ragazzi italiani. E trasformiamo quei dati in strumenti pratici gratuiti per chi ogni giorno si confronta con queste sfide: genitori, insegnanti, educatori, istituzioni.</p>

      <h2>Direzione scientifica</h2>
      <div class="bdg-card" style="margin:1.5rem 0 2rem;">
        <div class="bdg-founder-card">
          <div class="bdg-founder-photo">
            <img src="<?php echo BDG_URI; ?>/img/andrea-troisi.jpg" alt="Andrea Troisi — Direttore scientifico Osservatorio BDG">
          </div>
          <div class="bdg-founder-info">
            <h3 style="margin-bottom:.25rem;">Andrea Troisi</h3>
            <p style="font-size:.85rem;color:var(--bdg-teal);margin-bottom:.75rem;font-weight:600;">Direttore scientifico dell'Osservatorio</p>
            <p style="font-size:.88rem;">Fondatore di Troisi Ricerche S.r.l., istituto accreditato MIUR. 18 anni di esperienza nella ricerca sociale applicata, con specializzazione in benessere organizzativo, customer satisfaction e metodologie CAWI, CATI e Delphi. Ha diretto centinaia di progetti di ricerca per enti pubblici, aziende private e istituzioni europee.</p>
            <p style="font-size:.88rem;margin-top:.5rem;">L'Osservatorio BDG rappresenta l'applicazione del Metodo Troisi — lo stesso rigore scientifico utilizzato per la PA e le aziende — a un tema di urgente rilevanza sociale: il rapporto tra giovani e tecnologia.</p>
            <div class="bdg-founder-links">
              <a href="https://andreatroisi.it" target="_blank" rel="noopener">andreatroisi.it &rarr;</a>
              <a href="https://troisiricerche.net" target="_blank" rel="noopener">troisiricerche.net &rarr;</a>
              <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener" class="bdg-social-link">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                LinkedIn
              </a>
              <a href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener" class="bdg-social-link">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                YouTube
              </a>
            </div>
          </div>
        </div>
      </div>

      <h2>L'istituto dietro l'Osservatorio</h2>
      <p>Il rigore scientifico dell'Osservatorio è garantito da <a href="https://troisiricerche.net" target="_blank" rel="noopener">Troisi Ricerche S.r.l.</a>, istituto di ricerca fondato nel 2006 e accreditato presso il <strong>Ministero dell'Istruzione, dell'Università e della Ricerca (MIUR)</strong>.</p>
      <p>Troisi Ricerche opera in tre mercati — Pubblica Amministrazione, aziende private e progetti europei — con metodologie validate su centinaia di enti e organizzazioni italiane.</p>

      <div style="background:var(--bdg-teal-light);border-radius:var(--bdg-radius-lg);padding:1.5rem;margin:2rem 0;">
        <h3 style="color:var(--bdg-teal);font-size:1rem;margin-bottom:.75rem;">Metodologia scientifica</h3>
        <p style="font-size:.88rem;margin-bottom:.5rem;"><strong>CAWI</strong> (Computer Assisted Web Interviewing) — indagini quantitative su campioni rappresentativi.</p>
        <p style="font-size:.88rem;margin-bottom:.5rem;"><strong>Interviste qualitative profonde</strong> — con genitori, insegnanti e ragazzi.</p>
        <p style="font-size:.88rem;margin-bottom:.5rem;"><strong>Analisi longitudinale</strong> — monitoraggio dell'evoluzione nel tempo.</p>
        <p style="font-size:.88rem;"><strong>TR-Index</strong> — indicatori sintetici proprietari per misurare fenomeni complessi.</p>
      </div>

      <h3>L'ecosistema Troisi Ricerche</h3>
      <p>L'Osservatorio BDG fa parte di un ecosistema integrato di ricerca e strumenti digitali:</p>
      <div class="bdg-grid bdg-grid-2" style="margin:1.25rem 0 2rem;">
        <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius);padding:1rem;">
          <p style="font-size:.82rem;font-weight:600;color:var(--bdg-teal);margin-bottom:.25rem;"><a href="https://troisiricerche.net" target="_blank" rel="noopener">troisiricerche.net</a></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);">Hub istituzionale — accreditamento MIUR, profilo completo, metodologie</p>
        </div>
        <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius);padding:1rem;">
          <p style="font-size:.82rem;font-weight:600;color:var(--bdg-teal);margin-bottom:.25rem;"><a href="https://troisiinsight.it" target="_blank" rel="noopener">troisiinsight.it</a></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);">Benchmark e dati nazionali — i dati BDG confluiscono qui</p>
        </div>
        <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius);padding:1rem;">
          <p style="font-size:.82rem;font-weight:600;color:var(--bdg-teal);margin-bottom:.25rem;"><a href="https://benessereorganizzativo.it" target="_blank" rel="noopener">benessereorganizzativo.it</a></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);">Benessere organizzativo per la PA (D.Lgs. 81/2008)</p>
        </div>
        <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius);padding:1rem;">
          <p style="font-size:.82rem;font-weight:600;color:var(--bdg-teal);margin-bottom:.25rem;"><a href="https://customerpa.it" target="_blank" rel="noopener">customerpa.it</a></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);">Customer satisfaction PA (D.Lgs. 150/2009)</p>
        </div>
        <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius);padding:1rem;">
          <p style="font-size:.82rem;font-weight:600;color:var(--bdg-teal);margin-bottom:.25rem;"><a href="https://voiceinhub.it" target="_blank" rel="noopener">voiceinhub.it</a></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);">Podcast — contenuti audio su PA, ricerca e innovazione</p>
        </div>
        <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius);padding:1rem;">
          <p style="font-size:.82rem;font-weight:600;color:var(--bdg-teal);margin-bottom:.25rem;"><a href="https://andreatroisi.it" target="_blank" rel="noopener">andreatroisi.it</a></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);">Personal brand — thought leadership, pubblicazioni</p>
        </div>
      </div>

      <h2>Contatti stampa</h2>
      <p>Giornalisti e media possono contattare l'Osservatorio per dati, infografiche, interviste e commenti esperti.</p>
      <p><strong>Osservatorio:</strong> <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a><br>
      <strong>Andrea Troisi:</strong> <a href="https://andreatroisi.it" target="_blank" rel="noopener">andreatroisi.it</a></p>
    </div>
  </div>
</section>

<?php get_footer(); ?>
