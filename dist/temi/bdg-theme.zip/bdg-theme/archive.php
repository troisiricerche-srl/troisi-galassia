<?php get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1><?php the_archive_title(); ?></h1>
    <?php the_archive_description('<p>', '</p>'); ?>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container">
    <?php if (have_posts()) : ?>
    <div class="bdg-grid bdg-grid-3">
      <?php while (have_posts()) : the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="bdg-blog-card">
        <div class="bdg-blog-card-img">
          <?php if (has_post_thumbnail()) : the_post_thumbnail('blog-card'); else : ?>
            &#x1F4DD;
          <?php endif; ?>
        </div>
        <div class="bdg-blog-card-body">
          <?php $cats = get_the_category(); if ($cats) : ?>
            <div class="cat"><?php $bdg_c = bdg_main_cat(); echo esc_html($bdg_c ? $bdg_c->name : $cats[0]->name); ?></div>
          <?php endif; ?>
          <h3><?php the_title(); ?></h3>
          <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
          <div class="meta"><?php echo get_the_date('j F Y'); ?></div>
        </div>
      </a>
      <?php endwhile; ?>
    </div>
    <?php the_posts_pagination(['mid_size' => 2, 'prev_text' => '&larr;', 'next_text' => '&rarr;']); ?>
    <?php else : ?>
    <p style="text-align:center;">Nessun articolo trovato.</p>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
