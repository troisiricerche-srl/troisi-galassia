<?php
/**
 * Template Name: Scuole e Famiglie
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1>Scuole e Famiglie</h1>
    <p>Risorse gratuite basate su evidenze scientifiche</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container">

    <div class="bdg-section-header">
      <div class="eyebrow">Per le scuole</div>
      <h2>Materiale pronto per l'aula</h2>
      <p>Toolkit, guide e presentazioni che insegnanti e dirigenti possono usare subito — nelle assemblee, nei consigli di classe, nelle giornate dedicate.</p>
    </div>

    <div class="bdg-grid bdg-grid-3">
      <div class="bdg-card">
        <div class="bdg-card-body">
          <div class="bdg-card-icon teal">&#x1F4DA;</div>
          <h3>Guida per insegnanti</h3>
          <p>Come riconoscere i segnali di disagio digitale in classe. Cosa fare e cosa non fare. Basata sui dati della ricerca annuale.</p>
          <p style="margin-top:1rem;"><em style="color:var(--bdg-teal);">Disponibile a breve</em></p>
        </div>
      </div>
      <div class="bdg-card">
        <div class="bdg-card-body">
          <div class="bdg-card-icon amber">&#x1F3AF;</div>
          <h3>Kit assemblea di classe</h3>
          <p>Presentazione pronta con dati aggiornati, attività interattive e domande di discussione. Per studenti delle medie e superiori.</p>
          <p style="margin-top:1rem;"><em style="color:var(--bdg-teal);">Disponibile a breve</em></p>
        </div>
      </div>
      <div class="bdg-card">
        <div class="bdg-card-body">
          <div class="bdg-card-icon blue">&#x1F4CA;</div>
          <h3>Dati per il PTOF</h3>
          <p>Infografiche e dati citabili per il Piano Triennale dell'Offerta Formativa. Dimostra che la tua scuola affronta il tema con rigore.</p>
          <p style="margin-top:1rem;"><em style="color:var(--bdg-teal);">Disponibile a breve</em></p>
        </div>
      </div>
    </div>

    <div style="height:3rem;"></div>

    <div class="bdg-section-header">
      <div class="eyebrow">Per le famiglie</div>
      <h2>Strumenti pratici per genitori</h2>
      <p>Non prediche, non sensi di colpa. Consigli concreti basati su quello che la ricerca dice davvero.</p>
    </div>

    <div class="bdg-grid bdg-grid-3">
      <div class="bdg-card">
        <div class="bdg-card-body">
          <div class="bdg-card-icon coral">&#x1F9EA;</div>
          <h3>Checker esposizione</h3>
          <p>Il nostro test gratuito ti dice in 2 minuti quanto è esposto tuo figlio al digitale, con consigli personalizzati.</p>
          <p style="margin-top:1rem;"><a href="<?php echo home_url('/checker/'); ?>" style="font-weight:600;">Fai il test &rarr;</a></p>
        </div>
      </div>
      <div class="bdg-card">
        <div class="bdg-card-body">
          <div class="bdg-card-icon teal">&#x1F4D6;</div>
          <h3>Guida per genitori</h3>
          <p>10 pagine con consigli pratici suddivisi per fascia d'età: 6-9, 10-13, 14-17. Scaricabile gratuitamente in PDF.</p>
          <p style="margin-top:1rem;"><em style="color:var(--bdg-teal);">Disponibile a breve</em></p>
        </div>
      </div>
      <div class="bdg-card">
        <div class="bdg-card-body">
          <div class="bdg-card-icon amber">&#x1F399;</div>
          <h3>Webinar gratuiti</h3>
          <p>Incontri online con esperti su temi specifici: social media, gaming, AI e chatbot, privacy. Aperti a tutti.</p>
          <p style="margin-top:1rem;"><em style="color:var(--bdg-teal);">Prossimo evento in programma</em></p>
        </div>
      </div>
    </div>

    <div style="height:2rem;"></div>

    <div class="bdg-cta-banner">
      <h2>Collabora con noi</h2>
      <p>Sei un dirigente scolastico, un coordinatore di rete o un'associazione di genitori? Possiamo costruire insieme percorsi di sensibilizzazione basati sui dati.</p>
      <a href="<?php echo home_url('/contatti/'); ?>" class="bdg-hero-cta">
        Contattaci &rarr;
      </a>
    </div>

  </div>
</section>

<?php get_footer(); ?>
