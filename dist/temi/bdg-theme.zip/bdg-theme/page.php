<?php
/**
 * Default page template
 */
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1><?php the_title(); ?></h1>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-content" style="margin-top:-1.5rem;">
      <?php the_content(); ?>
    </div>
  </div>
</section>

<?php endwhile; ?>

<?php get_footer(); ?>
