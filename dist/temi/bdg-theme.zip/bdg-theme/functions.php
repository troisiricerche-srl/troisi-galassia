<?php
/**
 * Benessere Digitale Giovani — Theme Functions v3 SEO+AI
 * Osservatorio BDG by Troisi Ricerche S.r.l.
 */
if (!defined('ABSPATH')) exit;

define('BDG_VERSION', '3.0.2');
define('BDG_DIR', get_template_directory());
define('BDG_URI', get_template_directory_uri());

/* ═══ THEME SETUP ═══ */
add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    add_theme_support('custom-logo', ['height'=>60,'width'=>200,'flex-height'=>true,'flex-width'=>true]);
    register_nav_menus(['primary'=>'Menu principale','footer'=>'Menu footer']);
    add_image_size('blog-card', 600, 400, true);
});

/* ═══ ENQUEUE ═══ */
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('bdg-google-fonts',
        'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display:ital@0;1&display=swap',
        [], null
    );
    wp_enqueue_style('bdg-style', get_stylesheet_uri(), ['bdg-google-fonts'], BDG_VERSION);
    if (is_page_template('page-checker.php') || is_front_page()) {
        wp_enqueue_script('bdg-checker', BDG_URI . '/js/checker.js', [], BDG_VERSION, true);
    }
    wp_enqueue_script('bdg-nav', BDG_URI . '/js/nav.js', [], BDG_VERSION, true);
});

/* ═══ SEO — COMPLETE META + JSON-LD ═══ */
add_action('wp_head', function() {
    // Favicon
    echo '<link rel="icon" href="' . BDG_URI . '/favicon.ico" sizes="any">' . "\n";
    echo '<link rel="icon" href="' . BDG_URI . '/img/favicon-192.png" type="image/png" sizes="192x192">' . "\n";
    echo '<link rel="apple-touch-icon" href="' . BDG_URI . '/img/apple-touch-icon.png">' . "\n";

    // SEO Meta per pagina
    $seo = bdg_get_page_seo();
    if ($seo['description']) {
        echo '<meta name="description" content="' . esc_attr($seo['description']) . '">' . "\n";
    }
    if ($seo['keywords']) {
        echo '<meta name="keywords" content="' . esc_attr($seo['keywords']) . '">' . "\n";
    }

    // Open Graph
    echo '<meta property="og:site_name" content="Osservatorio Benessere Digitale Giovani">' . "\n";
    echo '<meta property="og:locale" content="it_IT">' . "\n";
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($seo['title'] ?: get_the_title()) . '">' . "\n";
    if ($seo['description']) {
        echo '<meta property="og:description" content="' . esc_attr($seo['description']) . '">' . "\n";
    }
    if (is_singular()) {
        echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '">' . "\n";
    }

    // JSON-LD Organization (homepage)
    if (is_front_page()) {
        $org = [
            '@context' => 'https://schema.org',
            '@type' => 'ResearchOrganization',
            'name' => 'Osservatorio sul Benessere Digitale dei Giovani',
            'alternateName' => ['BDG Observatory', 'Osservatorio BDG'],
            'url' => home_url('/'),
            'description' => 'Osservatorio indipendente sul rapporto tra tecnologie digitali e benessere dei giovani in Italia. Ricerca annuale, checker gratuito, risorse per scuole e famiglie.',
            'foundingDate' => '2024',
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => 'Via de Rossi 57',
                'addressLocality' => 'Bari',
                'postalCode' => '70122',
                'addressCountry' => 'IT',
            ],
            'parentOrganization' => [
                '@type' => 'ResearchOrganization',
                'name' => 'Troisi Ricerche S.r.l.',
                'url' => 'https://troisiricerche.net',
                'description' => 'Istituto di ricerca accreditato MIUR — Dal 2006',
                'taxID' => '07216100722',
            ],
            'areaServed' => ['@type'=>'Country','name'=>'Italia'],
            'knowsAbout' => [
                'Benessere digitale giovani',
                'Dipendenza smartphone adolescenti',
                'Tempo schermo bambini',
                'Social media salute mentale ragazzi',
                'Effetti TikTok Instagram adolescenti',
                'Educazione digitale scuola',
                'Cyberbullismo prevenzione',
                'AI adolescenti impatto',
            ],
            'sameAs' => [
                'https://troisiricerche.net',
                'https://troisiinsight.it',
                'https://www.linkedin.com/company/troisi-ricerche',
                'https://www.youtube.com/@troisiricerche',
            ],
        ];
        echo '<script type="application/ld+json">' . wp_json_encode($org, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    // JSON-LD Article (blog posts)
    if (is_singular('post')) {
        $article = [
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => get_the_title(),
            'datePublished' => get_the_date('c'),
            'dateModified' => get_the_modified_date('c'),
            'author' => ['@type'=>'Organization','name'=>'Osservatorio Benessere Digitale Giovani','url'=>home_url('/')],
            'publisher' => ['@type'=>'Organization','name'=>'Troisi Ricerche S.r.l.','url'=>'https://troisiricerche.net'],
            'mainEntityOfPage' => get_permalink(),
        ];
        echo '<script type="application/ld+json">' . wp_json_encode($article, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    // JSON-LD FAQ (pages with FAQ)
    if (is_front_page() || is_page_template('page-checker.php')) {
        $faqs = bdg_get_global_faqs();
        if ($faqs) {
            $faq_schema = [
                '@context' => 'https://schema.org',
                '@type' => 'FAQPage',
                'mainEntity' => array_map(function($q) {
                    return [
                        '@type' => 'Question',
                        'name' => $q['q'],
                        'acceptedAnswer' => ['@type'=>'Answer','text'=>$q['a']],
                    ];
                }, $faqs),
            ];
            echo '<script type="application/ld+json">' . wp_json_encode($faq_schema, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
        }
    }

    // RSS Feed syndication
    echo '<link rel="alternate" type="application/rss+xml" title="Feed per TroisiInsight" href="' . home_url('/feed/troisi-insight/') . '" />' . "\n";
});

/* SEO meta per pagina */
function bdg_get_page_seo() {
    $seo = ['title'=>'','description'=>'','keywords'=>''];
    if (is_front_page()) {
        $seo['title'] = 'Benessere digitale giovani: quanto è esposto tuo figlio? | Osservatorio BDG';
        $seo['description'] = 'Mio figlio usa troppo il telefono? Il 77% degli adolescenti non riesce a ridurre. Dati scientifici, checker gratuito e risorse per genitori e scuole — Osservatorio BDG by Troisi Ricerche.';
        $seo['keywords'] = 'benessere digitale giovani, mio figlio usa troppo il telefono, dipendenza smartphone adolescenti, tempo schermo bambini, social media salute mentale ragazzi';
    } elseif (is_page_template('page-checker.php')) {
        $seo['title'] = 'Test esposizione digitale figli: quanto è esposto tuo figlio? | Checker BDG';
        $seo['description'] = 'In 2 minuti scopri il livello di esposizione digitale di tuo figlio. Test gratuito basato su evidenze scientifiche. 10 domande, risultato immediato con consigli personalizzati.';
        $seo['keywords'] = 'test esposizione digitale figli, test dipendenza smartphone ragazzi, quiz screen time figli, mio figlio è dipendente dal telefono';
    } elseif (is_page_template('page-scuole.php')) {
        $seo['title'] = 'Educazione digitale scuola: risorse gratuite per insegnanti e genitori | BDG';
        $seo['description'] = 'Kit assemblea classe, guide insegnanti, materiale PTOF sul benessere digitale. Risorse gratuite basate su evidenze scientifiche per scuole e famiglie.';
        $seo['keywords'] = 'educazione digitale scuola risorse, kit assemblea classe benessere digitale, cyberbullismo prevenzione scuola';
    } elseif (is_page_template('page-ricerca.php')) {
        $seo['title'] = 'Ricerca annuale benessere digitale giovani Italia | Osservatorio BDG';
        $seo['description'] = 'La ricerca scientifica dell\'Osservatorio sul rapporto tra giovani e digitale in Italia. Metodologia CAWI, dati open access, campione rappresentativo.';
        $seo['keywords'] = 'benessere digitale giovani ricerca, osservatorio benessere digitale, dati screen time adolescenti Italia';
    } elseif (is_page_template('page-chi-siamo.php')) {
        $seo['title'] = 'Chi siamo — Osservatorio Benessere Digitale Giovani | Troisi Ricerche';
        $seo['description'] = 'L\'Osservatorio BDG è diretto da Andrea Troisi, fondatore di Troisi Ricerche S.r.l. — istituto accreditato MIUR dal 2006. Ricerca scientifica sul benessere digitale dei giovani.';
        $seo['keywords'] = 'osservatorio benessere digitale giovani, troisi ricerche, andrea troisi benessere digitale';
    } elseif (is_singular('post')) {
        $excerpt = get_the_excerpt();
        if ($excerpt) $seo['description'] = wp_trim_words($excerpt, 25);
    }
    return $seo;
}

/* FAQ globali per schema */
function bdg_get_global_faqs() {
    return [
        ['q'=>'Quanto tempo sugli schermi è troppo per un bambino?','a'=>'Non esiste una soglia universale. I dati PISA indicano che sotto 1 ora di social media al giorno l\'effetto è neutro. Oltre le 2-3 ore di uso passivo (scroll feed algoritmici), il benessere cala significativamente. Il tipo di attività conta più della durata.'],
        ['q'=>'Mio figlio usa troppo il telefono: come capirlo?','a'=>'Segnali: riduzione del sonno, calo rendimento scolastico, irritabilità quando non ha il telefono, preferenza per le interazioni online rispetto a quelle in presenza. Il checker dell\'Osservatorio BDG misura il livello di esposizione in 2 minuti con 10 domande.'],
        ['q'=>'I social media fanno male ai ragazzi?','a'=>'Dipende dalla piattaforma e dal tempo. WhatsApp ha impatto quasi nullo. TikTok e Instagram riducono il benessere significativamente sopra le 2 ore/giorno. Le ragazze sono più colpite dei ragazzi. Il 77% degli adolescenti che prova a ridurre non ci riesce.'],
        ['q'=>'A che età dare lo smartphone a un figlio?','a'=>'La ricerca suggerisce di ritardare l\'accesso ai social media almeno fino ai 13 anni (età minima legale). Uno smartphone senza social può essere dato prima per motivi pratici. L\'importante è accompagnare con regole condivise, non imposte.'],
        ['q'=>'Cosa fare se mio figlio è sempre online?','a'=>'Tre azioni: 1) Rimuovere lo smartphone dalla camera di notte (singolo cambiamento con maggiore impatto). 2) Stabilire regole condivise rispettate da tutta la famiglia. 3) Aumentare le attività sociali in presenza. Le regole condivise hanno il doppio dell\'efficacia di quelle imposte.'],
        ['q'=>'Il divieto di smartphone a scuola funziona?','a'=>'Il divieto copre 6 ore su 24 e migliora la concentrazione in classe, ma il 90% dell\'esposizione digitale avviene fuori dalla scuola. Serve un approccio combinato: divieto scolastico + educazione digitale + regole familiari condivise.'],
        ['q'=>'Il 41% degli adolescenti chiede aiuto all\'AI: è pericoloso?','a'=>'Usare l\'AI per studiare non è pericoloso. Diventa preoccupante quando il chatbot diventa il primo interlocutore nei momenti emotivi, sostituendo le relazioni umane. È un segnale che il ragazzo cerca ascolto senza giudizio: il problema è la mancanza relazionale, non la tecnologia.'],
    ];
}

/* ═══ CUSTOM TITLE TAG ═══ */
add_filter('pre_get_document_title', function($title) {
    $seo = bdg_get_page_seo();
    return $seo['title'] ?: $title;
});

/* ═══ EXCERPT ═══ */
add_filter('excerpt_length', function() { return 20; });
add_filter('excerpt_more', function() { return '&hellip;'; });

/* ═══ REMOVE BLOAT ═══ */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');

/* ═══════════════════════════════════════
   AUTO-INSTALL: PAGES + ARTICLES + MENU
   ═══════════════════════════════════════ */
add_action('after_switch_theme', 'bdg_auto_install');

function bdg_auto_install() {
    // ═══ PAGES ═══
    $pages = [
        'home' => ['title'=>'Home','template'=>'front-page.php'],
        'checker' => ['title'=>'Checker — Quanto è esposto tuo figlio?','template'=>'page-checker.php'],
        'ricerca' => ['title'=>'Ricerca annuale','template'=>'page-ricerca.php'],
        'scuole-famiglie' => ['title'=>'Scuole e Famiglie','template'=>'page-scuole.php'],
        'chi-siamo' => ['title'=>'Chi siamo','template'=>'page-chi-siamo.php'],
        'contatti' => ['title'=>'Contatti e Stampa','template'=>'page-contatti.php'],
        'privacy-policy' => ['title'=>'Privacy Policy','template'=>'page-privacy-policy.php'],
        'cookie-policy' => ['title'=>'Cookie Policy','template'=>'page-cookie-policy.php'],
    ];

    foreach ($pages as $slug => $data) {
        if (!get_page_by_path($slug)) {
            $pid = wp_insert_post([
                'post_title'=>$data['title'],'post_name'=>$slug,
                'post_status'=>'publish','post_type'=>'page','post_content'=>'',
            ]);
            if ($pid && !is_wp_error($pid)) {
                update_post_meta($pid, '_wp_page_template', $data['template']);
            }
        }
    }

    // Set homepage
    $front = get_page_by_path('home');
    if ($front) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $front->ID);
    }

    // ═══ CATEGORIES ═══
    $cats = ['Ricerca'=>'ricerca','Tecnologia'=>'tecnologia','Normativa'=>'normativa','Famiglia'=>'famiglia','Scuola'=>'scuola'];
    foreach ($cats as $name => $slug) {
        if (!term_exists($slug, 'category')) {
            wp_insert_term($name, 'category', ['slug'=>$slug]);
        }
    }

    // ═══ ARTICLES (auto-install from /articles/ folder) ═══
    $articles = [
        ['file'=>'art01-seo.html','title'=>'Tempo schermo e benessere dei giovani: cosa dice la ricerca nel 2026','slug'=>'tempo-schermo-benessere-giovani-ricerca-2026','cat'=>'ricerca',
         'excerpt'=>'Quanto tempo sugli schermi è troppo per bambini e adolescenti? I dati PISA su 270.000 quindicenni e il World Happiness Report 2026 distinguono tra uso attivo e passivo.'],
        ['file'=>'art02-seo.html','title'=>'AI e adolescenti: perché il 41% chiede aiuto ai chatbot nei momenti difficili','slug'=>'ai-adolescenti-chatbot-supporto-emotivo','cat'=>'tecnologia',
         'excerpt'=>'Il 41,8% degli adolescenti italiani chiede aiuto all\'intelligenza artificiale in momenti di tristezza o ansia. Dati Safer Internet Day 2026.'],
        ['file'=>'art03-seo.html','title'=>'Divieto smartphone a scuola 2026: cosa prevede la circolare Valditara e cosa dicono i dati','slug'=>'divieto-smartphone-scuola-2026-circolare-valditara','cat'=>'normativa',
         'excerpt'=>'Dal 2025-2026 è vietato usare lo smartphone in tutte le scuole italiane. Ma i dati internazionali dicono che non basta: serve educazione digitale.'],
        ['file'=>'art04-seo.html','title'=>'Social media e autostima degli adolescenti: cosa dicono i dati PISA su 270.000 quindicenni','slug'=>'social-media-autostima-adolescenti-dati-pisa','cat'=>'ricerca',
         'excerpt'=>'Instagram e TikTok colpiscono l\'autostima più di WhatsApp e YouTube. Le ragazze sono più vulnerabili. Lo studio PISA su 270.000 quindicenni spiega perché.'],
        ['file'=>'art05-seo.html','title'=>'Genitori e smartphone: chi usa di più il telefono in famiglia? Il paradosso dei dati','slug'=>'genitori-smartphone-paradosso-regole-famiglia','cat'=>'famiglia',
         'excerpt'=>'Gli adulti trascorrono 5 ore al giorno sullo smartphone, i ragazzi 2,5 ore sui social. Come chiedere ai figli quello che noi non facciamo?'],
        ['file'=>'art06-seo.html','title'=>'AI Act e minori: cosa cambia per i giovani con il regolamento europeo sull\'intelligenza artificiale','slug'=>'ai-act-minori-regolamento-europeo-protezione-giovani','cat'=>'normativa',
         'excerpt'=>'L\'AI Act europeo classifica come alto rischio i sistemi AI usati dai minori: TikTok, Instagram, ChatGPT. Ecco cosa prevede e cosa significa per le famiglie.'],
    ];

    foreach ($articles as $art) {
        if (get_page_by_path($art['slug'], OBJECT, 'post')) continue;

        $file = BDG_DIR . '/articles/' . $art['file'];
        if (!file_exists($file)) continue;

        $content = file_get_contents($file);
        // Replace theme URL placeholder
        $content = str_replace('{{THEME_URL}}', BDG_URI, $content);
        // Remove HTML comments (metadata lines)
        $content = preg_replace('/<!--\s*(?:ARTICOLO|Titolo|Categoria|Meta desc|Keywords|Slug).*?-->\s*/s', '', $content);

        $cat = get_term_by('slug', $art['cat'], 'category');
        $cat_id = $cat ? $cat->term_id : 0;

        $post_id = wp_insert_post([
            'post_title'   => $art['title'],
            'post_name'    => $art['slug'],
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_content' => $content,
            'post_excerpt' => $art['excerpt'],
            'post_category'=> $cat_id ? [$cat_id] : [],
        ]);
    }

    // ═══ AUTO-CREATE MENU ═══
    $menu_name = 'Menu principale';
    $menu_exists = wp_get_nav_menu_object($menu_name);
    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);
        $items = [
            ['title'=>'Checker','url'=>home_url('/checker/')],
            ['title'=>'Ricerca','url'=>home_url('/ricerca/')],
            ['title'=>'Scuole','url'=>home_url('/scuole-famiglie/')],
            ['title'=>'Chi siamo','url'=>home_url('/chi-siamo/')],
            ['title'=>'Analisi','url'=>home_url('/category/analisi/')],
        ];
        foreach ($items as $item) {
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title'=>$item['title'],'menu-item-url'=>$item['url'],
                'menu-item-status'=>'publish','menu-item-type'=>'custom',
            ]);
        }
        // CTA button
        wp_update_nav_menu_item($menu_id, 0, [
            'menu-item-title'=>'Fai il test','menu-item-url'=>home_url('/checker/'),
            'menu-item-status'=>'publish','menu-item-type'=>'custom',
            'menu-item-classes'=>'bdg-nav-cta',
        ]);
        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }

    // Flush rewrite rules
    flush_rewrite_rules();
}

/* ═══ CHECKER AJAX ═══ */
add_action('wp_enqueue_scripts', function() {
    if (is_page_template('page-checker.php') || is_front_page()) {
        wp_localize_script('bdg-checker', 'bdg_ajax', [
            'url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('bdg_checker_nonce'),
        ]);
    }
}, 20);

add_action('wp_ajax_bdg_checker_submit', 'bdg_handle_checker_submit');
add_action('wp_ajax_nopriv_bdg_checker_submit', 'bdg_handle_checker_submit');

function bdg_handle_checker_submit() {
    check_ajax_referer('bdg_checker_nonce', 'nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $score = sanitize_text_field($_POST['score'] ?? '');
    $profile = sanitize_text_field($_POST['profile'] ?? '');
    if (!is_email($email)) { wp_send_json_error('Email non valida'); return; }
    $leads = get_option('bdg_checker_leads', []);
    $leads[] = ['email'=>$email,'score'=>$score,'profile'=>$profile,'date'=>current_time('mysql'),'ip'=>sanitize_text_field($_SERVER['REMOTE_ADDR']??'')];
    update_option('bdg_checker_leads', $leads);
    wp_mail(get_option('admin_email'), '[BDG Checker] Nuovo lead — '.$profile,
        "Nuovo completamento checker:\n\nEmail: {$email}\nScore: {$score}\nProfilo: {$profile}\nData: ".current_time('d/m/Y H:i'));
    wp_send_json_success(['message'=>'Lead salvato']);
}

/* ═══ CONTACT FORM AJAX ═══ */
add_action('wp_ajax_bdg_contact_submit', 'bdg_handle_contact');
add_action('wp_ajax_nopriv_bdg_contact_submit', 'bdg_handle_contact');

function bdg_handle_contact() {
    check_ajax_referer('bdg_contact_nonce', 'bdg_contact_nonce_field');
    $name = sanitize_text_field($_POST['bdg_name']??'');
    $email = sanitize_email($_POST['bdg_email']??'');
    $role = sanitize_text_field($_POST['bdg_role']??'');
    $subject = sanitize_text_field($_POST['bdg_subject']??'Richiesta dal sito BDG');
    $message = sanitize_textarea_field($_POST['bdg_message']??'');
    if (!$name || !is_email($email) || !$role || !$message) { wp_send_json_error('Compila tutti i campi obbligatori.'); return; }
    $contacts = get_option('bdg_contacts', []);
    $contacts[] = ['name'=>$name,'email'=>$email,'role'=>$role,'subject'=>$subject,'message'=>$message,'date'=>current_time('mysql')];
    update_option('bdg_contacts', $contacts);
    wp_mail('info@benesseredigitalegiovani.it', "[BDG] {$subject} — {$role}",
        "Messaggio da: {$name} ({$email})\nRuolo: {$role}\nOggetto: {$subject}\n\n{$message}\n\nData: ".current_time('d/m/Y H:i'),
        ['Reply-To: '.$name.' <'.$email.'>']);
    wp_send_json_success(['message'=>'Inviato']);
}

/* ═══ ADMIN PAGES ═══ */
add_action('admin_menu', function() {
    add_menu_page('Lead Checker BDG','Lead BDG','manage_options','bdg-checker-leads','bdg_admin_leads_page','dashicons-chart-bar',30);
    add_submenu_page('bdg-checker-leads','Contatti BDG','Contatti','manage_options','bdg-contacts','bdg_admin_contacts_page');
});

function bdg_admin_leads_page() {
    $leads = array_reverse(get_option('bdg_checker_leads', []));
    echo '<div class="wrap"><h1>Lead Checker BDG</h1><p>Totale: <strong>'.count($leads).'</strong></p>';
    if ($leads) {
        echo '<table class="wp-list-table widefat fixed striped"><thead><tr><th>Data</th><th>Email</th><th>Score</th><th>Profilo</th></tr></thead><tbody>';
        foreach ($leads as $l) echo '<tr><td>'.esc_html($l['date']??'').'</td><td>'.esc_html($l['email']??'').'</td><td>'.esc_html($l['score']??'').'</td><td>'.esc_html($l['profile']??'').'</td></tr>';
        echo '</tbody></table>';
    }
    echo '</div>';
}

function bdg_admin_contacts_page() {
    $contacts = array_reverse(get_option('bdg_contacts', []));
    echo '<div class="wrap"><h1>Contatti BDG</h1><p>Totale: <strong>'.count($contacts).'</strong></p>';
    if ($contacts) {
        echo '<table class="wp-list-table widefat fixed striped"><thead><tr><th>Data</th><th>Nome</th><th>Email</th><th>Ruolo</th><th>Messaggio</th></tr></thead><tbody>';
        foreach ($contacts as $c) echo '<tr><td>'.esc_html($c['date']??'').'</td><td>'.esc_html($c['name']??'').'</td><td>'.esc_html($c['email']??'').'</td><td>'.esc_html($c['role']??'').'</td><td>'.esc_html(wp_trim_words($c['message']??'',15)).'</td></tr>';
        echo '</tbody></table>';
    }
    echo '</div>';
}

/* ═══ RSS FEED SYNDICATION ═══ */
add_action('init', function() { add_feed('troisi-insight', 'bdg_troisi_feed'); });

function bdg_troisi_feed() {
    header('Content-Type: application/rss+xml; charset=UTF-8');
    $posts = new WP_Query(['posts_per_page'=>20,'post_status'=>'publish']);
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/"><channel>';
    echo '<title>Osservatorio BDG</title><link>'.home_url('/').'</link>';
    while ($posts->have_posts()) { $posts->the_post();
        echo '<item><title>'.get_the_title_rss().'</title><link>'.get_permalink_rss().'</link>';
        echo '<description><![CDATA['.get_the_excerpt_rss().']]></description></item>';
    }
    wp_reset_postdata();
    echo '</channel></rss>';
}

/* ═══ CONTENT FEED ATTRIBUTION ═══ */
add_filter('the_content_feed', function($content) {
    return $content . '<p style="margin-top:2em;padding-top:1em;border-top:1px solid #eee;font-size:13px;color:#888;">Fonte: <a href="'.get_permalink().'">Osservatorio BDG</a> — <a href="https://troisiricerche.net">Troisi Ricerche S.r.l.</a></p>';
});

/* Categoria principale da mostrare: preferisce il tema dell'analisi rispetto alla categoria "Analisi" */
if (!function_exists('bdg_main_cat')) {
    function bdg_main_cat($post_id = null) {
        $cats = get_the_category($post_id);
        if (!$cats) return null;
        foreach ($cats as $c) { if ($c->slug !== 'analisi') return $c; }
        return $cats[0];
    }
}

/* Il vecchio indirizzo /blog/ porta all'archivio delle analisi */
add_action('template_redirect', function () {
    if (!is_404()) return;
    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    if ($path === 'blog' || strpos($path, 'blog/') === 0) {
        wp_safe_redirect(home_url('/category/analisi/'), 301);
        exit;
    }
});

/* ═══ v2.2.1 – pagina Privacy Policy sempre presente ═══
   /privacy-policy/ dava 404: la pagina creata all'attivazione del tema non esiste piu'.
   Al primo caricamento la ricrea (o la ripubblica) con il modello del tema. */
add_action('init', function () {
    if (get_option('bdg_privacy_ok_221')) return;
    $p = get_page_by_path('privacy-policy');
    if (!$p) {
        $pid = wp_insert_post(['post_title' => 'Privacy Policy', 'post_name' => 'privacy-policy',
            'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '']);
        if ($pid && !is_wp_error($pid)) update_post_meta($pid, '_wp_page_template', 'page-privacy-policy.php');
    } elseif ($p->post_status !== 'publish') {
        wp_update_post(['ID' => $p->ID, 'post_status' => 'publish']);
        update_post_meta($p->ID, '_wp_page_template', 'page-privacy-policy.php');
    }
    update_option('bdg_privacy_ok_221', 1);
}, 20);

