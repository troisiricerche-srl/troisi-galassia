<?php
/**
 * Template Name: Ricerca Annuale
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <div class="bdg-hero-badge" style="margin-bottom:1rem;">Ricerca &middot; Open access</div>
    <h1>Ricerca annuale</h1>
    <p>I dati originali dell'Osservatorio sul rapporto tra giovani e digitale in Italia</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-content" style="margin-top:-1.5rem;">

      <div style="background:var(--bdg-amber-light);border-left:3px solid var(--bdg-amber);border-radius:0 var(--bdg-radius) var(--bdg-radius) 0;padding:1.25rem;margin-bottom:2rem;">
        <strong style="color:var(--bdg-amber);">Ricerca 2026 in preparazione.</strong><br>
        La prima edizione della ricerca annuale dell'Osservatorio è in fase di progettazione. Iscriviti alla newsletter per ricevere i risultati appena disponibili.
      </div>

      <h2>Cosa misuriamo</h2>
      <p>La ricerca annuale dell'Osservatorio indaga il rapporto tra tecnologie digitali e benessere dei giovani italiani con un approccio scientifico rigoroso. Le aree di indagine principali:</p>

      <div class="bdg-grid bdg-grid-2" style="margin:1.5rem 0;">
        <div style="background:var(--bdg-teal-light);border-radius:var(--bdg-radius-lg);padding:1.25rem;">
          <h3 style="color:var(--bdg-teal);font-size:1rem;">Abitudini digitali</h3>
          <p style="font-size:.88rem;">Tempo schermo, piattaforme usate, età di accesso, tipo di contenuti, dispositivi posseduti.</p>
        </div>
        <div style="background:var(--bdg-coral-light);border-radius:var(--bdg-radius-lg);padding:1.25rem;">
          <h3 style="color:var(--bdg-coral);font-size:1rem;">Impatto sul benessere</h3>
          <p style="font-size:.88rem;">Qualità del sonno, attenzione, relazioni sociali, autostima, ansia e segnali di disagio.</p>
        </div>
        <div style="background:var(--bdg-amber-light);border-radius:var(--bdg-radius-lg);padding:1.25rem;">
          <h3 style="color:var(--bdg-amber);font-size:1rem;">Ruolo degli adulti</h3>
          <p style="font-size:.88rem;">Regole familiari, consapevolezza genitoriale, educazione digitale a scuola, supervisione.</p>
        </div>
        <div style="background:var(--bdg-blue-light);border-radius:var(--bdg-radius-lg);padding:1.25rem;">
          <h3 style="color:var(--bdg-blue);font-size:1rem;">Nuove tecnologie</h3>
          <p style="font-size:.88rem;">Uso di AI e chatbot, gaming, realtà virtuale, impatto sulle relazioni e sull'apprendimento.</p>
        </div>
      </div>

      <h2>Metodologia</h2>
      <p>La ricerca è condotta da Troisi Ricerche S.r.l. con le stesse metodologie validate utilizzate nei progetti istituzionali dell'istituto: indagine CAWI su campione rappresentativo di famiglie italiane, integrata da interviste qualitative con genitori, insegnanti e ragazzi.</p>
      <p>I risultati sono pubblicati in open access: chiunque può scaricare, citare e utilizzare i dati, a condizione di indicare la fonte.</p>

      <h2>Iscriviti per ricevere i risultati</h2>
      <div style="max-width:420px;margin:1.5rem auto 0;">
        <form class="bdg-newsletter">
          <input type="email" placeholder="La tua email" required>
          <button type="submit" class="bdg-btn bdg-btn-primary">Iscriviti</button>
        </form>
        <p style="font-size:.72rem;color:var(--bdg-ink-50);text-align:center;margin-top:.5rem;">Nessuno spam. Solo i risultati della ricerca e gli aggiornamenti dell'Osservatorio.</p>
      </div>

    </div>
  </div>
</section>

<?php get_footer(); ?>
