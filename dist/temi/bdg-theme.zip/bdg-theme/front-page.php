<?php
/**
 * Template Name: Homepage
 */
get_header(); ?>

<!-- HERO — H1 con keyword principale -->
<section class="bdg-hero">
  <div class="bdg-container">
    <div class="bdg-hero-inner">
      <div class="bdg-hero-badge"><span style="width:6px;height:6px;background:#6dd8c8;border-radius:50%;"></span> Osservatorio indipendente</div>
      <h1>Benessere digitale giovani:<br><em>quanto è esposto tuo figlio?</em></h1>
      <p class="bdg-hero-desc">Tuo figlio è sempre al cellulare e non sai cosa fare? L'Osservatorio BDG produce <strong>dati scientifici</strong>, strumenti gratuiti e risorse per chi si prende cura delle nuove generazioni. Un progetto di <strong>Troisi Ricerche</strong>, istituto accreditato MIUR.</p>
      <a href="<?php echo home_url('/checker/'); ?>" class="bdg-hero-cta">Fai il test gratuito: quanto è esposto? &rarr;</a>
      <div class="bdg-hero-stats">
        <div><div class="bdg-hero-stat-num">77%</div><div class="bdg-hero-stat-label">degli adolescenti non riesce<br>a ridurre il tempo online</div></div>
        <div><div class="bdg-hero-stat-num">41%</div><div class="bdg-hero-stat-label">chiede aiuto all'AI<br>in momenti di ansia</div></div>
        <div><div class="bdg-hero-stat-num">2,5h</div><div class="bdg-hero-stat-label">tempo medio sui<br>social al giorno</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ULTIMI ARTICOLI -->
<section class="bdg-section" style="background:var(--bdg-white);border-top:var(--bdg-border);">
  <div class="bdg-container">
    <div class="bdg-section-header">
      <div class="eyebrow">Ultime analisi &middot; una nuova ogni sabato</div>
      <h2>Benessere digitale dei giovani: i dati europei</h2>
      <p>Analisi settimanali su dati ufficiali Eurostat: vita online, informazione, privacy, intelligenza artificiale, competenze, scuola e benessere. <a href="<?php echo esc_url(home_url('/category/analisi/')); ?>">Tutte le analisi &rarr;</a></p>
    </div>
    <div class="bdg-grid bdg-grid-4">
      <?php
      $recent = new WP_Query(['posts_per_page'=>4,'post_status'=>'publish']);
      if ($recent->have_posts()) :
          while ($recent->have_posts()) : $recent->the_post(); ?>
          <a href="<?php the_permalink(); ?>" class="bdg-blog-card">
            <div class="bdg-blog-card-img"><?php if (has_post_thumbnail()) the_post_thumbnail('blog-card'); else echo '&#x1F4DD;'; ?></div>
            <div class="bdg-blog-card-body">
              <?php $bdg_c = bdg_main_cat(); if ($bdg_c) : ?><div class="cat"><?php echo esc_html($bdg_c->name); ?></div><?php endif; ?>
              <h3><?php the_title(); ?></h3>
              <p class="excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22)); ?></p>
              <div class="meta"><?php echo get_the_date('j F Y'); ?></div>
            </div>
          </a>
          <?php endwhile; wp_reset_postdata();
      endif; ?>
    </div>
  </div>
</section>

<!-- PROBLEMA — keyword emotive -->
<section class="bdg-section">
  <div class="bdg-container">
    <div class="bdg-section-header">
      <div class="eyebrow">Il problema è reale</div>
      <h2>Mio figlio usa troppo il telefono: i numeri che devi conoscere</h2>
      <p>Non è un'impressione. I dati confermano che la <strong>dipendenza da smartphone tra gli adolescenti</strong> è un fenomeno misurabile con conseguenze concrete sulla salute mentale.</p>
    </div>
    <div class="bdg-grid bdg-grid-4">
      <div class="bdg-stat-card"><div class="num">91%</div><div class="label">degli adolescenti riconosce<br>l'impatto del digitale</div></div>
      <div class="bdg-stat-card"><div class="num" style="color:var(--bdg-coral);">77%</div><div class="label">ha provato a ridurre<br>senza riuscirci</div></div>
      <div class="bdg-stat-card"><div class="num" style="color:var(--bdg-amber);">41%</div><div class="label">chiede aiuto all'AI<br>nei momenti difficili</div></div>
      <div class="bdg-stat-card"><div class="num" style="color:var(--bdg-blue);">7su10</div><div class="label">tra gli 8-10 anni<br>usano social regolarmente</div></div>
    </div>
    <p style="text-align:center;font-size:.78rem;color:var(--bdg-ink-50);margin-top:1rem;">Fonti: World Happiness Report 2026, Safer Internet Day 2026, Social Warning, Save the Children</p>
  </div>
</section>

<!-- COSA FACCIAMO -->
<section class="bdg-section" style="background:var(--bdg-white);border-top:var(--bdg-border);border-bottom:var(--bdg-border);">
  <div class="bdg-container">
    <div class="bdg-section-header">
      <div class="eyebrow">Cosa facciamo</div>
      <h2>Dati reali per decisioni informate</h2>
      <p>Non opinioni, non allarmismo. Ricerca scientifica rigorosa tradotta in strumenti pratici per genitori, insegnanti e istituzioni.</p>
    </div>
    <div class="bdg-grid bdg-grid-3">
      <div class="bdg-card"><div class="bdg-card-body">
        <div class="bdg-card-icon teal">&#x1F4CA;</div>
        <h3>Ricerca annuale</h3>
        <p>Indagine su campione rappresentativo di famiglie italiane. Dati su <strong>tempo schermo bambini</strong>, piattaforme usate, segnali di disagio. Metodologia Troisi, pubblicazione aperta.</p>
        <p style="margin-top:.75rem;"><a href="<?php echo home_url('/ricerca/'); ?>">Scopri la ricerca &rarr;</a></p>
      </div></div>
      <div class="bdg-card"><div class="bdg-card-body">
        <div class="bdg-card-icon coral">&#x1F9EA;</div>
        <h3>Checker gratuito</h3>
        <p>Tuo figlio è sempre al cellulare? Il <strong>test di esposizione digitale</strong> in 2 minuti restituisce un profilo di rischio personalizzato con consigli basati su evidenze scientifiche.</p>
        <p style="margin-top:.75rem;"><a href="<?php echo home_url('/checker/'); ?>"><strong>Fai il test &rarr;</strong></a></p>
      </div></div>
      <div class="bdg-card"><div class="bdg-card-body">
        <div class="bdg-card-icon amber">&#x1F3EB;</div>
        <h3>Risorse per scuole</h3>
        <p>Guide scaricabili, toolkit per insegnanti, materiale per assemblee di classe su <strong>educazione digitale</strong> e <strong>cyberbullismo</strong>. Tutto gratuito e basato sui dati.</p>
        <p style="margin-top:.75rem;"><a href="<?php echo home_url('/scuole-famiglie/'); ?>">Risorse gratuite &rarr;</a></p>
      </div></div>
    </div>
  </div>
</section>

<!-- CHECKER PREVIEW -->
<section class="bdg-section">
  <div class="bdg-container">
    <div class="bdg-section-header">
      <div class="eyebrow">Strumento gratuito</div>
      <h2>Quanto è esposto tuo figlio al digitale?</h2>
      <p>Figlio sempre al cellulare e non sai cosa fare? Un <strong>test rapido basato su evidenze scientifiche</strong>. 10 domande, 2 minuti, risultato immediato con consigli personalizzati.</p>
    </div>
    <div style="text-align:center;">
      <a href="<?php echo home_url('/checker/'); ?>" class="bdg-hero-cta" style="font-size:1.1rem;padding:1rem 2.5rem;">Fai il test gratuito &rarr;</a>
      <p style="font-size:.82rem;color:var(--bdg-ink-50);margin-top:1rem;">Gratuito, anonimo, basato su dati scientifici. Nessuna registrazione richiesta.</p>
    </div>
  </div>
</section>

<!-- FAQ GLOBALI — fondamentale per SEO + AI -->
<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-section-header">
      <div class="eyebrow">Domande frequenti</div>
      <h2>Smartphone, social media e adolescenti: le risposte della scienza</h2>
    </div>
    <?php $faqs = bdg_get_global_faqs(); foreach ($faqs as $faq) : ?>
    <div style="border-bottom:var(--bdg-border);padding:1.25rem 0;">
      <h3 style="font-size:1.05rem;margin-bottom:.5rem;color:var(--bdg-ink);"><?php echo esc_html($faq['q']); ?></h3>
      <p style="font-size:.9rem;color:var(--bdg-ink-80);line-height:1.7;"><?php echo esc_html($faq['a']); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- CTA FINALE -->
<section class="bdg-section">
  <div class="bdg-container">
    <div class="bdg-cta-banner">
      <h2>Fai il primo passo</h2>
      <p>Il checker è gratuito, anonimo e basato su evidenze scientifiche. In 2 minuti scopri il profilo di esposizione digitale di tuo figlio.</p>
      <a href="<?php echo home_url('/checker/'); ?>" class="bdg-hero-cta">Fai il test &rarr;</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
