<?php get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1>Risultati per: "<?php echo get_search_query(); ?>"</h1>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container">
    <?php if (have_posts()) : ?>
    <div class="bdg-grid bdg-grid-3">
      <?php while (have_posts()) : the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="bdg-blog-card">
        <div class="bdg-blog-card-body">
          <?php $cats = get_the_category(); if ($cats) : ?>
            <div class="cat"><?php echo esc_html($cats[0]->name); ?></div>
          <?php endif; ?>
          <h3><?php the_title(); ?></h3>
          <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
          <div class="meta"><?php echo get_the_date('j F Y'); ?></div>
        </div>
      </a>
      <?php endwhile; ?>
    </div>
    <?php else : ?>
    <div style="text-align:center;padding:3rem 0;">
      <h2>Nessun risultato</h2>
      <p style="color:var(--bdg-ink-50);margin-top:.75rem;">Prova con parole chiave diverse.</p>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
