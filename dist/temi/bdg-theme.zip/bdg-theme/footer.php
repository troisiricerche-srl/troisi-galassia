<?php if (!defined('ABSPATH')) exit; ?>

<footer class="bdg-footer">
  <div class="bdg-container">
    <div class="bdg-footer-grid">
      <div>
        <div class="bdg-logo" style="margin-bottom:1rem;">
          <img src="<?php echo BDG_URI; ?>/img/logo-icon.png" alt="BDG" style="width:28px;height:28px;border-radius:6px;">
          <div><div class="bdg-logo-text" style="color:rgba(250,248,245,.7);font-size:.9rem;">Benessere Digitale Giovani</div></div>
        </div>
        <p style="max-width:280px;line-height:1.7;">L'Osservatorio sul Benessere Digitale dei Giovani produce <strong style="color:rgba(250,248,245,.6);">dati scientifici</strong> e strumenti gratuiti per genitori, insegnanti e istituzioni. Dipendenza smartphone adolescenti, tempo schermo bambini, effetti social media: risposte basate su evidenze.</p>
        <p style="margin-top:1rem;font-size:.75rem;">Un progetto di <a href="https://troisiricerche.net" target="_blank" rel="noopener" style="color:rgba(250,248,245,.6);">Troisi Ricerche S.r.l.</a><br>Accreditata MIUR &middot; Dal 2006</p>
        <div class="bdg-footer-social">
          <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener" aria-label="LinkedIn"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg></a>
          <a href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener" aria-label="YouTube"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a>
        </div>
      </div>
      <div>
        <h4>Osservatorio</h4>
        <a href="<?php echo home_url('/checker/'); ?>">Checker genitori</a>
        <a href="<?php echo home_url('/ricerca/'); ?>">Ricerca annuale</a>
        <a href="<?php echo home_url('/scuole-famiglie/'); ?>">Scuole e famiglie</a>
        <a href="<?php echo home_url('/category/analisi/'); ?>">Analisi</a>
      </div>
      <div>
        <h4>Informazioni</h4>
        <a href="<?php echo home_url('/chi-siamo/'); ?>">Chi siamo</a>
        <a href="<?php echo home_url('/contatti/'); ?>">Contatti e stampa</a>
        <a href="javascript:void(0)" id="bdg-privacy-link">Privacy policy</a>
        <a href="javascript:void(0)" id="bdg-cookie-link">Cookie policy</a>
      </div>
      <div>
        <h4>Galassia Troisi</h4>
        <a href="https://troisiricerche.net" target="_blank" rel="noopener">Troisi Ricerche</a>
        <a href="https://t-index.it" target="_blank" rel="noopener">TR-Index</a>
        <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener">Mappatura delle Competenze</a>
        <a href="https://registrodellecompetenze.it" target="_blank" rel="noopener">Registro delle Competenze</a>
        <a href="https://customerpa.it" target="_blank" rel="noopener">CustomerPA</a>
        <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener">BenessereOrg.</a>
        <a href="https://troisiformazione.it" target="_blank" rel="noopener">Formazione</a>
        <a href="https://tiplive.it" target="_blank" rel="noopener">TIP Platform</a>
        <a href="https://troisiinsight.it" target="_blank" rel="noopener">TroisiInsight</a>
        <a href="https://digitalizzazionenellapa.it" target="_blank" rel="noopener">DigitalizzazionePA</a>
        <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener">Dibattito Pubblico</a>
        <a href="https://voiceinhub.it" target="_blank" rel="noopener">VoiceInHub</a>
        <a href="https://governancefinanziaria.it" target="_blank" rel="noopener">Governance Fin.</a>
        <a href="https://consulenzainternazionalizzazione.it" target="_blank" rel="noopener">Internazionalizzazione</a>
        <a href="https://benesseredigitalegiovani.it"><strong>BDG</strong></a>
        <a href="https://andreatroisi.it" target="_blank" rel="noopener">Andrea Troisi</a>
      </div>
    </div>
    <div class="bdg-footer-bottom">
      <div class="bdg-footer-troisi">&copy; <?php echo date('Y'); ?> Troisi Ricerche S.r.l. &middot; CF/P.IVA 07216100722 &middot; Via de Rossi 57, 70122 Bari &middot; Tutti i diritti riservati</div>
      <div style="font-size:.72rem;color:rgba(250,248,245,.2);">Dati &middot; Scienza &middot; Benessere</div>
    </div>
  </div>
</footer>

<script type="text/javascript" src="https://embeds.iubenda.com/widgets/4052945a-2337-48f6-bba2-1617bed040c8.js"></script>
<?php wp_footer(); ?>
</body>
</html>
