<?php get_header(); ?>

<section class="bdg-section" style="text-align:center;padding:5rem 0;">
  <div class="bdg-container">
    <h1 style="font-size:4rem;color:var(--bdg-teal);">404</h1>
    <h2 style="margin:.5rem 0 1rem;">Pagina non trovata</h2>
    <p style="color:var(--bdg-ink-50);max-width:400px;margin:0 auto 2rem;">La pagina che cerchi non esiste o è stata spostata. Torna alla homepage o fai il checker.</p>
    <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
      <a href="<?php echo home_url('/'); ?>" class="bdg-btn bdg-btn-ghost">Homepage</a>
      <a href="<?php echo home_url('/checker/'); ?>" class="bdg-btn bdg-btn-primary">Fai il test &rarr;</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
