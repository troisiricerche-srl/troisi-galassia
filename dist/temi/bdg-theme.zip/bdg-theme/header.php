<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="bdg-header">
  <div class="bdg-header-inner">
    <a href="<?php echo home_url('/'); ?>" class="bdg-logo" title="Osservatorio Benessere Digitale Giovani">
      <img src="<?php echo BDG_URI; ?>/img/logo-icon.png" alt="Osservatorio Benessere Digitale Giovani" class="bdg-logo-img">
      <div>
        <div class="bdg-logo-text">Benessere Digitale Giovani</div>
        <div class="bdg-logo-sub">Osservatorio &middot; Troisi Ricerche</div>
      </div>
    </a>
    <button class="bdg-menu-toggle" aria-label="Apri menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
    <?php
    wp_nav_menu([
        'theme_location'=>'primary','container'=>'nav','container_class'=>'bdg-nav',
        'menu_class'=>'','items_wrap'=>'%3$s','fallback_cb'=>'bdg_fallback_menu',
    ]);
    ?>
  </div>
</header>

<div id="bdg-cookie-banner" class="bdg-cookie-banner" style="display:none;">
  <div class="bdg-cookie-inner">
    <div class="bdg-cookie-text">
      <p>Questo sito utilizza cookie tecnici e, con il tuo consenso, cookie analitici per migliorare la tua esperienza.</p>
      <p style="font-size:.72rem;margin-top:.25rem;"><a href="<?php echo home_url('/cookie-policy/'); ?>">Cookie Policy</a> &middot; <a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy Policy</a></p>
    </div>
    <div class="bdg-cookie-actions">
      <button onclick="bdgAcceptCookies('all')" class="bdg-btn bdg-btn-primary bdg-btn-sm">Accetta tutti</button>
      <button onclick="bdgAcceptCookies('essential')" class="bdg-btn bdg-btn-ghost bdg-btn-sm">Solo essenziali</button>
    </div>
  </div>
</div>

<?php
function bdg_fallback_menu() {
    echo '<nav class="bdg-nav">';
    echo '<a href="'.home_url('/checker/').'">Checker</a>';
    echo '<a href="'.home_url('/ricerca/').'">Ricerca</a>';
    echo '<a href="'.home_url('/scuole-famiglie/').'">Scuole</a>';
    echo '<a href="'.home_url('/chi-siamo/').'">Chi siamo</a>';
    echo '<a href="'.home_url('/category/analisi/').'">Analisi</a>';
    echo '<span class="bdg-nav-cta"><a href="'.home_url('/checker/').'">Fai il test</a></span>';
    echo '</nav>';
}
?>
