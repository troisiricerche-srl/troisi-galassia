<?php
/**
 * Blog listing
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <div class="bdg-hero-badge" style="margin-bottom:1rem;">Blog scientifico</div>
    <h1>Approfondimenti</h1>
    <p>Articoli divulgativi ma rigorosi sul rapporto tra tecnologia e benessere dei giovani</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container">
    <?php if (have_posts()) : ?>
    <div class="bdg-grid bdg-grid-3">
      <?php while (have_posts()) : the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="bdg-blog-card">
        <div class="bdg-blog-card-img">
          <?php if (has_post_thumbnail()) : the_post_thumbnail('blog-card'); else : ?>
            &#x1F4DD;
          <?php endif; ?>
        </div>
        <div class="bdg-blog-card-body">
          <?php $cats = get_the_category(); if ($cats) : ?>
            <div class="cat"><?php echo esc_html($cats[0]->name); ?></div>
          <?php endif; ?>
          <h3><?php the_title(); ?></h3>
          <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
          <div class="meta"><?php echo get_the_date('j F Y'); ?></div>
        </div>
      </a>
      <?php endwhile; ?>
    </div>

    <div style="text-align:center;margin-top:2rem;">
      <?php
      the_posts_pagination([
          'mid_size'  => 2,
          'prev_text' => '&larr; Precedente',
          'next_text' => 'Successivo &rarr;',
      ]);
      ?>
    </div>

    <?php else : ?>
    <div style="text-align:center;padding:3rem 0;">
      <h2>Il blog è in arrivo</h2>
      <p style="color:var(--bdg-ink-50);margin-top:.75rem;max-width:480px;margin-left:auto;margin-right:auto;">Stiamo preparando i primi articoli. Iscriviti alla newsletter per essere avvisato quando pubblichiamo.</p>
      <div style="margin-top:1.5rem;">
        <form class="bdg-newsletter">
          <input type="email" placeholder="La tua email" required>
          <button type="submit" class="bdg-btn bdg-btn-primary">Iscriviti</button>
        </form>
      </div>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
