/**
 * BDG Checker — Esposizione digitale giovani
 * 10 domande, scoring 0-30, 3 profili
 */
(function() {
  'use strict';

  const questions = [
    {
      q: "Quanti anni ha tuo figlio/a?",
      sub: "Seleziona la fascia d'età",
      opts: [
        { text: "6–9 anni", score: 3 },
        { text: "10–13 anni", score: 2 },
        { text: "14–17 anni", score: 1 }
      ]
    },
    {
      q: "Ha uno smartphone personale?",
      sub: "Connesso a internet",
      opts: [
        { text: "No, non ha un dispositivo personale", score: 0 },
        { text: "Ha un tablet condiviso con la famiglia", score: 1 },
        { text: "Sì, ha uno smartphone personale", score: 3 }
      ]
    },
    {
      q: "Quanto tempo trascorre davanti a uno schermo al giorno?",
      sub: "Includi telefono, tablet, PC, console — esclusa la scuola",
      opts: [
        { text: "Meno di 1 ora", score: 0 },
        { text: "1–2 ore", score: 1 },
        { text: "2–4 ore", score: 2 },
        { text: "Più di 4 ore", score: 3 }
      ]
    },
    {
      q: "Usa social network?",
      sub: "TikTok, Instagram, Snapchat, YouTube (non solo per guardare video scolastici)",
      opts: [
        { text: "No, non usa social", score: 0 },
        { text: "Solo YouTube per contenuti specifici", score: 1 },
        { text: "Sì, 1-2 piattaforme regolarmente", score: 2 },
        { text: "Sì, 3 o più piattaforme ogni giorno", score: 3 }
      ]
    },
    {
      q: "Ci sono regole in casa sull'uso dei dispositivi?",
      sub: "Orari, limiti, supervisione",
      opts: [
        { text: "Sì, regole chiare e rispettate", score: 0 },
        { text: "Ci sono regole ma non sempre vengono rispettate", score: 1 },
        { text: "Le regole sono vaghe o sporadiche", score: 2 },
        { text: "Non ci sono regole particolari", score: 3 }
      ]
    },
    {
      q: "Lo smartphone è presente durante i pasti o prima di dormire?",
      sub: "Abitudini quotidiane",
      opts: [
        { text: "Mai — niente schermi a tavola e prima di dormire", score: 0 },
        { text: "A volte a tavola, mai prima di dormire", score: 1 },
        { text: "Non a tavola, ma lo usa prima di dormire", score: 2 },
        { text: "Sì, sia durante i pasti che prima di dormire", score: 3 }
      ]
    },
    {
      q: "Hai notato cambiamenti nell'umore legati all'uso del digitale?",
      sub: "Irritabilità quando non può usare il telefono, ansia per i like, confronto con gli altri",
      opts: [
        { text: "No, nessun segnale evidente", score: 0 },
        { text: "Qualche volta, ma nulla di preoccupante", score: 1 },
        { text: "Sì, si irrita quando deve smettere di usare il telefono", score: 2 },
        { text: "Sì, noto ansia, confronto sociale o ritiro frequente", score: 3 }
      ]
    },
    {
      q: "Tuo figlio/a ha mai provato a ridurre il tempo online?",
      sub: "Di sua iniziativa o su suggerimento",
      opts: [
        { text: "Sì, e ci è riuscito/a", score: 0 },
        { text: "Ha provato ma non ci è riuscito/a", score: 2 },
        { text: "Non ha mai provato — non ne sente il bisogno", score: 1 },
        { text: "Non vuole nemmeno provarci", score: 3 }
      ]
    },
    {
      q: "Usa chatbot o AI per supporto emotivo?",
      sub: "Chiedere consigli, sfogarsi, cercare conforto da un'intelligenza artificiale",
      opts: [
        { text: "No, non usa AI in questo modo", score: 0 },
        { text: "Non lo so", score: 1 },
        { text: "Sì, qualche volta", score: 2 },
        { text: "Sì, regolarmente — lo preferisce alle persone", score: 3 }
      ]
    },
    {
      q: "Come valuti la tua conoscenza delle piattaforme che usa?",
      sub: "Sai cosa fa online? Conosci le app che usa?",
      opts: [
        { text: "Conosco bene le app e parlo spesso con lui/lei di cosa fa", score: 0 },
        { text: "Ho un'idea generale ma non entro nei dettagli", score: 1 },
        { text: "So poco — usa app che non conosco", score: 2 },
        { text: "Non ho idea di cosa faccia online", score: 3 }
      ]
    }
  ];

  const profiles = {
    low: {
      label: "Esposizione bassa",
      color: "low",
      title: "Buone notizie: l'esposizione è contenuta",
      advice: [
        "Continua a mantenere regole chiare e dialogo aperto sull'uso del digitale",
        "Introduci gradualmente l'educazione critica ai contenuti online",
        "Monitora l'evoluzione — le abitudini cambiano rapidamente con l'età",
        "Parla di AI e chatbot prima che inizi a usarli: è meglio prevenire"
      ]
    },
    medium: {
      label: "Esposizione moderata",
      color: "medium",
      title: "Attenzione: ci sono aree da migliorare",
      advice: [
        "Stabilisci (o rafforza) regole chiare su orari e luoghi di utilizzo — niente schermi prima di dormire",
        "Parla con tuo figlio/a di come si sente dopo aver usato i social — i segnali emotivi sono importanti",
        "Riduci gradualmente il tempo schermo di 30 minuti al giorno — non serve un taglio drastico",
        "Informati sulle app che usa — chiedi di mostrartele, senza giudicare",
        "Proponi attività alternative concrete (sport, musica, uscite con amici)"
      ]
    },
    high: {
      label: "Esposizione alta",
      color: "high",
      title: "Segnale importante: serve un intervento",
      advice: [
        "Il livello di esposizione è significativo — non è colpa tua e non è colpa sua, ma è ora di agire",
        "Inizia dal dialogo: chiedi come si sente, senza accusare. La ricerca mostra che il divieto da solo non funziona",
        "Rimuovi lo smartphone dalla camera da letto di notte — è il cambiamento con il maggiore impatto",
        "Se noti ansia, ritiro sociale o uso compulsivo, considera un confronto con uno psicologo dell'età evolutiva",
        "Coinvolgi la scuola: chiedi se hanno programmi di educazione digitale",
        "Ricorda: la maggior parte dei ragazzi vorrebbe usare meno i social ma non riesce a farlo da sola"
      ]
    }
  };

  let current = 0;
  let answers = [];

  function init() {
    const container = document.getElementById('bdg-full-checker');
    if (!container) return;

    const progressEl = document.getElementById('checker-progress');
    const questionsEl = document.getElementById('checker-questions');

    // Build progress
    progressEl.innerHTML = questions.map((_, i) =>
      '<div class="step' + (i === 0 ? ' active' : '') + '"></div>'
    ).join('');

    // Build questions
    questionsEl.innerHTML = questions.map((q, i) =>
      '<div class="bdg-checker-question' + (i === 0 ? ' active' : '') + '" data-q="' + i + '">' +
        '<h3>' + q.q + '</h3>' +
        '<p class="subtitle">' + q.sub + '</p>' +
        '<div class="bdg-checker-options">' +
          q.opts.map((o, j) =>
            '<div class="bdg-checker-option" data-value="' + o.score + '" onclick="bdgSelectOption(this)">' +
              '<div class="radio"></div>' +
              '<span>' + o.text + '</span>' +
            '</div>'
          ).join('') +
        '</div>' +
      '</div>'
    ).join('');

    answers = new Array(questions.length).fill(null);
  }

  window.bdgSelectOption = function(el) {
    const parent = el.closest('.bdg-checker-question');
    parent.querySelectorAll('.bdg-checker-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    answers[current] = parseInt(el.dataset.value);

    document.getElementById('btn-next').disabled = false;
  };

  window.bdgNext = function() {
    if (answers[current] === null) return;

    if (current < questions.length - 1) {
      current++;
      updateView();
    } else {
      showResult();
    }
  };

  window.bdgPrev = function() {
    if (current > 0) {
      current--;
      updateView();
    }
  };

  function updateView() {
    // Update questions
    document.querySelectorAll('.bdg-checker-question').forEach((q, i) => {
      q.classList.toggle('active', i === current);
    });

    // Update progress
    document.querySelectorAll('#checker-progress .step').forEach((s, i) => {
      s.classList.remove('active', 'done');
      if (i === current) s.classList.add('active');
      else if (i < current) s.classList.add('done');
    });

    // Update nav
    document.getElementById('btn-prev').style.display = current === 0 ? 'none' : '';
    document.getElementById('btn-next').disabled = answers[current] === null;

    if (current === questions.length - 1) {
      document.getElementById('btn-next').textContent = 'Vedi risultato →';
    } else {
      document.getElementById('btn-next').innerHTML = 'Avanti &rarr;';
    }
  }

  function showResult() {
    const total = answers.reduce((sum, v) => sum + (v || 0), 0);
    const max = questions.length * 3;
    const pct = Math.round((total / max) * 100);

    let profile;
    if (total <= 8) profile = profiles.low;
    else if (total <= 18) profile = profiles.medium;
    else profile = profiles.high;

    document.getElementById('checker-questions').style.display = 'none';
    document.getElementById('checker-nav').style.display = 'none';

    // Update all progress steps to done
    document.querySelectorAll('#checker-progress .step').forEach(s => {
      s.classList.remove('active');
      s.classList.add('done');
    });

    const resultEl = document.getElementById('checker-result');
    resultEl.style.display = 'block';
    resultEl.innerHTML =
      '<div class="bdg-result">' +
        '<div class="bdg-result-score ' + profile.color + '">' +
          '<div class="score-num">' + total + '/' + max + '</div>' +
          '<div class="score-label">' + profile.label + '</div>' +
        '</div>' +
        '<h2 style="margin:1rem 0 .5rem;">' + profile.title + '</h2>' +
        '<p style="color:var(--bdg-ink-50);max-width:500px;margin:0 auto;">Punteggio: ' + total + ' su ' + max + ' (' + pct + '%). Ecco i consigli basati sul profilo emerso.</p>' +
        '<div class="bdg-result-advice">' +
          '<h4>Cosa puoi fare adesso</h4>' +
          '<ul>' + profile.advice.map(a => '<li>' + a + '</li>').join('') + '</ul>' +
        '</div>' +
        '<div id="bdg-checker-form-area" style="margin-top:2rem;padding-top:1.5rem;border-top:var(--bdg-border);text-align:center;">' +
          '<p style="font-size:.88rem;color:var(--bdg-ink-80);margin-bottom:1rem;">Vuoi ricevere la guida completa con approfondimenti per il tuo profilo?</p>' +
          getFormHTML(profile, total, max, pct) +
          '<p style="font-size:.72rem;color:var(--bdg-ink-50);margin-top:.75rem;">Nessuno spam. Solo la guida e gli aggiornamenti dell\'Osservatorio.</p>' +
        '</div>' +
        '<div style="margin-top:1.5rem;">' +
          '<button class="bdg-btn bdg-btn-ghost" onclick="location.reload()">Rifai il test</button>' +
        '</div>' +
      '</div>';
  }

  /**
   * Form HTML generator
   * Checks if a WordPress form plugin shortcode container exists (placed in page-checker.php).
   * If it does, it injects the checker results as hidden fields into that form.
   * If not, falls back to a simple native email form.
   *
   * SUPPORTED PLUGINS:
   * - Contact Form 7: add shortcode in page-checker.php inside #bdg-wp-form-slot
   * - WPForms: add shortcode in page-checker.php inside #bdg-wp-form-slot
   * - Gravity Forms: add shortcode in page-checker.php inside #bdg-wp-form-slot
   *
   * The checker will inject hidden fields with:
   * - bdg_score: total score (e.g. "15/30")
   * - bdg_profile: profile name (e.g. "Esposizione moderata")
   * - bdg_percentage: percentage (e.g. "50%")
   * - bdg_answers: JSON string of all answers
   */
  function getFormHTML(profile, total, max, pct) {
    // Check if WP form slot exists in page
    var wpFormSlot = document.getElementById('bdg-wp-form-slot');
    if (wpFormSlot && wpFormSlot.innerHTML.trim().length > 10) {
      // WordPress form plugin is active — inject hidden fields and show it
      var hiddenFields =
        '<input type="hidden" name="bdg_score" value="' + total + '/' + max + '">' +
        '<input type="hidden" name="bdg_profile" value="' + profile.label + '">' +
        '<input type="hidden" name="bdg_percentage" value="' + pct + '%">' +
        '<input type="hidden" name="bdg_answers" value=\'' + JSON.stringify(answers) + '\'>';

      // Try to inject hidden fields into the form
      var wpForm = wpFormSlot.querySelector('form');
      if (wpForm) {
        wpForm.insertAdjacentHTML('afterbegin', hiddenFields);
      }

      // Show the slot and return reference
      wpFormSlot.style.display = 'block';
      return '<div id="bdg-checker-wp-form-ref"></div>';
    }

    // Fallback: native HTML form (works without any plugin)
    return '<form id="bdg-native-form" style="display:flex;gap:.5rem;max-width:400px;margin:0 auto;" onsubmit="return bdgSubmitNative(event)">' +
      '<input type="hidden" name="bdg_score" value="' + total + '/' + max + '">' +
      '<input type="hidden" name="bdg_profile" value="' + profile.label + '">' +
      '<input type="hidden" name="bdg_percentage" value="' + pct + '%">' +
      '<input type="email" name="bdg_email" placeholder="La tua email" required ' +
        'style="flex:1;padding:.6rem 1rem;border:1px solid var(--bdg-ink-08);border-radius:var(--bdg-radius);font-family:var(--bdg-font-body);font-size:.88rem;">' +
      '<button type="submit" class="bdg-btn bdg-btn-primary">Invia</button>' +
    '</form>';
  }

  /**
   * Native form submit handler
   * Sends data via WP REST API or AJAX
   */
  window.bdgSubmitNative = function(e) {
    e.preventDefault();
    var form = document.getElementById('bdg-native-form');
    var email = form.querySelector('[name="bdg_email"]').value;
    var score = form.querySelector('[name="bdg_score"]').value;
    var profileName = form.querySelector('[name="bdg_profile"]').value;

    // If WP AJAX is available, send via admin-ajax
    if (typeof bdg_ajax !== 'undefined' && bdg_ajax.url) {
      var fd = new FormData();
      fd.append('action', 'bdg_checker_submit');
      fd.append('email', email);
      fd.append('score', score);
      fd.append('profile', profileName);
      fd.append('nonce', bdg_ajax.nonce);

      fetch(bdg_ajax.url, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function() { showThankYou(form); })
        .catch(function() { showThankYou(form); });
    } else {
      // No WP AJAX — just show thank you (email will need plugin integration)
      showThankYou(form);
    }
    return false;
  };

  function showThankYou(form) {
    form.outerHTML =
      '<div style="background:var(--bdg-teal-light);border-radius:var(--bdg-radius);padding:1rem;text-align:center;">' +
        '<p style="font-size:.88rem;color:var(--bdg-teal);font-weight:600;">Grazie! Riceverai la guida al tuo indirizzo email.</p>' +
      '</div>';
  }

  /**
   * Print checker (all questions visible)
   */
  window.bdgPrintChecker = function() {
    window.print();
  };

  // Init on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
