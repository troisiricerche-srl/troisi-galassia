/**
 * BDG Navigation + Cookie Banner
 */
(function() {
  'use strict';

  document.addEventListener('DOMContentLoaded', function() {

    /* ═══ HAMBURGER MENU ═══ */
    var toggle = document.querySelector('.bdg-menu-toggle');
    var nav = document.querySelector('.bdg-nav');
    var header = document.querySelector('.bdg-header');

    if (toggle && nav) {
      toggle.addEventListener('click', function() {
        var expanded = toggle.getAttribute('aria-expanded') === 'true';
        toggle.setAttribute('aria-expanded', !expanded);
        toggle.classList.toggle('is-active');
        nav.classList.toggle('is-open');
        document.body.classList.toggle('menu-open');
      });

      // Close menu when clicking a link
      var navLinks = nav.querySelectorAll('a');
      navLinks.forEach(function(link) {
        link.addEventListener('click', function() {
          toggle.setAttribute('aria-expanded', 'false');
          toggle.classList.remove('is-active');
          nav.classList.remove('is-open');
          document.body.classList.remove('menu-open');
        });
      });

      // Close menu on outside click
      document.addEventListener('click', function(e) {
        if (nav.classList.contains('is-open') && !header.contains(e.target)) {
          toggle.setAttribute('aria-expanded', 'false');
          toggle.classList.remove('is-active');
          nav.classList.remove('is-open');
          document.body.classList.remove('menu-open');
        }
      });

      // Close on Escape key
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && nav.classList.contains('is-open')) {
          toggle.setAttribute('aria-expanded', 'false');
          toggle.classList.remove('is-active');
          nav.classList.remove('is-open');
          document.body.classList.remove('menu-open');
        }
      });
    }

    /* ═══ COOKIE BANNER ═══ */
    var banner = document.getElementById('bdg-cookie-banner');
    if (banner && !getCookie('bdg_cookie_consent')) {
      banner.style.display = 'block';
    }
  });

  /* Cookie helpers */
  function getCookie(name) {
    var v = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    return v ? v.pop() : '';
  }

  function setCookie(name, value, days) {
    var d = new Date();
    d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
    document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax';
  }

  /* Global cookie functions */
  window.bdgAcceptCookies = function(type) {
    setCookie('bdg_cookie_consent', type, 365);
    var banner = document.getElementById('bdg-cookie-banner');
    if (banner) {
      banner.style.opacity = '0';
      banner.style.transform = 'translateY(100%)';
      setTimeout(function() { banner.style.display = 'none'; }, 300);
    }

    if (type === 'all') {
      // Enable analytics if GA is loaded
      if (typeof gtag === 'function') {
        gtag('consent', 'update', {
          'analytics_storage': 'granted'
        });
      }
    }
  };

  window.bdgResetCookies = function() {
    setCookie('bdg_cookie_consent', '', -1);
    var banner = document.getElementById('bdg-cookie-banner');
    if (banner) {
      banner.style.display = 'block';
      banner.style.opacity = '1';
      banner.style.transform = 'translateY(0)';
    }
  };

})();
