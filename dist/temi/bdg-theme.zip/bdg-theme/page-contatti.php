<?php
/**
 * Template Name: Contatti e Stampa
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1>Contatti e Stampa</h1>
    <p>Per collaborazioni, interviste e richieste media</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-content" style="margin-top:-1.5rem;">

      <div class="bdg-grid bdg-grid-2" style="margin-bottom:2rem;">
        <div style="background:var(--bdg-teal-light);border-radius:var(--bdg-radius-lg);padding:1.5rem;">
          <h3 style="color:var(--bdg-teal);font-size:1rem;margin-bottom:.75rem;">Contatti generali</h3>
          <p style="font-size:.88rem;margin-bottom:.25rem;"><strong>Email:</strong> <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a></p>
          <p style="font-size:.88rem;margin-bottom:.5rem;"><strong>Troisi Ricerche S.r.l.</strong></p>
          <p style="font-size:.82rem;color:var(--bdg-ink-50);line-height:1.5;">Via de Rossi 57, 70122 Bari<br>CF/P.IVA: 07216100722<br>SDI: KRRH6B9<br>PEC: <a href="mailto:andrea.troisi@pec.it">andrea.troisi@pec.it</a></p>
        </div>
        <div style="background:var(--bdg-coral-light);border-radius:var(--bdg-radius-lg);padding:1.5rem;">
          <h3 style="color:var(--bdg-coral);font-size:1rem;margin-bottom:.75rem;">Ufficio stampa</h3>
          <p style="font-size:.88rem;margin-bottom:.5rem;">Giornalisti e media possono richiedere dati, infografiche, interviste e commenti esperti.</p>
          <p style="font-size:.88rem;"><strong>Email:</strong> <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a></p>
        </div>
      </div>

      <h2>Collaborazioni</h2>
      <p>L'Osservatorio è aperto a collaborazioni con scuole, università, enti locali, associazioni di genitori e organizzazioni del terzo settore che condividano l'obiettivo di promuovere un rapporto sano tra giovani e tecnologia.</p>

      <h3>Per le scuole</h3>
      <p>Offriamo gratuitamente materiale didattico, dati per il PTOF e supporto nella progettazione di percorsi di educazione digitale. Se sei un dirigente scolastico o un coordinatore, contattaci.</p>

      <h3>Per le istituzioni</h3>
      <p>I dati dell'Osservatorio sono disponibili in open access per politiche pubbliche, delibere comunali e programmi regionali sul benessere digitale dei minori.</p>

      <h3>Per i media</h3>
      <p>Forniamo dati aggiornati, infografiche pronte per la pubblicazione e disponibilità per interviste. Andrea Troisi è disponibile come esperto per commenti su temi legati al benessere digitale giovanile, metodologie di ricerca e impatto delle piattaforme.</p>

      <div style="background:var(--bdg-ivory);border-radius:var(--bdg-radius-lg);padding:1.5rem;margin:2rem 0;">
        <h3 style="font-size:1rem;">Media kit</h3>
        <p style="font-size:.88rem;">Il media kit include: logo dell'Osservatorio, bio dei fondatori, scheda progetto, infografiche con i dati principali, foto. Richiedilo a <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a>.</p>
      </div>

      <h2>Scrivici</h2>
      <p>Usa il form qui sotto per qualsiasi richiesta. Rispondiamo entro 48 ore.</p>

      <div id="bdg-contact-form" style="background:var(--bdg-ivory);border-radius:var(--bdg-radius-lg);padding:1.5rem;margin-top:1rem;">
        <div id="bdg-contact-success" style="display:none;text-align:center;padding:2rem 0;">
          <div style="font-size:2.5rem;margin-bottom:.75rem;">✅</div>
          <h3 style="color:var(--bdg-teal);margin-bottom:.5rem;">Messaggio inviato</h3>
          <p style="color:var(--bdg-ink-50);font-size:.88rem;">Grazie per averci scritto. Risponderemo entro 48 ore.</p>
        </div>

        <form id="bdg-contact" style="display:flex;flex-direction:column;gap:1rem;" onsubmit="return bdgSendContact(event)">
          <?php wp_nonce_field('bdg_contact_nonce', 'bdg_contact_nonce_field'); ?>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div>
              <label style="font-size:.8rem;font-weight:600;color:var(--bdg-ink-50);display:block;margin-bottom:.25rem;">Nome *</label>
              <input type="text" name="bdg_name" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--bdg-ink-08);border-radius:var(--bdg-radius);font-family:var(--bdg-font-body);font-size:.88rem;" placeholder="Il tuo nome">
            </div>
            <div>
              <label style="font-size:.8rem;font-weight:600;color:var(--bdg-ink-50);display:block;margin-bottom:.25rem;">Email *</label>
              <input type="email" name="bdg_email" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--bdg-ink-08);border-radius:var(--bdg-radius);font-family:var(--bdg-font-body);font-size:.88rem;" placeholder="La tua email">
            </div>
          </div>

          <div>
            <label style="font-size:.8rem;font-weight:600;color:var(--bdg-ink-50);display:block;margin-bottom:.25rem;">Ruolo *</label>
            <select name="bdg_role" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--bdg-ink-08);border-radius:var(--bdg-radius);font-family:var(--bdg-font-body);font-size:.88rem;background:var(--bdg-white);color:var(--bdg-ink);">
              <option value="" disabled selected>Seleziona il tuo ruolo</option>
              <option value="genitore">Genitore</option>
              <option value="insegnante">Insegnante / Dirigente scolastico</option>
              <option value="giornalista">Giornalista / Media</option>
              <option value="istituzione">Istituzione / Ente pubblico</option>
              <option value="ricercatore">Ricercatore / Università</option>
              <option value="associazione">Associazione / Terzo settore</option>
              <option value="azienda">Azienda privata</option>
              <option value="altro">Altro</option>
            </select>
          </div>

          <div>
            <label style="font-size:.8rem;font-weight:600;color:var(--bdg-ink-50);display:block;margin-bottom:.25rem;">Oggetto</label>
            <input type="text" name="bdg_subject" style="width:100%;padding:.6rem .75rem;border:1px solid var(--bdg-ink-08);border-radius:var(--bdg-radius);font-family:var(--bdg-font-body);font-size:.88rem;" placeholder="Di cosa vuoi parlarci?">
          </div>

          <div>
            <label style="font-size:.8rem;font-weight:600;color:var(--bdg-ink-50);display:block;margin-bottom:.25rem;">Messaggio *</label>
            <textarea name="bdg_message" rows="5" required style="width:100%;padding:.6rem .75rem;border:1px solid var(--bdg-ink-08);border-radius:var(--bdg-radius);font-family:var(--bdg-font-body);font-size:.88rem;resize:vertical;" placeholder="Come possiamo aiutarti?"></textarea>
          </div>

          <div style="display:flex;align-items:flex-start;gap:.5rem;">
            <input type="checkbox" id="bdg_privacy" name="bdg_privacy" required style="margin-top:.25rem;">
            <label for="bdg_privacy" style="font-size:.78rem;color:var(--bdg-ink-50);line-height:1.5;">Ho letto e accetto la <a href="<?php echo home_url('/privacy-policy/'); ?>" target="_blank">Privacy Policy</a>. I dati saranno trattati ai sensi del GDPR da Troisi Ricerche S.r.l.</label>
          </div>

          <div>
            <button type="submit" id="bdg-contact-btn" class="bdg-btn bdg-btn-primary">Invia messaggio</button>
            <span id="bdg-contact-error" style="display:none;color:var(--bdg-coral);font-size:.82rem;margin-left:1rem;"></span>
          </div>
        </form>
      </div>

    </div>
  </div>
</section>

<script>
function bdgSendContact(e) {
  e.preventDefault();
  var form = document.getElementById('bdg-contact');
  var btn = document.getElementById('bdg-contact-btn');
  var errEl = document.getElementById('bdg-contact-error');
  btn.textContent = 'Invio in corso...';
  btn.disabled = true;
  errEl.style.display = 'none';

  var data = new FormData(form);
  data.append('action', 'bdg_contact_submit');

  fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
    method: 'POST',
    body: data
  })
  .then(function(r) { return r.json(); })
  .then(function(res) {
    if (res.success) {
      form.style.display = 'none';
      document.getElementById('bdg-contact-success').style.display = 'block';
    } else {
      errEl.textContent = res.data || 'Errore nell\'invio. Riprova.';
      errEl.style.display = 'inline';
      btn.textContent = 'Invia messaggio';
      btn.disabled = false;
    }
  })
  .catch(function() {
    errEl.textContent = 'Errore di connessione. Riprova.';
    errEl.style.display = 'inline';
    btn.textContent = 'Invia messaggio';
    btn.disabled = false;
  });

  return false;
}
</script>

<?php get_footer(); ?>
