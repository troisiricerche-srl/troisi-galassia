<?php
/**
 * Template Name: Cookie Policy
 */
get_header(); ?>

<div class="bdg-page-header">
  <div class="bdg-container">
    <h1>Cookie Policy</h1>
    <p>Informativa sull'utilizzo dei cookie</p>
  </div>
</div>

<section class="bdg-section">
  <div class="bdg-container" style="max-width:800px;">
    <div class="bdg-content" style="margin-top:-1.5rem;">

      <p><strong>Ultimo aggiornamento:</strong> <?php echo date('d/m/Y'); ?></p>

      <h2>Cosa sono i cookie</h2>
      <p>I cookie sono piccoli file di testo che i siti web salvano sul tuo dispositivo (computer, tablet, smartphone) durante la navigazione. Servono a migliorare l'esperienza di navigazione e, in alcuni casi, a raccogliere dati statistici sull'utilizzo del sito.</p>

      <h2>Cookie utilizzati da questo sito</h2>

      <h3>Cookie tecnici (essenziali)</h3>
      <p>Questi cookie sono necessari per il funzionamento del sito e non possono essere disattivati. Non raccolgono informazioni personali identificabili.</p>
      <div style="overflow-x:auto;">
        <table class="bdg-cookie-table">
          <thead><tr><th>Cookie</th><th>Scopo</th><th>Durata</th></tr></thead>
          <tbody>
            <tr><td>bdg_cookie_consent</td><td>Memorizza la scelta dell'utente sui cookie</td><td>12 mesi</td></tr>
            <tr><td>wordpress_sec_*</td><td>Autenticazione (solo per amministratori)</td><td>Sessione</td></tr>
            <tr><td>wp_lang</td><td>Preferenza lingua</td><td>Sessione</td></tr>
          </tbody>
        </table>
      </div>

      <h3>Cookie analitici (previo consenso)</h3>
      <p>Questi cookie ci permettono di capire come i visitatori utilizzano il sito, raccogliendo dati in forma aggregata e anonima. Vengono attivati <strong>solo con il consenso esplicito</strong> dell'utente.</p>
      <div style="overflow-x:auto;">
        <table class="bdg-cookie-table">
          <thead><tr><th>Cookie</th><th>Scopo</th><th>Durata</th></tr></thead>
          <tbody>
            <tr><td>_ga</td><td>Google Analytics — distingue utenti unici</td><td>13 mesi</td></tr>
            <tr><td>_ga_*</td><td>Google Analytics — mantiene stato sessione</td><td>13 mesi</td></tr>
          </tbody>
        </table>
      </div>
      <p style="font-size:.85rem;color:var(--bdg-ink-50);margin-top:.5rem;">Nota: utilizziamo Google Analytics con <strong>anonimizzazione IP</strong> attiva. I dati non vengono incrociati con altre informazioni di Google.</p>

      <h3>Cookie di profilazione / marketing</h3>
      <p>Questo sito <strong>non utilizza</strong> cookie di profilazione o marketing. Non vendiamo né condividiamo dati di navigazione con piattaforme pubblicitarie.</p>

      <h2>Come gestire i cookie</h2>
      <h3>Tramite il banner</h3>
      <p>Al primo accesso al sito, un banner ti permette di accettare tutti i cookie, accettare solo quelli essenziali o personalizzare le preferenze. Puoi modificare la tua scelta in qualsiasi momento cliccando sul pulsante qui sotto:</p>
      <p><button onclick="bdgResetCookies()" class="bdg-btn bdg-btn-primary" style="font-size:.85rem;">Gestisci preferenze cookie</button></p>

      <h3>Tramite il browser</h3>
      <p>Puoi anche gestire i cookie direttamente dalle impostazioni del tuo browser:</p>
      <ul>
        <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener">Google Chrome</a></li>
        <li><a href="https://support.mozilla.org/it/kb/protezione-antitracciamento-avanzata-firefox-desktop" target="_blank" rel="noopener">Mozilla Firefox</a></li>
        <li><a href="https://support.apple.com/it-it/guide/safari/sfri11471/mac" target="_blank" rel="noopener">Safari</a></li>
        <li><a href="https://support.microsoft.com/it-it/microsoft-edge/eliminare-i-cookie-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09" target="_blank" rel="noopener">Microsoft Edge</a></li>
      </ul>

      <h2>Aggiornamenti</h2>
      <p>Questa cookie policy può essere aggiornata. Ti invitiamo a consultarla periodicamente. La data dell'ultimo aggiornamento è indicata in alto.</p>

      <h2>Contatti</h2>
      <p>Per domande sui cookie o sulla privacy: <a href="mailto:info@benesseredigitalegiovani.it">info@benesseredigitalegiovani.it</a></p>

    </div>
  </div>
</section>

<?php get_footer(); ?>
