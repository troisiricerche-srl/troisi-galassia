<?php
/**
 * Single post template — with author box and chart support
 */
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>

<div class="bdg-single-header">
  <?php $cats = get_the_category(); if ($cats) : ?>
    <div style="margin-bottom:.5rem;">
      <span style="font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--bdg-teal);background:var(--bdg-teal-light);padding:.2rem .6rem;border-radius:20px;"><?php $bdg_c = bdg_main_cat(); echo esc_html($bdg_c ? $bdg_c->name : $cats[0]->name); ?></span>
    </div>
  <?php endif; ?>
  <h1><?php the_title(); ?></h1>
  <div class="bdg-single-meta">
    <?php echo get_the_date('j F Y'); ?> &middot; Osservatorio Benessere Digitale Giovani
  </div>
</div>

<article class="bdg-single-content">
  <?php if (has_post_thumbnail()) : ?>
    <figure class="bdg-single-hero" style="margin:0 0 2rem;"><?php the_post_thumbnail('large', ['style'=>'width:100%;height:auto;border-radius:14px;display:block;']); ?></figure>
  <?php endif; ?>
  <?php the_content(); ?>

  <!-- Author Box -->
  <div class="bdg-author-box">
    <img src="<?php echo BDG_URI; ?>/img/andrea-troisi.jpg" alt="Andrea Troisi" class="bdg-author-photo">
    <div class="bdg-author-info">
      <div class="bdg-author-label">Osservatorio BDG</div>
      <div class="bdg-author-name">Un progetto di Troisi Ricerche S.r.l.</div>
      <p class="bdg-author-bio">Istituto di ricerca accreditato MIUR. L'Osservatorio è diretto da <strong>Andrea Troisi</strong>, con 18 anni di esperienza nella ricerca sociale applicata.</p>
      <div class="bdg-author-links">
        <a href="https://troisiricerche.net" target="_blank" rel="noopener">troisiricerche.net</a>
        <a href="https://www.linkedin.com/company/troisi-ricerche" target="_blank" rel="noopener" class="bdg-social-link">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          LinkedIn
        </a>
        <a href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener" class="bdg-social-link">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
          YouTube
        </a>
      </div>
    </div>
  </div>

  <!-- Checker CTA -->
  <div style="margin-top:2rem;padding-top:1.5rem;border-top:var(--bdg-border);">
    <div style="background:var(--bdg-teal-light);border-radius:var(--bdg-radius-lg);padding:1.5rem;text-align:center;">
      <h3 style="color:var(--bdg-teal);font-size:1.1rem;">Scopri il tuo profilo</h3>
      <p style="font-size:.88rem;color:var(--bdg-ink-50);margin:.5rem 0 1rem;">Il nostro checker gratuito misura l'esposizione digitale di tuo figlio in 2 minuti.</p>
      <a href="<?php echo home_url('/checker/'); ?>" class="bdg-btn bdg-btn-primary">Fai il test &rarr;</a>
    </div>
  </div>

  <?php
  // Related posts
  $related = new WP_Query([
      'posts_per_page' => 3,
      'post__not_in'   => [get_the_ID()],
      'category__in'   => wp_get_post_categories(get_the_ID()),
  ]);
  if ($related->have_posts()) : ?>
  <div style="margin-top:2.5rem;">
    <h3 style="margin-bottom:1rem;">Articoli correlati</h3>
    <div class="bdg-grid bdg-grid-3">
      <?php while ($related->have_posts()) : $related->the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="bdg-blog-card">
        <div class="bdg-blog-card-body">
          <h3 style="font-size:.95rem;"><?php the_title(); ?></h3>
          <div class="meta"><?php echo get_the_date('j F Y'); ?></div>
        </div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
  <?php endif; ?>
</article>

<?php endwhile; ?>

<?php get_footer(); ?>
