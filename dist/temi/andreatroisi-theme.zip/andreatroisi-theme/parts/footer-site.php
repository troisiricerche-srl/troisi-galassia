<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!-- ═══════════════════ FOOTER ═══════════════════ -->
<footer class="at-footer">
  <div class="footer-top">
    <div>
      <div class="footer-brand-name">Andrea <span>Troisi</span></div>
      <div class="footer-brand-sub">Ricerca &middot; Dati &middot; AI &middot; Governance &middot; Italia</div>
      <nav class="footer-social" aria-label="Profili social">
        <a href="https://www.linkedin.com/in/andreatroisi" target="_blank" rel="noopener">LinkedIn ↗</a>
        <a href="https://www.linkedin.com/company/troisi-ricerche/" target="_blank" rel="noopener">LinkedIn Troisi Ricerche ↗</a>
        <a href="https://www.facebook.com/troisiricerche" target="_blank" rel="noopener">Facebook ↗</a>
        <a href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener">YouTube ↗</a>
        <a href="https://www.instagram.com/troisiricerche/" target="_blank" rel="noopener">Instagram ↗</a>
        <a href="https://whatsapp.com/channel/0029VbE9Kx9DeONGCBFx5v42" target="_blank" rel="noopener">WhatsApp «Il dato è tratto™» ↗</a>
      </nav>
    </div>
    <div class="footer-themes">
      <?php
      $themes = ['Economia e Lavoro','Turismo e Cultura','Puglia e Mezzogiorno','Ambiente e Clima','Innovazione e Digitale','Agroalimentare','Politica e Attualità','Media e Radio','Società e Demografia','Sanità','Istruzione','Sport'];
      foreach ($themes as $t): ?>
        <span class="footer-theme"><?php echo $t; ?></span>
      <?php endforeach; ?>
    </div>
  </div>
  <div style="padding:1.2rem 0;border-top:1px solid rgba(255,255,255,.08);border-bottom:1px solid rgba(255,255,255,.08);margin:1rem 0;">
    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.3);margin-bottom:.6rem;">Network Troisi</div>
    <div style="display:flex;flex-wrap:wrap;gap:.4rem;">
      <a href="https://andreatroisi.it" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.7);text-decoration:none;font-weight:700;">andreatroisi.it</a>
      <a href="https://troisiricerche.net" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Troisi Ricerche</a>
      <a href="https://t-index.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">TR-Index</a>
      <a href="https://mappaturadellecompetenze.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Mappatura delle Competenze</a>
      <a href="https://registrodellecompetenze.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Registro delle Competenze</a>
      <a href="https://customerpa.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">CustomerPA</a>
      <a href="https://benessereorganizzativo.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">BenessereOrg.</a>
      <a href="https://troisiformazione.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Formazione</a>
      <a href="https://tiplive.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">TIP Platform</a>
      <a href="https://troisiinsight.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">TroisiInsight</a>
      <a href="https://digitalizzazionenellapa.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">DigitalizzazionePA</a>
      <a href="https://dibattito-pubblico.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Dibattito Pubblico</a>
      <a href="https://voiceinhub.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">VoiceInHub</a>
      <a href="https://governancefinanziaria.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Governance Fin.</a>
      <a href="https://consulenzainternazionalizzazione.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Internazionalizzazione</a>
      <a href="https://benesseredigitalegiovani.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Benessere Digitale Giovani</a>
      <a href="https://svegliadigitale.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Sveglia Digitale</a>
      <a href="https://delfiweb.it" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">DELFI</a>
      <a href="https://www.osservatoriomezzogiorno.net" target="_blank" rel="noopener" style="display:inline-block;padding:.2rem .6rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:100px;font-size:.68rem;color:rgba(255,255,255,.4);text-decoration:none;transition:all .2s;">Osservatorio Mezzogiorno</a>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="footer-legal">
      CF TRSNDR80D21A662E &nbsp;·&nbsp; P.IVA 06824390725 &nbsp;·&nbsp; info@andreatroisi.it &nbsp;·&nbsp; andrea.troisi@uniba.it &nbsp;·&nbsp; SDI KRRH6B9
    </div>
    <div class="footer-copy">© <?php echo date('Y'); ?> Andrea Troisi — andreatroisi.it</div>
    <div style="margin-top:8px;">
      <script type="text/javascript" src="https://embeds.iubenda.com/widgets/adafb5d4-cf52-4782-a1b1-2573a39f5d04.js"></script>
    </div>
  </div>
</footer>
