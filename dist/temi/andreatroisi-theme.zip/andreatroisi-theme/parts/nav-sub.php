<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$h = home_url( '/' ); ?>
<nav class="at-nav scrolled" id="at-nav">
  <a href="<?php echo esc_url( $h ); ?>" class="nav-brand">Andrea <span>Troisi</span></a>
  <ul class="nav-links" id="nav-links">
    <li><a href="<?php echo esc_url( $h . '#about' ); ?>">Chi sono</a></li>
    <li><a href="<?php echo esc_url( $h . '#roles' ); ?>">Ruoli</a></li>
    <li><a href="<?php echo esc_url( at_evento_url() ); ?>" aria-current="page">Speaking</a></li>
    <li><a href="<?php echo esc_url( function_exists( 'at_articoli_url' ) ? at_articoli_url() : $h . '#articles' ); ?>">Articoli</a></li>
    <li><a href="<?php echo esc_url( $h . '#books' ); ?>">Libri</a></li>
    <li><a href="<?php echo esc_url( $h . '#press' ); ?>">Stampa</a></li>
    <li><a href="<?php echo esc_url( $h . '#contact' ); ?>" class="nav-cta">Contatti</a></li>
  </ul>
  <button class="nav-hamburger" id="nav-hamburger" aria-label="Menu" aria-controls="nav-links" aria-expanded="false">
    <span></span><span></span><span></span>
  </button>
</nav>
<script>
document.getElementById('nav-hamburger').addEventListener('click', function () {
  var n = document.getElementById('nav-links');
  n.classList.toggle('open');
  this.setAttribute('aria-expanded', n.classList.contains('open'));
});
</script>
