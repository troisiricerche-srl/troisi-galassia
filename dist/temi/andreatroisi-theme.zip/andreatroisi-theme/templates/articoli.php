<?php
/**
 * Pagina /articoli/: tutti gli articoli raccolti da Radio Notizie e dalle piattaforme di Troisi Ricerche.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$r       = at_articoli_richiesta();
$fonti   = at_articoli_fonti();
$tutti   = at_articoli();
$lista   = at_articoli( $r['fonte'], $r['argomento'] );
$pagine  = max( 1, (int) ceil( count( $lista ) / AT_ARTICOLI_PER_PAGINA ) );
$pagina  = min( $r['pagina'], $pagine );
if ( $r['pagina'] > $pagine ) { status_header( 404 ); }
$vista   = array_slice( $lista, ( $pagina - 1 ) * AT_ARTICOLI_PER_PAGINA, AT_ARTICOLI_PER_PAGINA );

/* Conteggi per i filtri. */
$per_fonte = array();
$per_tag   = array();
foreach ( $tutti as $a ) {
	$per_fonte[ $a['fonte'] ] = isset( $per_fonte[ $a['fonte'] ] ) ? $per_fonte[ $a['fonte'] ] + 1 : 1;
	foreach ( (array) $a['tags'] as $t ) { $per_tag[ $t ] = isset( $per_tag[ $t ] ) ? $per_tag[ $t ] + 1 : 1; }
}
arsort( $per_tag );
$filtri = array_filter( array( 'fonte' => $r['fonte'], 'argomento' => $r['argomento'] ) );
$pag_url = function ( $n ) use ( $filtri ) {
	$u = $n > 1 ? at_articoli_url() . 'pagina/' . $n . '/' : at_articoli_url();
	return $filtri ? add_query_arg( $filtri, $u ) : $u;
};

get_header();
get_template_part( 'parts/nav-sub' );
?>
<main class="palco palco-indice articoli-pagina" id="top">
  <header class="palco-indice-testa">
    <nav class="palco-briciole" aria-label="Percorso">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Andrea Troisi</a>
    </nav>
    <div class="section-label"><span>Articoli &amp; pensieri</span></div>
    <h1 class="section-title">Cosa scrivo,<br>cosa <em>penso</em></h1>
    <p class="palco-intro">Gli articoli di Andrea Troisi e della redazione su Radio Notizie e sulle piattaforme di Troisi Ricerche: statistica, Pubblica Amministrazione, benessere organizzativo, economia e innovazione.</p>
  </header>

  <?php if ( ! $tutti ) : ?>
    <p class="palco-intro articoli-vuoto">Stiamo raccogliendo gli articoli: torna tra qualche minuto. Nel frattempo li trovi su <a href="https://www.radionotizie.eu/author/andrea-troisi/" target="_blank" rel="noopener">Radio Notizie</a>.</p>
  <?php else : ?>

  <nav class="palco-filtro" id="argomenti" aria-label="Filtra per sito">
    <a href="<?php echo esc_url( at_articoli_url( $r['argomento'] ? array( 'argomento' => $r['argomento'] ) : array() ) ); ?>#argomenti"<?php echo $r['fonte'] ? '' : ' aria-current="true"'; ?>>Tutti i siti <small><?php echo count( $tutti ); ?></small></a>
    <?php foreach ( $fonti as $k => $f ) : if ( empty( $per_fonte[ $k ] ) ) { continue; } ?>
      <a href="<?php echo esc_url( at_articoli_url( array_filter( array( 'fonte' => $k, 'argomento' => $r['argomento'] ) ) ) ); ?>#argomenti"<?php echo $r['fonte'] === $k ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $f['nome'] ); ?> <small><?php echo (int) $per_fonte[ $k ]; ?></small></a>
    <?php endforeach; ?>
  </nav>
  <nav class="palco-filtro palco-filtro--argomenti" aria-label="Filtra per argomento">
    <a href="<?php echo esc_url( at_articoli_url( $r['fonte'] ? array( 'fonte' => $r['fonte'] ) : array() ) ); ?>#argomenti"<?php echo $r['argomento'] ? '' : ' aria-current="true"'; ?>>Tutti gli argomenti</a>
    <?php foreach ( $per_tag as $t => $n ) : if ( $n < 3 ) { continue; } ?>
      <a href="<?php echo esc_url( at_articoli_url( array_filter( array( 'fonte' => $r['fonte'], 'argomento' => at_tag_slug( $t ) ) ) ) ); ?>#argomenti"<?php echo $r['argomento'] === at_tag_slug( $t ) ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $t ); ?> <small><?php echo (int) $n; ?></small></a>
    <?php endforeach; ?>
  </nav>

  <p class="palco-filtro-nota"><?php echo count( $lista ); ?> articoli<?php echo $pagine > 1 ? ' · pagina ' . (int) $pagina . ' di ' . (int) $pagine : ''; ?></p>

  <section class="articoli-elenco" aria-label="Articoli">
    <div class="articles-grid">
      <?php foreach ( $vista as $a ) { echo at_articolo_card( $a ); } // phpcs:ignore ?>
    </div>
  </section>

  <?php if ( $pagine > 1 ) : ?>
  <nav class="articoli-paginazione" aria-label="Pagine">
    <?php if ( $pagina > 1 ) : ?><a href="<?php echo esc_url( $pag_url( $pagina - 1 ) ); ?>" rel="prev">&larr; Più recenti</a><?php endif; ?>
    <?php for ( $i = 1; $i <= $pagine; $i++ ) : ?>
      <?php if ( $i === $pagina ) : ?><span aria-current="page"><?php echo (int) $i; ?></span>
      <?php elseif ( 1 === $i || $i === $pagine || abs( $i - $pagina ) <= 2 ) : ?><a href="<?php echo esc_url( $pag_url( $i ) ); ?>"><?php echo (int) $i; ?></a>
      <?php elseif ( abs( $i - $pagina ) === 3 ) : ?><span class="gap">…</span><?php endif; ?>
    <?php endfor; ?>
    <?php if ( $pagina < $pagine ) : ?><a href="<?php echo esc_url( $pag_url( $pagina + 1 ) ); ?>" rel="next">Meno recenti &rarr;</a><?php endif; ?>
  </nav>
  <?php endif; ?>
  <?php endif; ?>

  <section class="palco-cta">
    <p>Vuoi un'analisi o un commento sui <span>dati</span>?</p>
    <div><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" class="btn-primary">Scrivi ad Andrea</a></div>
  </section>
</main>
<?php
get_template_part( 'parts/footer-site' );
get_footer();
