<?php
/**
 * Pagina del singolo intervento (/sul-palco/{chiave}/) o progetto (/sul-campo/{chiave}/)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$chiave = at_palco_richiesta();
$ev     = at_evento( $chiave );
$foto   = at_evento_foto( $ev );
$imgs   = at_evento_immagini( $ev );
$links  = at_evento_link( $ev );
$galleria = array_slice( $imgs, 1 );
$sez    = at_evento_sezione( $ev );
$S      = at_sezione( $sez );
$voce   = $S['voce'];

/* Interventi precedente e successivo nell'ordine cronologico. */
$chiavi = array_keys( at_eventi_ordinati( $sez ) );
$pos    = array_search( $chiave, $chiavi, true );
$piu_recente = $pos > 0 ? $chiavi[ $pos - 1 ] : null;
$meno_recente = $pos < count( $chiavi ) - 1 ? $chiavi[ $pos + 1 ] : null;

$icone = array( 'N' => 'Articolo', 'TV' => 'Video', 'R' => 'Sito', 'L' => 'Link' );

get_header();
get_template_part( 'parts/nav-sub' );
?>
<main class="palco" id="top">

  <header class="palco-hero<?php echo $foto ? '' : ' senza-foto'; ?>">
    <?php if ( $foto ) : ?>
      <figure class="palco-hero-foto">
        <img src="<?php echo esc_url( at_img_url( $foto['file'] ) ); ?>" alt="<?php echo esc_attr( $foto['didascalia'] ); ?>" fetchpriority="high"<?php echo at_img_attr( $foto, true ); ?>>
      </figure>
    <?php endif; ?>
    <div class="palco-hero-testo">
      <nav class="palco-briciole" aria-label="Percorso">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Andrea Troisi</a>
        <span aria-hidden="true">/</span>
        <a href="<?php echo esc_url( at_evento_url( '', $sez ) ); ?>"><?php echo esc_html( $S['titolo'] ); ?></a>
      </nav>
      <p class="palco-data"><?php echo esc_html( $ev['data_label'] ); ?><?php if ( $ev['tema'] ) : ?> <span>· <?php echo esc_html( $ev['tema'] ); ?></span><?php endif; ?></p>
      <h1 class="palco-titolo"><?php echo esc_html( $ev['titolo'] ); ?></h1>
      <?php if ( at_evento_dove( $ev ) ) : ?>
        <p class="palco-dove"><?php echo esc_html( at_evento_dove( $ev ) ); ?></p>
      <?php endif; ?>
    </div>
  </header>

  <?php if ( $foto && $foto['didascalia'] ) : ?>
    <p class="palco-didascalia-hero"><?php echo esc_html( $foto['didascalia'] ); ?></p>
  <?php endif; ?>

  <div class="palco-corpo">
    <article class="palco-testo">
      <?php foreach ( $ev['testo'] as $p ) : ?>
        <p><?php echo esc_html( $p ); ?></p>
      <?php endforeach; ?>
    </article>

    <aside class="palco-scheda" aria-label="Scheda <?php echo 'campo' === $sez ? 'del progetto' : "dell'intervento"; ?>">
      <dl>
        <dt>Quando</dt><dd><?php echo esc_html( $ev['data_label'] ); ?></dd>
        <?php if ( at_evento_dove( $ev ) ) : ?><dt>Dove</dt><dd><?php echo esc_html( at_evento_dove( $ev ) ); ?></dd><?php endif; ?>
        <?php if ( $ev['ruolo'] ) : ?><dt>Ruolo</dt><dd><?php echo esc_html( $ev['ruolo'] ); ?></dd><?php endif; ?>
        <?php if ( $ev['tema'] ) : ?><dt>Tema</dt><dd><?php echo esc_html( $ev['tema'] ); ?></dd><?php endif; ?>
      </dl>
      <?php if ( at_evento_tags( $ev ) ) : ?>
      <div class="palco-tag">
        <h2>Argomenti</h2>
        <ul>
          <?php foreach ( at_evento_tags( $ev ) as $t ) : ?>
            <li><a href="<?php echo esc_url( at_tag_url( $t, $sez ) ); ?>" rel="tag"><?php echo esc_html( $t ); ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endif; ?>
    </aside>
  </div>

  <?php if ( $galleria ) : ?>
  <section class="palco-galleria" aria-label="Foto">
    <?php foreach ( $galleria as $m ) : ?>
      <figure>
        <a href="<?php echo esc_url( at_img_url( $m['file'] ) ); ?>" target="_blank" rel="noopener">
          <img src="<?php echo esc_url( at_img_url( $m['file'] ) ); ?>" alt="<?php echo esc_attr( $m['didascalia'] ); ?>" loading="lazy" decoding="async"<?php echo at_img_attr( $m ); ?>>
        </a>
        <?php if ( $m['didascalia'] ) : ?><figcaption><?php echo esc_html( $m['didascalia'] ); ?></figcaption><?php endif; ?>
      </figure>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

  <?php if ( $links ) : ?>
  <section class="palco-fonti">
    <h2>Video, stampa e approfondimenti</h2>
    <ul>
      <?php foreach ( $links as $l ) :
        $yt = at_youtube_id( $l['url'] ); ?>
        <li class="<?php echo $yt ? 'con-video' : ''; ?>">
          <a href="<?php echo esc_url( $l['url'] ); ?>" target="_blank" rel="noopener">
            <?php if ( $yt ) : ?><span class="play" aria-hidden="true">&#9654;</span><?php endif; ?>
            <span class="tipo"><?php echo esc_html( isset( $icone[ $l['icona'] ] ) ? $icone[ $l['icona'] ] : 'Link' ); ?></span>
            <span class="titolo"><?php echo esc_html( $l['etichetta'] ); ?> <span aria-hidden="true">&#8599;</span></span>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endif; ?>

  <nav class="palco-altri" aria-label="<?php echo 'campo' === $sez ? 'Altri progetti' : 'Altri interventi'; ?>">
    <?php if ( $meno_recente ) : $e = at_evento( $meno_recente ); ?>
      <a class="prec" href="<?php echo esc_url( at_evento_url( $meno_recente ) ); ?>"><small>&larr; <?php echo 'campo' === $sez ? 'Progetto precedente' : 'Intervento precedente'; ?> · <?php echo esc_html( $e['data_label'] ); ?></small><?php echo esc_html( $e['titolo_breve'] ); ?></a>
    <?php else : ?><span></span><?php endif; ?>
    <?php if ( $piu_recente ) : $e = at_evento( $piu_recente ); ?>
      <a class="succ" href="<?php echo esc_url( at_evento_url( $piu_recente ) ); ?>"><small><?php echo 'campo' === $sez ? 'Progetto successivo' : 'Intervento successivo'; ?> · <?php echo esc_html( $e['data_label'] ); ?> &rarr;</small><?php echo esc_html( $e['titolo_breve'] ); ?></a>
    <?php endif; ?>
  </nav>

  <section class="palco-cta">
    <?php if ( 'campo' === $sez ) : ?>
    <p>Hai un progetto di <span>ricerca o di analisi dei dati</span>? Parliamone.</p>
    <?php else : ?>
    <p>Sei interessato ad invitare Andrea come <span>relatore o ospite</span>?</p>
    <?php endif; ?>
    <div>
      <a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" class="btn-primary">Prenota un incontro</a>
      <a href="<?php echo esc_url( at_evento_url( '', $sez ) ); ?>" class="palco-tutti"><?php echo esc_html( $S['voci'] ); ?></a>
    </div>
  </section>
</main>
<?php
get_template_part( 'parts/footer-site' );
get_footer();
