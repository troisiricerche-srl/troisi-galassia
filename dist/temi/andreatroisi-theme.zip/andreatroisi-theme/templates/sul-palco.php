<?php
/**
 * Indice degli interventi: /sul-palco/
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$sez    = at_sezione_richiesta();
$S      = at_sezione( $sez );
$eventi = at_eventi_ordinati( $sez );
$tutti_tag = at_tags_sezione( $sez );
$tag_sel   = at_tag_richiesto();
$tag_nome  = '';
if ( $tag_sel ) {
	foreach ( $tutti_tag as $t => $n ) { if ( at_tag_slug( $t ) === $tag_sel ) { $tag_nome = $t; } }
	if ( $tag_nome ) {
		$eventi = array_filter( $eventi, function ( $e ) use ( $tag_nome ) { return in_array( $tag_nome, at_evento_tags( $e ), true ); } );
	}
}
$anni   = array();
foreach ( $eventi as $k => $e ) {
	$anni[ substr( $e['data'], 0, 4 ) ][ $k ] = $e;
}

get_header();
get_template_part( 'parts/nav-sub' );
?>
<main class="palco palco-indice" id="top">
  <header class="palco-indice-testa">
    <nav class="palco-briciole" aria-label="Percorso">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Andrea Troisi</a>
    </nav>
    <?php if ( 'campo' === $sez ) : ?>
    <div class="section-label"><span>Ricerche &amp; progetti</span></div>
    <h1 class="section-title">Sul campo,<br>tra i <em>progetti</em></h1>
    <?php else : ?>
    <div class="section-label"><span>Speaking &amp; convegni</span></div>
    <h1 class="section-title">Sul palco,<br>tra le <em>idee</em></h1>
    <?php endif; ?>
    <?php if ( ! empty( $GLOBALS['at_palco_404'] ) ) : ?>
      <p class="palco-intro" role="alert"><strong style="color:var(--gold-light);font-weight:500">La pagina che cercavi non esiste o è stata spostata.</strong> Qui sotto trovi tutti gli interventi.</p>
    <?php endif; ?>
    <?php if ( 'campo' === $sez ) : ?>
    <p class="palco-intro">Le ricerche, le indagini e i progetti che Andrea Troisi ha guidato con Troisi Ricerche per istituzioni, enti pubblici e imprese: Camere di commercio, Regioni, aziende di trasporto e di servizi. Ogni progetto ha la sua pagina, con foto e racconto.</p>
    <p class="palco-intro"><a href="<?php echo esc_url( at_evento_url( '', 'palco' ) ); ?>" style="color:var(--gold-light)">Vai agli interventi: Sul palco, tra le idee &rarr;</a></p>
    <?php else : ?>
    <p class="palco-intro">Convegni, conferenze stampa e interventi pubblici di Andrea Troisi: dal Senato della Repubblica alla Camera dei Deputati, dai Forum della Pubblica Amministrazione agli incontri su dati, innovazione e intelligenza artificiale. Ogni intervento ha la sua pagina, con foto, racconto e rassegna.</p>
    <?php if ( at_eventi_ordinati( 'campo' ) ) : ?><p class="palco-intro"><a href="<?php echo esc_url( at_evento_url( '', 'campo' ) ); ?>" style="color:var(--gold-light)">Vai ai progetti con istituzioni e imprese: Sul campo, tra i progetti &rarr;</a></p><?php endif; ?>
    <?php endif; ?>
  </header>

  <?php if ( $tutti_tag ) : ?>
  <nav class="palco-filtro" id="argomenti" aria-label="Filtra per argomento">
    <a href="<?php echo esc_url( at_evento_url( '', $sez ) ); ?>#argomenti"<?php echo $tag_nome ? '' : ' aria-current="true"'; ?>>Tutti <small><?php echo count( at_eventi_ordinati( $sez ) ); ?></small></a>
    <?php foreach ( $tutti_tag as $t => $n ) : if ( $n < 2 || $n === count( at_eventi_ordinati( $sez ) ) ) { continue; } ?>
      <a href="<?php echo esc_url( at_tag_url( $t, $sez ) ); ?>"<?php echo $tag_nome === $t ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $t ); ?> <small><?php echo (int) $n; ?></small></a>
    <?php endforeach; ?>
  </nav>
  <?php if ( $tag_nome ) : ?><p class="palco-intro palco-filtro-nota">Argomento: <strong><?php echo esc_html( $tag_nome ); ?></strong> · <?php echo count( $eventi ); ?> pagine</p><?php endif; ?>
  <?php endif; ?>

  <?php foreach ( $anni as $anno => $lista ) : ?>
  <section class="palco-anno" aria-labelledby="anno-<?php echo esc_attr( $anno ); ?>">
    <h2 id="anno-<?php echo esc_attr( $anno ); ?>"><?php echo esc_html( $anno ); ?></h2>
    <div class="palco-griglia">
      <?php foreach ( $lista as $k => $e ) :
        $f = at_evento_foto( $e ); ?>
        <a class="palco-card" href="<?php echo esc_url( at_evento_url( $k ) ); ?>">
          <span class="palco-card-foto<?php echo $f ? '' : ' vuota'; ?>">
            <?php if ( $f ) : ?>
              <img src="<?php echo esc_url( at_img_url( $f['file'] ) ); ?>" alt="" loading="lazy" decoding="async"<?php echo at_img_attr( $f ); ?>>
            <?php else : ?>
              <span aria-hidden="true"><?php echo esc_html( $e['tema'] ); ?></span>
            <?php endif; ?>
          </span>
          <span class="palco-card-data"><?php echo esc_html( $e['data_label'] ); ?></span>
          <span class="palco-card-titolo"><?php echo esc_html( $e['titolo_breve'] ); ?></span>
          <?php if ( at_evento_dove( $e ) ) : ?><span class="palco-card-dove"><?php echo esc_html( at_evento_dove( $e ) ); ?></span><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endforeach; ?>

  <section class="palco-cta">
    <p>Sei interessato ad invitare Andrea come <span>relatore o ospite</span>?</p>
    <div><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" class="btn-primary">Prenota un incontro</a></div>
  </section>
</main>
<?php
get_template_part( 'parts/footer-site' );
get_footer();
