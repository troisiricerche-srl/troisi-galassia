<?php
/**
 * Voci aggiunte da WordPress alle sezioni «Sul palco, tra le idee» e «Sul campo, tra i progetti».
 *
 * Le voci storiche restano nel file dati del tema (sul-palco-dati.php). Le nuove si creano
 * come contenuti del tipo «Voce del sito» (at_voce), anche via REST dall'utente «redazione»,
 * senza reinstallare il tema. Ogni voce pubblicata compare con la stessa grafica, lo stesso
 * indirizzo /sul-palco/{chiave}/ (o /sul-campo/{chiave}/), nella home, nella sitemap e nei dati strutturati.
 *
 * Campi (meta, tutti testo):
 *   at_chiave   slug della pagina (minuscole, numeri, trattini); se vuoto si usa lo slug del contenuto
 *   at_data     AAAA-MM-GG
 *   at_sezione  palco | campo
 *   at_ruolo, at_luogo, at_citta, at_tema
 *   at_online   1 se l'evento era online
 *   at_tags     argomenti separati da virgola
 *   at_links    JSON [{ "url": "...", "etichetta": "..." }]
 *   at_gallery  id degli allegati separati da virgola (la foto di apertura è l'immagine in evidenza)
 *   at_pos      punto focale della foto di apertura, es. «50% 30%»
 *   at_fonte    URL del post LinkedIn da cui nasce la voce (serve a non duplicarla)
 * Testo: il contenuto (un paragrafo per blocco). Sintesi: il riassunto.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const AT_VOCE_META = array( 'at_chiave', 'at_data', 'at_sezione', 'at_ruolo', 'at_luogo', 'at_citta', 'at_tema', 'at_online', 'at_tags', 'at_links', 'at_gallery', 'at_pos', 'at_fonte', 'at_cover' );

add_action( 'init', function () {
	register_post_type( 'at_voce', array(
		'labels'          => array(
			'name'          => 'Palco e progetti',
			'singular_name' => 'Voce del sito',
			'add_new_item'  => 'Aggiungi voce (palco o progetto)',
			'edit_item'     => 'Modifica voce',
			'menu_name'     => 'Palco e progetti',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-microphone',
		'show_in_rest'    => true,
		'rest_base'       => 'voci-sito',
		'capability_type' => 'post',
		'map_meta_cap'    => true,
		'supports'        => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
	) );
	foreach ( AT_VOCE_META as $k ) {
		register_post_meta( 'at_voce', $k, array(
			'type'          => 'string',
			'single'        => true,
			'show_in_rest'  => true,
			'default'       => '',
			'auth_callback' => function () { return current_user_can( 'edit_posts' ); },
		) );
	}
} );

/** Ogni modifica a una voce svuota la cache delle voci. */
add_action( 'save_post_at_voce', function () { delete_transient( 'at_voci_db' ); } );
add_action( 'deleted_post', function () { delete_transient( 'at_voci_db' ); } );

function at_voce_img( $id, $didascalia, $pos = '' ) {
	$src = wp_get_attachment_image_src( $id, 'full' );
	if ( ! $src ) { return null; }
	$alt = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
	$cap = trim( (string) wp_get_attachment_caption( $id ) );
	return array(
		'tipo'       => 'img',
		'file'       => $src[0],
		'didascalia' => $cap ? $cap : ( $alt ? $alt : $didascalia ),
		'pos'        => $pos ? $pos : '50% 35%',
		'posh'       => $pos ? $pos : '50% 30%',
		'w'          => (string) $src[1],
		'h'          => (string) $src[2],
	);
}

function at_data_it( $ts ) {
	$mesi = array( '', 'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre' );
	return (int) gmdate( 'j', $ts ) . ' ' . $mesi[ (int) gmdate( 'n', $ts ) ] . ' ' . gmdate( 'Y', $ts );
}

/** Le voci pubblicate in WordPress, nello stesso formato del file dati. */
function at_eventi_db() {
	$c = get_transient( 'at_voci_db' );
	if ( is_array( $c ) ) { return $c; }
	$out = array();
	$q = get_posts( array( 'post_type' => 'at_voce', 'post_status' => 'publish', 'numberposts' => 300, 'orderby' => 'date', 'order' => 'DESC', 'suppress_filters' => false ) );
	foreach ( $q as $p ) {
		$m = array();
		foreach ( AT_VOCE_META as $k ) { $m[ $k ] = trim( (string) get_post_meta( $p->ID, $k, true ) ); }
		$chiave = sanitize_title( $m['at_chiave'] ? $m['at_chiave'] : $p->post_name );
		$data   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $m['at_data'] ) ? $m['at_data'] : get_the_date( 'Y-m-d', $p );
		if ( ! $chiave ) { continue; }
		$ts     = strtotime( $data . ' 12:00:00' );
		$titolo = html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' );
		$testo  = array();
		foreach ( preg_split( '~</p>|\n\s*\n~', (string) $p->post_content ) as $par ) {
			$par = trim( html_entity_decode( wp_strip_all_tags( $par ), ENT_QUOTES, 'UTF-8' ) );
			if ( '' !== $par ) { $testo[] = $par; }
		}
		$dove   = trim( implode( ', ', array_filter( array( $m['at_luogo'], $m['at_citta'] ) ) ) );
		$sintesi = trim( wp_strip_all_tags( $p->post_excerpt ) );
		if ( '' === $sintesi && $testo ) { $sintesi = wp_trim_words( $testo[0], 30, '…' ); }
		$media = array();
		$thumb = get_post_thumbnail_id( $p );
		if ( $thumb && ( $i = at_voce_img( $thumb, $titolo, $m['at_pos'] ) ) ) { $media[] = $i; }
		foreach ( array_filter( array_map( 'intval', explode( ',', $m['at_gallery'] ) ) ) as $gid ) {
			if ( $gid !== (int) $thumb && ( $i = at_voce_img( $gid, $titolo ) ) ) { $media[] = $i; }
		}
		$links = json_decode( $m['at_links'], true );
		if ( is_array( $links ) ) {
			foreach ( $links as $l ) {
				if ( empty( $l['url'] ) ) { continue; }
				$media[] = array( 'tipo' => 'link', 'url' => esc_url_raw( $l['url'] ), 'etichetta' => sanitize_text_field( isset( $l['etichetta'] ) ? $l['etichetta'] : $l['url'] ), 'icona' => false !== strpos( $l['url'], 'linkedin.' ) ? 'L' : 'N' );
			}
		}
		if ( $m['at_fonte'] && false === strpos( $m['at_links'], $m['at_fonte'] ) ) {
			$media[] = array( 'tipo' => 'link', 'url' => esc_url_raw( $m['at_fonte'] ), 'etichetta' => 'Il post di Andrea Troisi su LinkedIn', 'icona' => 'L' );
		}
		$out[ $chiave ] = array(
			'cover'        => '1' === $m['at_cover'],
			'titolo'       => $titolo,
			'titolo_breve' => $titolo,
			'data'         => $data,
			'data_label'   => at_data_it( $ts ),
			'luogo'        => $m['at_luogo'],
			'citta'        => $m['at_citta'],
			'online'       => '1' === $m['at_online'],
			'ruolo'        => $m['at_ruolo'] ? $m['at_ruolo'] : ( 'campo' === $m['at_sezione'] ? 'Progetto' : 'Relatore' ),
			'tema'         => $m['at_tema'],
			'sintesi'      => ( $dove ? $dove . ' · ' : '' ) . at_data_it( $ts ) . ' · ' . $sintesi,
			'testo'        => $testo,
			'media'        => $media,
			'sezione'      => 'campo' === $m['at_sezione'] ? 'campo' : 'palco',
			'tags'         => array_values( array_filter( array_map( 'trim', explode( ',', $m['at_tags'] ) ) ) ),
			'og'           => $thumb ? (string) wp_get_attachment_image_url( $thumb, 'large' ) : '',
			'fonte'        => $m['at_fonte'],
			'db_id'        => $p->ID,
		);
	}
	set_transient( 'at_voci_db', $out, DAY_IN_SECONDS );
	return $out;
}

/* ── REST per le attività automatiche ─────────────────── */

add_action( 'rest_api_init', function () {
	/* Elenco di tutte le voci (tema + WordPress): chiavi, date, titoli, fonti LinkedIn, argomenti in uso. Pubblico: sono dati già sul sito. */
	register_rest_route( 'at/v1', '/voci', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () {
			$voci = array();
			$tags = array();
			foreach ( at_eventi() as $k => $e ) {
				$li = array();
				foreach ( $e['media'] as $m ) {
					if ( 'link' === $m['tipo'] && preg_match( '~linkedin\.com/.*?(\d{19})~', $m['url'], $x ) ) { $li[] = $x[1]; }
				}
				if ( ! empty( $e['fonte'] ) && preg_match( '~(\d{19})~', $e['fonte'], $x ) ) { $li[] = $x[1]; }
				foreach ( at_evento_tags( $e ) as $t ) { $tags[ $t ] = true; }
				$voci[] = array( 'chiave' => $k, 'sezione' => at_evento_sezione( $e ), 'data' => $e['data'], 'titolo' => $e['titolo'], 'url' => at_evento_url( $k ), 'linkedin' => array_values( array_unique( $li ) ), 'origine' => isset( $e['db_id'] ) ? 'wordpress' : 'tema' );
			}
			ksort( $tags );
			return array( 'voci' => $voci, 'argomenti' => array_keys( $tags ) );
		},
	) );

	/* Scarica sul server un'immagine (solo da LinkedIn) e la aggiunge ai Media. Solo per chi può caricare file. */
	register_rest_route( 'at/v1', '/sideload', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'upload_files' ); },
		'args'                => array( 'url' => array( 'required' => true ), 'alt' => array( 'required' => false ), 'nome' => array( 'required' => false ) ),
		'callback'            => function ( WP_REST_Request $r ) {
			$url  = esc_url_raw( $r['url'] );
			$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
			if ( ! preg_match( '~(^|\.)licdn\.com$~', $host ) ) {
				return new WP_Error( 'at_host', 'Sono ammesse solo immagini di LinkedIn (licdn.com).', array( 'status' => 400 ) );
			}
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$tmp = download_url( $url, 30 );
			if ( is_wp_error( $tmp ) ) { return $tmp; }
			$tipo = wp_get_image_mime( $tmp );
			$ext  = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp' );
			if ( ! isset( $ext[ $tipo ] ) ) { @unlink( $tmp ); return new WP_Error( 'at_tipo', 'Il file non è un\'immagine JPEG, PNG o WebP.', array( 'status' => 400 ) ); }
			$nome = sanitize_file_name( ( $r['nome'] ? $r['nome'] : 'linkedin-' . time() ) . '.' . $ext[ $tipo ] );
			$id   = media_handle_sideload( array( 'name' => $nome, 'tmp_name' => $tmp ), 0, $r['alt'] ? sanitize_text_field( $r['alt'] ) : null );
			if ( is_wp_error( $id ) ) { @unlink( $tmp ); return $id; }
			if ( $r['alt'] ) { update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $r['alt'] ) ); }
			$src = wp_get_attachment_image_src( $id, 'full' );
			return array( 'id' => $id, 'url' => $src[0], 'w' => $src[1], 'h' => $src[2] );
		},
	) );
} );


/* ═══════════════════════════════════════════════════════════════
 * Pannello «Foto e collegamento» nella schermata di modifica di una voce:
 * permette di aggiungere foto a una voce già presente sul sito (anche a quelle
 * scritte nel tema) senza ricaricare il tema.
 * ═══════════════════════════════════════════════════════════════ */
add_action( 'add_meta_boxes_at_voce', function () {
	add_meta_box( 'at_voce_foto', 'Foto e collegamento alla voce', 'at_voce_foto_box', 'at_voce', 'normal', 'high' );
} );

function at_voce_foto_box( $post ) {
	wp_nonce_field( 'at_voce_foto', 'at_voce_foto_nonce' );
	wp_enqueue_media();
	$chiave  = (string) get_post_meta( $post->ID, 'at_chiave', true );
	$gallery = (string) get_post_meta( $post->ID, 'at_gallery', true );
	$cover   = '1' === (string) get_post_meta( $post->ID, 'at_cover', true );
	$base    = function_exists( 'at_eventi_base' ) ? at_eventi_base() : array();
	uasort( $base, function ( $a, $b ) { return strcmp( $b['data'], $a['data'] ); } );
	?>
	<p><label for="at_chiave_sel"><strong>Voce del sito a cui aggiungere le foto</strong></label><br>
	<select id="at_chiave_sel" name="at_chiave_sel" style="width:100%;max-width:720px">
		<option value="">— Nessuna: è una voce nuova (usa il titolo e il testo qui sopra) —</option>
		<?php foreach ( $base as $k => $e ) : ?>
			<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $chiave, $k ); ?>><?php echo esc_html( $e['data_label'] . ' — ' . ( ! empty( $e['titolo_breve'] ) ? $e['titolo_breve'] : $e['titolo'] ) ); ?></option>
		<?php endforeach; ?>
	</select></p>
	<p class="description">Se scegli una voce già presente, le foto qui sotto si aggiungono a quella pagina (il titolo e il testo di questa scheda servono solo a riconoscerla nell'elenco).</p>
	<p><strong>Foto</strong> <button type="button" class="button" id="at_gallery_btn">Scegli o carica foto</button> <button type="button" class="button-link" id="at_gallery_clear">svuota</button></p>
	<input type="hidden" id="at_gallery_ids" name="at_gallery_ids" value="<?php echo esc_attr( $gallery ); ?>">
	<div id="at_gallery_prev" style="display:flex;flex-wrap:wrap;gap:8px">
		<?php foreach ( array_filter( array_map( 'intval', explode( ',', $gallery ) ) ) as $id ) { echo wp_get_attachment_image( $id, array( 110, 110 ) ); } ?>
	</div>
	<p class="description">La didascalia di ogni foto è quella scritta nel campo «Didascalia» della libreria media. Puoi riordinare le foto trascinandole nella finestra di selezione.</p>
	<p><label><input type="checkbox" name="at_cover" value="1" <?php checked( $cover ); ?>> Usa la prima foto come <strong>foto principale</strong> della voce (altrimenti le foto si aggiungono in fondo alla galleria)</label></p>
	<script>
	jQuery(function($){
		var frame;
		$('#at_gallery_btn').on('click',function(e){
			e.preventDefault();
			var ids=$('#at_gallery_ids').val();
			frame=wp.media({title:'Foto della voce',button:{text:'Usa queste foto'},multiple:'add',library:{type:'image'}});
			frame.on('open',function(){var sel=frame.state().get('selection');(ids?ids.split(','):[]).forEach(function(id){var a=wp.media.attachment(id);a.fetch();sel.add(a);});});
			frame.on('select',function(){
				var sel=frame.state().get('selection').toJSON(),out=[],html='';
				sel.forEach(function(a){out.push(a.id);var u=(a.sizes&&a.sizes.thumbnail)?a.sizes.thumbnail.url:a.url;html+='<img src="'+u+'" style="width:110px;height:110px;object-fit:cover">';});
				$('#at_gallery_ids').val(out.join(','));$('#at_gallery_prev').html(html);
			});
			frame.open();
		});
		$('#at_gallery_clear').on('click',function(e){e.preventDefault();$('#at_gallery_ids').val('');$('#at_gallery_prev').empty();});
	});
	</script>
	<?php
}

add_action( 'save_post_at_voce', function ( $post_id ) {
	if ( ! isset( $_POST['at_voce_foto_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['at_voce_foto_nonce'] ) ), 'at_voce_foto' ) ) { return; }
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
	$sel = isset( $_POST['at_chiave_sel'] ) ? sanitize_title( wp_unslash( $_POST['at_chiave_sel'] ) ) : '';
	if ( '' !== $sel ) { update_post_meta( $post_id, 'at_chiave', $sel ); }
	$ids = isset( $_POST['at_gallery_ids'] ) ? implode( ',', array_filter( array_map( 'intval', explode( ',', wp_unslash( $_POST['at_gallery_ids'] ) ) ) ) ) : '';
	update_post_meta( $post_id, 'at_gallery', $ids );
	update_post_meta( $post_id, 'at_cover', empty( $_POST['at_cover'] ) ? '' : '1' );
	delete_transient( 'at_voci_db' );
}, 20 );

/** Cambiando la didascalia di una foto si aggiorna anche il sito. */
add_action( 'edit_attachment', function () { delete_transient( 'at_voci_db' ); } );
