<?php
/**
 * Sul palco, tra le idee — una pagina per ogni intervento.
 *
 * /sul-palco/            indice di tutti gli interventi
 * /sul-palco/{chiave}/   pagina del singolo intervento
 *
 * Le pagine sono generate dal tema (nessuna pagina da creare in WordPress):
 * regole di riscrittura, titolo, meta description, Open Graph, canonical,
 * dati strutturati (Event, BreadcrumbList) e voce nella sitemap di WordPress.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once __DIR__ . '/sul-palco-dati.php';
require_once __DIR__ . '/voci-db.php';

/** Tutte le voci: quelle storiche del tema più quelle pubblicate in WordPress. Una voce WordPress con la stessa chiave di una voce del tema aggiunge le sue foto a quella voce. */
function at_eventi() {
	static $tutte = null;
	if ( null === $tutte ) {
		$tutte = at_eventi_base();
		if ( did_action( 'init' ) ) {
			foreach ( at_eventi_db() as $k => $e ) {
				if ( ! isset( $tutte[ $k ] ) ) { $tutte[ $k ] = $e; continue; }
				// Voce già presente nel tema: si aggiungono solo le foto scelte in WordPress.
				$nuove = array_values( array_filter( $e['media'], function ( $m ) { return 'img' === $m['tipo']; } ) );
				if ( ! $nuove ) { continue; }
				$vecchie = $tutte[ $k ]['media'];
				$img = array_values( array_filter( $vecchie, function ( $m ) { return 'img' === $m['tipo']; } ) );
				$alt = array_values( array_filter( $vecchie, function ( $m ) { return 'img' !== $m['tipo']; } ) );
				$tutte[ $k ]['media'] = ! empty( $e['cover'] ) ? array_merge( $nuove, $img, $alt ) : array_merge( $img, $nuove, $alt );
				if ( ! empty( $e['cover'] ) && ! empty( $e['og'] ) ) { $tutte[ $k ]['og'] = $e['og']; }
			}
		} else {
			$base = $tutte;
			$tutte = null;
			return $base;
		}
	}
	return $tutte;
}

define( 'AT_PALCO_BASE', 'sul-palco' );
define( 'AT_CAMPO_BASE', 'sul-campo' );

/**
 * Le due sezioni dell'archivio: gli interventi (palco) e i progetti con istituzioni e clienti (campo).
 */
function at_sezioni() {
	return array(
		'palco' => array(
			'base'   => AT_PALCO_BASE,
			'titolo' => 'Sul palco, tra le idee',
			'voce'   => 'intervento',
			'voci'   => 'Tutti gli interventi',
			'desc'   => 'Convegni, conferenze stampa e interventi pubblici di Andrea Troisi: dal Senato della Repubblica alla Camera dei Deputati, dai Forum della PA agli eventi su dati, innovazione e intelligenza artificiale.',
		),
		'campo' => array(
			'base'   => AT_CAMPO_BASE,
			'titolo' => 'Sul campo, tra i progetti',
			'voce'   => 'progetto',
			'voci'   => 'Tutti i progetti',
			'desc'   => 'Ricerche, indagini e progetti di Andrea Troisi e di Troisi Ricerche con istituzioni, enti pubblici e imprese: dalle Camere di commercio alle Regioni, dal trasporto pubblico ai servizi idrici.',
		),
	);
}

function at_evento_sezione( $ev ) {
	return ( is_array( $ev ) && ! empty( $ev['sezione'] ) && 'campo' === $ev['sezione'] ) ? 'campo' : 'palco';
}

/** Sezione della richiesta corrente ('palco' o 'campo'). */
function at_sezione_richiesta() {
	return 'campo' === get_query_var( 'at_sez' ) ? 'campo' : 'palco';
}

function at_sezione( $sez ) {
	$s = at_sezioni();
	return isset( $s[ $sez ] ) ? $s[ $sez ] : $s['palco'];
}

/* ── Utilità ─────────────────────────────────────────── */

function at_evento( $chiave ) {
	$e = at_eventi();
	return isset( $e[ $chiave ] ) ? $e[ $chiave ] : null;
}

/** Voci di una sezione in ordine cronologico inverso (le più recenti prima). */
function at_eventi_ordinati( $sez = 'palco' ) {
	$e = array_filter( at_eventi(), function ( $x ) use ( $sez ) {
		return at_evento_sezione( $x ) === $sez;
	} );
	uksort( $e, function ( $a, $b ) use ( $e ) {
		return strcmp( $e[ $b ]['data'], $e[ $a ]['data'] );
	} );
	return $e;
}

function at_evento_url( $chiave = '', $sez = 'palco' ) {
	if ( $chiave ) {
		$sez = at_evento_sezione( at_evento( $chiave ) );
	}
	return home_url( '/' . at_sezione( $sez )['base'] . '/' . ( $chiave ? $chiave . '/' : '' ) );
}

function at_img_url( $file ) {
	if ( preg_match( '~^https?://~', $file ) ) { return $file; }
	return get_template_directory_uri() . '/img/' . implode( '/', array_map( 'rawurlencode', explode( '/', $file ) ) );
}

/**
 * Attributi per le foto: dimensioni reali e punto focale (i volti restano nel riquadro).
 * $hero = true usa il punto focale calcolato per l'apertura larga, con variabile per il mobile.
 */
function at_img_attr( $m, $hero = false ) {
	$out = '';
	if ( ! empty( $m['w'] ) && ! empty( $m['h'] ) ) {
		$out .= ' width="' . (int) $m['w'] . '" height="' . (int) $m['h'] . '"';
	}
	$pos  = ! empty( $m['pos'] ) ? $m['pos'] : '50% 40%';
	$posh = ! empty( $m['posh'] ) ? $m['posh'] : $pos;
	$css  = $hero ? '--pos:' . $pos . ';--posh:' . $posh : 'object-position:' . $pos;
	return $out . ' style="' . esc_attr( $css ) . '"';
}

function at_img_esiste( $file ) {
	return preg_match( '~^https?://~', $file ) || file_exists( get_template_directory() . '/img/' . $file );
}

/** Prima immagine dell'intervento (foto di apertura) o stringa vuota. */
function at_evento_foto( $ev ) {
	foreach ( $ev['media'] as $m ) {
		if ( 'img' === $m['tipo'] && at_img_esiste( $m['file'] ) ) {
			return $m;
		}
	}
	return null;
}

function at_evento_immagini( $ev ) {
	return array_values( array_filter( $ev['media'], function ( $m ) {
		return 'img' === $m['tipo'] && at_img_esiste( $m['file'] );
	} ) );
}

function at_evento_link( $ev ) {
	return array_values( array_filter( $ev['media'], function ( $m ) {
		return 'link' === $m['tipo'];
	} ) );
}

/** Luogo leggibile: «Palazzo Madama · Roma». */
/* Argomenti (tag) degli interventi: slug, url filtrato, argomento richiesto. */
function at_tag_slug( $t ) {
	return sanitize_title( remove_accents( $t ) );
}
function at_evento_tags( $ev ) {
	return isset( $ev['tags'] ) && is_array( $ev['tags'] ) ? $ev['tags'] : array();
}
function at_tag_url( $t, $sez = 'palco' ) {
	return add_query_arg( 'argomento', at_tag_slug( $t ), at_evento_url( '', $sez ) ) . '#argomenti';
}
function at_tag_richiesto() {
	return isset( $_GET['argomento'] ) ? sanitize_title( wp_unslash( $_GET['argomento'] ) ) : '';
}
/* Tutti gli argomenti di una sezione, con il numero di pagine, dal più frequente. */
function at_tags_sezione( $sez ) {
	$c = array();
	foreach ( at_eventi_ordinati( $sez ) as $e ) {
		foreach ( at_evento_tags( $e ) as $t ) {
			$c[ $t ] = isset( $c[ $t ] ) ? $c[ $t ] + 1 : 1;
		}
	}
	arsort( $c );
	return $c;
}

function at_evento_dove( $ev ) {
	return implode( ' · ', array_filter( array( $ev['luogo'], $ev['citta'] ) ) );
}

/** Estratto per meta description (max ~155 caratteri, a fine parola). */
function at_estratto( $testo, $max = 155 ) {
	$testo = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $testo ) ) );
	if ( mb_strlen( $testo ) <= $max ) { return $testo; }
	$t = mb_substr( $testo, 0, $max );
	$t = mb_substr( $t, 0, mb_strrpos( $t, ' ' ) );
	return rtrim( $t, ' ,;:.·—-' ) . '…';
}

/** Id YouTube da un URL, per mostrare l'anteprima senza incorporare il player. */
function at_youtube_id( $url ) {
	if ( preg_match( '~(?:youtube\.com/watch\?v=|youtu\.be/)([A-Za-z0-9_-]{11})~', $url, $m ) ) {
		return $m[1];
	}
	return '';
}

/* ── Contesto della richiesta ────────────────────────── */

/** '' se non siamo in /sul-palco/, '__indice' per l'indice, altrimenti la chiave. */
function at_palco_richiesta() {
	$v = get_query_var( 'at_palco' );
	return is_string( $v ) ? $v : '';
}

function at_is_palco() {
	return '' !== at_palco_richiesta();
}

/* ── Riscrittura degli indirizzi ─────────────────────── */

function at_palco_rewrite() {
	add_rewrite_rule( '^' . AT_PALCO_BASE . '/?$', 'index.php?at_palco=__indice', 'top' );
	add_rewrite_rule( '^' . AT_PALCO_BASE . '/([a-z0-9-]+)/?$', 'index.php?at_palco=$matches[1]', 'top' );
	add_rewrite_rule( '^' . AT_CAMPO_BASE . '/?$', 'index.php?at_palco=__indice&at_sez=campo', 'top' );
	add_rewrite_rule( '^' . AT_CAMPO_BASE . '/([a-z0-9-]+)/?$', 'index.php?at_palco=$matches[1]&at_sez=campo', 'top' );
}
add_action( 'init', 'at_palco_rewrite' );

add_filter( 'query_vars', function ( $v ) {
	$v[] = 'at_palco';
	$v[] = 'at_sez';
	return $v;
} );

/* Le regole vanno registrate una volta dopo l'installazione o l'aggiornamento del tema. */
function at_palco_flush_se_serve() {
	$ver = wp_get_theme( get_template() )->get( 'Version' );
	if ( get_option( 'at_palco_rewrite_ver' ) !== $ver ) {
		at_palco_rewrite();
		flush_rewrite_rules( false );
		update_option( 'at_palco_rewrite_ver', $ver, true );
	}
}
add_action( 'init', 'at_palco_flush_se_serve', 99 );
add_action( 'after_switch_theme', function () {
	delete_option( 'at_palco_rewrite_ver' );
} );

/* La richiesta non è la home del blog: stato corretto e 404 per chiavi inesistenti. */
add_action( 'parse_query', function ( $q ) {
	if ( ! $q->is_main_query() || '' === (string) $q->get( 'at_palco' ) ) { return; }
	$q->is_home       = false;
	$q->is_front_page = false;
	$q->is_page       = false;
	$q->is_singular   = false;
	$q->is_archive    = false;
	$chiave = $q->get( 'at_palco' );
	$sez    = 'campo' === $q->get( 'at_sez' ) ? 'campo' : 'palco';
	if ( '__indice' !== $chiave && ( ! at_evento( $chiave ) || at_evento_sezione( at_evento( $chiave ) ) !== $sez ) ) {
		$q->set_404();
	}
} );

/* Non interrogare il database per i post: la pagina è generata dal tema. */
add_filter( 'posts_pre_query', function ( $posts, $q ) {
	if ( $q->is_main_query() && '' !== (string) $q->get( 'at_palco' ) ) {
		$q->found_posts   = 0;
		$q->max_num_pages = 0;
		return array();
	}
	return $posts;
}, 10, 2 );

/* Nessun post trovato è normale qui: WordPress non deve trasformarlo in 404. */
add_filter( 'pre_handle_404', function ( $gestito, $q ) {
	if ( $q->is_main_query() && '' !== (string) $q->get( 'at_palco' ) && ! $q->is_404() ) {
		return true;
	}
	return $gestito;
}, 10, 2 );

add_filter( 'template_include', function ( $t ) {
	if ( ! at_is_palco() ) { return $t; }
	if ( is_404() ) {
		/* Intervento inesistente: stato 404, ma si mostra l'indice per non lasciare il visitatore a mani vuote. */
		status_header( 404 );
		nocache_headers();
		$GLOBALS['at_palco_404'] = true;
		return get_template_directory() . '/templates/sul-palco.php';
	}
	status_header( 200 );
	$f = '__indice' === at_palco_richiesta() ? 'templates/sul-palco.php' : 'templates/evento.php';
	return get_template_directory() . '/' . $f;
}, 99 );

/* Senza barra finale → con barra finale. */
add_action( 'template_redirect', function () {
	if ( ! at_is_palco() || is_404() ) { return; }
	$path = wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );
	if ( $path && '/' !== substr( $path, -1 ) ) {
		wp_safe_redirect( home_url( $path . '/' ), 301 );
		exit;
	}
} );

/* ── Titolo, meta, Open Graph, dati strutturati ──────── */

add_filter( 'pre_get_document_title', function ( $title ) {
	if ( ! at_is_palco() ) { return $title; }
	if ( is_404() ) { return 'Pagina non trovata | Andrea Troisi'; }
	if ( '__indice' === at_palco_richiesta() ) {
		return 'campo' === at_sezione_richiesta()
			? 'Sul campo, tra i progetti: ricerche con istituzioni e imprese | Andrea Troisi'
			: 'Sul palco, tra le idee: interventi e convegni | Andrea Troisi';
	}
	$ev = at_evento( at_palco_richiesta() );
	return $ev['titolo_breve'] . ' (' . $ev['data_label'] . ') | Andrea Troisi';
}, 30 );

function at_palco_head() {
	if ( ! at_is_palco() ) { return; }
	if ( is_404() ) {
		echo "\n<meta name=\"robots\" content=\"noindex\">\n";
		return;
	}
	$indice = '__indice' === at_palco_richiesta();
	$home   = home_url( '/' );
	$person = array( '@id' => 'https://andreatroisi.it/#person' );

	if ( $indice ) {
		$sez   = at_sezione_richiesta();
		$S     = at_sezione( $sez );
		$url   = at_evento_url( '', $sez );
		$title = $S['titolo'] . ( 'campo' === $sez ? ': ricerche e progetti di Andrea Troisi' : ': interventi e convegni di Andrea Troisi' );
		$desc  = $S['desc'];
		$img   = get_template_directory_uri() . '/img/andrea-troisi-hero.jpg';
		$lista = array();
		$i     = 1;
		foreach ( at_eventi_ordinati( $sez ) as $k => $e ) {
			$lista[] = array( '@type' => 'ListItem', 'position' => $i++, 'url' => at_evento_url( $k ), 'name' => $e['titolo_breve'] );
		}
		$graph = array(
			array( '@type' => 'CollectionPage', '@id' => $url, 'url' => $url, 'name' => $title, 'description' => $desc, 'inLanguage' => 'it-IT', 'about' => $person,
				'mainEntity' => array( '@type' => 'ItemList', 'itemListElement' => $lista ) ),
			array( '@type' => 'BreadcrumbList', 'itemListElement' => array(
				array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Andrea Troisi', 'item' => $home ),
				array( '@type' => 'ListItem', 'position' => 2, 'name' => $S['titolo'], 'item' => $url ),
			) ),
		);
	} else {
		$k     = at_palco_richiesta();
		$ev    = at_evento( $k );
		$sez   = at_evento_sezione( $ev );
		$S     = at_sezione( $sez );
		$url   = at_evento_url( $k );
		$title = $ev['titolo_breve'];
		$desc  = at_estratto( implode( ' ', $ev['testo'] ) );
		$foto  = at_evento_foto( $ev );
		$img   = ! empty( $ev['og'] ) ? at_img_url( $ev['og'] ) : ( $foto ? at_img_url( $foto['file'] ) : get_template_directory_uri() . '/img/andrea-troisi-hero.jpg' );
		$imgs  = array_map( function ( $m ) { return at_img_url( $m['file'] ); }, at_evento_immagini( $ev ) );

		if ( ! empty( $ev['online'] ) ) {
			$location = array( '@type' => 'VirtualLocation', 'name' => $ev['luogo'] );
			$mode     = 'https://schema.org/OnlineEventAttendanceMode';
		} else {
			$location = array( '@type' => 'Place', 'name' => at_evento_dove( $ev ) ?: $ev['citta'],
				'address' => array( '@type' => 'PostalAddress', 'addressLocality' => $ev['citta'], 'addressCountry' => 'IT' ) );
			$mode     = 'https://schema.org/OfflineEventAttendanceMode';
		}
		$event = array(
			'@type'               => 'Event',
			'@id'                 => $url . '#evento',
			'name'                => $ev['titolo'],
			'description'         => implode( ' ', $ev['testo'] ),
			'startDate'           => $ev['data'],
			'eventStatus'         => 'https://schema.org/EventScheduled',
			'eventAttendanceMode' => $mode,
			'location'            => $location,
			'performer'           => $person,
			'url'                 => $url,
			'inLanguage'          => 'it-IT',
		);
		if ( at_evento_tags( $ev ) ) { $event['keywords'] = implode( ', ', at_evento_tags( $ev ) ); }
		if ( $imgs ) { $event['image'] = $imgs; }
		$pagina = array( '@type' => 'WebPage', '@id' => $url, 'url' => $url, 'name' => $title, 'description' => $desc, 'inLanguage' => 'it-IT',
			'primaryImageOfPage' => $img, 'isPartOf' => array( '@id' => at_evento_url( '', $sez ) ) );
		if ( at_evento_tags( $ev ) ) { $pagina['keywords'] = implode( ', ', at_evento_tags( $ev ) ); }
		if ( 'palco' === $sez ) {
			$pagina['about'] = array( '@id' => $url . '#evento' );
		} else {
			$pagina['about'] = $person;
			if ( ! empty( $ev['data'] ) ) { $pagina['datePublished'] = $ev['data']; }
		}
		$graph = array( $pagina );
		if ( 'palco' === $sez ) { $graph[] = $event; }
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Andrea Troisi', 'item' => $home ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => $S['titolo'], 'item' => at_evento_url( '', $sez ) ),
			array( '@type' => 'ListItem', 'position' => 3, 'name' => $title, 'item' => $url ),
		) );
	}

	echo "\n<meta name=\"description\" content=\"" . esc_attr( $desc ) . "\">\n";
	echo '<link rel="canonical" href="' . esc_url( $url ) . "\">\n";
	echo '<meta property="og:type" content="' . ( $indice ? 'website' : 'article' ) . "\">\n";
	echo "<meta property=\"og:locale\" content=\"it_IT\">\n<meta property=\"og:site_name\" content=\"Andrea Troisi\">\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . "\">\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . "\">\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . "\">\n";
	echo '<meta property="og:image" content="' . esc_url( $img ) . "\">\n";
	echo "<meta name=\"twitter:card\" content=\"summary_large_image\">\n";
	if ( ! $indice && ! empty( $ev ) ) {
		foreach ( at_evento_tags( $ev ) as $t ) { echo '<meta property="article:tag" content="' . esc_attr( $t ) . "\">\n"; }
	}
	if ( $indice && at_tag_richiesto() ) { echo "<meta name=\"robots\" content=\"noindex, follow\">\n"; }
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
}
add_action( 'at_head_meta', 'at_palco_head' );

/* ── Sitemap di WordPress (wp-sitemap.xml) ───────────── */

add_action( 'init', function () {
	if ( ! function_exists( 'wp_register_sitemap_provider' ) || ! class_exists( 'WP_Sitemaps_Provider' ) ) { return; }
	if ( ! class_exists( 'AT_Palco_Sitemap' ) ) {
		class AT_Palco_Sitemap extends WP_Sitemaps_Provider {
			public function __construct() {
				$this->name        = 'sulpalco';
				$this->object_type = 'sulpalco';
			}
			public function get_url_list( $page_num, $object_subtype = '' ) {
				$urls = array();
				foreach ( array( 'palco', 'campo' ) as $sez ) {
					$voci = at_eventi_ordinati( $sez );
					if ( ! $voci ) { continue; }
					$urls[] = array( 'loc' => at_evento_url( '', $sez ) );
					foreach ( $voci as $k => $e ) {
						$urls[] = array( 'loc' => at_evento_url( $k ) );
					}
				}
				return $urls;
			}
			public function get_max_num_pages( $object_subtype = '' ) {
				return 1;
			}
		}
	}
	wp_register_sitemap_provider( 'sulpalco', new AT_Palco_Sitemap() );
}, 20 );
