<?php
/**
 * Articoli — raccolta automatica degli articoli di Andrea Troisi e della redazione
 * pubblicati su Radio Notizie e sulle piattaforme di Troisi Ricerche.
 *
 * Come funziona
 * - Ogni 3 ore WP-Cron interroga l'API REST di WordPress di ciascun sito
 *   (/wp-json/wp/v2/posts) e salva l'elenco nell'opzione «at_articoli_dati».
 * - Se un sito non risponde si tengono gli ultimi articoli letti da quel sito.
 * - Le pagine non aspettano mai i siti esterni: leggono solo la copia salvata.
 * - Gli articoli senza immagine ricevono una copertina generata dal tema (SVG).
 * - Pagina completa: https://andreatroisi.it/articoli/ (filtri per sito e argomento).
 * - Strumenti → Articoli: stato di ogni fonte e pulsante «Aggiorna ora».
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'AT_ARTICOLI_BASE', 'articoli' );
define( 'AT_ARTICOLI_PER_PAGINA', 24 );

/* ── Fonti ───────────────────────────────────────────── */

function at_articoli_fonti() {
	$f = array(
		'radionotizie'        => array( 'Radio Notizie', 'https://www.radionotizie.eu', array( 'author' => 4 ), '#9e2a2b', true ),
		'troisiricerche'      => array( 'Troisi Ricerche', 'https://www.troisiricerche.net', array(), '#2c4a6e', false ),
		'ildatoetratto'       => array( 'Il dato è tratto', 'https://www.ildatoetratto.it', array(), '#b8963e', false ),
		'mappatura'           => array( 'Mappatura delle Competenze', 'https://www.mappaturadellecompetenze.it', array(), '#1f6f68', false ),
		'customerpa'          => array( 'CustomerPA', 'https://www.customerpa.it', array(), '#355c9a', false ),
		'benessere'           => array( 'Benessere Organizzativo', 'https://www.benessereorganizzativo.it', array(), '#5b8c51', false ),
		'troisiinsight'       => array( 'TroisiInsight', 'https://www.troisiinsight.it', array(), '#6a4c93', false ),
		'digitalizzazionepa'  => array( 'Digitalizzazione nella PA', 'https://www.digitalizzazionenellapa.it', array(), '#1d6fa3', false ),
		'dibattitopubblico'   => array( 'Dibattito Pubblico', 'https://www.dibattito-pubblico.it', array(), '#a4502a', false ),
		'governance'          => array( 'Governance Finanziaria', 'https://www.governancefinanziaria.it', array(), '#3d4f63', false ),
		'internazionalizzazione' => array( 'Consulenza Internazionalizzazione', 'https://www.consulenzainternazionalizzazione.it', array(), '#0f7a8a', false ),
		'benesseregiovani'    => array( 'Benessere Digitale Giovani', 'https://www.benesseredigitalegiovani.it', array(), '#c0633f', false ),
		'tindex'              => array( 'TR-Index', 'https://www.t-index.it', array(), '#2f5d50', false ),
		'registro'            => array( 'Registro delle Competenze', 'https://www.registrodellecompetenze.it', array(), '#44607a', false ),
		'formazione'          => array( 'Troisi Formazione', 'https://www.troisiformazione.it', array(), '#7a5c2e', false ),
		'svegliadigitale'     => array( 'Sveglia Digitale', 'https://www.svegliadigitale.it', array(), '#b0472f', false ),
		'voiceinhub'          => array( 'VoiceInHub', 'https://www.voiceinhub.it', array(), '#4b3f72', false ),
		'osservatorio'        => array( "Osservatorio sull'Innovazione del Mezzogiorno", 'https://www.osservatoriomezzogiorno.net', array(), '#274060', false ),
	);
	$out = array();
	foreach ( $f as $k => $v ) {
		$out[ $k ] = array( 'nome' => $v[0], 'url' => $v[1], 'param' => $v[2], 'colore' => $v[3], 'immagini_nel_testo' => $v[4] );
	}
	/** Filtro per aggiungere o togliere siti senza modificare il tema. */
	return apply_filters( 'at_articoli_fonti', $out );
}

/* Titoli che WordPress crea da solo all'installazione: non sono articoli. */
function at_articolo_da_escludere( $titolo, $slug ) {
	$t = strtolower( trim( $titolo ) );
	return in_array( $t, array( 'ciao mondo!', 'hello world!', 'ciao mondo', 'hello world' ), true )
		|| in_array( $slug, array( 'ciao-mondo', 'hello-world' ), true );
}

/* ── Argomenti (stesso vocabolario delle pagine Sul palco / Sul campo) ── */

function at_argomenti_vocabolario() {
	return array(
		'Intelligenza artificiale'   => '/intelligenza artificiale|(?-i:\bIA\b|\bAI\b)|chatgpt|algoritm/i',
		'Statistica'                 => '/statistic|(?-i:\bSIS\b)|istat\b|campione|indicator/i',
		'Customer satisfaction'      => '/customer satisfaction|soddisfazione|qualità percepita/i',
		'Trasporto pubblico'         => '/trasport|(?-i:\bTPL\b)|autobus|mobilità|bigliettazione/i',
		'Formazione continua'        => '/formazione|fondimpresa|fondirigenti|fondi interprofessionali|competenze/i',
		'Pubblica Amministrazione'   => '/pubblica amministrazione|(?-i:\bPA\b)|comuni\b|ministero|regione|enti pubblici|partecipat/i',
		'Innovazione'                => '/innovazion|digital|smart city|tecnolog/i',
		'Turismo'                    => '/turism|alberghi|destinazion/i',
		'Sostenibilità'              => '/sostenibil|circolare|ambient|clima\b|energi/i',
		'Benessere organizzativo'    => '/benessere|clima aziendale|stress|burnout/i',
		'Internazionalizzazione'     => '/internazionalizz|export|dazi|mercati esteri|commercio estero/i',
		'Fondi europei e PNRR'       => '/fondi europei|(?-i:PNRR)|finanziament|bando|bandi\b/i',
		'Giovani'                    => '/giovan|student|universit|scuol/i',
		'Lavoro'                     => '/mercato del lavoro|occupazion|\blavoro\b|salari|dipendent/i',
		'Economia'                   => '/economi|(?-i:PIL)|inflazion|credito|banca|banche|bankitalia|impres/i',
		'Mezzogiorno e Puglia'       => '/mezzogiorno|puglia|pugliese|\bbari\b|taranto|\bsud\b/i',
		'Governance e finanza'       => '/governance|finanza|bilanci|rischio/i',
		'Partecipazione e dibattito pubblico' => '/dibattito pubblico|partecipazion|consultazion|opinione pubblica|sondagg/i',
		'Sanità'                     => '/sanit|medic|ospedal|salute/i',
	);
}

function at_argomenti_da_testo( $testo, $max = 3 ) {
	$c = array();
	foreach ( at_argomenti_vocabolario() as $tag => $rx ) {
		$n = preg_match_all( $rx, $testo );
		if ( $n ) { $c[ $tag ] = $n; }
	}
	arsort( $c );
	return array_slice( array_keys( $c ), 0, $max );
}

/* ── Lettura dei siti (solo da WP-Cron o dal pulsante in Strumenti) ── */

function at_articoli_leggi_fonte( $chiave, $f ) {
	$items  = array();
	$pagine = 1;
	for ( $p = 1; $p <= $pagine && $p <= 6; $p++ ) {
		$campi = 'id,date,link,slug,title,excerpt,featured_media,_links,_embedded' . ( $f['immagini_nel_testo'] ? ',content' : '' );
		$url   = add_query_arg( array_merge( $f['param'], array(
			'per_page' => 100,
			'page'     => $p,
			'_embed'   => 'wp:featuredmedia',
			'_fields'  => $campi,
		) ), trailingslashit( $f['url'] ) . 'wp-json/wp/v2/posts' );
		$r = wp_remote_get( $url, array( 'timeout' => 15, 'redirection' => 3, 'user-agent' => 'andreatroisi.it/articoli; ' . home_url( '/' ) ) );
		if ( is_wp_error( $r ) ) { return $p > 1 ? $items : $r; }
		$code = wp_remote_retrieve_response_code( $r );
		if ( 200 !== (int) $code ) { return $p > 1 ? $items : new WP_Error( 'at_http', 'HTTP ' . $code ); }
		$pagine = max( 1, (int) wp_remote_retrieve_header( $r, 'x-wp-totalpages' ) );
		$json   = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $json ) ) { return $p > 1 ? $items : new WP_Error( 'at_json', 'Risposta non valida' ); }
		foreach ( $json as $post ) {
			if ( empty( $post['link'] ) || empty( $post['title']['rendered'] ) ) { continue; }
			$titolo = trim( wp_strip_all_tags( html_entity_decode( $post['title']['rendered'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
			$slug   = isset( $post['slug'] ) ? $post['slug'] : '';
			if ( '' === $titolo || at_articolo_da_escludere( $titolo, $slug ) ) { continue; }
			$estratto = isset( $post['excerpt']['rendered'] ) ? $post['excerpt']['rendered'] : '';
			$estratto = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( $estratto, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
			$estratto = preg_replace( '/\s*(\[…\]|\[\.\.\.\]|Leggi tutto.*|Continua a leggere.*)$/u', '…', $estratto );
			$estratto = wp_trim_words( $estratto, 30, '…' );
			$img      = '';
			if ( ! empty( $post['_embedded']['wp:featuredmedia'][0] ) ) {
				$m     = $post['_embedded']['wp:featuredmedia'][0];
				$sizes = isset( $m['media_details']['sizes'] ) ? $m['media_details']['sizes'] : array();
				foreach ( array( 'medium_large', 'large', 'full' ) as $s ) {
					if ( ! empty( $sizes[ $s ]['source_url'] ) ) { $img = $sizes[ $s ]['source_url']; break; }
				}
				if ( ! $img && ! empty( $m['source_url'] ) ) { $img = $m['source_url']; }
			}
			if ( ! $img && ! empty( $post['content']['rendered'] ) && preg_match( '/<img[^>]+src="([^"]+)"/i', $post['content']['rendered'], $mm ) ) {
				/* Nel testo WordPress inserisce spesso la miniatura (-300x300): si usa l'originale. */
				$img = preg_replace( '/-\d{2,4}x\d{2,4}(\.(?:jpe?g|png|webp|gif))$/i', '$1', $mm[1] );
			}
			$items[] = array(
				'id'       => $chiave . '-' . (int) $post['id'],
				'fonte'    => $chiave,
				'titolo'   => $titolo,
				'url'      => esc_url_raw( $post['link'] ),
				'data'     => substr( $post['date'], 0, 10 ),
				'estratto' => $estratto,
				'img'      => $img ? esc_url_raw( $img ) : '',
				'tags'     => at_argomenti_da_testo( $titolo . ' ' . $estratto ),
			);
		}
	}
	return $items;
}

function at_articoli_aggiorna() {
	$dati  = get_option( 'at_articoli_dati', array() );
	$prima = isset( $dati['per_fonte'] ) ? $dati['per_fonte'] : array();
	$per   = array();
	$stato = array();
	foreach ( at_articoli_fonti() as $k => $f ) {
		$r = at_articoli_leggi_fonte( $k, $f );
		if ( is_wp_error( $r ) ) {
			$per[ $k ]   = isset( $prima[ $k ] ) ? $prima[ $k ] : array();
			$stato[ $k ] = array( 'ok' => false, 'n' => count( $per[ $k ] ), 'msg' => $r->get_error_message(), 'ora' => time() );
		} else {
			$per[ $k ]   = $r;
			$stato[ $k ] = array( 'ok' => true, 'n' => count( $r ), 'msg' => '', 'ora' => time() );
		}
	}
	/* Tutti insieme, dal più recente; lo stesso titolo pubblicato su più siti compare una volta sola. */
	$tutti = array();
	$visti = array();
	foreach ( $per as $lista ) {
		foreach ( $lista as $a ) { $tutti[] = $a; }
	}
	usort( $tutti, function ( $a, $b ) { return strcmp( $b['data'], $a['data'] ); } );
	$uniche = array();
	foreach ( $tutti as $a ) {
		$h = md5( sanitize_title( remove_accents( $a['titolo'] ) ) );
		if ( isset( $visti[ $h ] ) ) { continue; }
		$visti[ $h ] = true;
		$uniche[]    = $a;
	}
	update_option( 'at_articoli_dati', array( 'articoli' => $uniche, 'per_fonte' => $per, 'stato' => $stato, 'aggiornato' => time() ), false );
	return $stato;
}
add_action( 'at_articoli_cron', 'at_articoli_aggiorna' );
add_action( 'at_articoli_primo', 'at_articoli_aggiorna' );

/* Home con l'elenco ancora vuoto: niente cache, così le schede nuove compaiono appena lette. */
add_action( 'template_redirect', function () {
	if ( ( is_front_page() || is_home() ) && function_exists( 'at_articoli' ) && ! at_articoli() ) {
		nocache_headers();
		header( 'X-Accel-Expires: 0' );
	}
} );

add_filter( 'cron_schedules', function ( $s ) {
	$s['at_ogni_3_ore'] = array( 'interval' => 3 * HOUR_IN_SECONDS, 'display' => 'Ogni 3 ore (articoli)' );
	return $s;
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'at_articoli_cron' ) ) {
		wp_schedule_event( time() + 60, 'at_ogni_3_ore', 'at_articoli_cron' );
	}
} );
add_action( 'after_switch_theme', function () {
	wp_schedule_single_event( time() + 5, 'at_articoli_cron' );
} );
add_action( 'switch_theme', function () {
	wp_clear_scheduled_hook( 'at_articoli_cron' );
} );

/* ── Lettura della copia salvata ─────────────────────── */

function at_articoli( $fonte = '', $argomento = '' ) {
	$dati = get_option( 'at_articoli_dati', array() );
	$a    = isset( $dati['articoli'] ) && is_array( $dati['articoli'] ) ? $dati['articoli'] : array();
	/* Elenco ancora vuoto (tema appena installato o aggiornato): prima lettura subito, non tra 3 ore. */
	if ( ! $a && ! get_transient( 'at_articoli_primo_giro' ) ) {
		set_transient( 'at_articoli_primo_giro', 1, 5 * MINUTE_IN_SECONDS );
		wp_schedule_single_event( time(), 'at_articoli_primo' );
		if ( function_exists( 'spawn_cron' ) ) { spawn_cron(); }
	}
	if ( $fonte ) {
		$a = array_values( array_filter( $a, function ( $x ) use ( $fonte ) { return $x['fonte'] === $fonte; } ) );
	}
	if ( $argomento ) {
		$a = array_values( array_filter( $a, function ( $x ) use ( $argomento ) {
			foreach ( (array) $x['tags'] as $t ) { if ( at_tag_slug( $t ) === $argomento ) { return true; } }
			return false;
		} ) );
	}
	return $a;
}

function at_articoli_url( $args = array() ) {
	$u = home_url( '/' . AT_ARTICOLI_BASE . '/' );
	return $args ? add_query_arg( $args, $u ) : $u;
}

function at_articolo_data( $iso ) {
	$ts = strtotime( $iso );
	if ( ! $ts ) { return ''; }
	$mesi = array( 1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre' );
	return (int) gmdate( 'j', $ts ) . ' ' . $mesi[ (int) gmdate( 'n', $ts ) ] . ' ' . gmdate( 'Y', $ts );
}

/* Copertina generata per gli articoli senza immagine: colore del sito, nome del sito, titolo. */
function at_articolo_copertina( $a ) {
	$fonti = at_articoli_fonti();
	$f     = isset( $fonti[ $a['fonte'] ] ) ? $fonti[ $a['fonte'] ] : array( 'nome' => '', 'colore' => '#2c4a6e' );
	$col   = preg_match( '/^#[0-9a-f]{6}$/i', $f['colore'] ) ? $f['colore'] : '#2c4a6e';
	$righe = array();
	$riga  = '';
	foreach ( preg_split( '/\s+/u', $a['titolo'] ) as $w ) {
		if ( mb_strlen( $riga . ' ' . $w ) > 30 && '' !== $riga ) { $righe[] = $riga; $riga = $w; }
		else { $riga = trim( $riga . ' ' . $w ); }
	}
	if ( '' !== $riga ) { $righe[] = $riga; }
	if ( count( $righe ) > 4 ) { $righe = array_slice( $righe, 0, 4 ); $righe[3] = rtrim( $righe[3], ' ,.;:' ) . '…'; }
	$y0  = 250 - ( count( $righe ) - 1 ) * 25;
	$gid = 'g' . substr( md5( $a['id'] ), 0, 8 );
	$tag = ! empty( $a['tags'][0] ) ? $a['tags'][0] : '';
	$s   = '<svg class="article-cover-svg" viewBox="0 0 800 450" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">';
	$s  .= '<defs><linearGradient id="' . $gid . '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' . $col . '"/><stop offset="1" stop-color="#0d1b2a"/></linearGradient></defs>';
	$s  .= '<rect width="800" height="450" fill="url(#' . $gid . ')"/>';
	$s  .= '<circle cx="700" cy="70" r="190" fill="#ffffff" fill-opacity=".05"/><circle cx="740" cy="400" r="120" fill="#d4b265" fill-opacity=".08"/>';
	$s  .= '<rect x="56" y="58" width="44" height="3" fill="#d4b265"/>';
	$s  .= '<text x="56" y="96" fill="#d4b265" font-family="Outfit,Arial,sans-serif" font-size="20" letter-spacing="3">' . esc_html( mb_strtoupper( $f['nome'] ) ) . '</text>';
	foreach ( $righe as $i => $r ) {
		$s .= '<text x="56" y="' . ( $y0 + $i * 50 ) . '" fill="#ffffff" font-family="Outfit,Arial,sans-serif" font-size="40" font-weight="400">' . esc_html( $r ) . '</text>';
	}
	if ( $tag ) {
		$s .= '<text x="56" y="400" fill="#ffffff" fill-opacity=".7" font-family="Outfit,Arial,sans-serif" font-size="18" letter-spacing="2">' . esc_html( mb_strtoupper( $tag ) ) . '</text>';
	}
	$s .= '</svg>';
	return $s;
}

/* Scheda di un articolo (home e pagina /articoli/). */
function at_articolo_card( $a, $anim = false ) {
	$fonti = at_articoli_fonti();
	$nome  = isset( $fonti[ $a['fonte'] ] ) ? $fonti[ $a['fonte'] ]['nome'] : '';
	ob_start(); ?>
	<a class="article-card article-card--con-foto<?php echo $anim ? ' fade-in' : ''; ?>" href="<?php echo esc_url( $a['url'] ); ?>" target="_blank" rel="noopener">
	  <span class="article-cover">
	    <?php echo at_articolo_copertina( $a ); // phpcs:ignore ?>
	    <?php if ( $a['img'] ) : ?>
	      <img src="<?php echo esc_url( $a['img'] ); ?>" alt="" loading="lazy" decoding="async" width="768" height="432" referrerpolicy="no-referrer" onerror="this.remove()">
	    <?php endif; ?>
	  </span>
	  <span class="article-date"><?php echo esc_html( at_articolo_data( $a['data'] ) ); ?> · <?php echo esc_html( $nome ); ?></span>
	  <?php if ( ! empty( $a['tags'][0] ) ) : ?><span class="article-tag"><?php echo esc_html( $a['tags'][0] ); ?></span><?php endif; ?>
	  <span class="article-title"><?php echo esc_html( $a['titolo'] ); ?></span>
	  <?php if ( $a['estratto'] ) : ?><span class="article-excerpt"><?php echo esc_html( $a['estratto'] ); ?></span><?php endif; ?>
	  <span class="article-link">Leggi su <?php echo esc_html( $nome ); ?> →</span>
	</a>
	<?php
	return ob_get_clean();
}

/* ── Pagina /articoli/ ───────────────────────────────── */

function at_is_articoli() {
	return '1' === (string) get_query_var( 'at_articoli' );
}

add_action( 'init', function () {
	add_rewrite_rule( '^' . AT_ARTICOLI_BASE . '/?$', 'index.php?at_articoli=1', 'top' );
	add_rewrite_rule( '^' . AT_ARTICOLI_BASE . '/pagina/([0-9]+)/?$', 'index.php?at_articoli=1&at_pag=$matches[1]', 'top' );
} );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'at_articoli';
	$v[] = 'at_pag';
	return $v;
} );
add_action( 'parse_query', function ( $q ) {
	if ( ! $q->is_main_query() || '1' !== (string) $q->get( 'at_articoli' ) ) { return; }
	$q->is_home = $q->is_front_page = $q->is_page = $q->is_singular = $q->is_archive = false;
} );
add_filter( 'posts_pre_query', function ( $posts, $q ) {
	if ( $q->is_main_query() && '1' === (string) $q->get( 'at_articoli' ) ) {
		$q->found_posts = 0; $q->max_num_pages = 0;
		return array();
	}
	return $posts;
}, 10, 2 );
add_filter( 'pre_handle_404', function ( $g, $q ) {
	return ( $q->is_main_query() && '1' === (string) $q->get( 'at_articoli' ) ) ? true : $g;
}, 10, 2 );
add_filter( 'template_include', function ( $t ) {
	if ( ! at_is_articoli() ) { return $t; }
	status_header( 200 );
	/* Finché l'elenco è vuoto la pagina non va messa in cache (né dal browser né dalla cache di Aruba). */
	if ( ! at_articoli() ) { nocache_headers(); header( 'X-Accel-Expires: 0' ); }
	return get_template_directory() . '/templates/articoli.php';
}, 99 );
add_filter( 'pre_get_document_title', function ( $t ) {
	return at_is_articoli() ? 'Articoli di Andrea Troisi: Radio Notizie e piattaforme Troisi Ricerche' . ( (int) get_query_var( 'at_pag' ) > 1 ? ' — pagina ' . (int) get_query_var( 'at_pag' ) : '' ) . ' | Andrea Troisi' : $t;
}, 30 );

function at_articoli_richiesta() {
	$fonte = isset( $_GET['fonte'] ) ? sanitize_key( wp_unslash( $_GET['fonte'] ) ) : '';
	$fonti = at_articoli_fonti();
	if ( ! isset( $fonti[ $fonte ] ) ) { $fonte = ''; }
	return array(
		'fonte'     => $fonte,
		'argomento' => isset( $_GET['argomento'] ) ? sanitize_title( wp_unslash( $_GET['argomento'] ) ) : '',
		'pagina'    => max( 1, (int) get_query_var( 'at_pag' ) ),
	);
}

add_action( 'at_head_meta', function () {
	if ( ! at_is_articoli() ) { return; }
	$r    = at_articoli_richiesta();
	$url  = $r['pagina'] > 1 ? at_articoli_url() . 'pagina/' . $r['pagina'] . '/' : at_articoli_url();
	$desc = 'Tutti gli articoli di Andrea Troisi e della redazione su Radio Notizie e sulle piattaforme di Troisi Ricerche: statistica, Pubblica Amministrazione, benessere organizzativo, economia, innovazione.';
	$img  = get_template_directory_uri() . '/img/andrea-troisi-hero.jpg';
	echo "\n<meta name=\"description\" content=\"" . esc_attr( $desc ) . "\">\n";
	echo '<link rel="canonical" href="' . esc_url( $url ) . "\">\n";
	if ( $r['fonte'] || $r['argomento'] || ( $r['pagina'] - 1 ) * AT_ARTICOLI_PER_PAGINA >= max( 1, count( at_articoli() ) ) ) { echo "<meta name=\"robots\" content=\"noindex, follow\">\n"; }
	echo "<meta property=\"og:type\" content=\"website\">\n<meta property=\"og:locale\" content=\"it_IT\">\n<meta property=\"og:site_name\" content=\"Andrea Troisi\">\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . "\">\n";
	echo "<meta property=\"og:title\" content=\"Articoli di Andrea Troisi\">\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . "\">\n";
	echo '<meta property="og:image" content="' . esc_url( $img ) . "\">\n<meta name=\"twitter:card\" content=\"summary_large_image\">\n";
	$fonti = at_articoli_fonti();
	$lista = array();
	$i     = 1;
	foreach ( array_slice( at_articoli( $r['fonte'], $r['argomento'] ), ( $r['pagina'] - 1 ) * AT_ARTICOLI_PER_PAGINA, AT_ARTICOLI_PER_PAGINA ) as $a ) {
		$art = array( '@type' => 'Article', 'headline' => $a['titolo'], 'url' => $a['url'], 'datePublished' => $a['data'], 'inLanguage' => 'it-IT',
			'publisher' => array( '@type' => 'Organization', 'name' => $fonti[ $a['fonte'] ]['nome'], 'url' => $fonti[ $a['fonte'] ]['url'] ) );
		if ( 'radionotizie' === $a['fonte'] ) { $art['author'] = array( '@id' => 'https://andreatroisi.it/#person' ); }
		if ( $a['estratto'] ) { $art['description'] = $a['estratto']; }
		if ( $a['img'] ) { $art['image'] = $a['img']; }
		if ( $a['tags'] ) { $art['keywords'] = implode( ', ', $a['tags'] ); }
		$lista[] = array( '@type' => 'ListItem', 'position' => $i++, 'item' => $art );
	}
	$graph = array(
		array( '@type' => 'CollectionPage', '@id' => $url, 'url' => $url, 'name' => 'Articoli di Andrea Troisi', 'description' => $desc, 'inLanguage' => 'it-IT',
			'about' => array( '@id' => 'https://andreatroisi.it/#person' ), 'mainEntity' => array( '@type' => 'ItemList', 'itemListElement' => $lista ) ),
		array( '@type' => 'BreadcrumbList', 'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Andrea Troisi', 'item' => home_url( '/' ) ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Articoli', 'item' => at_articoli_url() ),
		) ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
} );

/* Sitemap: la pagina /articoli/ */
add_action( 'init', function () {
	if ( ! function_exists( 'wp_register_sitemap_provider' ) || ! class_exists( 'WP_Sitemaps_Provider' ) ) { return; }
	if ( ! class_exists( 'AT_Articoli_Sitemap' ) ) {
		class AT_Articoli_Sitemap extends WP_Sitemaps_Provider {
			public function __construct() { $this->name = 'articoli'; $this->object_type = 'articoli'; }
			public function get_url_list( $page_num, $object_subtype = '' ) {
				$n    = max( 1, (int) ceil( count( at_articoli() ) / AT_ARTICOLI_PER_PAGINA ) );
				$urls = array( array( 'loc' => at_articoli_url() ) );
				for ( $i = 2; $i <= $n; $i++ ) { $urls[] = array( 'loc' => at_articoli_url() . 'pagina/' . $i . '/' ); }
				return $urls;
			}
			public function get_max_num_pages( $object_subtype = '' ) { return 1; }
		}
	}
	wp_register_sitemap_provider( 'articoli', new AT_Articoli_Sitemap() );
}, 20 );

/* ── Strumenti → Articoli ────────────────────────────── */

add_action( 'admin_menu', function () {
	add_management_page( 'Articoli', 'Articoli', 'manage_options', 'at-articoli', 'at_articoli_admin' );
} );
function at_articoli_admin() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( isset( $_POST['at_aggiorna'] ) && check_admin_referer( 'at_articoli_aggiorna' ) ) {
		at_articoli_aggiorna();
		echo '<div class="notice notice-success"><p>Articoli aggiornati.</p></div>';
	}
	$dati  = get_option( 'at_articoli_dati', array() );
	$stato = isset( $dati['stato'] ) ? $dati['stato'] : array();
	echo '<div class="wrap"><h1>Articoli</h1><p>Il sito legge ogni 3 ore gli articoli di Radio Notizie (autore Andrea Troisi) e delle piattaforme di Troisi Ricerche. Pagina pubblica: <a href="' . esc_url( at_articoli_url() ) . '" target="_blank">' . esc_html( at_articoli_url() ) . '</a></p>';
	echo '<p>Ultimo aggiornamento: <strong>' . ( ! empty( $dati['aggiornato'] ) ? esc_html( date_i18n( 'j F Y H:i', $dati['aggiornato'] + (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) ) : 'mai' ) . '</strong> · articoli in elenco: <strong>' . count( isset( $dati['articoli'] ) ? $dati['articoli'] : array() ) . '</strong></p>';
	echo '<form method="post">';
	wp_nonce_field( 'at_articoli_aggiorna' );
	echo '<p><button class="button button-primary" name="at_aggiorna" value="1">Aggiorna ora</button></p></form>';
	echo '<table class="widefat striped"><thead><tr><th>Sito</th><th>Stato</th><th>Articoli</th></tr></thead><tbody>';
	foreach ( at_articoli_fonti() as $k => $f ) {
		$s = isset( $stato[ $k ] ) ? $stato[ $k ] : null;
		echo '<tr><td><a href="' . esc_url( $f['url'] ) . '" target="_blank">' . esc_html( $f['nome'] ) . '</a></td><td>' . ( $s ? ( $s['ok'] ? 'OK' : 'Non raggiungibile (' . esc_html( $s['msg'] ) . ') — restano gli ultimi letti' ) : '—' ) . '</td><td>' . ( $s ? (int) $s['n'] : '' ) . '</td></tr>';
	}
	echo '</tbody></table></div>';
}
