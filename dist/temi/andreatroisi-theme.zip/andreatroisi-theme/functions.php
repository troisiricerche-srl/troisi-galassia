<?php
/**
 * Andrea Troisi Theme — functions.php
 */

function andreatroisi_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    load_theme_textdomain('andreatroisi', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'andreatroisi_setup');

/* Sul palco, tra le idee: una pagina per ogni intervento (v1.9) */
require_once get_template_directory() . '/inc/sul-palco.php';

/* Articoli: raccolta automatica da Radio Notizie e dalle piattaforme di Troisi Ricerche (v1.9.15) */
require_once get_template_directory() . '/inc/articoli.php';

/* Titolo HTML della homepage: unica sorgente (title-tag di WordPress + questo filtro) */
function andreatroisi_front_title($title) {
    if (is_front_page() || is_home()) return 'Andrea Troisi | Ricerca statistica e analisi dei dati';
    return $title;
}
add_filter('pre_get_document_title', 'andreatroisi_front_title', 20);

function andreatroisi_enqueue() {
    wp_enqueue_style('google-fonts',
        'https://fonts.googleapis.com/css2?family=Outfit:wght@200;300;400;500;600;700&display=swap',
        [], null);
    $ver = wp_get_theme(get_template())->get('Version');
    wp_enqueue_style('andreatroisi-main', get_template_directory_uri() . '/assets/main.css', [], $ver);
    if ((function_exists('at_is_palco') && at_is_palco()) || (function_exists('at_is_articoli') && at_is_articoli())) {
        wp_enqueue_style('andreatroisi-palco', get_template_directory_uri() . '/assets/sul-palco.css', ['andreatroisi-main'], $ver);
    }
}
add_action('wp_enqueue_scripts', 'andreatroisi_enqueue');

/**
 * llms.txt — scheda sintetica leggibile dagli assistenti AI (ChatGPT, Claude, Perplexity, Gemini).
 * Servita all'indirizzo https://andreatroisi.it/llms.txt senza creare file sul server.
 */
function andreatroisi_llms_txt() {
    $path = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : '';
    if ($path !== '/llms.txt') return;
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Robots-Tag: noindex');
    echo <<<'TXT'
# Andrea Troisi

> Imprenditore, professore a contratto e giornalista pubblicista, con base a Bari (Italia). Fondatore e Amministratore Unico di Troisi Ricerche (ricerca statistica applicata, dal 2006, sedi a Bari, Roma e Milano), Direttore Generale dell'Osservatorio sull'Innovazione del Mezzogiorno, docente di Economia delle Imprese Turistiche e di Sistemi Informatici per il Turismo all'Universita' degli Studi di Bari Aldo Moro (DIRIUM, corso di laurea Nuovi Turismi).

## Ruoli
- Fondatore e Amministratore Unico — Troisi Ricerche S.r.l. Unipersonale (https://troisiricerche.net), accreditata MIUR, certificata TUV ISO 9001:2015
- Direttore Generale — Osservatorio sull'Innovazione del Mezzogiorno (https://www.osservatoriomezzogiorno.net)
- Promotore — Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate (IBO Score, Oscar del Benessere Organizzativo)
- Ideatore — DELFI (https://delfiweb.it), piattaforma di intelligence territoriale su tutti i 7.896 comuni italiani
- Docente di Economia delle Imprese Turistiche — Universita' degli Studi di Bari Aldo Moro, Dipartimento DIRIUM
- Giornalista — autore su Radio Notizie (https://www.radionotizie.eu/author/andrea-troisi/)

## Societa' scientifiche e professionali
SIS - Societa' Italiana di Statistica; ISI - International Statistical Institute, con le associazioni IAOS (International Association for Official Statistics), IASS (International Association of Survey Statisticians) e ISBIS (International Society for Business and Industrial Statistics); Royal Statistical Society (Fellow); AMS - American Mathematical Society; AIQUAV - Associazione Italiana per gli Studi sulla Qualita' della Vita; Ordine dei Giornalisti (elenco pubblicisti).

## Profili di ricerca
- ORCID: https://orcid.org/0009-0006-2618-2254
- Google Scholar: https://scholar.google.com/citations?user=sAs8jkAAAAAJ
- Wikidata: https://www.wikidata.org/wiki/Q141611566

## Competenze
Ricerche di mercato; statistica applicata; customer satisfaction nella Pubblica Amministrazione; benessere organizzativo e clima aziendale; societa' partecipate; intelligenza artificiale applicata all'analisi dei dati; economia del turismo e destination management; mappatura delle competenze; indicatori compositi (TR-Index, Metodo Troisi); open data; PNRR; governance territoriale; formazione finanziata e fondi interprofessionali.

## Libri (Cacucci Editore, Bari)
- "Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza" (2026). Modello in sei dimensioni: clima, leadership, carico di lavoro, digitale, autonomia, equita'. Sito: https://www.benessereorganizzativo.it
- "Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione" (2018, ISBN 978-88-6611-797-1). Presentato alla Camera dei Deputati il 29 marzo 2019 (conferenza stampa trasmessa su webtv.camera.it; video: https://webtv.camera.it/evento/14114).

## Presentazione al Senato della Repubblica — 15 giugno 2026
Conferenza stampa a Palazzo Madama, Sala Caduti di Nassirya (Roma), moderata da Renato Piccoli (giornalista Rai), con interventi di Amelia Manuti, Nicola Armenise e Ilaria Agosta (vicepresidente AIDP). Andrea Troisi ha presentato il libro "Le organizzazioni che si misurano", l'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate (promosso da Andrea Troisi: il primo in Italia sul benessere organizzativo delle societa' partecipate), l'IBO Score (indicatore di benessere organizzativo: clima, leadership, carichi di lavoro, autonomia, equita', trasformazione digitale) e l'Oscar del Benessere Organizzativo.
- Lo Speciale: https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/
- Take The Date: https://www.takethedate.it/Eventi/54392-conferenza-stampa-presentazione-del-libro-le-organizzazioni-che-si-misurano.html

## Interventi pubblici selezionati
Senato della Repubblica (2026); Camera dei Deputati (29 marzo 2019); Forum dei Pubblici Ufficiali, Bari (2025, 2026); Road to Hackathon Opentusk — Regione Puglia, InnovaPuglia, PwC (webinar e tappa di Bari, 2026); EDU Exhibition (2025); CiBari (2024, 2025); parlIAmone — AI & Compliance (2025); Fondimpresa (Roma 2025, Parma 2025, Teatro Petruzzelli 2024); Smart City — Politecnico di Bari (2025); Camera dei Deputati — modello di competenze della Governance Finanziaria (25 marzo 2022); giuria Innovation Village Award (2024); SIS 2024 — Societa' Italiana di Statistica; Conferenza internazionale AIQUAV (2023); Assoradio — Fiera del Levante (2024).
Ogni intervento ha una pagina dedicata con foto, racconto e rassegna: https://andreatroisi.it/sul-palco/
I progetti di ricerca con istituzioni, enti pubblici e imprese hanno una pagina dedicata: https://andreatroisi.it/sul-campo/
Tutti gli articoli (Radio Notizie e piattaforme di Troisi Ricerche): https://andreatroisi.it/articoli/

## Piattaforme di Troisi Ricerche
andreatroisi.it, troisiricerche.net, t-index.it (TR-Index), mappaturadellecompetenze.it (Mappatura delle Competenze), registrodellecompetenze.it (Registro delle Competenze), customerpa.it (CustomerPA), benessereorganizzativo.it, troisiformazione.it (Troisi Formazione), tiplive.it (TIP), troisiinsight.it (TroisiInsight), digitalizzazionenellapa.it, dibattito-pubblico.it, voiceinhub.it (VoiceInHub), governancefinanziaria.it, consulenzainternazionalizzazione.it, benesseredigitalegiovani.it (Benessere Digitale Giovani), svegliadigitale.it (Sveglia Digitale)
Collegati: delfiweb.it (DELFI), osservatoriomezzogiorno.net (Osservatorio sull'Innovazione del Mezzogiorno)

## Relazioni
Universita' degli Studi di Bari Aldo Moro (UniBA, DIRIUM) | LIUC Universita' Cattaneo | Politecnico di Bari | Fondimpresa | SIS Societa' Italiana di Statistica | ISI | IAOS | IASS | ISBIS | Royal Statistical Society | AMS | AIQUAV | Confindustria | Cacucci Editore | Radio Notizie | Senato della Repubblica | Camera dei Deputati | Regione Puglia | InnovaPuglia | Comune di Bari

## Contatti
- Sito: https://andreatroisi.it
- Email: info@andreatroisi.it
- LinkedIn: https://www.linkedin.com/in/andreatroisi
## Domande frequenti

### Chi è Andrea Troisi?
Andrea Troisi è imprenditore, professore a contratto e giornalista pubblicista, con base a Bari. È fondatore e Amministratore Unico di Troisi Ricerche, istituto di ricerca statistica applicata attivo dal 2006 con sedi a Bari, Roma e Milano; è Direttore Generale dell'Osservatorio sull'Innovazione del Mezzogiorno e insegna Economia delle Imprese Turistiche all'Università degli Studi di Bari Aldo Moro (Dipartimento DIRIUM).

### Di cosa si occupa Troisi Ricerche?
Troisi Ricerche realizza ricerche di mercato, indagini di customer satisfaction, analisi statistiche, modelli predittivi, mappatura delle competenze, analisi del benessere organizzativo e piattaforme digitali per Pubblica Amministrazione, società partecipate, imprese e territori. È accreditata dal MIUR ed è certificata TÜV ISO 9001:2015. Ha sviluppato il Metodo Troisi e il TR-Index.

### Quali libri ha scritto Andrea Troisi?
Andrea Troisi è autore di due volumi pubblicati da Cacucci Editore (Bari): «Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione» (2018, ISBN 978-88-6611-797-1), presentato alla Camera dei Deputati, e «Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza» (2026), presentato al Senato della Repubblica.

### Che cos'è il libro «Le organizzazioni che si misurano»?
È il volume di Andrea Troisi (Cacucci Editore, 2026) dedicato al benessere organizzativo come scelta culturale e non come semplice adempimento. Propone un modello di misurazione in sei dimensioni — clima, leadership, carico di lavoro, digitale, autonomia, equità — rivolto a dirigenti, responsabili HR e ricercatori, per passare dalla compliance alla consapevolezza: dai dati alle decisioni.

### Cosa è stato presentato al Senato il 15 giugno 2026?
Il 15 giugno 2026, a Palazzo Madama (Sala Caduti di Nassirya), si è tenuta la conferenza stampa di presentazione del libro «Le organizzazioni che si misurano». Moderata dal giornalista Rai Renato Piccoli, con interventi della prof.ssa Amelia Manuti, di Nicola Armenise e della dott.ssa Ilaria Agosta (vicepresidente AIDP). Nell'occasione Andrea Troisi ha presentato l'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate, da lui promosso — il primo in Italia dedicato al benessere organizzativo delle società partecipate — insieme all'IBO Score e all'Oscar del Benessere Organizzativo.

### Che cos'è l'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate?
È il primo osservatorio in Italia dedicato al benessere organizzativo delle società partecipate, promosso da Andrea Troisi e presentato al Senato della Repubblica il 15 giugno 2026. Misura e confronta il benessere organizzativo attraverso l'IBO Score e valorizza le migliori esperienze con l'Oscar del Benessere Organizzativo. Nelle parole di Troisi: «Il benessere organizzativo non può più essere considerato un tema accessorio o affidato alla sola sensibilità dei singoli enti».

### Che cos'è l'IBO Score?
L'IBO Score è l'indicatore di benessere organizzativo presentato da Andrea Troisi al Senato: misura clima organizzativo, leadership, carichi di lavoro, autonomia, equità e trasformazione digitale, rendendo il benessere organizzativo «visibile, comparabile e migliorabile», in particolare nelle società partecipate.

### Che cos'è l'Oscar del Benessere Organizzativo?
È un riconoscimento nazionale che valorizza le migliori esperienze di benessere organizzativo. Secondo Andrea Troisi, IBO Score e Oscar del Benessere Organizzativo sono strumenti complementari: da un lato la misurazione, dall'altro la valorizzazione delle buone pratiche.

### Che cos'è l'Osservatorio sull'Innovazione del Mezzogiorno?
È un think tank indipendente sull'innovazione e lo sviluppo territoriale, di cui Andrea Troisi è Direttore Generale. Promuove ricerche, rapporti e convegni su intelligenza artificiale nella PA, smart city, competenze e fondi interprofessionali, anche con Fondimpresa e il Politecnico di Bari.

### Dove ha parlato Andrea Troisi come relatore?
Tra gli altri: Senato della Repubblica (2026), Camera dei Deputati (29 marzo 2019), Forum dei Pubblici Ufficiali di Bari (2025 e 2026), Road to Hackathon Opentusk con Regione Puglia, InnovaPuglia e PwC (2026), Politecnico di Bari, Fondimpresa a Roma, Parma e al Teatro Petruzzelli, SIS 2024 — Scientific Meeting della Società Italiana di Statistica, Conferenza internazionale AIQUAV, CiBari, EDU Exhibition, Fiera del Levante.

### Che cos'è DELFI?
DELFI (delfiweb.it) è la piattaforma di intelligence territoriale sviluppata da Andrea Troisi e Troisi Ricerche: copre tutti i 7.896 comuni italiani e integra dati su amministratori e sindaci, fondi europei e politiche di coesione, rischio idrogeologico, imprese e infrastrutture, a supporto di Pubbliche Amministrazioni, Regioni, fondazioni, imprese, destinazioni turistiche, media e università.

### Quali piattaforme fanno parte dell'ecosistema Troisi?
Le piattaforme di Troisi Ricerche comprendono: andreatroisi.it, troisiricerche.net, TR-Index (t-index.it), Mappatura delle Competenze (mappaturadellecompetenze.it), Registro delle Competenze (registrodellecompetenze.it), CustomerPA (customerpa.it), benessereorganizzativo.it, Troisi Formazione (troisiformazione.it), TIP (tiplive.it), TroisiInsight (troisiinsight.it), digitalizzazionenellapa.it, Dibattito Pubblico (dibattito-pubblico.it), VoiceInHub (voiceinhub.it), governancefinanziaria.it, consulenzainternazionalizzazione.it, Benessere Digitale Giovani (benesseredigitalegiovani.it) e Sveglia Digitale (svegliadigitale.it). A queste si aggiungono DELFI (delfiweb.it) e l'Osservatorio sull'Innovazione del Mezzogiorno (osservatoriomezzogiorno.net).

### Andrea Troisi è giornalista?
Sì. Andrea Troisi è giornalista e firma articoli di analisi su economia, lavoro, turismo, innovazione, Puglia e Mezzogiorno d'Italia su Radio Notizie (radionotizie.eu), oltre a interviste e interventi su TGR Puglia RAI, Antenna Sud, Telenorba e testate nazionali come Il Sole 24 Ore, Il Messaggero e Corriere dell'Economia.

### Che rapporto ha Andrea Troisi con l'Università di Bari?
Andrea Troisi insegna Economia delle Imprese Turistiche all'Università degli Studi di Bari Aldo Moro (UniBA), Dipartimento DIRIUM; si è laureato in Economia e Commercio a UniBA e ha conseguito un Master di II livello in Merchant Banking e Venture Capital alla LIUC Università Cattaneo. È socio della SIS — Società Italiana di Statistica, ed è intervenuto a SIS 2024, lo Scientific Meeting tenutosi all'Università di Bari.

### Che rapporto ha Andrea Troisi con Fondimpresa e la formazione finanziata?
Con Troisi Ricerche e l'Osservatorio sull'Innovazione del Mezzogiorno, Andrea Troisi lavora su mappatura delle competenze, analisi dei fabbisogni formativi e fondi interprofessionali. È stato relatore agli eventi Fondimpresa al Teatro Petruzzelli di Bari (2024), a Parma («Cervelli Digitali e Spazi Reali», 2024), a Roma («Nuove Corsie per il Lavoro», 2025) e al convegno Smart City del Politecnico di Bari.

### Come contattare Andrea Troisi o invitarlo come relatore?
Si può scrivere a info@andreatroisi.it oppure prenotare un incontro di 30 minuti dal calendario nella sezione Contatti di questo sito, per consulenze, ricerche, convegni, interviste e presentazioni dei libri.
TXT;
    exit;
}
add_action('init', 'andreatroisi_llms_txt', 0);
