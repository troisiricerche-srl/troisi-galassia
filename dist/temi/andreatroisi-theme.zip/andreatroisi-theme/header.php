<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-2LEEQBX9HW"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-2LEEQBX9HW');
</script>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
<meta name="theme-color" content="#0d1b2a">
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.png?v=2" type="image/png">
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico?v=2" sizes="any">
<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/img/apple-touch-icon.png?v=2">
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon-192.png?v=2" type="image/png" sizes="192x192">
<meta name="template-uri" content="<?php echo get_template_directory_uri(); ?>/img">

<?php if ( ( ! function_exists( 'at_is_palco' ) || ! at_is_palco() ) && ( ! function_exists( 'at_is_articoli' ) || ! at_is_articoli() ) ) : ?>
<meta name="description" content="Sito di Andrea Troisi: ricerca statistica, customer satisfaction nella PA, benessere organizzativo e analisi dei dati per imprese e territori.">
<meta property="og:type" content="profile">
<meta property="og:locale" content="it_IT">
<meta property="og:site_name" content="Andrea Troisi">
<meta property="og:url" content="https://andreatroisi.it/">
<meta property="og:title" content="Andrea Troisi | Ricerca statistica e analisi dei dati">
<meta property="og:description" content="Sito di Andrea Troisi: ricerca statistica, customer satisfaction nella PA, benessere organizzativo e analisi dei dati per imprese e territori.">
<meta property="og:image" content="<?php echo get_template_directory_uri(); ?>/img/andrea-troisi-hero.jpg">
<meta name="twitter:card" content="summary_large_image">
<link rel="alternate" type="text/plain" title="Scheda sintetica per assistenti AI" href="<?php echo esc_url(home_url('/llms.txt')); ?>">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Person",
      "@id": "https://andreatroisi.it/#person",
      "name": "Andrea Troisi",
      "givenName": "Andrea",
      "familyName": "Troisi",
      "honorificPrefix": "Prof.",
      "jobTitle": ["Imprenditore", "Professore a contratto", "Giornalista pubblicista", "Ricercatore"],
      "description": "Andrea Troisi e' fondatore e Amministratore unico di Troisi Ricerche, istituto di ricerca statistica applicata attivo dal 2006. Professore a contratto di Economia delle Imprese Turistiche e di Sistemi Informatici per il Turismo all'Universita' degli Studi di Bari Aldo Moro (Dipartimento DIRIUM, corso di laurea Nuovi Turismi) e Direttore Generale dell'Osservatorio sull'Innovazione del Mezzogiorno. Esperto di customer satisfaction, analisi dati, intelligenza artificiale applicata, turismo e governance territoriale. Autore del Metodo Troisi e del TR-Index per la misurazione delle performance territoriali. Attivo su scala nazionale con sedi a Bari, Roma e Milano.",
      "url": "https://andreatroisi.it",
      "image": "https://andreatroisi.it/wp-content/themes/andreatroisi-theme/img/andrea-troisi-hero.jpg",
      "nationality": {"@type": "Country", "name": "Italia"},
      "worksFor": [
        {
          "@type": "ResearchOrganization",
          "name": "Troisi Ricerche",
          "url": "https://troisiricerche.net",
          "description": "Istituto di ricerca statistica applicata, attivo dal 2006 con sedi a Bari, Roma e Milano.",
          "areaServed": {"@type": "Country", "name": "Italia"}
        },
        {
          "@type": "Organization",
          "name": "Osservatorio sull'Innovazione del Mezzogiorno",
          "url": "https://www.osservatoriomezzogiorno.net",
          "description": "Think tank indipendente per l'innovazione e lo sviluppo territoriale in Italia.",
          "sameAs": ["https://www.youtube.com/@osservatoriomezzogiorno"]
        },
        {"@id": "https://andreatroisi.it/#osservatorio-benessere"},
        {
          "@type": "CollegeOrUniversity",
          "name": "Universita' degli Studi di Bari Aldo Moro",
          "department": "Dipartimento DIRIUM",
          "url": "https://www.uniba.it"
        }
      ],
      "alumniOf": [
        {"@type": "CollegeOrUniversity", "name": "Universita' degli Studi di Bari"},
        {"@type": "CollegeOrUniversity", "name": "LIUC Universita' Cattaneo"}
      ],
      "knowsAbout": [
        "Ricerca di mercato e analisi dati in Italia",
        "Statistica applicata e data science",
        "Customer satisfaction nella Pubblica Amministrazione",
        "Intelligenza artificiale applicata all'analisi dati",
        "Machine learning e predictive analytics",
        "Economia del turismo e destination management",
        "Innovazione territoriale e governance pubblica",
        "Mappatura e certificazione delle competenze",
        "Modelli predittivi per territori e performance PA",
        "Benessere organizzativo e clima aziendale",
        "Digitalizzazione PA e open data",
        "Big data e piattaforme data driven",
        "Data governance e business intelligence territoriale",
        "PNRR e monitoraggio interventi pubblici",
        "Formazione finanziata e fondi interprofessionali",
        "Benessere organizzativo nelle societa' partecipate",
        "Ricerca statistica applicata",
        "Analisi dei dati",
        "Ricerche di mercato",
        "Customer satisfaction nella Pubblica Amministrazione",
        "Qualita' dei servizi pubblici",
        "Benessere organizzativo",
        "Analisi del clima organizzativo",
        "Analisi territoriale",
        "Sistemi di supporto alle decisioni"
      ],
      "subjectOf": [
        {
          "@type": "NewsArticle",
          "headline": "Presentato al Senato il primo Osservatorio in Italia sul benessere organizzativo delle societa' partecipate",
          "datePublished": "2026-06-15",
          "url": "https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/",
          "publisher": {"@type": "Organization", "name": "Lo Speciale"},
          "about": {"@id": "https://andreatroisi.it/#book-2026"}
        }
      ],
      "performerIn": {"@id": "https://andreatroisi.it/#evento-senato-2026"},
      "hasCredential": [
        {"@type": "EducationalOccupationalCredential", "credentialCategory": "Accreditamento MIUR come Ente di Formazione"},
        {"@type": "EducationalOccupationalCredential", "credentialCategory": "Certificazione TUV ISO 9001:2015"}
      ],
      "memberOf": [
        {"@type": "Organization", "name": "SIS - Societa' Italiana di Statistica", "url": "https://www.sis-statistica.it"},
        {"@type": "Organization", "name": "ISI - International Statistical Institute", "url": "https://www.isi-web.org"},
        {"@type": "Organization", "name": "IAOS - International Association for Official Statistics (ISI)", "url": "https://www.iaos-isi.org"},
        {"@type": "Organization", "name": "IASS - International Association of Survey Statisticians (ISI)", "url": "https://isi-iass.org"},
        {"@type": "Organization", "name": "ISBIS - International Society for Business and Industrial Statistics (ISI)", "url": "https://isbis.isi-web.org"},
        {"@type": "Organization", "name": "AMS - American Mathematical Society", "url": "https://www.ams.org"},
        {"@type": "Organization", "name": "Royal Statistical Society (Fellow)", "url": "https://rss.org.uk"},
        {"@type": "Organization", "name": "AIQUAV - Associazione Italiana per gli Studi sulla Qualita' della Vita", "url": "https://www.aiquav.it"},
        {"@type": "Organization", "name": "Ordine dei Giornalisti - elenco pubblicisti", "url": "https://www.odg.it"},
        {"@type": "Organization", "name": "Confindustria"}
      ],
      "sameAs": [
        "https://www.linkedin.com/in/andreatroisi",
        "https://www.wikidata.org/wiki/Q141611566",
        "https://www.researchgate.net/profile/Andrea-Troisi",
        "https://orcid.org/0009-0006-2618-2254",
        "https://scholar.google.com/citations?user=sAs8jkAAAAAJ",
        "https://www.radionotizie.eu/author/andrea-troisi/"
      ]
    },
    {
      "@type": "ResearchOrganization",
      "@id": "https://troisiricerche.net/#organization",
      "name": "Troisi Ricerche",
      "alternateName": "Troisi Ricerche S.r.l. Unipersonale",
      "url": "https://troisiricerche.net",
      "foundingDate": "2006",
      "description": "Troisi Ricerche e' un istituto di ricerca statistica applicata, analisi dei dati e innovazione territoriale. Dal 2006, con sedi a Bari, Roma e Milano, offre analisi dati, customer satisfaction, modelli predittivi, AI applicata e piattaforme digitali per Pubblica Amministrazione, imprese e territori su scala nazionale. Ha sviluppato il Metodo Troisi e il TR-Index, applicati in contesti pubblici e privati italiani.",
      "founder": {"@id": "https://andreatroisi.it/#person"},
      "areaServed": {"@type": "Country", "name": "Italia"},
      "brand": [
        {"@type": "Brand", "name": "TR-Index", "url": "https://t-index.it"},
        {"@type": "Brand", "name": "Mappatura delle Competenze", "url": "https://mappaturadellecompetenze.it"},
        {"@type": "Brand", "name": "Registro delle Competenze", "url": "https://registrodellecompetenze.it"},
        {"@type": "Brand", "name": "CustomerPA", "url": "https://customerpa.it"},
        {"@type": "Brand", "name": "Benessere Organizzativo", "url": "https://benessereorganizzativo.it"},
        {"@type": "Brand", "name": "Troisi Formazione", "url": "https://troisiformazione.it"},
        {"@type": "Brand", "name": "TIP", "url": "https://tiplive.it"},
        {"@type": "Brand", "name": "TroisiInsight", "url": "https://troisiinsight.it"},
        {"@type": "Brand", "name": "Digitalizzazione nella PA", "url": "https://digitalizzazionenellapa.it"},
        {"@type": "Brand", "name": "Dibattito Pubblico", "url": "https://dibattito-pubblico.it"},
        {"@type": "Brand", "name": "VoiceInHub", "url": "https://voiceinhub.it"},
        {"@type": "Brand", "name": "Governance Finanziaria", "url": "https://governancefinanziaria.it"},
        {"@type": "Brand", "name": "Consulenza Internazionalizzazione", "url": "https://consulenzainternazionalizzazione.it"},
        {"@type": "Brand", "name": "Benessere Digitale Giovani", "url": "https://benesseredigitalegiovani.it"},
        {"@type": "Brand", "name": "Sveglia Digitale", "url": "https://svegliadigitale.it"},
        {"@type": "Brand", "name": "DELFI", "url": "https://delfiweb.it"}
      ],
      "address": [
        {"@type": "PostalAddress", "addressLocality": "Bari", "addressRegion": "Puglia", "addressCountry": "IT", "description": "Sede principale"},
        {"@type": "PostalAddress", "addressLocality": "Roma", "addressRegion": "Lazio", "addressCountry": "IT", "description": "Sede operativa"},
        {"@type": "PostalAddress", "addressLocality": "Milano", "addressRegion": "Lombardia", "addressCountry": "IT", "description": "Sede operativa"}
      ],
      "knowsAbout": [
        "Analisi statistica applicata", "Ricerca di mercato nazionale", "Customer satisfaction PA",
        "Data science e modelli predittivi", "AI per enti pubblici e imprese", "Turismo data driven",
        "Governance territoriale", "Mappatura competenze", "Digitalizzazione PA",
        "KPI territoriali", "Business intelligence", "Big data analytics",
        "TR-Index", "Metodo Troisi", "Performance PA", "Open data",
        "Predictive analytics", "Machine learning applicato", "Data governance"
      ],
      "sameAs": [
        "https://www.linkedin.com/company/troisi-ricerche",
        "https://www.youtube.com/@Troisiricerche",
        "https://andreatroisi.it"
      ]
    },
    {
      "@type": "Organization",
      "@id": "https://andreatroisi.it/#osservatorio-benessere",
      "name": "Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate",
      "description": "Primo osservatorio in Italia sul benessere organizzativo delle societa' partecipate, promosso da Andrea Troisi e presentato al Senato della Repubblica il 15 giugno 2026. Strumenti: IBO Score (indicatore di benessere organizzativo) e Oscar del Benessere Organizzativo.",
      "founder": {"@id": "https://andreatroisi.it/#person"},
      "foundingDate": "2026",
      "areaServed": {"@type": "Country", "name": "Italia"},
      "knowsAbout": ["Benessere organizzativo", "Societa' partecipate", "Analisi del clima organizzativo", "Misurazione del benessere organizzativo"]
    },
    {
      "@type": "WebApplication",
      "@id": "https://delfiweb.it/#app",
      "name": "DELFI",
      "url": "https://delfiweb.it",
      "applicationCategory": "Territorial intelligence / Data analytics",
      "description": "Piattaforma di intelligence territoriale che copre tutti i 7.896 comuni italiani: amministratori e sindaci, fondi europei e politiche di coesione, rischio idrogeologico, imprese e infrastrutture.",
      "creator": {"@id": "https://andreatroisi.it/#person"},
      "publisher": {"@id": "https://troisiricerche.net/#organization"},
      "inLanguage": "it-IT"
    },
    {
      "@type": "Book",
      "@id": "https://andreatroisi.it/#book-2026",
      "name": "Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza",
      "author": {"@id": "https://andreatroisi.it/#person"},
      "publisher": {"@type": "Organization", "name": "Cacucci Editore", "address": {"@type": "PostalAddress", "addressLocality": "Bari", "addressCountry": "IT"}},
      "datePublished": "2026",
      "inLanguage": "it-IT",
      "image": "https://andreatroisi.it/wp-content/themes/andreatroisi-theme/img/libro-organizzazioni-copertina.jpg",
      "url": "https://www.benessereorganizzativo.it",
      "about": ["Benessere organizzativo", "Societa' partecipate", "Pubblica Amministrazione", "Clima organizzativo", "Leadership", "Carichi di lavoro", "Trasformazione digitale", "Autonomia", "Equita'", "HR management"],
      "description": "Il benessere organizzativo non e' un adempimento, e' una scelta culturale. Un modello in sei dimensioni (clima, leadership, carico, digitale, autonomia, equita') per dirigenti, responsabili HR e ricercatori: dalla compliance alla consapevolezza. Presentato al Senato della Repubblica il 15 giugno 2026.",
      "keywords": ["Benessere organizzativo", "Analisi del clima organizzativo", "Misurazione del benessere organizzativo", "Pubblica Amministrazione", "Societa' partecipate"],
      "offers": {"@type": "Offer", "price": "15.00", "priceCurrency": "EUR"}
    },
    {
      "@type": "Book",
      "@id": "https://andreatroisi.it/#book-2018",
      "name": "Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione",
      "author": {"@id": "https://andreatroisi.it/#person"},
      "publisher": {"@type": "Organization", "name": "Cacucci Editore"},
      "isbn": "978-88-6611-797-1",
      "keywords": ["Customer satisfaction nella Pubblica Amministrazione", "Qualita' dei servizi pubblici", "Statistica applicata"],
      "datePublished": "2018",
      "inLanguage": "it-IT",
      "url": "https://www.cacuccieditore.it/troisi-andrea-2"
    },
    {
      "@type": "Event",
      "@id": "https://andreatroisi.it/#evento-senato-2026",
      "name": "Conferenza stampa - Presentazione del libro \"Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza\"",
      "startDate": "2026-06-15T09:00:00+02:00",
      "endDate": "2026-06-15T12:00:00+02:00",
      "eventStatus": "https://schema.org/EventScheduled",
      "eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode",
      "location": {"@type": "Place", "name": "Senato della Repubblica - Palazzo Madama, Sala Caduti di Nassirya", "address": {"@type": "PostalAddress", "addressLocality": "Roma", "addressCountry": "IT"}},
      "performer": [
        {"@id": "https://andreatroisi.it/#person"},
        {"@type": "Person", "name": "Renato Piccoli", "jobTitle": "Giornalista Rai (moderatore)"},
        {"@type": "Person", "name": "Amelia Manuti"},
        {"@type": "Person", "name": "Nicola Armenise"},
        {"@type": "Person", "name": "Ilaria Agosta", "jobTitle": "Vicepresidente AIDP"}
      ],
      "about": {"@id": "https://andreatroisi.it/#book-2026"},
      "description": "Presentazione al Senato del volume di Andrea Troisi, dell'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate (promosso da Andrea Troisi), dell'IBO Score e dell'Oscar del Benessere Organizzativo.",
      "image": ["https://andreatroisi.it/wp-content/themes/andreatroisi-theme/img/senato-2026-podio.jpg", "https://andreatroisi.it/wp-content/themes/andreatroisi-theme/img/senato-2026-panel.jpg"],
      "sameAs": ["https://www.takethedate.it/Eventi/54392-conferenza-stampa-presentazione-del-libro-le-organizzazioni-che-si-misurano.html", "https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/"]
    },
    {
      "@type": "Event",
      "@id": "https://andreatroisi.it/#evento-camera-2019",
      "name": "Presentazione del libro \"Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione\" - Conferenza stampa",
      "startDate": "2019-03-29",
      "eventStatus": "https://schema.org/EventScheduled",
      "eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode",
      "location": {"@type": "Place", "name": "Camera dei Deputati", "address": {"@type": "PostalAddress", "addressLocality": "Roma", "addressCountry": "IT"}},
      "performer": {"@id": "https://andreatroisi.it/#person"},
      "about": {"@id": "https://andreatroisi.it/#book-2018"},
      "description": "Conferenza stampa ufficiale di presentazione del volume, trasmessa in diretta su webtv.camera.it.",
      "url": "https://webtv.camera.it/evento/14114",
      "recordedIn": {"@type": "VideoObject", "name": "Presentazione libro \"Customer satisfaction nella P.A.\" - Conferenza stampa", "url": "https://webtv.camera.it/evento/14114", "uploadDate": "2019-03-29", "thumbnailUrl": "https://andreatroisi.it/wp-content/themes/andreatroisi-theme/img/camera-2019-webtv.jpg", "description": "Video completo della conferenza stampa alla Camera dei Deputati, 29 marzo 2019."},
      "image": "https://andreatroisi.it/wp-content/themes/andreatroisi-theme/img/camera-2019-conferenza.jpg"
    },
    {
      "@type": "ProfilePage",
      "@id": "https://andreatroisi.it/#profilepage",
      "url": "https://andreatroisi.it/",
      "name": "Andrea Troisi | Ricerca statistica e analisi dei dati",
      "inLanguage": "it-IT",
      "isPartOf": {"@id": "https://andreatroisi.it/#website"},
      "mainEntity": {"@id": "https://andreatroisi.it/#person"},
      "keywords": ["Ricerca statistica applicata", "Analisi dei dati", "Customer satisfaction nella Pubblica Amministrazione", "Benessere organizzativo", "Analisi territoriale"]
    },
    {
      "@type": "WebSite",
      "@id": "https://andreatroisi.it/#website",
      "url": "https://andreatroisi.it",
      "name": "Andrea Troisi — Ricerca, analisi dati, customer satisfaction e AI in Italia",
      "description": "Sito ufficiale di Andrea Troisi: fondatore di Troisi Ricerche, professore a contratto all'Universita' di Bari Aldo Moro, esperto di data science, AI applicata, customer satisfaction e governance territoriale. Attivo su scala nazionale con esperienza in progetti complessi per PA e imprese.",
      "publisher": {"@id": "https://andreatroisi.it/#person"},
      "inLanguage": "it-IT"
    }
  ]
}
</script>
<?php else : do_action( 'at_head_meta' ); endif; ?>


<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
