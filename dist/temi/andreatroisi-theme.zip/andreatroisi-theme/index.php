<?php get_header(); ?>


<!-- ═══════════════════ NAVIGAZIONE ═══════════════════ -->
<nav class="at-nav" id="at-nav">
  <a href="#top" class="nav-brand">Andrea <span>Troisi</span></a>
  <ul class="nav-links" id="nav-links">
    <li><a href="#about">Chi sono</a></li>
    <li><a href="#roles">Ruoli</a></li>
    <li><a href="#speaking">Speaking</a></li>
    <li><a href="#articles">Articoli</a></li>
    <li><a href="#books">Libri</a></li>
    <li><a href="#press">Stampa</a></li>
    <li><a href="#contact" class="nav-cta">Contatti</a></li>
  </ul>
  <button class="nav-hamburger" id="nav-hamburger" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>

<!-- ═══════════════════ HERO ═══════════════════ -->
<section class="at-hero" id="top">
  <div class="hero-bg-glow"></div>
  <div class="hero-bg-glow2"></div>
  <div class="hero-grain"></div>

  <div class="hero-left">
    <div class="hero-eyebrow"><span>Italia &middot; Bari &middot; Roma &middot; Milano</span></div>
    <h1 class="hero-name">Andrea<br><em>Troisi</em></h1>
    <p class="hero-tagline">Fondatore e Amministratore unico di Troisi Ricerche, istituto di ricerca statistica applicata attivo dal 2006 a Bari, Roma e Milano. Professore a contratto all'Universit&agrave; di Bari Aldo Moro, giornalista pubblicista. Ha presentato i suoi studi alla Camera dei Deputati (2019) e al Senato della Repubblica (2026).</p>
    <div class="hero-tags">
      <span class="hero-tag">Ricerca &amp; Analisi Dati</span>
      <span class="hero-tag">Customer Satisfaction PA</span>
      <span class="hero-tag">AI &amp; Data Science</span>
      <span class="hero-tag">Professore UniBA</span>
    </div>
    <div class="hero-cta">
      <a href="#about" class="btn-primary">Scopri di pi&ugrave;</a>
      <a href="#contact" class="btn-ghost">Contattami</a>
    </div>
  </div>

  <div class="hero-right">
    <div class="hero-photo-wrap">
      <div class="hero-photo-frame">
        <?php
        $hero_photo = get_template_directory_uri() . '/img/andrea-troisi-hero.jpg';
        $hero_photo_path = get_template_directory() . '/img/andrea-troisi-hero.jpg';
        if (file_exists($hero_photo_path)): ?>
          <img src="<?php echo $hero_photo; ?>" alt="Andrea Troisi">
        <?php else: ?>
          <div class="hero-photo-placeholder">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1">
              <circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
            </svg>
            <span>Foto Andrea Troisi</span>
          </div>
        <?php endif; ?>
      </div>
      <div class="hero-label">
        <div class="hero-label-name">Andrea Troisi</div>
        <div class="hero-label-sub">Ricerca &middot; Dati &middot; AI &middot; Governance</div>
      </div>
    </div>
  </div>
</section>

<!-- ─── HERO STATS ─── -->
<div class="hero-stats">
  <div class="stat-item">
    <div class="stat-num">500+</div>
    <div class="stat-label">Ricerche realizzate<br>in Italia</div>
  </div>
  <div class="stat-item">
    <div class="stat-num">200+</div>
    <div class="stat-label">Clienti tra PA<br>e imprese nazionali</div>
  </div>
  <div class="stat-item">
    <div class="stat-num">11</div>
    <div class="stat-label">Piattaforme<br>nell'ecosistema</div>
  </div>
  <div class="stat-item">
    <div class="stat-num">6</div>
    <div class="stat-label">Dipartimenti<br>Osservatorio</div>
  </div>
  <div class="stat-item">
    <div class="stat-num">2</div>
    <div class="stat-label">Libri pubblicati<br>Cacucci Editore</div>
  </div>
</div>

<!-- ═══════════════════ CHI SONO ═══════════════════ -->
<section class="at-about" id="about">
  <div class="about-text fade-in">
    <div class="section-label"><span>Chi sono</span></div>
    <h2 class="section-title">Dati, ricerca<br>e <em>innovazione</em></h2>
    <br>
    <p>Sono <strong>Andrea Troisi</strong>, fondatore di <strong>Troisi Ricerche</strong>, istituto di ricerca statistica applicata e analisi dei dati. Dal 2006, con sedi a Bari, Roma e Milano, lavoro su tre assi complementari: <strong>imprenditoria</strong>, <strong>ricerca accademica</strong> e <strong>giornalismo</strong>, con un filo conduttore che &egrave; sempre stato trasformare i dati in conoscenza utile per chi decide.</p>
    <p>Insegno all'<strong>Universit&agrave; degli Studi di Bari Aldo Moro</strong>, nel corso di laurea Nuovi Turismi del Dipartimento DIRIUM, <em>Economia delle Imprese Turistiche</em> e <em>Sistemi Informatici per il Turismo</em>. Dirigo l'<strong>Osservatorio sull'Innovazione del Mezzogiorno</strong> e ho costruito un ecosistema di 11 piattaforme digitali per la governance pubblica, l'analisi dati e l'intelligenza artificiale applicata, attivo su scala nazionale in contesti pubblici e privati italiani.</p>
    <div class="about-quote">
      <blockquote>&laquo;L'Italia ha bisogno di ricercatori che parlino il linguaggio dell'impresa, e di imprenditori che capiscano il valore dei dati.&raquo;</blockquote>
      <cite></cite>
    </div>
  </div>
  <div class="about-visual fade-in">
    <div class="about-card">
      <div class="about-card-title">Aree di attivit&agrave;</div>
      <ul class="about-list">
        <li>Ricerche di mercato e statistica applicata in contesti pubblici e privati</li>
        <li>Customer satisfaction e misurazione qualit&agrave; dei servizi pubblici</li>
        <li>Intelligenza artificiale applicata all'analisi dei dati</li>
        <li>Economia del turismo e destination management</li>
        <li>Innovazione e digitalizzazione della Pubblica Amministrazione</li>
        <li>Mappatura e certificazione delle competenze</li>
        <li>Indicatori compositi e modelli di performance (TR-Index, Metodo Troisi)</li>
        <li>Governance finanziaria, ESG e supporto decisionale</li>
        <li>Benessere organizzativo e analisi del clima aziendale</li>
        <li>Data governance, predictive analytics e piattaforme data driven</li>
      </ul>
    </div>
    <div class="about-card" style="margin-top:16px">
      <div class="about-card-title">Formazione</div>
      <ul class="about-list" style="font-size:.9rem">
        <li><strong>Laurea in Economia e Commercio</strong> — UniBA</li>
        <li><strong>Master di II Livello in Merchant Banking e Venture Capital</strong> — LIUC Università Cattaneo</li>
      </ul>
    </div>
    <div class="about-card" style="margin-top:16px">
      <div class="about-card-title">Socio delle principali societ&agrave; scientifiche internazionali e italiane</div>
      <ul class="soc-badges" aria-label="Societ&agrave; scientifiche e professionali di cui Andrea Troisi &egrave; socio">
        <li class="soc-badge"><a href="https://www.sis-statistica.it" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/sis.png" alt="Logo Società Italiana di Statistica" loading="lazy"></span><span class="soc-sigla">SIS</span><span class="soc-nome">Società Italiana di Statistica</span></a></li>
        <li class="soc-badge"><a href="https://www.isi-web.org" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/isi.png" alt="Logo International Statistical Institute" loading="lazy"></span><span class="soc-sigla">ISI</span><span class="soc-nome">International Statistical Institute</span></a></li>
        <li class="soc-badge"><a href="https://www.iaos-isi.org" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/iaos.png" alt="Logo International Association for Official Statistics" loading="lazy"></span><span class="soc-sigla">IAOS</span><span class="soc-nome">International Association for Official Statistics · ISI</span></a></li>
        <li class="soc-badge"><a href="https://isi-iass.org" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/iass.png" alt="Logo International Association of Survey Statisticians" loading="lazy"></span><span class="soc-sigla">IASS</span><span class="soc-nome">International Association of Survey Statisticians · ISI</span></a></li>
        <li class="soc-badge"><a href="https://isbis.isi-web.org" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/isbis.png" alt="Logo International Society for Business and Industrial Statistics" loading="lazy"></span><span class="soc-sigla">ISBIS</span><span class="soc-nome">International Society for Business and Industrial Statistics · ISI</span></a></li>
        <li class="soc-badge"><a href="https://rss.org.uk" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/rss.png" alt="Logo Royal Statistical Society" loading="lazy"></span><span class="soc-sigla">RSS</span><span class="soc-nome">Royal Statistical Society · Fellow</span></a></li>
        <li class="soc-badge"><a href="https://www.ams.org" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/ams.png" alt="Logo American Mathematical Society" loading="lazy"></span><span class="soc-sigla">AMS</span><span class="soc-nome">American Mathematical Society</span></a></li>
        <li class="soc-badge"><a href="https://www.aiquav.it" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/aiquav.png" alt="Logo Associazione Italiana per gli Studi sulla Qualità della Vita" loading="lazy"></span><span class="soc-sigla">AIQUAV</span><span class="soc-nome">Associazione Italiana per gli Studi sulla Qualità della Vita</span></a></li>
        <li class="soc-badge"><a href="https://www.odg.it" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/soc/odg.png" alt="Logo Ordine dei Giornalisti" loading="lazy"></span><span class="soc-sigla">ODG</span><span class="soc-nome">Ordine dei Giornalisti · pubblicisti</span></a></li>
      </ul>
    </div>
    <div class="about-card" style="margin-top:16px">
      <div class="about-card-title">Profili di ricerca</div>
      <ul class="soc-badges" aria-label="Profili di ricerca di Andrea Troisi">
        <li class="soc-badge"><a href="https://orcid.org/0009-0006-2618-2254" target="_blank" rel="noopener me"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/prof/orcid.svg" alt="Logo ORCID" loading="lazy" style="height:46px"></span><span class="soc-sigla">ORCID</span><span class="soc-nome">0009-0006-2618-2254 ↗</span></a></li>
        <li class="soc-badge"><a href="https://scholar.google.com/citations?user=sAs8jkAAAAAJ" target="_blank" rel="noopener me"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/prof/scholar.svg" alt="Logo Google Scholar" loading="lazy" style="height:46px"></span><span class="soc-sigla">Google Scholar</span><span class="soc-nome">Pubblicazioni e citazioni ↗</span></a></li>
        <li class="soc-badge"><a href="https://www.wikidata.org/wiki/Q141611566" target="_blank" rel="noopener"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/prof/wikidata.svg" alt="Logo Wikidata" loading="lazy" style="height:34px"></span><span class="soc-sigla">Wikidata</span><span class="soc-nome">Q141611566 ↗</span></a></li>
        <li class="soc-badge"><a href="https://www.researchgate.net/profile/Andrea-Troisi" target="_blank" rel="noopener me"><span class="soc-logo"><img src="<?php echo get_template_directory_uri(); ?>/img/prof/researchgate.svg" alt="Logo ResearchGate" loading="lazy" style="height:46px"></span><span class="soc-sigla">ResearchGate</span><span class="soc-nome">Pubblicazioni e letture ↗</span></a></li>
      </ul>
    </div>
  </div>
</section>

<!-- ═══════════════════ NUMERI ═══════════════════ -->
<div class="at-numbers">
  <div class="number-item fade-in">
    <div class="number-num">500+</div>
    <div class="number-desc">Ricerche<br>in Italia</div>
  </div>
  <div class="number-item fade-in">
    <div class="number-num">20+</div>
    <div class="number-desc">Anni ricerca<br>&amp; impresa</div>
  </div>
  <div class="number-item fade-in">
    <div class="number-num">200+</div>
    <div class="number-desc">Clienti PA<br>&amp; imprese</div>
  </div>
  <div class="number-item fade-in">
    <div class="number-num">11</div>
    <div class="number-desc">Piattaforme<br>ecosistema</div>
  </div>
  <div class="number-item fade-in">
    <div class="number-num">2</div>
    <div class="number-desc">Libri<br>Cacucci Editore</div>
  </div>
</div>

<!-- ═══════════════════ GALLERIA — NASCOSTA TEMPORANEAMENTE ═══════════════════ -->
<section class="at-gallery" style="display:none">
  <div class="section-label"><span>Momenti</span></div>
  <h2 class="section-title" style="color:white">In campo,<br>sul <em>palco</em>, tra le idee</h2>
  <div class="slideshow" id="slideshow">
    <div class="slide active">
      <?php if(file_exists(get_template_directory() . '/img/andrea-troisi-hero.jpg')): ?>
        <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/andrea-troisi-hero.jpg" alt="Andrea Troisi">
      <?php else: ?><div class="slide-placeholder"><div class="slide-placeholder-icon">&#x1F3E0;</div></div><?php endif; ?>
      <div class="slide-caption"><div class="slide-caption-title">Presentazione "Canone Giusto"</div><div class="slide-caption-sub">Palazzo della Città · Comune di Bari · Ottobre 2025</div></div>
    </div>
    <div class="slide">
      <?php if(file_exists(get_template_directory() . '/img/uniba-lezione.jpg')): ?>
        <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/uniba-lezione.jpg" alt="UniBA lezione">
      <?php else: ?><div class="slide-placeholder"><div class="slide-placeholder-icon">&#x1F393;</div></div><?php endif; ?>
      <div class="slide-caption"><div class="slide-caption-title">Università degli Studi di Bari</div><div class="slide-caption-sub">Corso «Sistemi Informatici per il Turismo» · Laurea Nuovi Turismi · 2025</div></div>
    </div>
    <div class="slide">
      <?php if(file_exists(get_template_directory() . '/img/fondimpresa-roma-2025-banner.webp')): ?>
        <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/fondimpresa-roma-2025-banner.webp" alt="Fondimpresa Roma">
      <?php else: ?><div class="slide-placeholder"><div class="slide-placeholder-icon">&#x1F3DB;</div></div><?php endif; ?>
      <div class="slide-caption"><div class="slide-caption-title">Fondimpresa — «Nuove Corsie per il Lavoro»</div><div class="slide-caption-sub">Corsie Sistine · Santo Spirito in Sassia · Roma · 2025</div></div>
    </div>
    <div class="slide">
      <?php if(file_exists(get_template_directory() . '/img/cibari-2025-new-1.webp')): ?>
        <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/cibari-2025-new-1.webp" alt="CiBari 2025">
      <?php else: ?><div class="slide-placeholder"><div class="slide-placeholder-icon">&#x1F34A;</div></div><?php endif; ?>
      <div class="slide-caption"><div class="slide-caption-title">CiBari 2025 — Il Cibo della Salute</div><div class="slide-caption-sub">Piazza del Ferrarese · Bari · Membro Comitato Tecnico-Scientifico · 3ª edizione</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/camera-deputati-2.webp" alt="Camera dei Deputati">
      <div class="slide-caption"><div class="slide-caption-title">Camera dei Deputati — Roma</div><div class="slide-caption-sub">Presentazione del modello di competenze della Governance Finanziaria · 25 marzo 2022</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/camera-deputati-1.webp" alt="Convegno Camera dei Deputati">
      <div class="slide-caption"><div class="slide-caption-title">Convegno istituzionale</div><div class="slide-caption-sub">Conferenza stampa · Camera dei Deputati, Roma · 2022</div></div>
    </div>
    <div class="slide">
      <?php if(file_exists(get_template_directory() . '/img/parlIAmone.jpg')): ?>
        <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/parlIAmone.jpg" alt="parlIAmone">
      <?php else: ?><div class="slide-placeholder"><div class="slide-placeholder-icon">&#x1F916;</div></div><?php endif; ?>
      <div class="slide-caption"><div class="slide-caption-title">parlIAmone — AI &amp; Compliance</div><div class="slide-caption-sub">Domus Libraria Cacucci · Bari · Con Cacucci Editore · 2025</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/forum-pa-2.jpg" alt="Forum Pubblici Ufficiali 2025">
      <div class="slide-caption"><div class="slide-caption-title">Forum Pubblici Ufficiali — II Edizione</div><div class="slide-caption-sub">Venerdì 4 Aprile 2025 · Bari</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/cibari-2025-c.jpg" alt="CiBari 2025">
      <div class="slide-caption"><div class="slide-caption-title">CiBari 2025 — Conferenza stampa</div><div class="slide-caption-sub">Palazzo della Città Metropolitana di Bari · 16 Ottobre 2025</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/canone-giusto-b.jpg" alt="Canone Giusto team">
      <div class="slide-caption"><div class="slide-caption-title">Canone Giusto — Il team</div><div class="slide-caption-sub">Palazzo della Città · Comune di Bari · Ottobre 2025</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/tgr-puglia.jpg" alt="TGR Puglia">
      <div class="slide-caption"><div class="slide-caption-title">Intervista TGR Puglia</div><div class="slide-caption-sub">Rubrica «Puglia che va» — Ricerca, impresa e sviluppo nel Sud Italia · RAI 2023</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/scriba-evento.jpg" alt="Evento Scriba">
      <div class="slide-caption"><div class="slide-caption-title">Lancio Scriba — Archivio Digitale</div><div class="slide-caption-sub">Relatore al lancio ufficiale · Bari · 2024</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/assoradio-fiera-levante-2.jpg" alt="Assoradio Fiera del Levante">
      <div class="slide-caption"><div class="slide-caption-title">Assoradio — Indagine Radio Puglia</div><div class="slide-caption-sub">Fiera del Levante · Bari · Ottobre 2024 · Troisi Ricerche</div></div>
    </div>
    <div class="slide">
      <img class="slide-img" src="<?php echo get_template_directory_uri(); ?>/img/accademia-nicolaiana-sassoli.jpg" alt="Accademia Cittadella Nicolaiana">
      <div class="slide-caption"><div class="slide-caption-title">Accademia Cittadella Nicolaiana</div><div class="slide-caption-sub">Con l'on. David Sassoli, Presidente Onorario · Bari · 2019</div></div>
    </div>
    <div class="slide-controls">
      <button class="slide-btn" onclick="slidePrev()">← Prec</button>
      <div class="slide-dots" id="slide-dots"></div>
      <div class="slide-counter"><span id="slide-cur">1</span> / <span id="slide-tot">4</span></div>
      <button class="slide-btn" onclick="slideNext()">Succ →</button>
    </div>
  </div>
</section>

<!-- ═══════════════════ VIDEO YOUTUBE ═══════════════════ -->
<section class="at-video" id="video">
  <div class="section-label"><span>Video</span></div>
  <h2 class="section-title">Interventi<br>& <em>ricerche</em> in video</h2>
  <p style="font-size:.9rem;color:var(--text-light);margin-top:12px;margin-bottom:36px;max-width:560px">
    Dai canali YouTube di <strong>Troisi Ricerche</strong> e dell'<strong>Osservatorio sull'Innovazione del Mezzogiorno</strong>
  </p>
  <div class="video-grid">
    <a href="https://www.youtube.com/watch?v=UWvHMezg4ts" target="_blank" rel="noopener" class="video-card">
      <div class="video-thumb"><img src="https://img.youtube.com/vi/UWvHMezg4ts/mqdefault.jpg" alt="Video Troisi Ricerche" loading="lazy"><div class="video-play"><div class="video-play-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg></div></div><div style="position:absolute;top:10px;left:10px;background:rgba(13,27,42,.8);padding:3px 8px;font-size:.6rem;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)">Troisi Ricerche</div></div>
      <div class="video-info"><div class="video-title">Troisi Ricerche — Ricerca e innovazione</div></div>
    </a>
    <a href="https://www.youtube.com/watch?v=7FlwW_9RKI0" target="_blank" rel="noopener" class="video-card">
      <div class="video-thumb"><img src="https://img.youtube.com/vi/7FlwW_9RKI0/mqdefault.jpg" alt="Video Troisi Ricerche" loading="lazy"><div class="video-play"><div class="video-play-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg></div></div><div style="position:absolute;top:10px;left:10px;background:rgba(13,27,42,.8);padding:3px 8px;font-size:.6rem;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)">Troisi Ricerche</div></div>
      <div class="video-info"><div class="video-title">Troisi Ricerche — Analisi e dati</div></div>
    </a>
    <a href="https://www.youtube.com/watch?v=zB1iZVjzK5k" target="_blank" rel="noopener" class="video-card">
      <div class="video-thumb"><img src="https://img.youtube.com/vi/zB1iZVjzK5k/mqdefault.jpg" alt="Video Troisi Ricerche" loading="lazy"><div class="video-play"><div class="video-play-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg></div></div><div style="position:absolute;top:10px;left:10px;background:rgba(13,27,42,.8);padding:3px 8px;font-size:.6rem;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)">Osservatorio</div></div>
      <div class="video-info"><div class="video-title">Osservatorio Mezzogiorno — Innovazione</div></div>
    </a>
    <a href="https://www.youtube.com/watch?v=M9UDGUVUivo" target="_blank" rel="noopener" class="video-card">
      <div class="video-thumb"><img src="https://img.youtube.com/vi/M9UDGUVUivo/mqdefault.jpg" alt="Video Osservatorio Mezzogiorno" loading="lazy"><div class="video-play"><div class="video-play-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg></div></div><div style="position:absolute;top:10px;left:10px;background:rgba(13,27,42,.8);padding:3px 8px;font-size:.6rem;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)">Osservatorio</div></div>
      <div class="video-info"><div class="video-title">Osservatorio Mezzogiorno — Territorio</div></div>
    </a>
    <a href="https://www.youtube.com/watch?v=KxSZIcEX170" target="_blank" rel="noopener" class="video-card">
      <div class="video-thumb"><img src="https://img.youtube.com/vi/KxSZIcEX170/mqdefault.jpg" alt="Video Troisi Ricerche" loading="lazy"><div class="video-play"><div class="video-play-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg></div></div><div style="position:absolute;top:10px;left:10px;background:rgba(13,27,42,.8);padding:3px 8px;font-size:.6rem;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)">Troisi Ricerche</div></div>
      <div class="video-info"><div class="video-title">Troisi Ricerche — Convegni e eventi</div></div>
    </a>
    <a href="https://www.youtube.com/watch?v=SmIAaspOyvI" target="_blank" rel="noopener" class="video-card">
      <div class="video-thumb"><img src="https://img.youtube.com/vi/SmIAaspOyvI/mqdefault.jpg" alt="Video Osservatorio Mezzogiorno" loading="lazy"><div class="video-play"><div class="video-play-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="white"><polygon points="5,3 19,12 5,21"/></svg></div></div><div style="position:absolute;top:10px;left:10px;background:rgba(13,27,42,.8);padding:3px 8px;font-size:.6rem;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)">Osservatorio</div></div>
      <div class="video-info"><div class="video-title">Osservatorio Mezzogiorno — Sud Italia</div></div>
    </a>
  </div>
  <div style="text-align:center;margin-top:36px;display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
    <a href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener" class="btn-ghost" style="border-color:rgba(13,27,42,.2);color:var(--navy)">Troisi Ricerche su YouTube</a>
    <a href="https://www.youtube.com/@osservatoriomezzogiorno" target="_blank" rel="noopener" class="btn-ghost" style="border-color:rgba(13,27,42,.2);color:var(--navy)">Osservatorio Mezzogiorno</a>
  </div>
</section>

<!-- ═══════════════════ RUOLI ═══════════════════ -->
<section class="at-roles" id="roles">
  <div class="section-label"><span>Attività e ruoli</span></div>
  <h2 class="section-title">Dove opero,<br>cosa <em>costruisco</em></h2>
  <div class="roles-grid" style="margin-top:48px">
    <div class="role-item fade-in">
      <div class="role-num">01</div>
      <div class="role-name">Direttore Generale</div>
      <div class="role-org">Osservatorio sull'Innovazione del Mezzogiorno</div>
      <div class="role-desc">Think tank indipendente con sede a Bari, Roma e Milano. Sei dipartimenti di ricerca su innovazione, sostenibilità, turismo, formazione, PA e welfare.</div>
      <a href="https://www.osservatoriomezzogiorno.net" target="_blank" rel="noopener" class="role-link">osservatoriomezzogiorno.net ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">02</div>
      <div class="role-name">Amministratore</div>
      <div class="role-org">Troisi Ricerche S.r.l.</div>
      <div class="role-desc">Istituto di ricerca statistica fondato nel 2006. Specializzato in ricerche di mercato, customer satisfaction, analisi territoriali e studi economici. Ente accreditato MIUR come Ente di Formazione.</div>
      <a href="https://troisiricerche.net" target="_blank" rel="noopener" class="role-link">troisiricerche.net ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">03</div>
      <div class="role-name">Amministratore</div>
      <div class="role-org">Ti Quadro S.r.l.</div>
      <div class="role-desc">Realtà operante nel settore della comunicazione, consulenza strategica e sviluppo di soluzioni digitali per imprese e istituzioni pubbliche. Partner per progetti di innovazione.</div>
      <a href="https://www.ti-quadro.com/" target="_blank" rel="noopener" class="role-link">ti-quadro.com ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">04</div>
      <div class="role-name">Amministratore</div>
      <div class="role-org">Smarticall — Start-up Innovativa</div>
      <div class="role-desc">Startup innovativa nel settore delle tecnologie per la comunicazione e l'intelligenza artificiale applicata ai servizi. Iscritta al Registro Nazionale Startup Innovative.</div>
      <a href="https://www.smarticall.com" target="_blank" rel="noopener" class="role-link">smarticall.com ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">05</div>
      <div class="role-name">Professore Universitario</div>
      <div class="role-org">Università degli Studi di Bari "Aldo Moro"</div>
      <div class="role-desc">Docente di Economia delle Imprese Turistiche. Attività di ricerca su economia del turismo, modelli d'impresa territoriali e strategie di sviluppo locale per il Mezzogiorno.</div>
      <a href="https://www.uniba.it/it/corsi/nuovi-turismi/attivita-formative/programmi-a-a-2025-2026" target="_blank" rel="noopener" class="role-link">uniba.it — Programmi 2025/2026 ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">06</div>
      <div class="role-name">Giornalista</div>
      <div class="role-org">Economia · Innovazione · Territorio</div>
      <div class="role-desc">187 articoli pubblicati su Radio Notizie. Analisi e commento su temi di economia, innovazione tecnologica, politiche del lavoro e sviluppo del Mezzogiorno d'Italia.</div>
      <a href="https://www.radionotizie.eu/author/andrea-troisi" target="_blank" rel="noopener" class="role-link">radionotizie.eu ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">07</div>
      <div class="role-name">Socio Fondatore</div>
      <div class="role-org">Fondazione Attua</div>
      <div class="role-desc">Fondazione impegnata nella promozione dell'innovazione sociale, della cultura d'impresa e dello sviluppo del capitale umano nel Mezzogiorno. Percorsi di mentoring e formazione.</div>
      <a href="https://fondazioneattua.org/" target="_blank" rel="noopener" class="role-link">fondazioneattua.org ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">08</div>
      <div class="role-name">Vice Presidente</div>
      <div class="role-org">Accademia Cittadella Nicolaiana · Bari</div>
      <div class="role-desc">L'Accademia gestisce il Museo Nicolaiano e il Caffè dell'Accademia nel cuore della Cittadella di San Nicola a Bari. Valorizzazione del patrimonio storico e culturale pugliese.</div>
      <a href="https://accademiacittadellanicolaiana.it/" target="_blank" rel="noopener" class="role-link">accademiacittadellanicolaiana.it ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">09</div>
      <div class="role-name">Responsabile Statistico e della Comunicazione</div>
      <div class="role-org">Agenzia Sociale per la Casa — Città di Bari</div>
      <div class="role-desc">Responsabile statistico e della comunicazione istituzionale dell'Agenzia Sociale per la Casa del Comune di Bari. Ideatore del modello <strong style="color:var(--gold-light)">"Canone Giusto"</strong>: la piattaforma digitale — prima del genere in Italia — che traduce gli Accordi Territoriali del Comune di Bari in uno strumento semplice, trasparente e verificabile per il calcolo del canone concordato. Presentata in conferenza stampa monotematica all'8 ottobre 2025 a Palazzo della Città.</div>
      <a href="https://www.agenziasocialecasabari.it" target="_blank" rel="noopener" class="role-link">agenziasocialecasabari.it ↗</a>
    </div>
    <div class="role-item fade-in">
      <div class="role-num">10</div>
      <div class="role-name">Segretario Generale</div>
      <div class="role-org">Barispac</div>
      <div class="role-desc">Barispac è il progetto di azionariato popolare diffuso per il Bari Calcio, ispirato al modello del Bayern Monaco. L'associazione promuove la partecipazione dei tifosi nella proprietà del club, integrando risorse dei sostenitori con quelle di investitori qualificati, con l'obiettivo di dare ai tifosi baresi una voce nella governance della squadra.</div>
      <a href="https://www.barispac.it" target="_blank" rel="noopener" class="role-link">barispac.it ↗</a>
    </div>
  </div>
</section>

<!-- ═══════════════════ SPEAKING & CONVEGNI ═══════════════════ -->
<section class="at-speaking" id="speaking">
  <div class="section-label"><span>Speaking & Convegni</span></div>
  <h2 class="section-title">Sul <em>palco</em>,<br>tra le idee</h2>
  <div class="speaking-grid">
    <?php foreach ( at_eventi_ordinati() as $k => $e ) : ?>
    <a class="speaking-card fade-in" data-event="<?php echo esc_attr( $k ); ?>" href="<?php echo esc_url( at_evento_url( $k ) ); ?>">
      <div class="speaking-year"><?php echo esc_html( substr( $e['data'], 0, 4 ) ); ?></div>
      <div class="speaking-event"><?php echo esc_html( $e['titolo_breve'] ); ?></div>
      <div class="speaking-where"><?php echo esc_html( $e['sintesi'] ); ?></div>
      <div class="speaking-open-hint">Leggi l'intervento &rarr;</div>
      <span class="speaking-tag"><?php echo esc_html( $e['tema'] ); ?></span>
    </a>
    <?php endforeach; ?>
  </div>
  <div style="text-align:center;margin:8px 0 40px"><a href="<?php echo esc_url( at_evento_url() ); ?>" class="btn-ghost" style="border-color:rgba(13,27,42,.2);color:var(--navy)">Tutti gli interventi &rarr;</a><?php if ( at_eventi_ordinati( 'campo' ) ) : ?> <a href="<?php echo esc_url( at_evento_url( '', 'campo' ) ); ?>" class="btn-ghost" style="border-color:rgba(13,27,42,.2);color:var(--navy);margin-left:12px">Sul campo: progetti con istituzioni e imprese &rarr;</a><?php endif; ?></div>
  <div class="speaking-cta">
    <div class="speaking-cta-text">Sei interessato ad invitare Andrea<br>come <span>relatore o ospite</span>?</div>
    <a href="#contact" class="btn-primary">Prenota un incontro</a>
  </div>
</section>

<!-- ═══════════════════ ARTICOLI ═══════════════════ -->
<section class="at-articles" id="articles">
  <div class="section-label"><span>Articoli & pensieri</span></div>
  <h2 class="section-title">Cosa scrivo,<br>cosa <em>penso</em></h2>
  <?php $at_ultimi = function_exists( 'at_articoli' ) ? array_slice( at_articoli(), 0, 6 ) : array(); ?>
  <?php if ( $at_ultimi ) : ?>
  <div class="articles-grid">
    <?php foreach ( $at_ultimi as $a ) { echo at_articolo_card( $a, true ); } // phpcs:ignore ?>
  </div>
  <div style="text-align:center;margin-top:48px">
    <a href="<?php echo esc_url( at_articoli_url() ); ?>" class="btn-ghost" style="border-color:rgba(13,27,42,.2);color:var(--navy)">Tutti gli articoli (<?php echo count( at_articoli() ); ?>) →</a>
  </div>
  <?php else : ?>
  <div class="articles-grid">
    <div class="article-card fade-in">
      <div class="article-date">Luglio 2025</div>
      <span class="article-tag">Economia</span>
      <div class="article-title">Dazi ieri e oggi: evoluzione storica e guerra commerciale nell'era Trump</div>
      <div class="article-excerpt">Un'analisi storica ed economica sull'evoluzione dei dazi commerciali, dal dopoguerra alle tensioni geopolitiche contemporanee.</div>
      <a href="https://www.radionotizie.eu/author/andrea-troisi" target="_blank" rel="noopener" class="article-link">Leggi su Radio Notizie →</a>
    </div>
    <div class="article-card fade-in">
      <div class="article-date">Luglio 2025</div>
      <span class="article-tag">Sud Italia</span>
      <div class="article-title">Ilva di Taranto: storia del grande acciaio tra sviluppo, inquinamento e futuro incerto</div>
      <div class="article-excerpt">Dal sogno industriale alla crisi: il più grande impianto siderurgico d'Europa e il destino di una città.</div>
      <a href="https://www.radionotizie.eu/author/andrea-troisi" target="_blank" rel="noopener" class="article-link">Leggi su Radio Notizie →</a>
    </div>
    <div class="article-card fade-in">
      <div class="article-date">Giugno 2025</div>
      <span class="article-tag">Economia</span>
      <div class="article-title">Rapporto Bankitalia 2025: cosa ci dicono i dati sull'Italia che cambia</div>
      <div class="article-excerpt">Lettura e analisi del rapporto annuale della Banca d'Italia: crescita, mercato del lavoro e divari territoriali.</div>
      <a href="https://www.radionotizie.eu/author/andrea-troisi" target="_blank" rel="noopener" class="article-link">Leggi su Radio Notizie →</a>
    </div>
  </div>
  <div style="text-align:center;margin-top:48px">
    <a href="https://www.radionotizie.eu/author/andrea-troisi" target="_blank" rel="noopener" class="btn-ghost" style="border-color:rgba(13,27,42,.2);color:var(--navy)">Tutti gli articoli su Radio Notizie →</a>
  </div>
  <?php endif; ?>
</section>

<!-- ═══════════════════ LIBRO ═══════════════════ -->

<div class="at-books-header" id="books">
  <div class="section-label"><span>Pubblicazioni scientifiche</span></div>
  <h2 class="section-title" style="color:white">Due contributi<br>alla <em>ricerca</em> applicata</h2>
</div>

<!-- LIBRO 2 — nuovo, in evidenza -->
<section class="at-book">
  <div class="fade-in">
    <img class="book-cover-img"
         src="<?php echo get_template_directory_uri(); ?>/img/libro-organizzazioni-copertina.jpg"
         alt="Le organizzazioni che si misurano — Andrea Troisi, Cacucci Editore 2026">
  </div>
  <div class="book-info fade-in">
    <div class="section-label" style="margin-bottom:12px"><span style="background:var(--gold);color:var(--navy);border-color:var(--gold);padding:4px 12px;font-weight:600;">NUOVO · 2026</span></div>
    <h3 class="section-title" style="color:white;font-size:clamp(1.4rem,2.5vw,2rem);">Le organizzazioni<br>che si <em>misurano</em></h3>
    <p class="book-desc" style="margin-top:12px;">Il benessere organizzativo non è un adempimento. È una scelta culturale. Attraverso un modello in sei dimensioni — clima, leadership, carico, digitale, autonomia, equità — il volume guida dirigenti, responsabili HR e ricercatori in un percorso che va dalla compliance alla consapevolezza: dai dati alle decisioni, dalla misurazione alla responsabilità condivisa.</p>
    <div class="book-meta">
      <div class="book-meta-item"><span>Editore</span><span>Cacucci Editore, Bari</span></div>
      <div class="book-meta-item"><span>Anno</span><span>2026</span></div>
      <div class="book-meta-item"><span>Autore</span><span>Andrea Troisi</span></div>
      <div class="book-meta-item"><span>Prezzo</span><span>€ 15,00</span></div>
      <div class="book-meta-item"><span>Area</span><span>Benessere organizzativo · Management · PA</span></div>
      <div class="book-meta-item"><span>Web</span><span><a href="https://www.benessereorganizzativo.it" target="_blank" rel="noopener" style="color:var(--gold)">www.benessereorganizzativo.it</a></span></div>
      <div class="book-meta-item"><span>Presentazione</span><span>Senato della Repubblica · Roma, 15 giugno 2026</span></div>
    </div>
    <div class="book-senato" onclick="location.href='<?php echo esc_url( at_evento_url( 'senato-2026' ) ); ?>'" style="cursor:pointer">
      <img src="<?php echo get_template_directory_uri(); ?>/img/senato-2026-podio.webp" alt="Andrea Troisi presenta il libro Le organizzazioni che si misurano al Senato della Repubblica, 15 giugno 2026" loading="lazy">
      <div>
        <div class="book-senato-kicker">Presentato al Senato della Repubblica</div>
        <div class="book-senato-text">Palazzo Madama, Sala Caduti di Nassirya · 15 giugno 2026. Con il volume Andrea Troisi ha presentato l'<strong>Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate</strong>, da lui promosso, l'<strong>IBO Score</strong> e l'<strong>Oscar del Benessere Organizzativo</strong>.</div>
        <div class="book-senato-hint">&#9654; Guarda foto &amp; media</div>
      </div>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:12px">
      <a href="https://www.benessereorganizzativo.it" target="_blank" rel="noopener" class="btn-primary">Scopri il libro →</a>
      <a href="https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/" target="_blank" rel="noopener" class="btn-ghost">Leggi l'articolo su Lo Speciale ↗</a>
    </div>
  </div>
</section>

<!-- LIBRO 1 — 2018 -->
<section class="at-book">
  <div class="book-cover fade-in">
    <div class="book-cover-inner">
      <div class="book-cover-label">Pubblicazione scientifica · 2018</div>
      <div class="book-cover-title">Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione</div>
      <div class="book-cover-author">Andrea Troisi</div>
    </div>
  </div>
  <div class="book-info fade-in">
    <h3 class="section-title" style="color:white;font-size:clamp(1.2rem,2vw,1.7rem);">Un modello statistico<br>per la <em>Customer Satisfaction</em><br>nella PA</h3>
    <br>
    <p class="book-desc">Un contributo scientifico che unisce <strong style="color:var(--fog)">statistica applicata</strong>, marketing research e valutazione delle politiche pubbliche. Il modello elaborato da Troisi Ricerche per misurare e migliorare la qualità dei servizi pubblici attraverso l'analisi della soddisfazione del cittadino.</p>
    <div class="book-meta">
      <div class="book-meta-item"><span>Editore</span><span>Cacucci Editore, Bari</span></div>
      <div class="book-meta-item"><span>ISBN</span><span>978-88-6611-797-1</span></div>
      <div class="book-meta-item"><span>Anno</span><span>2018</span></div>
      <div class="book-meta-item"><span>Autore</span><span>Andrea Troisi</span></div>
      <div class="book-meta-item"><span>Area</span><span>Statistica applicata · Customer satisfaction · PA</span></div>
      <div class="book-meta-item"><span>Presentazione</span><span>Camera dei Deputati · Roma, 29 marzo 2019</span></div>
    </div>
    <div class="book-senato" onclick="location.href='<?php echo esc_url( at_evento_url( 'camera-2019' ) ); ?>'" style="cursor:pointer">
      <img src="<?php echo get_template_directory_uri(); ?>/img/camera-2019-conferenza.webp" alt="Andrea Troisi presenta il volume sulla Customer Satisfaction nella PA alla Camera dei Deputati, 29 marzo 2019" loading="lazy">
      <div>
        <div class="book-senato-kicker">Presentato alla Camera dei Deputati</div>
        <div class="book-senato-text">Roma · 29 marzo 2019 · Conferenza stampa ufficiale di presentazione del volume e del modello statistico per misurare la <strong>soddisfazione dei cittadini</strong> e la <strong>qualità dei servizi pubblici</strong>. Trasmessa in diretta su <strong>webtv.camera.it</strong> e disponibile nell'archivio parlamentare.</div>
        <div class="book-senato-hint">&#9654; Guarda foto &amp; media</div>
      </div>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:12px">
      <a href="https://www.cacuccieditore.it/troisi-andrea-2" target="_blank" rel="noopener" class="btn-primary">Acquista su Cacucci Editore →</a>
      <a href="https://webtv.camera.it/evento/14114" target="_blank" rel="noopener" class="btn-ghost">Guarda il video su webtv.camera.it ↗</a>
    </div>
  </div>
</section>

<!-- ═══════════════════ RASSEGNA STAMPA ═══════════════════ -->
<section class="at-press" id="press">
  <div class="section-label"><span>Rassegna stampa</span></div>
  <h2 class="section-title">Come <em>parlano</em><br>di me</h2>
  <div class="press-grid">
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/','_blank')">
      <div class="press-outlet">Lo Speciale &#8599;</div>
      <div class="press-headline">«Presentato al Senato il primo Osservatorio in Italia sul benessere organizzativo delle società partecipate» — l'Osservatorio promosso da Andrea Troisi, il suo volume, l'IBO Score e l'Oscar del Benessere Organizzativo</div>
      <div class="press-date">15 Giugno 2026</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.takethedate.it/Eventi/54392-conferenza-stampa-presentazione-del-libro-le-organizzazioni-che-si-misurano.html','_blank')">
      <div class="press-outlet">Take The Date &#8599;</div>
      <div class="press-headline">Conferenza stampa al Senato: presentazione del libro «Le organizzazioni che si misurano» — agenda istituzionale, eventi al Senato</div>
      <div class="press-date">15 Giugno 2026 · Roma</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.ilmessaggero.it/italia/quel_sogno_chiamato_smart_city_pnrr_convegno_bari_innovazione_mezzogiorno-9114869.html','_blank')">
      <div class="press-outlet">Il Messaggero &#8599;</div>
      <div class="press-headline">«Quel sogno chiamato Smart City» — Convegno al Politecnico di Bari sull'innovazione del Mezzogiorno</div>
      <div class="press-date">Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.corrieredelleconomia.it/2025/10/13/osservatorio-sullinnovazione-del-mezzogiorno-smart-city-la-sfida-e-nelle-competenze/','_blank')">
      <div class="press-outlet">Corriere dell'Economia &#8599;</div>
      <div class="press-headline">«Smart City, la sfida è nelle competenze» — Osservatorio sull'Innovazione del Mezzogiorno</div>
      <div class="press-date">13 Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.bitmat.it/vertical/smart-home-city/smart-city-10-miliardi-dal-pnrr-ma-il-sud-resta-indietro/','_blank')">
      <div class="press-outlet">BitMAT &#8599;</div>
      <div class="press-headline">«Smart City: 10 miliardi dal PNRR, ma il Sud resta indietro» — Andrea Troisi, direttore dell'Osservatorio sull'Innovazione del Mezzogiorno, al convegno del Politecnico di Bari</div>
      <div class="press-date">10 Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.milanofinanza.it/news/quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-troppo-indietro-202510081638248255','_blank')">
      <div class="press-outlet">MF Milano Finanza &#8599;</div>
      <div class="press-headline">«Quel sogno chiamato smart city, ma il Sud è ancora troppo indietro» — il convegno al Politecnico di Bari dell'Osservatorio sull'Innovazione del Mezzogiorno con Fondimpresa</div>
      <div class="press-date">8 Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.oggiquotidiano.it/economia/102543-quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-troppo-indietro/','_blank')">
      <div class="press-outlet">Oggi Quotidiano &#8599;</div>
      <div class="press-headline">«Quel sogno chiamato Smart City ma il Sud è ancora troppo indietro» — il convegno al Politecnico di Bari con Fondimpresa</div>
      <div class="press-date">7 Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://norbaonline.it/2025/10/03/citta-smart-levento-promosso-dal-politecnico-di-bari/','_blank')">
      <div class="press-outlet">Norba Online / Telenorba &#8599;</div>
      <div class="press-headline">«Città smart, l'evento promosso dal Politecnico di Bari» — servizio televisivo regionale</div>
      <div class="press-date">3 Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.baritoday.it/economia/bari-attiva-portale-canone-giusto-procedure-chiare-calcolo-affitti.html','_blank')">
      <div class="press-outlet">BariToday &#8599;</div>
      <div class="press-headline">Attivo il portale «Canone Giusto»: la prima piattaforma in Italia per il calcolo del canone concordato</div>
      <div class="press-date">Ottobre 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.corrieredelleconomia.it/2025/07/31/osservatorio-sullinnovazione-nel-mezzogiorno-strategie-e-orizzonti-per-governare-lai-nella-pubblica-amministrazione/','_blank')">
      <div class="press-outlet">Corriere dell'Economia &#8599;</div>
      <div class="press-headline">«Strategie e orizzonti per governare l'AI nella Pubblica Amministrazione» — dopo il Convegno di Parma</div>
      <div class="press-date">31 Luglio 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://finanza.ilsecoloxix.it/News/2025/07/07/IA-crescono-investimenti-della-Pubblica-amministrazione/','_blank')">
      <div class="press-outlet">Il Secolo XIX / Finanza &#8599;</div>
      <div class="press-headline">«IA, crescono gli investimenti della Pubblica Amministrazione» — dati Osservatorio Mezzogiorno</div>
      <div class="press-date">7 Luglio 2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('<?php echo get_template_directory_uri(); ?>/stampa/gazzetta-di-parma-2025-07-22-pag7.pdf','_blank')">
      <div class="press-outlet">Gazzetta di Parma · PDF &#8599;</div>
      <div class="press-headline">«L'AI aiuta e semplifica il lavoro nei cantieri» — Convegno Cervelli Digitali, Spazi Reali: Andrea Troisi tra i relatori</div>
      <div class="press-date">22 Luglio 2025 · Pagina 7</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://risparmio.tiscali.it/economia/articoli/ia-crescono-investimenti-pubblica-amministrazione-00001/','_blank')">
      <div class="press-outlet">Tiscali Risparmio &#8599;</div>
      <div class="press-headline">«IA, crescono gli investimenti della Pubblica Amministrazione» — dati Osservatorio</div>
      <div class="press-date">2025</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.antennasud.com','_blank')">
      <div class="press-outlet">Antenna Sud &#8599;</div>
      <div class="press-headline">Intervista televisiva ad Andrea Troisi su ricerca, statistica e innovazione nel Mezzogiorno</div>
      <div class="press-date">2024</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.rainews.it/tgr/puglia/video/2023/05/centri-di-ricerca-imprese-business-troisi-bari-puglia-che-va-22e2cb36-95fd-46a4-a8d5-8d7c452d5be6.html','_blank')">
      <div class="press-outlet">TGR Puglia — RAI &#8599;</div>
      <div class="press-headline">Intervista a Andrea Troisi su ricerca, impresa e sviluppo nel Sud Italia — Rubrica «Puglia che va»</div>
      <div class="press-date">Maggio 2023</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://roma.repubblica.it/dossier-adv/eccellenze-lazio/2021/11/15/news/troisi_ricerche_i_dati_analizzarli_e_interpretarli_per_prendere_le_decisioni-326423272/','_blank')">
      <div class="press-outlet">la Repubblica &#8599;</div>
      <div class="press-headline">«Troisi Ricerche: i dati, analizzarli e interpretarli per prendere le decisioni» — Speciale Eccellenze Lazio</div>
      <div class="press-date">15 Novembre 2021</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('<?php echo get_template_directory_uri(); ?>/img/sole24ore-articolo-2021.jpg','_blank')">
      <div class="press-outlet">Il Sole 24 Ore &#8599;</div>
      <div class="press-headline">«Ricerche di mercato con mission sviluppo» — Troisi Ricerche come punto di riferimento per imprese e PA</div>
      <div class="press-date">12 Novembre 2021</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('<?php echo get_template_directory_uri(); ?>/img/mattino-padova-articolo-2018.jpg','_blank')">
      <div class="press-outlet">Il Mattino di Padova &#8599;</div>
      <div class="press-headline">«Casa, meccanica e Ict: un'unica filiera per l'innovazione» — Padova Innovation Hub, Troisi Ricerche partner</div>
      <div class="press-date">12 Novembre 2018</div>
    </div>
    <div class="press-card fade-in" style="cursor:pointer" onclick="window.open('https://www.radionotizie.eu/author/andrea-troisi/','_blank')">
      <div class="press-outlet">Radio Notizie &#8599;</div>
      <div class="press-headline">187 articoli su economia, lavoro, turismo, innovazione e Mezzogiorno d'Italia</div>
      <div class="press-date">Dal 2018 — in corso</div>
    </div>
  </div>
</section>

<!-- ═══════════════════ CONTATTI ═══════════════════ -->
<section class="at-contact" id="contact">
  <div class="contact-left fade-in">
    <div class="section-label"><span>Contatti</span></div>
    <h2 class="section-title">Prenota<br>un <em>incontro</em></h2>
    <br>
    <p class="contact-desc">Sei un giornalista, un'istituzione, un'impresa o semplicemente vuoi scambiare idee sul futuro del Sud? Scegli direttamente un orario nel calendario qui a fianco.</p>
    <div class="contact-links">
      <a class="contact-link-item" href="https://www.linkedin.com/in/andreatroisi" target="_blank" rel="noopener">
        <span class="contact-link-icon">in</span>
        <span>LinkedIn — Andrea Troisi ↗</span>
      </a>
      <a class="contact-link-item" href="https://www.linkedin.com/company/troisi-ricerche/" target="_blank" rel="noopener">
        <span class="contact-link-icon">in</span>
        <span>LinkedIn — Troisi Ricerche ↗</span>
      </a>
      <a class="contact-link-item" href="https://www.facebook.com/troisiricerche" target="_blank" rel="noopener">
        <span class="contact-link-icon">f</span>
        <span>Facebook — Troisi Ricerche ↗</span>
      </a>
      <a class="contact-link-item" href="https://www.youtube.com/@troisiricerche" target="_blank" rel="noopener">
        <span class="contact-link-icon">▶</span>
        <span>YouTube — Troisi Ricerche ↗</span>
      </a>
      <a class="contact-link-item" href="https://www.troisiricerche.net" target="_blank" rel="noopener">
        <span class="contact-link-icon">🔬</span>
        <span>Troisi Ricerche ↗</span>
      </a>
      <a class="contact-link-item" href="https://www.osservatoriomezzogiorno.net" target="_blank" rel="noopener">
        <span class="contact-link-icon">🌐</span>
        <span>Osservatorio Mezzogiorno ↗</span>
      </a>
      <a class="contact-link-item" href="mailto:info@andreatroisi.it">
        <span class="contact-link-icon">✉</span>
        <span>info@andreatroisi.it</span>
      </a>
      <a class="contact-link-item" href="mailto:andrea.troisi@uniba.it">
        <span class="contact-link-icon">🎓</span>
        <span>andrea.troisi@uniba.it — Università di Bari</span>
      </a>
    </div>
    <a href="https://calendly.com/andreatroisi/30min" target="_blank" rel="noopener" class="btn-primary">📅 Prenota 30 minuti</a>
  </div>
  <div class="contact-right fade-in">
    <div class="calendly-wrap">
      <div class="calendly-inline-widget"
        data-url="https://calendly.com/andreatroisi"
        style="min-width:320px;height:500px;">
      </div>
      <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
    </div>
  </div>
</section>

<?php get_template_part( 'parts/footer-site' ); ?>

<script>
/* ── NAVIGAZIONE scroll ── */
window.addEventListener('scroll', function(){
  document.getElementById('at-nav').classList.toggle('scrolled', window.scrollY > 50);
});
document.getElementById('nav-hamburger').addEventListener('click', function(){
  document.getElementById('nav-links').classList.toggle('open');
});
document.querySelectorAll('.nav-links a').forEach(function(a){
  a.addEventListener('click', function(){
    document.getElementById('nav-links').classList.remove('open');
  });
});

/* ── SLIDESHOW ── */
var slides = document.querySelectorAll('.slide');
var curSlide = 0;
var dotsWrap = document.getElementById('slide-dots');
if(dotsWrap) {
  document.getElementById('slide-tot').textContent = slides.length;
  slides.forEach(function(_, i){
    var d = document.createElement('div');
    d.className = 'slide-dot' + (i===0?' active':'');
    d.onclick = function(){ goSlide(i); };
    dotsWrap.appendChild(d);
  });
}
function goSlide(n){
  if(!slides.length) return;
  slides[curSlide].classList.remove('active');
  dotsWrap.children[curSlide].classList.remove('active');
  curSlide = (n + slides.length) % slides.length;
  slides[curSlide].classList.add('active');
  dotsWrap.children[curSlide].classList.add('active');
  document.getElementById('slide-cur').textContent = curSlide + 1;
}
function slideNext(){ goSlide(curSlide + 1); }
function slidePrev(){ goSlide(curSlide - 1); }
if(slides.length) setInterval(function(){ goSlide(curSlide + 1); }, 5000);

/* ── VIDEO — ora statici, nessun caricamento RSS necessario ── */

/* ── FADE IN su scroll ── */
var fadeEls = document.querySelectorAll('.fade-in');
var observer = new IntersectionObserver(function(entries){
  entries.forEach(function(e){
    if (e.isIntersecting){ e.target.classList.add('visible'); observer.unobserve(e.target); }
  });
}, { threshold:0.1, rootMargin:'0px 0px -40px 0px' });
fadeEls.forEach(function(el){ observer.observe(el); });

/* SPEAKING MODAL */
var EVENTS = {
  "senato-2026":{y:"15 Giugno 2026",t:"Senato della Repubblica — Presentazione del libro «Le organizzazioni che si misurano. Il benessere organizzativo dalla compliance alla consapevolezza»",w:"Palazzo Madama · Sala Caduti di Nassirya, Roma · Modera Renato Piccoli (giornalista Rai) · Intervengono la prof.ssa Amelia Manuti, Nicola Armenise e la dott.ssa Ilaria Agosta (vicepresidente AIDP) · Andrea Troisi presenta l'Osservatorio Nazionale sul Benessere Organizzativo nelle Partecipate, da lui promosso — il primo in Italia sulle società partecipate — con l'IBO Score e l'Oscar del Benessere Organizzativo",m:[
    {type:"img",src:"TPLURI/senato-2026-podio.webp",cap:"Andrea Troisi al Senato della Repubblica · Palazzo Madama, Sala Caduti di Nassirya · 15 giugno 2026"},
    {type:"img",src:"TPLURI/senato-2026-panel.webp",cap:"Il tavolo dei relatori · Presentazione di «Le organizzazioni che si misurano» · Senato, 15 giugno 2026"},
    {type:"img",src:"TPLURI/senato-2026-senatotv.webp",cap:"La conferenza stampa trasmessa da Senato TV · Roma, 15 giugno 2026"},
    {type:"img",src:"TPLURI/senato-2026-locandina.webp",cap:"Locandina ufficiale del Senato della Repubblica · Lunedì 15 giugno 2026, ore 9"},
    {type:"link",href:"https://www.lospecialegiornale.it/2026/06/15/presentato-al-senato-il-primo-osservatorio-in-italia-sul-benessere-organizzativo-delle-societa-partecipate/",icon:"N",label:"Lo Speciale — Presentato al Senato il primo Osservatorio in Italia sul benessere organizzativo delle società partecipate"},
    {type:"link",href:"https://www.takethedate.it/Eventi/54392-conferenza-stampa-presentazione-del-libro-le-organizzazioni-che-si-misurano.html",icon:"L",label:"Take The Date — scheda dell'evento al Senato"}
  ]},
  "forum-pubblici-ufficiali-2026":{y:"17 Aprile 2026",t:"Forum Pubblici Ufficiali — III Edizione",w:"Bari · Prof. Andrea Troisi · Università degli Studi di Bari Aldo Moro · DIRIUM · Intervento tecnico-metodologico su «Strumenti e questionari per misurare la Customer Satisfaction nella PA»",m:[
    {type:"img",src:"TPLURI/forum-fpu-2026-platea.webp",cap:"Andrea Troisi al podio — III Forum dei Pubblici Ufficiali · Bari, 17 aprile 2026 · Sala piena"},
    {type:"img",src:"TPLURI/forum-fpu-2026-likert.webp",cap:"La scala Likert — intervento metodologico di Andrea Troisi · III Forum Pubblici Ufficiali 2026"},
    {type:"img",src:"TPLURI/forum-2026-g.webp",cap:"Focus sulle tipologie di questionario · Intervento di Andrea Troisi"}
  ]},
  "opentusk-2026":{y:"12 Maggio 2026",t:"Road to Hackathon — Opentusk 2026",w:"Webinar gratuito online · «Open Data per generare valore sostenibile per il territorio» · Organizzato da Regione Puglia — InnovaPuglia SpA — PwC · Speaker: Andrea Troisi (Fondatore e Amministratore Troisi Ricerche S.r.l.) e Carlo Rossi Chauvenet (Chief Legal Officer, Data Valley Consulting)",m:[
    {type:"img",src:"TPLURI/opentusk-2026-locandina.webp",cap:"Locandina ufficiale Road to Hackathon Opentusk 2026 · Andrea Troisi speaker · 12 Maggio 2026"}
  ]},
  "edu-exhibition-2025":{y:"10 Dicembre 2025",t:"EDU Exhibition 2ª ed. — Tra bit e qubit: l'IA entra in classe",w:"Villa De Grecis, Bari · Modera l'incontro: Prof. Andrea Troisi",m:[
    {type:"img",src:"TPLURI/edu-exhibition-locandina-new.webp",cap:"Locandina ufficiale EDU Exhibition 2025 — Andrea Troisi moderatore"},
    {type:"img",src:"TPLURI/edu-exhibition-foto.webp",cap:"Andrea Troisi moderatore — EDU Exhibition 2025 · Villa De Grecis, Bari"}
  ]},
  "cibari-2025":{y:"Ottobre 2025",t:"CiBari 2025 — Il Cibo della Salute",w:"Piazza del Ferrarese · Bari · Membro Comitato Tecnico-Scientifico",m:[
    {type:"img",src:"TPLURI/cibari-2025-new-1.webp",cap:"CiBari 2025 · Andrea Troisi presenta i dati della ricerca"},
    {type:"img",src:"TPLURI/cibari-2025-new-2.webp",cap:"Foto di gruppo CiBari 2025 · Conferenza stampa Bari"},
    {type:"img",src:"TPLURI/cibari-2025-new-3.webp",cap:"CiBari 2025 · Comitato Tecnico-Scientifico"},
    {type:"img",src:"TPLURI/cibari-2025-new-4.webp",cap:"CiBari 2025 · Relatori al tavolo"},
    {type:"link",href:"https://www.youtube.com/watch?v=7FlwW_9RKI0",icon:"TV",label:"Video CiBari 2025 su YouTube"}
  ]},
  "scriba-lancio-2024":{y:"Dicembre 2024",t:"Lancio Scriba — L'Archivio Digitale in un Click",w:"Bari · Relatore al lancio ufficiale della piattaforma Scriba",m:[
    {type:"img",src:"TPLURI/scriba-evento.jpg",cap:"Andrea Troisi relatore al lancio di Scriba — archivio digitale"}
  ]},
  "parliamone-2025":{y:"21 Novembre 2025",t:"parlIAmone — AI & Compliance",w:"Domus Libraria Cacucci · Bari · Prof. Andrea Troisi: Direttore Generale Osservatorio",m:[
    {type:"img",src:"TPLURI/parliamone-locandina-new.webp",cap:"Locandina ufficiale parlIAmone — AI & Compliance, modelli, rischi e opportunità"}
  ]},
  "fondimpresa-roma-2025":{y:"Novembre 2025",t:"Fondimpresa — Nuove Corsie per il Lavoro",w:"Corsie Sistine · Santo Spirito in Sassia, Roma",m:[
    {type:"img",src:"TPLURI/fondimpresa-roma.jpg",cap:"Corsie Sistine di Santo Spirito in Sassia · Roma 2025"},
    {type:"link",href:"https://www.corrieredelleconomia.it/2025/07/31/osservatorio-sullinnovazione-nel-mezzogiorno-strategie-e-orizzonti-per-governare-lai-nella-pubblica-amministrazione/",icon:"N",label:"Corriere dell'Economia"}
  ]},
  "canone-giusto-2025":{y:"Ottobre 2025",t:"Presentazione Canone Giusto",w:"Palazzo della Città, Bari",m:[
    {type:"img",src:"TPLURI/canone-giusto-new-1.webp",cap:"Andrea Troisi presenta Canone Giusto · Palazzo della Città, Bari"},
    {type:"img",src:"TPLURI/canone-giusto-new-2.webp",cap:"Conferenza stampa Canone Giusto · Sala Giunta · Bari"},
    {type:"img",src:"TPLURI/canone-giusto-new-3.webp",cap:"Il team Canone Giusto · Palazzo della Città, Bari"},
    {type:"link",href:"https://www.baritoday.it/economia/bari-attiva-portale-canone-giusto-procedure-chiare-calcolo-affitti.html",icon:"N",label:"BariToday — attivo il portale Canone Giusto"}
  ]},
  "forum-pubblici-ufficiali-2025":{y:"4 Aprile 2025",t:"Forum Pubblici Ufficiali — II Edizione",w:"Bari · Relatore e ospite d'onore sul palco principale",m:[
    {type:"img",src:"TPLURI/forum-2025-1.webp",cap:"Forum Pubblici Ufficiali 2025 · Platea gremita · Bari"},
    {type:"img",src:"TPLURI/forum-2025-2.webp",cap:"Andrea Troisi relatore al Forum Pubblici Ufficiali · Bari 2025"},
    {type:"img",src:"TPLURI/forum-2025-3.webp",cap:"Andrea Troisi sul palco · Forum Pubblici Ufficiali 2025"}
  ]},
  "smartcity-poliba-2025":{y:"Ottobre 2025",t:"Smart City — Governance, Competenze e Risorse",w:"Politecnico di Bari · Con Fondimpresa e Osservatorio Mezzogiorno",m:[
    {type:"link",href:"https://www.youtube.com/watch?v=SmIAaspOyvI",icon:"TV",label:"Video Smart City 2025 su YouTube"},
    {type:"link",href:"https://www.ilmessaggero.it/italia/quel_sogno_chiamato_smart_city_pnrr_convegno_bari_innovazione_mezzogiorno-9114869.html",icon:"N",label:"Il Messaggero — Quel sogno chiamato Smart City"},
    {type:"link",href:"https://www.corrieredelleconomia.it/2025/10/13/osservatorio-sullinnovazione-del-mezzogiorno-smart-city-la-sfida-e-nelle-competenze/",icon:"N",label:"Corriere dell'Economia — Smart City e competenze"},
    {type:"link",href:"https://www.ilgiardinodellacultura.com/2025/10/14/smart-city-italia-mezzogiorno-competenze-pnrr/",icon:"N",label:"Il Giardino della Cultura — Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro"},
    {type:"link",href:"https://www.bitmat.it/vertical/smart-home-city/smart-city-10-miliardi-dal-pnrr-ma-il-sud-resta-indietro/",icon:"N",label:"BitMAT — Smart City: 10 miliardi dal PNRR, ma il Sud resta indietro"},
    {type:"link",href:"https://www.milanofinanza.it/news/quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-troppo-indietro-202510081638248255",icon:"N",label:"MF Milano Finanza — Quel sogno chiamato smart city, ma il Sud è ancora troppo indietro"},
    {type:"link",href:"https://www.adriaeco.eu/2025/10/08/il-sogno-delle-smart-city-stanziati-10-miliardi-ma-mancano-le-competenze-ed-il-sud-resta-indietro/",icon:"N",label:"Adriaeco — Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro"},
    {type:"link",href:"https://www.businessgentlemen.it/2025/10/il-sogno-delle-smart-city-stanziati-10-miliardi-ma-mancano-le-competenze-ed-il-sud-resta-indietro/",icon:"N",label:"Business & Gentlemen — Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro"},
    {type:"link",href:"https://www.oggiquotidiano.it/economia/102543-quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-troppo-indietro/",icon:"N",label:"Oggi Quotidiano — Quel sogno chiamato Smart City ma il Sud è ancora troppo indietro"},
    {type:"link",href:"https://www.inpressmagazine.com/quel-sogno-chiamato-smart-city-ma-il-sud-e-ancora-indietro/",icon:"N",label:"INpressMAGAZINE — Quel sogno chiamato Smart City ma il Sud è ancora indietro"},
    {type:"link",href:"https://www.anordest.it/il-sogno-delle-smart-city-e-la-sfida-delle-competenze/",icon:"N",label:"@Nordest — Il sogno delle Smart City e la sfida delle competenze"},
    {type:"link",href:"https://www.comunicatistampa.net/smart-city-mancanza-competenze-sud-indietro/",icon:"N",label:"ComunicatiStampa.net — Il sogno delle Smart City: stanziati 10 miliardi, ma mancano le competenze ed il Sud resta indietro"}
  ]},
  "fondimpresa-petruzzelli-2024":{y:"Febbraio 2024",t:"Fondimpresa — Fondi Interprofessionali e Competenze",w:"Foyer Teatro Petruzzelli, Bari · Con Antonio Decaro, Pina Picierno, prof. Corrado Crocetta",m:[
    {type:"img",src:"TPLURI/mappatura-competenze-poster.webp",cap:"Locandina — Mappatura delle Competenze e uso dei Fondi Interprofessionali · Teatro Petruzzelli, Bari"},
    {type:"img",src:"TPLURI/petruzzelli-2024.webp",cap:"Andrea Troisi al Foyer del Teatro Petruzzelli · Fondimpresa · Febbraio 2024"}
  ]},
  "smartcity-poliba-2024":{y:"2024",t:"Smart City al Politecnico di Bari",w:"Governance, competenze e risorse per le città del Sud",m:[
    {type:"link",href:"https://norbaonline.it/2025/10/03/citta-smart-levento-promosso-dal-politecnico-di-bari/",icon:"TV",label:"Norba Online — Smart City Politecnico"}
  ]},
  "cibari-2024":{y:"Ottobre 2024",t:"CiBari 2024 — Il Cibo della Salute",w:"Bari · Membro Comitato Tecnico-Scientifico · 2ª edizione",m:[
    {type:"img",src:"TPLURI/cibari-2024-a.webp",cap:"CiBari 2024 — sessione scientifica, sala affrescata, Bari"},
    {type:"img",src:"TPLURI/cibari-2024-b.webp",cap:"Foto di gruppo CiBari 2024 — con Andrea Troisi"}
  ]},
  "cervelli-digitali-2024":{y:"Luglio 2024",t:"Cervelli Digitali e Spazi Reali — Parma",w:"Palazzo Soragna · Parma · 1° Convegno Nazionale AI-Competenze con Fondimpresa",m:[
    {type:"img",src:"TPLURI/fondimpresa-roma.jpg",cap:"Delegazione Osservatorio al convegno di Parma"},
    {type:"link",href:"https://www.corrieredelleconomia.it/2025/07/31/osservatorio-sullinnovazione-nel-mezzogiorno-strategie-e-orizzonti-per-governare-lai-nella-pubblica-amministrazione/",icon:"N",label:"Corriere dell'Economia — dopo Parma"}
  ]},
  "sis-2024":{y:"Giugno 2024",t:"SIS 2024 — Scientific Meeting of the Italian Statistical Society",w:"Università degli Studi di Bari",m:[
    {type:"link",href:"https://www.youtube.com/watch?v=SAwy3KA3wgk",icon:"TV",label:"Video SIS 2024 su YouTube"},
    {type:"link",href:"https://www.sis-statistica.it/",icon:"R",label:"SIS — Societa Italiana di Statistica"}
  ]},
  "aiquav-2023":{y:"21 Settembre 2023",t:"Conferenza Internazionale AIQUAV — Food Policy e Benessere",w:"Hotel Excelsior, Bari · Con Pina Picierno (VP Parlamento Europeo) e Assessore Paola Romano",m:[
    {type:"img",src:"TPLURI/aiquav-2023-locandina.webp",cap:"Locandina AIQUAV 2023 — Andrea Troisi tra i relatori con Pina Picierno"},
    {type:"link",href:"https://www.youtube.com/watch?v=zB1iZVjzK5k",icon:"TV",label:"Video AIQUAV 2023 su YouTube"},
    {type:"link",href:"https://aiquav.it/",icon:"R",label:"AIQUAV — Associazione Italiana Qualita della Vita"}
  ]},
  "assoradio-fiera-2024":{y:"1 Ottobre 2024",t:"Assoradio — Indagine sulle abitudini di ascolto delle radio in Puglia",w:"Fiera del Levante, Pad. 152 Sala 3, Bari · Conferenza stampa risultati dell'indagine · Troisi Ricerche",m:[
    {type:"img",src:"TPLURI/assoradio-new-1.webp",cap:"Andrea Troisi presenta i dati sull'ascolto radiofonico in Puglia · Fiera del Levante 2024"},
    {type:"img",src:"TPLURI/assoradio-new-2.webp",cap:"Conferenza stampa Assoradio · Fiera del Levante, Bari · 1 ottobre 2024"}
  ]},
  "startup-italia-2022":{y:"2022",t:"StartupItalia #Italia2022",w:"Andrea Troisi selezionato tra i protagonisti di #Italia2022 da StartupItalia",m:[
    {type:"img",src:"TPLURI/startup-italia-2022.jpg",cap:"Andrea Troisi — StartupItalia #Italia2022"}
  ]},
  "osservatorio-report-2023":{y:"2023",t:"Osservatorio Mezzogiorno — Presentazione Rapporto Annuale",w:"Bari · Risultati dell'indagine territoriale annuale",m:[
    {type:"link",href:"https://www.osservatoriomezzogiorno.net",icon:"L",label:"Osservatorio Innovazione Mezzogiorno"}
  ]},
  "camera-2019":{y:"29 Marzo 2019",t:"Camera dei Deputati — Presentazione del libro sulla Customer Satisfaction nella P.A.",w:"Roma · Conferenza stampa ufficiale · Andrea Troisi presenta il volume Cacucci Editore «Un modello statistico per l'analisi della Customer Satisfaction nella Pubblica Amministrazione» · Trasmessa in diretta su webtv.camera.it, disponibile nell'archivio parlamentare",m:[
    {type:"img",src:"TPLURI/camera-2019-conferenza.webp",cap:"Andrea Troisi presenta il volume · Camera dei Deputati, Roma · 29 marzo 2019"},
    {type:"img",src:"TPLURI/camera-deputati-new.webp",cap:"Andrea Troisi alla Camera dei Deputati · Roma · 29 marzo 2019"},
    {type:"img",src:"TPLURI/camera-2019-webtv.webp",cap:"La conferenza stampa nell'archivio di webtv.camera.it · «Presentazione libro Customer satisfaction nella P.A.»"},
    {type:"link",href:"https://webtv.camera.it/evento/14114",icon:"TV",label:"Video completo della conferenza stampa su webtv.camera.it"},
    {type:"link",href:"https://www.troisiricerche.net/media/",icon:"L",label:"Troisi Ricerche — Media: la presentazione alla Camera"}
  ]},
  "accademia-2021":{y:"2021",t:"Accademia Cittadella Nicolaiana",w:"Bari · Cultura, identità e sviluppo del Mezzogiorno · Con l'on. David Sassoli",m:[
    {type:"img",src:"TPLURI/sassoli-new-1.webp",cap:"Con David Sassoli · Accademia Cittadella Nicolaiana · Bari"},
    {type:"img",src:"TPLURI/sassoli-new-2.webp",cap:"Consegna targa con l'on. David Sassoli · Accademia Cittadella Nicolaiana"},
    {type:"link",href:"https://accademiacittadellanicolaiana.it/",icon:"L",label:"Accademia Cittadella Nicolaiana"}
  ]}
};

var ICON_MAP = {N:"&#x1F4F0;",TV:"&#x1F4FA;",R:"&#x1F52C;",L:"&#x1F517;"};

function openSpeakingModal(id) {
  var ev = EVENTS[id]; if (!ev) return;
  var tplUri = document.querySelector('meta[name="template-uri"]') ?
    document.querySelector('meta[name="template-uri"]').content : '';
  document.getElementById('sm-year-text').textContent = ev.y;
  document.getElementById('sm-title-text').textContent = ev.t;
  document.getElementById('sm-where-text').textContent = ev.w;
  var wrap = document.getElementById('sm-media-content');
  wrap.innerHTML = '';
  if (!ev.m || !ev.m.length) {
    wrap.innerHTML = '<div class="sm-no-media">Nessun media disponibile per questo evento.</div>';
    return;
  }
  ev.m.forEach(function(m) {
    var el = document.createElement('div');
    if (m.type === 'img') {
      var src = m.src.replace('TPLURI', tplUri);
      el.innerHTML = '<img src="'+src+'" alt="'+(m.cap||'')+'" loading="lazy" onerror="this.closest(\'div\').style.display=\'none\'">'
        + (m.cap ? '<div class="sm-media-caption">'+m.cap+'</div>' : '');
    } else {
      var ico = ICON_MAP[m.icon] || '&#x1F517;';
      el.innerHTML = '<a href="'+m.href+'" target="_blank" rel="noopener" class="sm-link">'
        + '<span class="sm-link-icon">'+ico+'</span>'+m.label+' &#8599;</a>';
    }
    wrap.appendChild(el);
  });
  document.getElementById('speaking-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeSpeakingModal() {
  document.getElementById('speaking-modal').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeSpeakingModal(); });
document.addEventListener('DOMContentLoaded', function() {
  var m = document.getElementById('speaking-modal');
  if (m) m.addEventListener('click', function(e) { if (e.target === this) closeSpeakingModal(); });
});
</script>

<!-- SPEAKING MODAL -->
<div id="speaking-modal" role="dialog" aria-modal="true">
  <div class="sm-box">
    <button class="sm-close" onclick="closeSpeakingModal()" aria-label="Chiudi">&#x2715;</button>
    <div class="sm-year" id="sm-year-text"></div>
    <div class="sm-title" id="sm-title-text"></div>
    <div class="sm-where" id="sm-where-text"></div>
    <div class="sm-media" id="sm-media-content"></div>
  </div>
</div>

<?php get_footer(); ?>